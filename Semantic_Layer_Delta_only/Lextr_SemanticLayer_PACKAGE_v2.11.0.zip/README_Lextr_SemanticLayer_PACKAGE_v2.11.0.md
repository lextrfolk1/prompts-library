# Lextr Semantic Layer — Development Package

**Baseline:** manifest `v2.11.0+fable.1` (package `stable_v6`) · **Released:** 2026-08-26
**Scale:** 44 logic points · 165 sub-task lanes · 39 tables · 5 schemas · 577 columns

This package contains two things: the **full v2.11.0 release**, and an **incremental v2.3.0 → v2.11.0 set** for the team that already shipped v2.3.0.

---

## Start here

**If your team built against v2.3.0** — go to `02_DELTA/` and read `Lextr_SemanticLayer_DELTA_README_v2.3.0_to_v2.11.0.md`. Do not read the full manifest end to end; most of it is already implemented. The delta tells you exactly which 9 points to leave alone, which 12 to change, and which 23 to build.

**If you are new to the Semantic Layer** — open `01_FINAL/Lextr_SemanticLayer_Map_FINAL_v2.11.0.html` for the system overview, then `Lextr_SemanticLayer_RELEASE_NOTE_FINAL_v2.11.0.md`.

---

## 01_FINAL — the complete v2.11.0 release

| File | What it is |
|---|---|
| `Lextr_SemanticLayer_RELEASE_NOTE_FINAL_v2.11.0.md` | **README for the release.** Verification performed, what is committed vs proposed, known gaps. |
| `Lextr_SemanticLayer_Map_FINAL_v2.11.0.html` | **Best first look.** Dependency graph · build context · coverage & assessment · system map · flows · database (ER with click-to-detail). |
| `Lextr_SemanticLayer_Manifest_FINAL_v2.11.0.html` | Manifest viewer — every logic point, the changes diff, the consumer-traversal contract. |
| `Lextr_SemanticLayer_Manifest_FINAL_v2.11.0.json` | **Source of truth.** Drive automation from this. |
| `Lextr_SemanticLayer_Manifest_FINAL_v2.11.0.jsx` | Viewer source; embeds the JSON byte-for-byte. |
| `Lextr_SemanticLayer_Manifest_FINAL_v2.11.0.md` | Readable digest of all 44 points. |
| `Lextr_SemanticLayer_DDL_FINAL_v2.11.0.sql` | Full schema — V1 baseline + V3…V16 additive migrations. |
| `Lextr_SemanticLayer_UI_FINAL_v2.11.0.html` | Registration & catalog UI prototype (open directly). |
| `Lextr_SemanticLayer_UI_FINAL_v2.11.0.jsx` | UI source. |
| `Lextr_SemanticLayer_Catalog_FINAL_v2.11.0.jsx` | Estate catalog — **input to registration, not a runtime artifact.** |

## 02_DELTA — incremental v2.3.0 → v2.11.0

| File | What it is |
|---|---|
| `Lextr_SemanticLayer_DELTA_README_v2.3.0_to_v2.11.0.md` | **README for the delta.** Build order, the expensive change, what not to build. |
| `Lextr_SemanticLayer_DELTA_Manifest_v2.3.0_to_v2.11.0.html` | **Open this.** Six tabs: summary · unchanged · amended · new · database · do-not-build. |
| `..._DELTA_Manifest_....jsx` | Viewer source. |
| `..._DELTA_Manifest_....json` | Machine-readable — drive backlog or ticket import from this. |
| `..._DELTA_Manifest_....md` | The same content as text. |
| `..._DELTA_DDL_v2.3.0_to_v2.11.0.sql` | Migration script: 21 applyable tables + 27 columns. Additive only. |

---

## What changed, in one table

| | v2.3.0 | v2.11.0 | delta |
|---|---|---|---|
| Logic points | 21 | 44 | +23 new · 12 amended · 9 unchanged · **0 removed** |
| Sub-task lanes | 77 | 165 | +88 |
| Tables | 16 | 39 | +23 (21 applyable, 2 proposed) |
| `attribute_catalog` columns | — | — | +27 |
| Closed vocabularies (CHECK) | — | — | +24 |

---

## Verification performed on this package

- Manifest JSX embed is **byte-identical** to the JSON (both the final and the delta).
- Standalone DDL **contains the manifest's `ddl_body`** verbatim.
- All four HTML files **compile (esbuild exit 0) and mount** in a headless DOM; every tab renders real content.
- UI domain modes match the DDL's final CHECK exactly; zero live `YN_FLAG` references remain.
- Map reports the same baseline, point count and table count as the manifest.
- Delta coverage proven: every one of the 44 points is classified exactly once, and the delta DDL contains **every** new table and column with **nothing missing and nothing extra**.

---

## Status is not uniform — read before estimating

**PROPOSED, do not build:** LP-42 (logical hierarchies, migration V9) and LP-44 (attribute promotion, migration V16). Both are commented out in the DDL.

**Deferred / open, carried deliberately:**
- `POL-DM-001` (domain-resolve policy) is not yet authored — lands in the LP-14 OPA bundle.
- `meta.governance_event` is commented out; the LP-30 history-versus-audit decision is open.
- `meta.attribute_text` (attribute-name localization) is a recorded gap on LP-05.
- Report Store and Report Inventory exposure are blocked on Lextr Core.

**The UI is contract-*consistent*, not contract-*complete*.** It no longer contradicts the manifest — `YN_FLAG` is gone and booleans register as two-value `ENUM_LIST` with per-attribute polarity. But synonym authoring, the locale editor, the source-map screen, per-value AI exposure and version display have **no screens yet**, and domain values in the prototype are **mock** — production reads LP-43 `/semantic/resolve-domain`. The prototype also hardcodes its theme, with no configurable logo or client CSS hook; fix that before anything client-facing.

**The largest open item is in the estate, not the code.** The catalog carries **0 domain values across 1,425 attributes** against **753 CODE-role attributes**. Until each coded attribute declares a domain mode, phrase-to-code resolution cannot be grounded. That is the purpose of the separate bulk-registration workstream.

---

## A correction worth knowing about

An earlier draft of the release note listed `meta.data_classification_ref` as "named in the manifest but absent from the DDL". **That was wrong** — it is a real, live table created by the DDL and owned by LP-31, and LP-03 validates against it. The cause was a regex that matched a commented-out table declaration and swallowed the next table's block. Both the map and the delta have been regenerated; the two genuinely absent tables are `governance_event` (deferred) and `attribute_text` (recorded gap).

---

## Not in this package, current at the same baseline

`Lextr_Semantic_to_Intelligence_Integration_Contract` (md + docx) · `Lextr_SL_Response_to_Intelligence_DomainValues_ASK.md` · `Lextr_SL_to_Core_Requirements.md` · the four `Lextr_BulkRegistration_*` files · `Lextr_SemanticLayer_SME_Briefing.docx`.
