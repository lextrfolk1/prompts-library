// Lextr Semantic Layer — Registration & Catalog UI — FINAL v2.11.0
// Aligned to manifest v2.11.0+fable.1 (stable_v6) · 2026-08-23
// v6 changes: YN_FLAG removed (booleans are two-value ENUM_LIST with per-attribute polarity,
// v2.10.0 ASK 2a); domain mock upgraded to the governed shape (value_desc + ai_context +
// synonyms + lifecycle) matching meta.domain_value / domain_value_synonym.
// NOTE: still a PROTOTYPE — values below are mock; production reads LP-43 /semantic/resolve-domain.
import { useState, useMemo, useEffect, useRef, Fragment } from "react"

// ── API Client Stub ────────────────────────────────────────────────────────
// Replace with real fetch() calls to your FastAPI backend.
// All endpoints follow the pattern: POST /api/semantic-layer/{resource}
// Authentication: Bearer token via Authorization header (IAM-managed).
// Every mutating call creates a meta.workflow_task record (DRAFT→APPROVAL flow).
const api = {
  // Object registration
  saveRegistrationDraft:       (payload) => fetch('/api/semantic-layer/registrations/draft',        {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),
  submitRegistrationForApproval:(payload) => fetch('/api/semantic-layer/registrations/submit',       {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),
  // Attribute pairings
  savePairingDraft:            (payload) => fetch('/api/semantic-layer/pairings/draft',              {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),
  registerPairing:             (payload) => fetch('/api/semantic-layer/pairings',                    {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),
  // Relationships
  saveRelationshipDraft:       (payload) => fetch('/api/semantic-layer/relationships/draft',         {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),
  registerRelationship:        (payload) => fetch('/api/semantic-layer/relationships',               {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),
  // CDE tagging
  tagCde:                      (payload) => fetch('/api/semantic-layer/cde-tags',                    {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),
  // Workspaces
  createWorkspace:             (payload) => fetch('/api/semantic-layer/workspaces',                  {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),
  addObjectToWorkspace:        (payload) => fetch('/api/semantic-layer/workspaces/objects',          {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),
  removeObjectFromWorkspace:   (payload) => fetch(`/api/semantic-layer/workspaces/${payload.workspaceId}/objects/${encodeURIComponent(payload.objectKey)}`, {method:'DELETE'}),
  // Logical name overrides
  submitLogicalNameOverride:   (payload) => fetch('/api/semantic-layer/logical-name-overrides',     {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),
  approveLogicalNameOverride:  (payload) => fetch(`/api/semantic-layer/logical-name-overrides/${payload.id}/approve`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),
  // Query Studio
  executeQuery:                (payload) => fetch('/api/semantic-layer/query/execute',               {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}),
  // Introspection (DB column discovery)
  introspectObject:            (schema, obj) => fetch(`/api/semantic-layer/introspect/${schema}/${obj}`),
}


import {
  LayoutDashboard, Layers, Link2, Plus, Play, GitBranch, CheckSquare,
  Search, Database, Tag, AlignLeft, List, TreePine, Network, BookOpen,
  ChevronRight, Check, Clock, ArrowRight, Eye, RefreshCw, Edit2, Zap,
  Table2, Columns, Globe, User, Calendar, Activity, Info, AlertTriangle,
  Settings, Filter, BarChart2, Shield, Download, History
} from "lucide-react"

// ══════════════════════════════════════════════════════════════════════
// LEXTR DESIGN TOKENS — aligned to LHP governance theme
// ══════════════════════════════════════════════════════════════════════
const L = {
  // Brand
  teal:'#1D9E75', tealBg:'#e8f6f0', tealDk:'#0a5a3a',
  blue:'#2265B8', blueBg:'#e4eef9', blueDk:'#153d7a',
  amb:'#B87414',  ambBg:'#faeeda',  ambDk:'#633806',
  cor:'#b83830',  corBg:'#fceee8',  corDk:'#782010',
  pur:'#6657CC',  purBg:'#eeedfe',  purDk:'#3d2fa0',
  grn:'#2d6a10',  grnBg:'#e5f3db',
  // Neutrals (LHP governance palette)
  nv:'#0e1e35',       // navy sidebar
  nvMid:'#152844',    // sidebar hover
  t1:'#0e1e35', t2:'#1e3a5f', t3:'#4a6fa5', t4:'#7a9cc8',
  s1:'#ffffff', s2:'#f6f9fc', s3:'#eef3fa', s4:'#e4eef9',
  bd:'#c8d9ee', bd2:'#ddeaf8',
  // Sidebar accent
  accent:'#1D9E75',
  font:"'IBM Plex Sans',system-ui,sans-serif",
  mono:"'IBM Plex Mono',monospace",
}

// ══════════════════════════════════════════════════════════════════════
// MOCK DATA CATALOG — the authoritative store UI reads from
// ══════════════════════════════════════════════════════════════════════
const CATALOG = {
  'core.gl_balance': {
    connectionId:'lextr-pg', logicalShortNm:'GL Balance', logicalLongNm:'General Ledger Balance Position',
    schema:'core', obj:'gl_balance', type:'TABLE',
    grain:'One row per legal-entity, account, currency, and fiscal period',
    desc:'General Ledger balance positions used as the primary source for all Y-9C HC schedule computations and variance attribution pipelines.',
    st:'ACTIVE', aiTier:'ALLOWED', rows:'~420M', updated:'2026-05-20', owner:'m.johnson',
    // Object-level operational profile
    opProfile:{
      insertModes:['ETL_BATCH','API'],
      updateModes:['ETL_BATCH'],
      deleteModes:['SOFT_DELETE'],
      srcSystems:['ACBS','CORE_BANKING'],
      etlFrequency:'Daily — 02:00 UTC',
      latencyP99:'< 4 hrs from source close',
      retentionPolicy:'7 years regulatory minimum',
    },
    attrs: [
      // ── Business attributes ──────────────────────────────────────────────
      {cd:'gl_balance_id',    ln:'GL Balance ID',        type:'bigint',       semantic:'IDENTIFIER',pk:true, indexed:true, nullable:false,domain:null,         cde:'CDE',cdeSource:'ORGANIC',  desc:'Surrogate primary key',
       op:false, insMode:'ETL_BATCH',  updMode:'IMMUTABLE',    delMode:'N/A',       srcSystem:'ACBS',         nullOnIns:false, immutable:true,  createdBy:'etl_svc',    updatedBy:null,         createdTs:'on insert',      updatedTs:null,         notes:'Generated by sequence at ETL load. Never updated.'},
      {cd:'legal_entity_cd',  ln:'Legal Entity',         type:'varchar(20)',  semantic:'CODE',      pk:false,indexed:true, nullable:false,domain:'ORG_ENTITY',  cde:'CDE',cdeSource:'ORGANIC',  desc:'Legal entity code — FK to ref.organization_hierarchy',
       op:false, insMode:'ETL_BATCH',  updMode:'ETL_BATCH',    delMode:'N/A',       srcSystem:'CORE_BANKING', nullOnIns:false, immutable:false, createdBy:'etl_svc',    updatedBy:'etl_svc',    createdTs:'on insert',      updatedTs:'on rebook',  notes:'Updates only on trade rebook or entity restructure.'},
      {cd:'account_cd',       ln:'Account Code',         type:'varchar(30)',  semantic:'CODE',      pk:false,indexed:true, nullable:false,domain:'GL_ACCOUNT',  cde:'CDE',cdeSource:'ORGANIC',  desc:'Chart of accounts code',
       op:false, insMode:'ETL_BATCH',  updMode:'IMMUTABLE',    delMode:'N/A',       srcSystem:'CORE_BANKING', nullOnIns:false, immutable:true,  createdBy:'etl_svc',    updatedBy:null,         createdTs:'on insert',      updatedTs:null,         notes:'Account assignment is immutable after posting.'},
      {cd:'account_desc_txt', ln:'Account Description',  type:'varchar(200)', semantic:'DIMENSION', pk:false,indexed:false,nullable:true, domain:null,         cde:'DE', cdeSource:'HUMAN',   desc:'Human-readable account description (display attribute)',
       op:false, insMode:'ETL_BATCH',  updMode:'ETL_BATCH',    delMode:'N/A',       srcSystem:'CORE_BANKING', nullOnIns:true,  immutable:false, createdBy:'etl_svc',    updatedBy:'etl_svc',    createdTs:'on insert',      updatedTs:'on COA update',notes:'COA description synced nightly from source.'},
      {cd:'currency_cd',      ln:'Currency',             type:'char(3)',      semantic:'CODE',      pk:false,indexed:true, nullable:false,domain:'ISO_CURRENCY',cde:'CDE',cdeSource:'ORGANIC',  desc:'ISO 4217 currency code',
       op:false, insMode:'ETL_BATCH',  updMode:'IMMUTABLE',    delMode:'N/A',       srcSystem:'ACBS',         nullOnIns:false, immutable:true,  createdBy:'etl_svc',    updatedBy:null,         createdTs:'on insert',      updatedTs:null,         notes:'ISO 4217. Immutable after booking.'},
      {cd:'period_cd',        ln:'Fiscal Period',        type:'varchar(10)',  semantic:'DATE',      pk:false,indexed:true, nullable:false,domain:'FISCAL_PERIOD',cde:'CDE',cdeSource:'ORGANIC', desc:'Fiscal period key (YYYY-Qn or YYYY-MM)',
       op:false, insMode:'ETL_BATCH',  updMode:'IMMUTABLE',    delMode:'N/A',       srcSystem:'ACBS',         nullOnIns:false, immutable:true,  createdBy:'etl_svc',    updatedBy:null,         createdTs:'on insert',      updatedTs:null,         notes:'Period key frozen at time of posting.'},
      {cd:'balance_amt',      ln:'Balance Amount',       type:'numeric(22,4)',semantic:'MEASURE',   pk:false,indexed:false,nullable:false,domain:null,         cde:'CDE',cdeSource:'ORGANIC',  desc:'Ledger balance in functional currency',
       op:false, insMode:'ETL_BATCH',  updMode:'ETL_BATCH',    delMode:'N/A',       srcSystem:'CORE_BANKING', nullOnIns:false, immutable:false, createdBy:'etl_svc',    updatedBy:'etl_svc',    createdTs:'on insert',      updatedTs:'daily recalc',notes:'Recalculated each processing cycle. Superseded rows soft-deleted.'},
      {cd:'is_regulatory_flg',ln:'Regulatory Flag',     type:'boolean',      semantic:'DIMENSION', pk:false,indexed:true, nullable:false,domain:null,         cde:'CDE',cdeSource:'ORGANIC',  desc:'True if this balance feeds a regulatory schedule',
       op:false, insMode:'ETL_BATCH',  updMode:'API',          delMode:'N/A',       srcSystem:'RULES_ENGINE', nullOnIns:false, immutable:false, createdBy:'etl_svc',    updatedBy:'rules_svc',  createdTs:'on insert',      updatedTs:'on rule eval',notes:'Set by rules engine at batch close. Can be overridden via API with governance approval.'},
      // ── Operational / governance columns ────────────────────────────────
      {cd:'source_system_cd', ln:'Source System',        type:'varchar(20)',  semantic:'CODE',      pk:false,indexed:true, nullable:false,domain:null,         cde:null, cdeSource:null,      desc:'Source system identifier (lineage)',
       op:true,  insMode:'ETL_BATCH',  updMode:'IMMUTABLE',    delMode:'N/A',       srcSystem:'ETL_FRAMEWORK',nullOnIns:false, immutable:true,  createdBy:'etl_svc',    updatedBy:null,         createdTs:'on insert',      updatedTs:null,         notes:'ETL lineage tag. Never changes after insert.'},
      {cd:'created_ts',       ln:'Created Timestamp',    type:'timestamptz', semantic:null,        pk:false,indexed:false,nullable:false,domain:null,         cde:null, cdeSource:null,      desc:'Row creation timestamp (governance)',
       op:true,  insMode:'ETL_BATCH',  updMode:'IMMUTABLE',    delMode:'N/A',       srcSystem:'POSTGRES',     nullOnIns:false, immutable:true,  createdBy:'DB_DEFAULT', updatedBy:null,         createdTs:'now()',           updatedTs:null,         notes:'Set by DEFAULT now() on INSERT. Cannot be updated.'},
      {cd:'created_by',       ln:'Created By',           type:'varchar(100)',semantic:null,        pk:false,indexed:false,nullable:false,domain:null,         cde:null, cdeSource:null,      desc:'Created by user or service account (governance)',
       op:true,  insMode:'ETL_BATCH',  updMode:'IMMUTABLE',    delMode:'N/A',       srcSystem:'POSTGRES',     nullOnIns:false, immutable:true,  createdBy:'DB_DEFAULT', updatedBy:null,         createdTs:'current_user',   updatedTs:null,         notes:'Set by DEFAULT current_user. ETL sets via SET LOCAL.'},
      {cd:'updated_ts',       ln:'Updated Timestamp',    type:'timestamptz', semantic:null,        pk:false,indexed:false,nullable:true, domain:null,         cde:null, cdeSource:null,      desc:'Last update timestamp',
       op:true,  insMode:'IMMUTABLE',  updMode:'ETL_BATCH',    delMode:'N/A',       srcSystem:'POSTGRES',     nullOnIns:true,  immutable:false, createdBy:null,         updatedBy:'DB_TRIGGER', createdTs:'NULL',           updatedTs:'trigger',    notes:'NULL on insert. Set by trg_audit_updated_ts trigger on any UPDATE.'},
      {cd:'updated_by',       ln:'Updated By',           type:'varchar(100)',semantic:null,        pk:false,indexed:false,nullable:true, domain:null,         cde:null, cdeSource:null,      desc:'Last updated by user or service account',
       op:true,  insMode:'IMMUTABLE',  updMode:'ETL_BATCH',    delMode:'N/A',       srcSystem:'POSTGRES',     nullOnIns:true,  immutable:false, createdBy:null,         updatedBy:'DB_TRIGGER', createdTs:'NULL',           updatedTs:'trigger',    notes:'NULL on insert. Set by trigger on UPDATE.'},
      {cd:'version_nbr',      ln:'Version',              type:'integer',     semantic:null,        pk:false,indexed:false,nullable:false,domain:null,         cde:null, cdeSource:null,      desc:'Optimistic lock version counter',
       op:true,  insMode:'ETL_BATCH',  updMode:'ETL_BATCH',    delMode:'N/A',       srcSystem:'POSTGRES',     nullOnIns:false, immutable:false, createdBy:'DB_DEFAULT', updatedBy:'DB_TRIGGER', createdTs:'1',              updatedTs:'increment',  notes:'Starts at 1. Incremented by trigger on every UPDATE. Used for optimistic locking.'},
      {cd:'lifecycle_status_cd',ln:'Lifecycle Status',  type:'varchar(30)', semantic:null,        pk:false,indexed:true, nullable:false,domain:null,         cde:null, cdeSource:null,      desc:'Row lifecycle status (governance)',
       op:true,  insMode:'ETL_BATCH',  updMode:'ETL_BATCH',    delMode:'N/A',       srcSystem:'RULES_ENGINE', nullOnIns:false, immutable:false, createdBy:'etl_svc',    updatedBy:'rules_svc',  createdTs:'ACTIVE',         updatedTs:'on lifecycle',notes:'ACTIVE→SUPERSEDED→ARCHIVED. Drives soft-delete pattern.'},
    ],
    usedBy:['core_gl_balance (cube)','CUST_NAME_TO_ID (pairing)','GL_ACCT_DESC_TO_CD (pairing)'],
    relationships:[{to:'ref.organization_hierarchy',on:'legal_entity_cd = org_node_cd',type:'many-to-one'},{to:'ref.fiscal_period',on:'period_cd = period_cd',type:'many-to-one'}],
  },
  'core.customer_master': {
    connectionId:'lextr-pg', logicalShortNm:'Customer Master', logicalLongNm:'Customer Registry and KYC Master',
    schema:'core', obj:'customer_master', type:'TABLE',
    grain:'One row per customer across all tenants',
    desc:'Master customer registry. Primary reference for customer name-to-ID resolution in attribute pairing.',
    st:'ACTIVE', aiTier:'RESTRICTED', rows:'~2.4M', updated:'2026-05-18', owner:'j.chen',
    opProfile:{
      insertModes:['API','MANUAL'],
      updateModes:['API','MANUAL'],
      deleteModes:['SOFT_DELETE'],
      srcSystems:['CRM','ONBOARDING_PORTAL'],
      etlFrequency:'Real-time API + nightly batch reconciliation',
      latencyP99:'< 30 s via API',
      retentionPolicy:'Active customer lifetime + 7 years',
    },
    attrs:[
      {cd:'customer_id',      ln:'Customer ID',          type:'bigint',      semantic:'IDENTIFIER',pk:true, indexed:true, nullable:false,domain:null,         cde:'CDE',cdeSource:'ORGANIC',  desc:'Surrogate customer PK',
       op:false, insMode:'API',        updMode:'IMMUTABLE',    delMode:'N/A',       srcSystem:'POSTGRES',     nullOnIns:false, immutable:true,  createdBy:'api_svc',    updatedBy:null,         createdTs:'now()',           updatedTs:null,         notes:'Generated by sequence on INSERT via API. Never updated.'},
      {cd:'customer_nm',      ln:'Customer Name',        type:'varchar(250)',semantic:'DIMENSION', pk:false,indexed:false,nullable:false,domain:null,         cde:'DE', cdeSource:'HUMAN',   desc:'Full legal customer name (display attribute for pairing)',
       op:false, insMode:'API',        updMode:'API',          delMode:'N/A',       srcSystem:'CRM',          nullOnIns:false, immutable:false, createdBy:'api_svc',    updatedBy:'api_svc',    createdTs:'on insert',      updatedTs:'on KYC update',notes:'Updated via API on legal name change. Triggers CUST_NAME_TO_ID pairing cache rebuild.'},
      {cd:'customer_cd',      ln:'Customer Code',        type:'varchar(30)', semantic:'CODE',     pk:false,indexed:true, nullable:false,domain:null,         cde:'DE', cdeSource:'HUMAN',   desc:'Short customer code',
       op:false, insMode:'API',        updMode:'IMMUTABLE',    delMode:'N/A',       srcSystem:'CRM',          nullOnIns:false, immutable:true,  createdBy:'api_svc',    updatedBy:null,         createdTs:'on insert',      updatedTs:null,         notes:'Immutable after initial assignment.'},
      {cd:'customer_type_cd', ln:'Customer Type',        type:'varchar(20)', semantic:'CODE',     pk:false,indexed:true, nullable:false,domain:'CUST_TYPE',  cde:'DE', cdeSource:'HUMAN',   desc:'Customer classification',
       op:false, insMode:'API',        updMode:'API',          delMode:'N/A',       srcSystem:'CRM',          nullOnIns:false, immutable:false, createdBy:'api_svc',    updatedBy:'api_svc',    createdTs:'on insert',      updatedTs:'on reclassify',notes:'Updated on customer reclassification. Audit trail in metadata_change_history.'},
      {cd:'country_cd',       ln:'Country',              type:'char(3)',     semantic:'CODE',     pk:false,indexed:true, nullable:false,domain:'ISO_COUNTRY',cde:'DE', cdeSource:'HUMAN',   desc:'Domicile country',
       op:false, insMode:'API',        updMode:'API',          delMode:'N/A',       srcSystem:'CRM',          nullOnIns:false, immutable:false, createdBy:'api_svc',    updatedBy:'api_svc',    createdTs:'on insert',      updatedTs:'on address change',notes:'ISO 3166-1 alpha-3. Updated on verified address change.'},
      {cd:'tenant_cd',        ln:'Tenant',               type:'varchar(50)', semantic:'CODE',     pk:false,indexed:true, nullable:false,domain:null,         cde:null, cdeSource:null,      desc:'Tenant scope',
       op:true,  insMode:'API',        updMode:'IMMUTABLE',    delMode:'N/A',       srcSystem:'IAM',          nullOnIns:false, immutable:true,  createdBy:'iam_svc',    updatedBy:null,         createdTs:'on insert',      updatedTs:null,         notes:'Set at customer onboarding. Immutable — tenant reassignment requires data migration.'},
      {cd:'created_ts',       ln:'Created Timestamp',    type:'timestamptz', semantic:null,       pk:false,indexed:false,nullable:false,domain:null,         cde:null, cdeSource:null,      desc:'Row creation timestamp',
       op:true,  insMode:'API',        updMode:'IMMUTABLE',    delMode:'N/A',       srcSystem:'POSTGRES',     nullOnIns:false, immutable:true,  createdBy:'DB_DEFAULT', updatedBy:null,         createdTs:'now()',           updatedTs:null,         notes:'DB DEFAULT now(). Cannot be updated.'},
      {cd:'updated_ts',       ln:'Updated Timestamp',    type:'timestamptz', semantic:null,       pk:false,indexed:false,nullable:true, domain:null,         cde:null, cdeSource:null,      desc:'Last update timestamp',
       op:true,  insMode:'IMMUTABLE',  updMode:'API',          delMode:'N/A',       srcSystem:'POSTGRES',     nullOnIns:true,  immutable:false, createdBy:null,         updatedBy:'DB_TRIGGER', createdTs:'NULL',           updatedTs:'trigger',    notes:'Set by trigger on every UPDATE.'},
    ],
    usedBy:['CUST_NAME_TO_ID (pairing)'],
    relationships:[],
  },
  'ref.organization_hierarchy': {
    connectionId:'lextr-pg', logicalShortNm:'Org Hierarchy', logicalLongNm:'Legal Entity and Organization Hierarchy',
    schema:'ref', obj:'organization_hierarchy', type:'TABLE',
    grain:'One row per organization node in the legal entity hierarchy',
    desc:'Legal entity and organizational hierarchy reference. Used for entity resolution, regulatory reporting scope, and variance attribution entity dimension.',
    st:'ACTIVE', aiTier:'ALLOWED', rows:'~12K', updated:'2026-05-10', owner:'s.patel',
    opProfile:{
      insertModes:['MANUAL','API'],
      updateModes:['MANUAL','API'],
      deleteModes:['SOFT_DELETE'],
      srcSystems:['GOVERNANCE_PORTAL','GLEIF_FEED'],
      etlFrequency:'On-demand + GLEIF nightly sync',
      latencyP99:'< 1 hr from GLEIF update',
      retentionPolicy:'Permanent — regulatory requirement',
    },
    attrs:[
      {cd:'org_node_cd',      ln:'Entity Code',             type:'varchar(20)', semantic:'IDENTIFIER',pk:true, indexed:true, nullable:false,domain:null,cde:'CDE',cdeSource:'ORGANIC',desc:'Unique organization node code',
       op:false, insMode:'MANUAL',     updMode:'IMMUTABLE',    delMode:'SOFT_DELETE',srcSystem:'GOVERNANCE_PORTAL',nullOnIns:false,immutable:true, createdBy:'admin',      updatedBy:null,         createdTs:'on insert',      updatedTs:null,         notes:'Assigned by governance team. Immutable once active nodes reference it.'},
      {cd:'org_node_nm',      ln:'Entity Name',             type:'varchar(200)',semantic:'DIMENSION', pk:false,indexed:false,nullable:false,domain:null,cde:'CDE',cdeSource:'ORGANIC',desc:'Organization node full name (display attribute)',
       op:false, insMode:'MANUAL',     updMode:'MANUAL',       delMode:'N/A',       srcSystem:'GOVERNANCE_PORTAL',nullOnIns:false,immutable:false,createdBy:'admin',      updatedBy:'admin',      createdTs:'on insert',      updatedTs:'on rename',  notes:'Updated on legal name change. Triggers ORG_NODE_NAME_TO_CD cache rebuild.'},
      {cd:'parent_cd',        ln:'Parent Entity Code',      type:'varchar(20)', semantic:'CODE',     pk:false,indexed:true, nullable:true, domain:null,cde:'DE', cdeSource:'HUMAN',  desc:'Parent node code — self-referential FK',
       op:false, insMode:'MANUAL',     updMode:'API',          delMode:'N/A',       srcSystem:'GOVERNANCE_PORTAL',nullOnIns:true, immutable:false,createdBy:'admin',      updatedBy:'api_svc',    createdTs:'on insert',      updatedTs:'on restructure',notes:'NULL for root BHC node. Updated on org restructure — triggers hierarchy recalculation.'},
      {cd:'node_level_nbr',   ln:'Hierarchy Level',         type:'integer',     semantic:'MEASURE',  pk:false,indexed:true, nullable:false,domain:null,cde:'DE', cdeSource:'HUMAN',  desc:'Hierarchy depth (1=BHC, 2=Bank, 3=Division)',
       op:false, insMode:'ETL_BATCH',  updMode:'ETL_BATCH',    delMode:'N/A',       srcSystem:'RULES_ENGINE', nullOnIns:false,immutable:false,createdBy:'etl_svc',    updatedBy:'etl_svc',    createdTs:'computed',       updatedTs:'on restructure',notes:'Computed by hierarchy traversal job after any parent_cd change.'},
      {cd:'is_regulatory_flg',ln:'In Regulatory Scope',    type:'boolean',     semantic:'DIMENSION', pk:false,indexed:true, nullable:false,domain:null,cde:'CDE',cdeSource:'ORGANIC',desc:'Participates in regulatory reporting scope',
       op:false, insMode:'MANUAL',     updMode:'API',          delMode:'N/A',       srcSystem:'GOVERNANCE_PORTAL',nullOnIns:false,immutable:false,createdBy:'admin',      updatedBy:'api_svc',    createdTs:'on insert',      updatedTs:'on scope change',notes:'Governance-controlled. Change requires workflow approval.'},
      {cd:'lei_cd',           ln:'Legal Entity Identifier', type:'char(20)',    semantic:'CODE',     pk:false,indexed:true, nullable:true, domain:null,cde:'CDE',cdeSource:'ORGANIC',desc:'Legal Entity Identifier (GLEIF)',
       op:false, insMode:'ETL_BATCH',  updMode:'ETL_BATCH',    delMode:'N/A',       srcSystem:'GLEIF_FEED',   nullOnIns:true, immutable:false,createdBy:'etl_svc',    updatedBy:'etl_svc',    createdTs:'from GLEIF',     updatedTs:'on GLEIF update',notes:'Synced nightly from GLEIF golden copy. NULL for non-regulated entities.'},
      {cd:'created_ts',       ln:'Created Timestamp',      type:'timestamptz', semantic:null,       pk:false,indexed:false,nullable:false,domain:null,cde:null, cdeSource:null,     desc:'Row creation timestamp',
       op:true,  insMode:'MANUAL',     updMode:'IMMUTABLE',    delMode:'N/A',       srcSystem:'POSTGRES',     nullOnIns:false,immutable:true, createdBy:'DB_DEFAULT', updatedBy:null,         createdTs:'now()',           updatedTs:null,         notes:'DB DEFAULT now(). Immutable.'},
      {cd:'updated_ts',       ln:'Updated Timestamp',      type:'timestamptz', semantic:null,       pk:false,indexed:false,nullable:true, domain:null,cde:null, cdeSource:null,     desc:'Last update timestamp',
       op:true,  insMode:'IMMUTABLE',  updMode:'MANUAL',       delMode:'N/A',       srcSystem:'POSTGRES',     nullOnIns:true, immutable:false,createdBy:null,         updatedBy:'DB_TRIGGER', createdTs:'NULL',           updatedTs:'trigger',    notes:'Set by trigger on UPDATE.'},
      {cd:'country_cd',ln:'Country',type:'char(3)',semantic:'CODE',pk:false,indexed:true,nullable:true,domain:'ISO_COUNTRY',cde:null,cdeSource:null,desc:'Jurisdiction country — FK to ref.country_master',op:false,insMode:'MANUAL',updMode:'MANUAL',delMode:'N/A',srcSystem:'INTERNAL',nullOnIns:true,immutable:false,createdBy:'system',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
    ],
    usedBy:['ref_org_hierarchy (cube)','ORG_NODE_NAME_TO_CD (pairing)','Y-9C schedule hierarchy'],
    relationships:[],
  },
  'core.loan_contract': {
    connectionId:'lextr-pg', logicalShortNm:'Loan Contract', logicalLongNm:'Loan and Credit Facility Master',
    schema:'core', obj:'loan_contract', type:'TABLE',
    grain:'One row per loan facility per legal entity',
    desc:'Loan and credit facility master. Primary source for regulatory credit exposure schedules (Y-14Q-H). Links to customer master and organization hierarchy for entity resolution.',
    st:'ACTIVE', aiTier:'RESTRICTED', rows:'~18M', updated:'2026-05-22', owner:'j.chen',
    opProfile:{
      insertModes:['API','ETL_BATCH'],
      updateModes:['API','ETL_BATCH'],
      deleteModes:['SOFT_DELETE'],
      srcSystems:['LOAN_ORIGINATION','ACBS'],
      etlFrequency:'Real-time API + daily batch reconciliation',
      latencyP99:'< 2 hrs from origination',
      retentionPolicy:'Loan lifetime + 7 years regulatory minimum',
    },
    attrs:[
      {cd:'loan_id',            ln:'Loan ID',              type:'bigint',       semantic:'IDENTIFIER',pk:true, indexed:true, nullable:false,domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'Surrogate loan PK',
       op:false,insMode:'API',     updMode:'IMMUTABLE',  delMode:'N/A',    srcSystem:'POSTGRES',          nullOnIns:false,immutable:true, createdBy:'api_svc',   updatedBy:null,        createdTs:'now()',        updatedTs:null,           notes:'Generated by sequence. Never updated.'},
      {cd:'loan_ref_cd',        ln:'Loan Reference',       type:'varchar(30)',  semantic:'CODE',      pk:false,indexed:true, nullable:false,domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'External loan reference from source system',
       op:false,insMode:'ETL_BATCH',updMode:'IMMUTABLE', delMode:'N/A',    srcSystem:'ACBS',              nullOnIns:false,immutable:true, createdBy:'etl_svc',   updatedBy:null,        createdTs:'on insert',    updatedTs:null,           notes:'ACBS deal number. Immutable after booking.'},
      {cd:'customer_id',        ln:'Customer ID',           type:'bigint',       semantic:'IDENTIFIER',pk:false,indexed:true, nullable:false,domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'FK to core.customer_master',
       op:false,insMode:'ETL_BATCH',updMode:'IMMUTABLE', delMode:'N/A',    srcSystem:'LOAN_ORIGINATION',  nullOnIns:false,immutable:true, createdBy:'etl_svc',   updatedBy:null,        createdTs:'on insert',    updatedTs:null,           notes:'Borrower link. Immutable after booking.'},
      {cd:'legal_entity_cd',    ln:'Legal Entity',          type:'varchar(20)',  semantic:'CODE',      pk:false,indexed:true, nullable:false,domain:'ORG_ENTITY',   cde:'CDE',cdeSource:'ORGANIC',desc:'Booking legal entity — FK to ref.organization_hierarchy',
       op:false,insMode:'ETL_BATCH',updMode:'IMMUTABLE', delMode:'N/A',    srcSystem:'ACBS',              nullOnIns:false,immutable:true, createdBy:'etl_svc',   updatedBy:null,        createdTs:'on insert',    updatedTs:null,           notes:'Booking entity code. Immutable after origination.'},
      {cd:'product_type_cd',    ln:'Product Type',          type:'varchar(30)',  semantic:'CODE',      pk:false,indexed:true, nullable:false,domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'Loan product classification (TERM_LOAN, REVOLVER, LOC)',
       op:false,insMode:'ETL_BATCH',updMode:'API',       delMode:'N/A',    srcSystem:'LOAN_ORIGINATION',  nullOnIns:false,immutable:false,createdBy:'etl_svc',   updatedBy:'api_svc',   createdTs:'on insert',    updatedTs:'on amendment', notes:'Can change on loan amendment.'},
      {cd:'currency_cd',        ln:'Currency',              type:'char(3)',      semantic:'CODE',      pk:false,indexed:true, nullable:false,domain:'ISO_CURRENCY',  cde:'CDE',cdeSource:'ORGANIC',desc:'Facility currency — ISO 4217',
       op:false,insMode:'ETL_BATCH',updMode:'IMMUTABLE', delMode:'N/A',    srcSystem:'ACBS',              nullOnIns:false,immutable:true, createdBy:'etl_svc',   updatedBy:null,        createdTs:'on insert',    updatedTs:null,           notes:'Set at origination. Immutable.'},
      {cd:'commitment_amt',     ln:'Committed Amount',      type:'numeric(22,4)',semantic:'MEASURE',   pk:false,indexed:false,nullable:false,domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'Total committed facility amount',
       op:false,insMode:'ETL_BATCH',updMode:'ETL_BATCH', delMode:'N/A',    srcSystem:'ACBS',              nullOnIns:false,immutable:false,createdBy:'etl_svc',   updatedBy:'etl_svc',   createdTs:'on insert',    updatedTs:'on amendment', notes:'Updated on commitment increase/decrease. Feeds Y-14Q-H schedule.'},
      {cd:'outstanding_amt',    ln:'Outstanding Balance',   type:'numeric(22,4)',semantic:'MEASURE',   pk:false,indexed:false,nullable:false,domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'Current drawn/outstanding balance',
       op:false,insMode:'ETL_BATCH',updMode:'ETL_BATCH', delMode:'N/A',    srcSystem:'ACBS',              nullOnIns:false,immutable:false,createdBy:'etl_svc',   updatedBy:'etl_svc',   createdTs:'on insert',    updatedTs:'daily',        notes:'Recalculated daily. Critical for regulatory capital.'},
      {cd:'origination_dt',     ln:'Origination Date',      type:'date',         semantic:'DATE',      pk:false,indexed:true, nullable:false,domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'Loan origination date',
       op:false,insMode:'ETL_BATCH',updMode:'IMMUTABLE', delMode:'N/A',    srcSystem:'ACBS',              nullOnIns:false,immutable:true, createdBy:'etl_svc',   updatedBy:null,        createdTs:'on insert',    updatedTs:null,           notes:'Immutable. Used for vintage analysis.'},
      {cd:'maturity_dt',        ln:'Maturity Date',         type:'date',         semantic:'DATE',      pk:false,indexed:true, nullable:false,domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'Final maturity date of the facility',
       op:false,insMode:'ETL_BATCH',updMode:'API',       delMode:'N/A',    srcSystem:'ACBS',              nullOnIns:false,immutable:false,createdBy:'etl_svc',   updatedBy:'api_svc',   createdTs:'on insert',    updatedTs:'on extension', notes:'Can change on maturity extension.'},
      {cd:'risk_rating_cd',     ln:'Risk Rating',           type:'varchar(10)',  semantic:'CODE',      pk:false,indexed:true, nullable:true, domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'Internal credit risk rating (1–10 scale)',
       op:false,insMode:'ETL_BATCH',updMode:'ETL_BATCH', delMode:'N/A',    srcSystem:'RISK_ENGINE',       nullOnIns:true, immutable:false,createdBy:'etl_svc',   updatedBy:'etl_svc',   createdTs:'on insert',    updatedTs:'quarterly',    notes:'Updated quarterly from risk rating engine.'},
      {cd:'is_regulatory_flg',  ln:'Regulatory Flag',       type:'boolean',      semantic:'DIMENSION', pk:false,indexed:true, nullable:false,domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'True if loan feeds a regulatory schedule',
       op:false,insMode:'ETL_BATCH',updMode:'API',       delMode:'N/A',    srcSystem:'RULES_ENGINE',      nullOnIns:false,immutable:false,createdBy:'etl_svc',   updatedBy:'rules_svc', createdTs:'on insert',    updatedTs:'on rule eval', notes:'Set by rules engine. Governance approval required to change.'},
      // ── Operational columns ────────────────────────────────────────────
      {cd:'lifecycle_status_cd',ln:'Lifecycle Status',      type:'varchar(30)',  semantic:null,        pk:false,indexed:true, nullable:false,domain:null,           cde:null, cdeSource:null,      desc:'Row lifecycle (ACTIVE/MATURED/WRITTEN_OFF)',
       op:true, insMode:'ETL_BATCH',updMode:'ETL_BATCH', delMode:'N/A',    srcSystem:'RULES_ENGINE',      nullOnIns:false,immutable:false,createdBy:'etl_svc',   updatedBy:'rules_svc', createdTs:'ACTIVE',       updatedTs:'on lifecycle', notes:'Drives soft-delete pattern.'},
      {cd:'created_ts',         ln:'Created Timestamp',     type:'timestamptz',  semantic:null,        pk:false,indexed:false,nullable:false,domain:null,           cde:null, cdeSource:null,      desc:'Row creation timestamp',
       op:true, insMode:'ETL_BATCH',updMode:'IMMUTABLE', delMode:'N/A',    srcSystem:'POSTGRES',          nullOnIns:false,immutable:true, createdBy:'DB_DEFAULT',updatedBy:null,        createdTs:'now()',        updatedTs:null,           notes:'DB DEFAULT. Cannot be updated.'},
      {cd:'updated_ts',         ln:'Updated Timestamp',     type:'timestamptz',  semantic:null,        pk:false,indexed:false,nullable:true, domain:null,           cde:null, cdeSource:null,      desc:'Last update timestamp',
       op:true, insMode:'IMMUTABLE',updMode:'ETL_BATCH', delMode:'N/A',    srcSystem:'POSTGRES',          nullOnIns:true, immutable:false,createdBy:null,        updatedBy:'DB_TRIGGER',createdTs:'NULL',         updatedTs:'trigger',      notes:'Set by trigger on every UPDATE.'},
    ],
    usedBy:['LOAN_TO_CUSTOMER (relationship)','LOAN_TO_ORG (relationship)'],
    relationships:[
      {to:'core.customer_master',      on:'customer_id = customer_id',       type:'many-to-one'},
      {to:'ref.organization_hierarchy',on:'legal_entity_cd = org_node_cd',   type:'many-to-one'},
    ],
  },
  'ref.fiscal_period': {
    connectionId:'lextr-pg', logicalShortNm:'Fiscal Period', logicalLongNm:'Fiscal and Regulatory Period Calendar',
    schema:'ref', obj:'fiscal_period', type:'TABLE',
    grain:'One row per fiscal period (quarter or month)',
    desc:'Fiscal and regulatory period calendar. Defines period boundaries, status, and regulatory submission deadlines.',
    st:'ACTIVE', aiTier:'ALLOWED', rows:'~240', updated:'2026-04-01', owner:'system',
    opProfile:{
      insertModes:['MANUAL','ETL_BATCH'],
      updateModes:['MANUAL','API'],
      deleteModes:['NONE'],
      srcSystems:['CALENDAR_SVC','REGULATORY_PORTAL'],
      etlFrequency:'Quarterly (pre-loaded 2 quarters ahead)',
      latencyP99:'N/A — static reference',
      retentionPolicy:'Permanent — regulatory calendar',
    },
    attrs:[
      {cd:'period_cd',        ln:'Period Key',              type:'varchar(10)', semantic:'IDENTIFIER',pk:true, indexed:true, nullable:false,domain:'FISCAL_PERIOD',cde:'CDE',cdeSource:'ORGANIC',desc:'Period key e.g. 2026-Q1',
       op:false, insMode:'MANUAL',     updMode:'IMMUTABLE',    delMode:'NONE',      srcSystem:'CALENDAR_SVC', nullOnIns:false,immutable:true, createdBy:'admin',      updatedBy:null,         createdTs:'on insert',      updatedTs:null,         notes:'Pre-loaded. Immutable after activation.'},
      {cd:'fiscal_year_nbr',  ln:'Fiscal Year',             type:'integer',     semantic:'MEASURE',  pk:false,indexed:true, nullable:false,domain:null,         cde:'CDE',cdeSource:'ORGANIC',desc:'Fiscal year',
       op:false, insMode:'MANUAL',     updMode:'IMMUTABLE',    delMode:'NONE',      srcSystem:'CALENDAR_SVC', nullOnIns:false,immutable:true, createdBy:'admin',      updatedBy:null,         createdTs:'on insert',      updatedTs:null,         notes:'Immutable reference value.'},
      {cd:'period_nbr',       ln:'Period Number',           type:'integer',     semantic:'MEASURE',  pk:false,indexed:true, nullable:false,domain:null,         cde:'CDE',cdeSource:'ORGANIC',desc:'Period number within fiscal year',
       op:false, insMode:'MANUAL',     updMode:'IMMUTABLE',    delMode:'NONE',      srcSystem:'CALENDAR_SVC', nullOnIns:false,immutable:true, createdBy:'admin',      updatedBy:null,         createdTs:'on insert',      updatedTs:null,         notes:'1-4 for quarters, 1-12 for months.'},
      {cd:'period_type_cd',   ln:'Period Type',             type:'varchar(10)', semantic:'CODE',     pk:false,indexed:true, nullable:false,domain:'PERIOD_TYPE', cde:'DE', cdeSource:'HUMAN',  desc:'QUARTER or MONTH',
       op:false, insMode:'MANUAL',     updMode:'IMMUTABLE',    delMode:'NONE',      srcSystem:'CALENDAR_SVC', nullOnIns:false,immutable:true, createdBy:'admin',      updatedBy:null,         createdTs:'on insert',      updatedTs:null,         notes:'Immutable. Determines aggregation logic.'},
      {cd:'period_status_cd', ln:'Period Status',           type:'varchar(20)', semantic:'CODE',     pk:false,indexed:true, nullable:false,domain:'PERIOD_STATUS',cde:'CDE',cdeSource:'ORGANIC',desc:'OPEN, CLOSED, REGULATORY_LOCKED',
       op:false, insMode:'MANUAL',     updMode:'API',          delMode:'NONE',      srcSystem:'REGULATORY_PORTAL',nullOnIns:false,immutable:false,createdBy:'admin',   updatedBy:'api_svc',    createdTs:'OPEN',           updatedTs:'on close/lock',notes:'OPEN→CLOSED by batch job at period end. CLOSED→REGULATORY_LOCKED after FFIEC submission.'},
    ],
    usedBy:['ref_fiscal_period (cube)'],
    relationships:[],
  },

  'analytics.gl_balance_daily_agg': {
    connectionId:'lextr-ch', logicalShortNm:'Daily GL Bal Agg', logicalLongNm:'Daily General Ledger Balance Aggregate',
    schema:'analytics', obj:'gl_balance_daily_agg', type:'TABLE',
    grain:'One row per legal_entity_cd · account_cd · currency_cd · period_cd · report_dt',
    desc:'Pre-aggregated daily GL balance positions in ClickHouse. Primary source for variance analysis and Lexie AI narrative generation. Refreshed nightly from core.gl_balance via ETL pipeline.',
    st:'ACTIVE', aiTier:'ALLOWED', rows:'~280M', updated:'2026-05-25', owner:'system',
    engine:'CLICKHOUSE',
    opProfile:{
      insertModes:['ETL_BATCH'], updateModes:['NONE'], deleteModes:['PARTITION_DROP'],
      srcSystems:['ETL_FROM_CORE_GL'], etlFrequency:'Nightly — 03:00 UTC after GL close',
      latencyP99:'< 6 hrs from GL close', retentionPolicy:'7 years (partition-based TTL)',
    },
    attrs:[
      {cd:'legal_entity_cd',   ln:'Legal Entity',         type:'LowCardinality(String)', semantic:'CODE',    pk:false,indexed:true, nullable:false,domain:'ORG_ENTITY',   cde:'CDE',cdeSource:'ORGANIC',desc:'Legal entity code — FK to ref.organization_hierarchy (PG, cross-engine)',op:false,insMode:'ETL_BATCH',updMode:'IMMUTABLE',delMode:'N/A',srcSystem:'ETL',nullOnIns:false,immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Partition key. Immutable.'},
      {cd:'account_cd',        ln:'Account Code',          type:'LowCardinality(String)', semantic:'CODE',    pk:false,indexed:true, nullable:false,domain:'GL_ACCOUNT',   cde:'CDE',cdeSource:'ORGANIC',desc:'Chart of accounts code',op:false,insMode:'ETL_BATCH',updMode:'IMMUTABLE',delMode:'N/A',srcSystem:'ETL',nullOnIns:false,immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Sorting key component.'},
      {cd:'currency_cd',       ln:'Currency',              type:'FixedString(3)',         semantic:'CODE',    pk:false,indexed:true, nullable:false,domain:'ISO_CURRENCY', cde:'CDE',cdeSource:'ORGANIC',desc:'ISO 4217 currency code',op:false,insMode:'ETL_BATCH',updMode:'IMMUTABLE',delMode:'N/A',srcSystem:'ETL',nullOnIns:false,immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Part of ORDER BY key.'},
      {cd:'period_cd',         ln:'Fiscal Period',         type:'LowCardinality(String)', semantic:'DATE',    pk:false,indexed:true, nullable:false,domain:'FISCAL_PERIOD',cde:'CDE',cdeSource:'ORGANIC',desc:'Fiscal period key — FK to ref.fiscal_period (PG, cross-engine)',op:false,insMode:'ETL_BATCH',updMode:'IMMUTABLE',delMode:'N/A',srcSystem:'ETL',nullOnIns:false,immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Primary time dimension.'},
      {cd:'report_dt',         ln:'Report Date',           type:'Date',                  semantic:'DATE',    pk:false,indexed:true, nullable:false,domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'Daily snapshot date',op:false,insMode:'ETL_BATCH',updMode:'IMMUTABLE',delMode:'N/A',srcSystem:'ETL',nullOnIns:false,immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Partition key (PARTITION BY toYYYYMM(report_dt)).'},
      {cd:'opening_balance_amt',ln:'Opening Balance',      type:'Decimal(22,4)',          semantic:'MEASURE', pk:false,indexed:false,nullable:false,domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'Opening balance at start of report_dt',op:false,insMode:'ETL_BATCH',updMode:'NONE',delMode:'N/A',srcSystem:'ETL',nullOnIns:false,immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Aggregated from core.gl_balance.'},
      {cd:'closing_balance_amt',ln:'Closing Balance',      type:'Decimal(22,4)',          semantic:'MEASURE', pk:false,indexed:false,nullable:false,domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'Closing balance at end of report_dt',op:false,insMode:'ETL_BATCH',updMode:'NONE',delMode:'N/A',srcSystem:'ETL',nullOnIns:false,immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Primary balance measure for Lexie AI variance narrative.'},
      {cd:'net_movement_amt',   ln:'Net Movement',         type:'Decimal(22,4)',          semantic:'MEASURE', pk:false,indexed:false,nullable:false,domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'closing_balance_amt - opening_balance_amt',op:false,insMode:'ETL_BATCH',updMode:'NONE',delMode:'N/A',srcSystem:'ETL',nullOnIns:false,immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Derived at ETL. Used for variance attribution.'},
      {cd:'row_count_nbr',      ln:'Source Row Count',     type:'UInt32',                 semantic:'MEASURE', pk:false,indexed:false,nullable:false,domain:null,           cde:null, cdeSource:null,     desc:'Count of source gl_balance rows aggregated',op:true, insMode:'ETL_BATCH',updMode:'NONE',delMode:'N/A',srcSystem:'ETL',nullOnIns:false,immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Lineage / data quality check.'},
    ],
    usedBy:['Lexie AI variance analysis','semantic-service analytics_gl_balance_agg'],
    relationships:[
      {to:'core.gl_balance',          on:'(pre-aggregated from)',     type:'many-to-one', crossEngine:true},
      {to:'ref.fiscal_period',        on:'period_cd = period_cd',     type:'many-to-one', crossEngine:true},
      {to:'ref.organization_hierarchy',on:'legal_entity_cd = org_node_cd', type:'many-to-one', crossEngine:true},
    ],
  },
  'analytics.loan_performance_daily': {
    connectionId:'lextr-ch', logicalShortNm:'Loan Perf Daily', logicalLongNm:'Daily Loan Performance Snapshot',
    schema:'analytics', obj:'loan_performance_daily', type:'TABLE',
    grain:'One row per loan_id · snapshot_dt (daily loan health snapshot)',
    desc:'Daily performance snapshot of every active loan. Feeds regulatory stress-testing, early-warning dashboards, and Lexie AI credit narrative generation. Stored in ClickHouse for fast time-series range scans.',
    st:'ACTIVE', aiTier:'RESTRICTED', rows:'~95M', updated:'2026-05-25', owner:'j.chen',
    engine:'CLICKHOUSE',
    opProfile:{
      insertModes:['ETL_BATCH'], updateModes:['NONE'], deleteModes:['PARTITION_DROP'],
      srcSystems:['ETL_FROM_CORE_LOAN','RISK_ENGINE'],
      etlFrequency:'Nightly — 04:00 UTC', latencyP99:'< 8 hrs',
      retentionPolicy:'5 years (partition TTL)',
    },
    attrs:[
      {cd:'loan_id',              ln:'Loan ID',             type:'UInt64',                semantic:'IDENTIFIER',pk:false,indexed:true, nullable:false,domain:null,cde:'CDE',cdeSource:'ORGANIC',desc:'FK to core.loan_contract (PG, cross-engine)',op:false,insMode:'ETL_BATCH',updMode:'IMMUTABLE',delMode:'N/A',srcSystem:'ETL',nullOnIns:false,immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Primary key component. Matches core.loan_contract.loan_id.'},
      {cd:'snapshot_dt',          ln:'Snapshot Date',       type:'Date',                  semantic:'DATE',    pk:false,indexed:true, nullable:false,domain:null,cde:'CDE',cdeSource:'ORGANIC',desc:'Daily snapshot date (PARTITION BY toYYYYMM)',op:false,insMode:'ETL_BATCH',updMode:'IMMUTABLE',delMode:'N/A',srcSystem:'ETL',nullOnIns:false,immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Partition key.'},
      {cd:'outstanding_amt',      ln:'Outstanding Balance',  type:'Decimal(22,4)',          semantic:'MEASURE', pk:false,indexed:false,nullable:false,domain:null,cde:'CDE',cdeSource:'ORGANIC',desc:'Outstanding balance on snapshot_dt',op:false,insMode:'ETL_BATCH',updMode:'NONE',delMode:'N/A',srcSystem:'ETL',nullOnIns:false,immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'past_due_days_nbr',    ln:'Days Past Due',        type:'UInt16',                 semantic:'MEASURE', pk:false,indexed:true, nullable:false,domain:null,cde:'CDE',cdeSource:'ORGANIC',desc:'Number of calendar days past due on snapshot_dt',op:false,insMode:'ETL_BATCH',updMode:'NONE',delMode:'N/A',srcSystem:'RISK_ENGINE',nullOnIns:false,immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'0 = current. >90 = NPL trigger.'},
      {cd:'risk_rating_cd',       ln:'Risk Rating',          type:'LowCardinality(String)', semantic:'CODE',    pk:false,indexed:true, nullable:true, domain:null,cde:'CDE',cdeSource:'ORGANIC',desc:'Internal credit risk rating on snapshot_dt',op:false,insMode:'ETL_BATCH',updMode:'NONE',delMode:'N/A',srcSystem:'RISK_ENGINE',nullOnIns:true, immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'performance_status_cd',ln:'Performance Status',   type:'LowCardinality(String)', semantic:'CODE',    pk:false,indexed:true, nullable:false,domain:null,cde:'CDE',cdeSource:'ORGANIC',desc:'CURRENT · WATCH · SUBSTANDARD · DOUBTFUL · LOSS',op:false,insMode:'ETL_BATCH',updMode:'NONE',delMode:'N/A',srcSystem:'RISK_ENGINE',nullOnIns:false,immutable:true,createdBy:'etl_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Drives regulatory classification. Feeds Y-14Q-H.'},
    ],
    usedBy:['Lexie AI credit narrative','Stress-testing dashboard','Y-14Q-H schedule'],
    relationships:[{to:'core.loan_contract', on:'loan_id = loan_id', type:'many-to-one', crossEngine:true}],
  },
  'analytics.variance_result_cache': {
    connectionId:'lextr-ch', logicalShortNm:'Variance Cache', logicalLongNm:'Variance Analysis Result Cache',
    schema:'analytics', obj:'variance_result_cache', type:'TABLE',
    grain:'One row per run_id · dimension_key combination (variance attribution result)',
    desc:'Materialised variance analysis results. Written by the Lextr Intelligence variance pipeline, read by Lexie AI for narrative generation and by the Variance Analysis UI. Never queried for raw data — always pre-computed.',
    st:'ACTIVE', aiTier:'ALLOWED', rows:'~12M', updated:'2026-05-25', owner:'system',
    engine:'CLICKHOUSE',
    opProfile:{
      insertModes:['API'], updateModes:['NONE'], deleteModes:['PARTITION_DROP'],
      srcSystems:['VARIANCE_PIPELINE'],
      etlFrequency:'On-demand (triggered per variance run)', latencyP99:'< 5 min post-run',
      retentionPolicy:'2 years (partition TTL)',
    },
    attrs:[
      {cd:'run_id',          ln:'Run ID',           type:'UUID',                  semantic:'IDENTIFIER',pk:false,indexed:true, nullable:false,domain:null,cde:null,cdeSource:null,desc:'Variance run identifier — FK to intelligence.variance_run (PG)',op:false,insMode:'API',updMode:'NONE',delMode:'N/A',srcSystem:'VARIANCE_PIPELINE',nullOnIns:false,immutable:true,createdBy:'pipeline_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'report_id',       ln:'Report ID',        type:'LowCardinality(String)', semantic:'CODE',    pk:false,indexed:true, nullable:false,domain:null,cde:null,cdeSource:null,desc:'Report type (Y-9C, Y-14Q-H, custom)',op:false,insMode:'API',updMode:'NONE',delMode:'N/A',srcSystem:'VARIANCE_PIPELINE',nullOnIns:false,immutable:true,createdBy:'pipeline_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'period_cd',       ln:'Fiscal Period',    type:'LowCardinality(String)', semantic:'DATE',    pk:false,indexed:true, nullable:false,domain:'FISCAL_PERIOD',cde:'CDE',cdeSource:'ORGANIC',desc:'Reporting period',op:false,insMode:'API',updMode:'NONE',delMode:'N/A',srcSystem:'VARIANCE_PIPELINE',nullOnIns:false,immutable:true,createdBy:'pipeline_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'dimension_key',   ln:'Dimension Key',    type:'String',                semantic:'CODE',    pk:false,indexed:true, nullable:false,domain:null,cde:null,cdeSource:null,desc:'JSON-encoded dimension combination key',op:false,insMode:'API',updMode:'NONE',delMode:'N/A',srcSystem:'VARIANCE_PIPELINE',nullOnIns:false,immutable:true,createdBy:'pipeline_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'e.g. {legal_entity_cd:BHC_A001, account_cd:4210}'},
      {cd:'current_amt',     ln:'Current Amount',   type:'Decimal(22,4)',          semantic:'MEASURE', pk:false,indexed:false,nullable:false,domain:null,cde:'CDE',cdeSource:'ORGANIC',desc:'Current period value',op:false,insMode:'API',updMode:'NONE',delMode:'N/A',srcSystem:'VARIANCE_PIPELINE',nullOnIns:false,immutable:true,createdBy:'pipeline_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'prior_amt',       ln:'Prior Amount',     type:'Decimal(22,4)',          semantic:'MEASURE', pk:false,indexed:false,nullable:false,domain:null,cde:'CDE',cdeSource:'ORGANIC',desc:'Prior period value (comparison base)',op:false,insMode:'API',updMode:'NONE',delMode:'N/A',srcSystem:'VARIANCE_PIPELINE',nullOnIns:false,immutable:true,createdBy:'pipeline_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'variance_amt',    ln:'Variance Amount',  type:'Decimal(22,4)',          semantic:'MEASURE', pk:false,indexed:false,nullable:false,domain:null,cde:'CDE',cdeSource:'ORGANIC',desc:'current_amt - prior_amt',op:false,insMode:'API',updMode:'NONE',delMode:'N/A',srcSystem:'VARIANCE_PIPELINE',nullOnIns:false,immutable:true,createdBy:'pipeline_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'variance_pct',    ln:'Variance %',       type:'Float64',                semantic:'MEASURE', pk:false,indexed:false,nullable:true, domain:null,cde:'CDE',cdeSource:'ORGANIC',desc:'variance_amt / prior_amt × 100',op:false,insMode:'API',updMode:'NONE',delMode:'N/A',srcSystem:'VARIANCE_PIPELINE',nullOnIns:true, immutable:true,createdBy:'pipeline_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'NULL when prior_amt = 0.'},
      {cd:'driver_cd',       ln:'Variance Driver',  type:'LowCardinality(String)', semantic:'CODE',    pk:false,indexed:true, nullable:true, domain:null,cde:null,cdeSource:null,desc:'Primary variance driver: RULE_CHANGE · MARKET · VOLUME · STRATEGY',op:false,insMode:'API',updMode:'NONE',delMode:'N/A',srcSystem:'VARIANCE_PIPELINE',nullOnIns:true, immutable:true,createdBy:'pipeline_svc',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Horizontal variance dimension used by Lexie narrative.'},
    ],
    usedBy:['Lexie AI variance narrative','Variance Analysis screen'],
    relationships:[{to:'ref.fiscal_period', on:'period_cd = period_cd', type:'many-to-one', crossEngine:true}],
  },

  'ref.country_master': {
    connectionId:'lextr-pg', logicalShortNm:'Country Master', logicalLongNm:'Country Reference and Regulatory Classification Master',
    schema:'ref', obj:'country_master', type:'TABLE',
    grain:'One row per ISO 3166-1 alpha-3 country code',
    desc:'Reference table of all countries with sovereign credit ratings, sanction status, regulatory classification, and jurisdiction flags. Primary source for OFAC, AAA, and cross-border regulatory lookups. Replicated to ClickHouse for filter lookup performance.',
    st:'ACTIVE', aiTier:'ALLOWED', rows:'~250', updated:'2026-05-25', owner:'system',
    engine:'POSTGRES',
    opProfile:{insertModes:['MANUAL'],updateModes:['MANUAL'],deleteModes:['LOGICAL'],
      srcSystems:['OFAC_FEED','SP_RATINGS','MOODYS_RATINGS','FITCH_RATINGS'],
      etlFrequency:'Monthly — OFAC feed monthly, ratings quarterly',
      latencyP99:'< 24 hrs from source update', retentionPolicy:'Permanent (regulatory)'},
    attrs:[
      {cd:'country_cd',          ln:'Country Code',         type:'char(3)',                 semantic:'CODE',      pk:true, indexed:true, nullable:false,domain:'ISO_COUNTRY',   cde:'CDE',cdeSource:'ORGANIC',desc:'ISO 3166-1 alpha-3 country code (primary key)',op:false,insMode:'MANUAL',updMode:'RESTRICTED',delMode:'LOGICAL',srcSystem:'ISO',nullOnIns:false,immutable:true,createdBy:'system',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Primary key. Immutable once issued.'},
      {cd:'country_nm',          ln:'Country Name',          type:'varchar(100)',            semantic:'DIMENSION', pk:false,indexed:true, nullable:false,domain:null,           cde:'CDE',cdeSource:'ORGANIC',desc:'Full country name in English',op:false,insMode:'MANUAL',updMode:'MANUAL',delMode:'N/A',srcSystem:'ISO',nullOnIns:false,immutable:false,createdBy:'system',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'iso2_cd',             ln:'ISO 2 Code',            type:'char(2)',                 semantic:'CODE',      pk:false,indexed:true, nullable:true, domain:null,           cde:null, cdeSource:null,    desc:'ISO 3166-1 alpha-2 code (e.g. US)',op:false,insMode:'MANUAL',updMode:'MANUAL',delMode:'N/A',srcSystem:'ISO',nullOnIns:true,immutable:false,createdBy:'system',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'region_cd',           ln:'Region',                type:'varchar(20)',             semantic:'DIMENSION', pk:false,indexed:true, nullable:true, domain:null,           cde:null, cdeSource:null,    desc:'UN M.49 region classification',op:false,insMode:'MANUAL',updMode:'MANUAL',delMode:'N/A',srcSystem:'UN',nullOnIns:true,immutable:false,createdBy:'system',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'sp_rating',           ln:'S&P Rating',            type:'varchar(10)',             semantic:'CODE',      pk:false,indexed:true, nullable:true, domain:null,           cde:'CDE',cdeSource:'HUMAN',  desc:'S&P sovereign credit rating (AAA, AA+, AA, … D)',op:false,insMode:'MANUAL',updMode:'MANUAL',delMode:'N/A',srcSystem:'SP_RATINGS',nullOnIns:true,immutable:false,createdBy:'system',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Quarterly update. Drives AAA_RATED_COUNTRIES filter lookup.'},
      {cd:'moodys_rating',       ln:'Moodys Rating',         type:'varchar(10)',             semantic:'CODE',      pk:false,indexed:true, nullable:true, domain:null,           cde:'CDE',cdeSource:'HUMAN',  desc:'Moodys sovereign credit rating (Aaa, Aa1, Aa2, … C)',op:false,insMode:'MANUAL',updMode:'MANUAL',delMode:'N/A',srcSystem:'MOODYS_RATINGS',nullOnIns:true,immutable:false,createdBy:'system',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'fitch_rating',        ln:'Fitch Rating',          type:'varchar(10)',             semantic:'CODE',      pk:false,indexed:true, nullable:true, domain:null,           cde:null, cdeSource:null,    desc:'Fitch sovereign credit rating',op:false,insMode:'MANUAL',updMode:'MANUAL',delMode:'N/A',srcSystem:'FITCH_RATINGS',nullOnIns:true,immutable:false,createdBy:'system',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'sanction_status',     ln:'Sanction Status',       type:'varchar(30)',             semantic:'CODE',      pk:false,indexed:true, nullable:false,domain:null,           cde:'CDE',cdeSource:'HUMAN',  desc:'OFAC/UN sanction status: CLEAN | OFAC_BLOCKED | UN_SANCTIONED | PARTIAL',op:false,insMode:'MANUAL',updMode:'MANUAL',delMode:'N/A',srcSystem:'OFAC_FEED',nullOnIns:false,immutable:false,createdBy:'system',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:'Drives OFAC_BLOCKED_COUNTRIES filter lookup. Monthly OFAC feed.'},
      {cd:'is_fatf_member',      ln:'FATF Member',           type:'boolean',                 semantic:'CODE',      pk:false,indexed:true, nullable:false,domain:'ENUM_LIST',      cde:null, cdeSource:null,    desc:'Financial Action Task Force membership flag',op:false,insMode:'MANUAL',updMode:'MANUAL',delMode:'N/A',srcSystem:'FATF',nullOnIns:false,immutable:false,createdBy:'system',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'is_regulatory_jurisdiction',ln:'Regulatory Jurisdiction',type:'boolean',         semantic:'CODE',      pk:false,indexed:true, nullable:false,domain:'ENUM_LIST',      cde:null, cdeSource:null,    desc:'Whether this country is a primary regulatory reporting jurisdiction for BHC',op:false,insMode:'MANUAL',updMode:'MANUAL',delMode:'N/A',srcSystem:'INTERNAL',nullOnIns:false,immutable:false,createdBy:'system',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'currency_cd',         ln:'Local Currency',        type:'char(3)',                 semantic:'CODE',      pk:false,indexed:true, nullable:true, domain:'ISO_CURRENCY', cde:null, cdeSource:null,    desc:'ISO 4217 primary currency code for this country',op:false,insMode:'MANUAL',updMode:'MANUAL',delMode:'N/A',srcSystem:'ISO',nullOnIns:true,immutable:false,createdBy:'system',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
      {cd:'effective_from_dt',   ln:'Effective From',        type:'date',                   semantic:'DATE',      pk:false,indexed:false,nullable:false,domain:null,           cde:null, cdeSource:null,    desc:'Date from which this record is valid',op:false,insMode:'MANUAL',updMode:'RESTRICTED',delMode:'N/A',srcSystem:'INTERNAL',nullOnIns:false,immutable:true,createdBy:'system',updatedBy:null,createdTs:'on insert',updatedTs:null,notes:''},
    ],
    usedBy:['OFAC_BLOCKED_COUNTRIES filter lookup','AAA_RATED_COUNTRIES filter lookup','CUSTOMER_TO_COUNTRY','ORG_TO_COUNTRY'],
    relationships:[
      {to:'core.customer_master',          on:'country_cd = country_cd', type:'one-to-many'},
      {to:'ref.organization_hierarchy',    on:'country_cd = country_cd', type:'one-to-many'},
    ],
  },
}
const OBJECTS = Object.keys(CATALOG)

const PAIRINGS = [
  {cd:'CUST_NAME_TO_ID',   srcObj:'core.customer_master',          dispAttr:'customer_nm',   filtAttr:'customer_id', strategy:'CACHED_LOOKUP', cardinality:'ONE_TO_ONE',  perf:78, st:'ACTIVE', bidir:true,  cube:'core_gl_balance'},
  {cd:'ORG_NODE_NAME_TO_CD',srcObj:'ref.organization_hierarchy',   dispAttr:'org_node_nm',   filtAttr:'org_node_cd', strategy:'INLINE_MAP',    cardinality:'ONE_TO_ONE',  perf:65, st:'ACTIVE', bidir:true,  cube:'ref_org_hierarchy'},
  {cd:'GL_ACCT_DESC_TO_CD', srcObj:'core.gl_balance',              dispAttr:'account_desc_txt',filtAttr:'account_cd',strategy:'CACHED_LOOKUP', cardinality:'ONE_TO_ONE',  perf:82, st:'REVIEW', bidir:true,  cube:'core_gl_balance'},
  {cd:'LOAN_REF_TO_ID',    srcObj:'core.loan_contract',            dispAttr:'loan_ref_cd',   filtAttr:'loan_id',    strategy:'CACHED_LOOKUP', cardinality:'ONE_TO_ONE',  perf:88, st:'ACTIVE', bidir:false, cube:'core_loan_contract'},
  {cd:'CH_PERF_STATUS_LABEL',srcObj:'analytics.loan_performance_daily',dispAttr:'performance_status_cd',filtAttr:'performance_status_cd',strategy:'INLINE_MAP',cardinality:'ONE_TO_ONE',perf:95,st:'ACTIVE',bidir:false,cube:'analytics_loan_performance'},
]

const DOMAINS = {
  // Governed shape — mirrors meta.domain_value (+ domain_value_synonym).
  // v: value_cd · l: value_desc · ai: ai_context_txt · syn: BUSINESS synonyms · st: lifecycle_status_cd
  ORG_ENTITY:   [{v:'BHC_A001',l:'Bank Holding Company Alpha',ai:'Top-tier BHC; consolidates all US subsidiaries',syn:['bhc alpha','alpha'],st:'ACTIVE'},
                 {v:'BHC_B002',l:'Bank Holding Company Beta',ai:'Second-tier BHC',syn:['bhc beta','beta'],st:'ACTIVE'},
                 {v:'SUB_C010',l:'Subsidiary C',ai:'Non-bank subsidiary',syn:['sub c'],st:'ACTIVE'}],
  GL_ACCOUNT:   [{v:'ACC_4210',l:'Loans - Commercial',ai:'Commercial loan balances; FR Y-9C Sched HC-C',syn:['commercial loans','c&i loans'],st:'ACTIVE'},
                 {v:'ACC_3150',l:'Investment Securities AFS',ai:'Available-for-sale securities at fair value; ASC 320',syn:['afs securities','available for sale'],st:'ACTIVE'},
                 {v:'ACC_1100',l:'Cash and Due from Banks',ai:'HQLA Level 1; FR Y-9C Sched HC line 1',syn:['cash','due from banks'],st:'ACTIVE'}],
  ISO_CURRENCY: [{v:'USD',l:'US Dollar',ai:'Reporting currency for US regulatory filings',syn:['dollar','us dollar'],st:'ACTIVE'},
                 {v:'EUR',l:'Euro',ai:'',syn:['euro'],st:'ACTIVE'},
                 {v:'GBP',l:'Pound Sterling',ai:'',syn:['sterling','pound'],st:'ACTIVE'},
                 {v:'JPY',l:'Japanese Yen',ai:'',syn:['yen'],st:'ACTIVE'}],
  FISCAL_PERIOD:[{v:'2026-Q1',l:'Q1 2026',ai:'Current open reporting period',syn:['current quarter'],st:'ACTIVE'},
                 {v:'2025-Q4',l:'Q4 2025',ai:'',syn:['prior quarter'],st:'ACTIVE'},
                 {v:'2025-Q3',l:'Q3 2025',ai:'',syn:[],st:'ACTIVE'}],
  CUST_TYPE:    [{v:'CORP',l:'Corporate',ai:'Non-financial corporate counterparty',syn:['corporate','corp'],st:'ACTIVE'},
                 {v:'FI',l:'Financial Institution',ai:'Bank or non-bank FI; Basel counterparty class',syn:['financial institution','bank'],st:'ACTIVE'},
                 {v:'GOV',l:'Government',ai:'Sovereign or agency',syn:['government','sovereign'],st:'ACTIVE'},
                 {v:'RETAIL',l:'Retail',ai:'Individual / small business',syn:['retail','consumer'],st:'ACTIVE'}],
  ISO_COUNTRY:  [{v:'US',l:'United States',ai:'',syn:['usa','united states','us'],st:'ACTIVE'},
                 {v:'GB',l:'United Kingdom',ai:'',syn:['uk','britain'],st:'ACTIVE'},
                 {v:'DE',l:'Germany',ai:'',syn:['germany'],st:'ACTIVE'},
                 {v:'JP',l:'Japan',ai:'',syn:['japan'],st:'ACTIVE'}],
  PERIOD_TYPE:  [{v:'QUARTER',l:'Quarterly',ai:'',syn:['quarterly'],st:'ACTIVE'},
                 {v:'MONTH',l:'Monthly',ai:'',syn:['monthly'],st:'ACTIVE'}],
  PERIOD_STATUS:[{v:'OPEN',l:'Open — submissions accepted',ai:'Period accepts new submissions',syn:['open'],st:'ACTIVE'},
                 {v:'CLOSED',l:'Closed — locked for amendment',ai:'No new submissions; amendments only',syn:['closed','locked'],st:'ACTIVE'},
                 {v:'REGULATORY_LOCKED',l:'Regulatory locked — FFIEC submission complete',ai:'Filed with the agency; immutable',syn:['filed','regulatory locked'],st:'ACTIVE'}],
}

// Per-attribute boolean polarity (v2.10.0 ASK 2a): a boolean is a TWO-VALUE ENUM_LIST.
// The same physical Y means different things per attribute — polarity is never assumed.
const BOOLEAN_POLARITY = {
  is_fatf_member:             [{v:'Y',l:'FATF member'},{v:'N',l:'Not a FATF member'}],
  is_regulatory_jurisdiction: [{v:'Y',l:'Primary regulatory jurisdiction'},{v:'N',l:'Not a reporting jurisdiction'}],
}

// DB_COLUMNS — simulates PostgreSQL information_schema introspection result
// Includes ALL columns (business + operational/governance) so the user can
// selectively include/exclude each from the semantic layer and AI exposure.
// In production this would be fetched from FastAPI /introspect/{schema}/{table}.
const TODAY = '2026-05-24'
const DB_COLUMNS = {
  'core.gl_balance': [
    // ── Business columns — semantic: true, aiExposed: true by default ──
    {cd:'gl_balance_id',    dbType:'bigint',       pk:true,  indexed:true,  nullable:false, op:false, suggested:'IDENTIFIER', semantic:true,  aiExposed:true,  domain:'',            desc:'Surrogate primary key',                          effectiveFrom:TODAY, effectiveTo:''},
    {cd:'legal_entity_cd',  dbType:'varchar(20)',  pk:false, indexed:true,  nullable:false, op:false, suggested:'CODE',       semantic:true,  aiExposed:true,  domain:'ORG_ENTITY',  desc:'Legal entity code — FK to organization_hierarchy', effectiveFrom:TODAY, effectiveTo:''},
    {cd:'account_cd',       dbType:'varchar(30)',  pk:false, indexed:true,  nullable:false, op:false, suggested:'CODE',       semantic:true,  aiExposed:true,  domain:'GL_ACCOUNT',  desc:'Chart of accounts code',                         effectiveFrom:TODAY, effectiveTo:''},
    {cd:'account_desc_txt', dbType:'varchar(200)', pk:false, indexed:false, nullable:true,  op:false, suggested:'DIMENSION',  semantic:true,  aiExposed:true,  domain:'',            desc:'Human-readable account description (display attr)', effectiveFrom:TODAY, effectiveTo:''},
    {cd:'currency_cd',      dbType:'char(3)',      pk:false, indexed:true,  nullable:false, op:false, suggested:'CODE',       semantic:true,  aiExposed:true,  domain:'ISO_CURRENCY',desc:'ISO 4217 currency code',                          effectiveFrom:TODAY, effectiveTo:''},
    {cd:'period_cd',        dbType:'varchar(10)',  pk:false, indexed:true,  nullable:false, op:false, suggested:'DATE',       semantic:true,  aiExposed:true,  domain:'FISCAL_PERIOD',desc:'Fiscal period key (YYYY-Qn or YYYY-MM)',          effectiveFrom:TODAY, effectiveTo:''},
    {cd:'balance_amt',      dbType:'numeric(22,4)',pk:false, indexed:false, nullable:false, op:false, suggested:'MEASURE',    semantic:true,  aiExposed:true,  domain:'',            desc:'Ledger balance in functional currency',           effectiveFrom:TODAY, effectiveTo:''},
    {cd:'is_regulatory_flg',dbType:'boolean',     pk:false, indexed:true,  nullable:false, op:false, suggested:'DIMENSION',  semantic:true,  aiExposed:true,  domain:'',            desc:'True if this balance feeds a regulatory schedule', effectiveFrom:TODAY, effectiveTo:''},
    // ── Operational columns — semantic: false by default; AI exposure varies ──
    {cd:'source_system_cd', dbType:'varchar(20)',  pk:false, indexed:true,  nullable:false, op:true,  suggested:'CODE',       semantic:false, aiExposed:true,  domain:'',            desc:'Source system identifier (lineage)',              effectiveFrom:TODAY, effectiveTo:''},
    {cd:'created_ts',       dbType:'timestamptz', pk:false, indexed:false, nullable:false, op:true,  suggested:'—',          semantic:false, aiExposed:true,  domain:'',            desc:'Row creation timestamp (governance)',             effectiveFrom:TODAY, effectiveTo:''},
    {cd:'created_by',       dbType:'varchar(100)',pk:false, indexed:false, nullable:false, op:true,  suggested:'—',          semantic:false, aiExposed:false, domain:'',            desc:'Created by user (governance)',                    effectiveFrom:TODAY, effectiveTo:''},
    {cd:'updated_ts',       dbType:'timestamptz', pk:false, indexed:false, nullable:true,  op:true,  suggested:'—',          semantic:false, aiExposed:false, domain:'',            desc:'Last update timestamp',                           effectiveFrom:TODAY, effectiveTo:''},
    {cd:'updated_by',       dbType:'varchar(100)',pk:false, indexed:false, nullable:true,  op:true,  suggested:'—',          semantic:false, aiExposed:false, domain:'',            desc:'Last updated by user',                            effectiveFrom:TODAY, effectiveTo:''},
    {cd:'version_nbr',      dbType:'integer',     pk:false, indexed:false, nullable:false, op:true,  suggested:'—',          semantic:false, aiExposed:false, domain:'',            desc:'Optimistic lock version counter',                 effectiveFrom:TODAY, effectiveTo:''},
    {cd:'lifecycle_status_cd',dbType:'varchar(30)',pk:false,indexed:true,  nullable:false, op:true,  suggested:'—',          semantic:false, aiExposed:true,  domain:'',            desc:'Row lifecycle status (governance)',                effectiveFrom:TODAY, effectiveTo:''},
    {cd:'row_hash',         dbType:'varchar(64)', pk:false, indexed:false, nullable:true,  op:true,  suggested:'—',          semantic:false, aiExposed:false, domain:'',            desc:'ETL row hash for change detection',               effectiveFrom:TODAY, effectiveTo:''},
    {cd:'etl_batch_id',     dbType:'bigint',      pk:false, indexed:false, nullable:true,  op:true,  suggested:'—',          semantic:false, aiExposed:false, domain:'',            desc:'ETL batch identifier',                            effectiveFrom:TODAY, effectiveTo:''},
    {cd:'load_ts',          dbType:'timestamptz', pk:false, indexed:false, nullable:true,  op:true,  suggested:'—',          semantic:false, aiExposed:false, domain:'',            desc:'ETL load timestamp',                              effectiveFrom:TODAY, effectiveTo:''},
    {cd:'is_deleted_flg',   dbType:'boolean',     pk:false, indexed:true,  nullable:false, op:true,  suggested:'—',          semantic:false, aiExposed:false, domain:'',            desc:'Soft-delete flag',                                effectiveFrom:TODAY, effectiveTo:''},
  ],
  'core.customer_master': [
    {cd:'customer_id',      dbType:'bigint',      pk:true,  indexed:true,  nullable:false, op:false, suggested:'IDENTIFIER', semantic:true,  aiExposed:true,  domain:'',           desc:'Surrogate customer PK',                 effectiveFrom:TODAY, effectiveTo:''},
    {cd:'customer_nm',      dbType:'varchar(250)',pk:false, indexed:false, nullable:false, op:false, suggested:'DIMENSION',  semantic:true,  aiExposed:true,  domain:'',           desc:'Full legal customer name (display attr)',effectiveFrom:TODAY, effectiveTo:''},
    {cd:'customer_cd',      dbType:'varchar(30)', pk:false, indexed:true,  nullable:false, op:false, suggested:'CODE',       semantic:true,  aiExposed:true,  domain:'',           desc:'Short customer code',                   effectiveFrom:TODAY, effectiveTo:''},
    {cd:'customer_type_cd', dbType:'varchar(20)', pk:false, indexed:true,  nullable:false, op:false, suggested:'CODE',       semantic:true,  aiExposed:true,  domain:'CUST_TYPE',  desc:'Customer classification',               effectiveFrom:TODAY, effectiveTo:''},
    {cd:'country_cd',       dbType:'char(3)',     pk:false, indexed:true,  nullable:false, op:false, suggested:'CODE',       semantic:true,  aiExposed:true,  domain:'ISO_COUNTRY',desc:'Domicile country',                       effectiveFrom:TODAY, effectiveTo:''},
    {cd:'tenant_cd',        dbType:'varchar(50)', pk:false, indexed:true,  nullable:false, op:true,  suggested:'CODE',       semantic:false, aiExposed:false, domain:'',           desc:'Tenant scope (operational)',             effectiveFrom:TODAY, effectiveTo:''},
    {cd:'is_active_flg',    dbType:'boolean',     pk:false, indexed:true,  nullable:false, op:true,  suggested:'—',          semantic:false, aiExposed:true,  domain:'',           desc:'Customer active status',                effectiveFrom:TODAY, effectiveTo:''},
    {cd:'lifecycle_status_cd',dbType:'varchar(30)',pk:false,indexed:true, nullable:false, op:true,  suggested:'—',          semantic:false, aiExposed:true,  domain:'',           desc:'Row lifecycle (governance)',             effectiveFrom:TODAY, effectiveTo:''},
    {cd:'created_ts',       dbType:'timestamptz', pk:false, indexed:false, nullable:false, op:true,  suggested:'—',          semantic:false, aiExposed:false, domain:'',           desc:'Row creation timestamp',                effectiveFrom:TODAY, effectiveTo:''},
    {cd:'updated_ts',       dbType:'timestamptz', pk:false, indexed:false, nullable:true,  op:true,  suggested:'—',          semantic:false, aiExposed:false, domain:'',           desc:'Last update timestamp',                 effectiveFrom:TODAY, effectiveTo:''},
  ],
  'core.loan_contract': [
    {cd:'loan_id',         dbType:'bigint',       pk:true,  indexed:true,  nullable:false,op:false,suggested:'IDENTIFIER',semantic:true, aiExposed:true, domain:'',            desc:'Surrogate loan PK',                            effectiveFrom:TODAY,effectiveTo:''},
    {cd:'loan_ref_cd',     dbType:'varchar(30)',  pk:false, indexed:true,  nullable:false,op:false,suggested:'CODE',       semantic:true, aiExposed:true, domain:'',            desc:'External loan reference (ACBS deal number)',    effectiveFrom:TODAY,effectiveTo:''},
    {cd:'customer_id',     dbType:'bigint',       pk:false, indexed:true,  nullable:false,op:false,suggested:'IDENTIFIER',semantic:true, aiExposed:true, domain:'',            desc:'FK to core.customer_master',                   effectiveFrom:TODAY,effectiveTo:''},
    {cd:'legal_entity_cd', dbType:'varchar(20)',  pk:false, indexed:true,  nullable:false,op:false,suggested:'CODE',       semantic:true, aiExposed:true, domain:'ORG_ENTITY',  desc:'Booking legal entity — FK to ref.organization_hierarchy',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'product_type_cd', dbType:'varchar(30)',  pk:false, indexed:true,  nullable:false,op:false,suggested:'CODE',       semantic:true, aiExposed:true, domain:'',            desc:'TERM_LOAN, REVOLVER, LOC',                     effectiveFrom:TODAY,effectiveTo:''},
    {cd:'currency_cd',     dbType:'char(3)',      pk:false, indexed:true,  nullable:false,op:false,suggested:'CODE',       semantic:true, aiExposed:true, domain:'ISO_CURRENCY',desc:'Facility currency — ISO 4217',                  effectiveFrom:TODAY,effectiveTo:''},
    {cd:'commitment_amt',  dbType:'numeric(22,4)',pk:false, indexed:false, nullable:false,op:false,suggested:'MEASURE',    semantic:true, aiExposed:true, domain:'',            desc:'Total committed facility amount',               effectiveFrom:TODAY,effectiveTo:''},
    {cd:'outstanding_amt', dbType:'numeric(22,4)',pk:false, indexed:false, nullable:false,op:false,suggested:'MEASURE',    semantic:true, aiExposed:true, domain:'',            desc:'Current drawn/outstanding balance',             effectiveFrom:TODAY,effectiveTo:''},
    {cd:'origination_dt',  dbType:'date',         pk:false, indexed:true,  nullable:false,op:false,suggested:'DATE',       semantic:true, aiExposed:true, domain:'',            desc:'Loan origination date',                        effectiveFrom:TODAY,effectiveTo:''},
    {cd:'maturity_dt',     dbType:'date',         pk:false, indexed:true,  nullable:false,op:false,suggested:'DATE',       semantic:true, aiExposed:true, domain:'',            desc:'Final maturity date',                          effectiveFrom:TODAY,effectiveTo:''},
    {cd:'risk_rating_cd',  dbType:'varchar(10)',  pk:false, indexed:true,  nullable:true, op:false,suggested:'CODE',       semantic:true, aiExposed:true, domain:'',            desc:'Internal credit risk rating (1–10)',            effectiveFrom:TODAY,effectiveTo:''},
    {cd:'is_regulatory_flg',dbType:'boolean',    pk:false, indexed:true,  nullable:false,op:false,suggested:'DIMENSION',  semantic:true, aiExposed:true, domain:'',            desc:'True if loan feeds a regulatory schedule',     effectiveFrom:TODAY,effectiveTo:''},
    {cd:'lifecycle_status_cd',dbType:'varchar(30)',pk:false,indexed:true,  nullable:false,op:true, suggested:'—',          semantic:false,aiExposed:true, domain:'',            desc:'Row lifecycle (ACTIVE/MATURED/WRITTEN_OFF)',   effectiveFrom:TODAY,effectiveTo:''},
    {cd:'created_ts',      dbType:'timestamptz', pk:false, indexed:false, nullable:false,op:true, suggested:'—',          semantic:false,aiExposed:false,domain:'',            desc:'Row creation timestamp',                       effectiveFrom:TODAY,effectiveTo:''},
    {cd:'updated_ts',      dbType:'timestamptz', pk:false, indexed:false, nullable:true, op:true, suggested:'—',          semantic:false,aiExposed:false,domain:'',            desc:'Last update timestamp',                        effectiveFrom:TODAY,effectiveTo:''},
  ],
  'ref.fiscal_period': [
    {cd:'period_cd',        dbType:'varchar(10)', pk:true,  indexed:true,  nullable:false,op:false,suggested:'IDENTIFIER',semantic:true, aiExposed:true, domain:'FISCAL_PERIOD',desc:'Period key e.g. 2026-Q1',           effectiveFrom:TODAY,effectiveTo:''},
    {cd:'fiscal_year_nbr',  dbType:'integer',     pk:false, indexed:true,  nullable:false,op:false,suggested:'MEASURE',   semantic:true, aiExposed:true, domain:'',            desc:'Fiscal year',                       effectiveFrom:TODAY,effectiveTo:''},
    {cd:'period_nbr',       dbType:'integer',     pk:false, indexed:true,  nullable:false,op:false,suggested:'MEASURE',   semantic:true, aiExposed:true, domain:'',            desc:'Period number within fiscal year',  effectiveFrom:TODAY,effectiveTo:''},
    {cd:'period_type_cd',   dbType:'varchar(10)', pk:false, indexed:true,  nullable:false,op:false,suggested:'CODE',      semantic:true, aiExposed:true, domain:'PERIOD_TYPE', desc:'QUARTER or MONTH',                  effectiveFrom:TODAY,effectiveTo:''},
    {cd:'period_status_cd', dbType:'varchar(20)', pk:false, indexed:true,  nullable:false,op:false,suggested:'CODE',      semantic:true, aiExposed:true, domain:'PERIOD_STATUS',desc:'OPEN / CLOSED / REGULATORY_LOCKED',effectiveFrom:TODAY,effectiveTo:''},
  ],
  'analytics.gl_balance_daily_agg': [
    {cd:'legal_entity_cd',   dbType:'LowCardinality(String)',pk:false,indexed:true, nullable:false,op:false,suggested:'CODE',    semantic:true, aiExposed:true, domain:'ORG_ENTITY',  desc:'Legal entity code',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'account_cd',        dbType:'LowCardinality(String)',pk:false,indexed:true, nullable:false,op:false,suggested:'CODE',    semantic:true, aiExposed:true, domain:'GL_ACCOUNT',  desc:'Chart of accounts code',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'currency_cd',       dbType:'FixedString(3)',        pk:false,indexed:true, nullable:false,op:false,suggested:'CODE',    semantic:true, aiExposed:true, domain:'ISO_CURRENCY',desc:'ISO 4217',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'period_cd',         dbType:'LowCardinality(String)',pk:false,indexed:true, nullable:false,op:false,suggested:'DATE',    semantic:true, aiExposed:true, domain:'FISCAL_PERIOD',desc:'Fiscal period key',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'report_dt',         dbType:'Date',                  pk:false,indexed:true, nullable:false,op:false,suggested:'DATE',    semantic:true, aiExposed:true, domain:'',            desc:'Daily snapshot date (partition key)',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'opening_balance_amt',dbType:'Decimal(22,4)',        pk:false,indexed:false,nullable:false,op:false,suggested:'MEASURE', semantic:true, aiExposed:true, domain:'',            desc:'Opening balance',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'closing_balance_amt',dbType:'Decimal(22,4)',        pk:false,indexed:false,nullable:false,op:false,suggested:'MEASURE', semantic:true, aiExposed:true, domain:'',            desc:'Closing balance',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'net_movement_amt',  dbType:'Decimal(22,4)',          pk:false,indexed:false,nullable:false,op:false,suggested:'MEASURE', semantic:true, aiExposed:true, domain:'',            desc:'Net movement (closing - opening)',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'row_count_nbr',     dbType:'UInt32',                pk:false,indexed:false,nullable:false,op:true, suggested:'—',       semantic:false,aiExposed:false,domain:'',            desc:'Source row count (lineage)',effectiveFrom:TODAY,effectiveTo:''},
  ],
  'analytics.loan_performance_daily': [
    {cd:'loan_id',              dbType:'UInt64',                 pk:false,indexed:true, nullable:false,op:false,suggested:'IDENTIFIER',semantic:true, aiExposed:true, domain:'',desc:'FK to core.loan_contract',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'snapshot_dt',          dbType:'Date',                   pk:false,indexed:true, nullable:false,op:false,suggested:'DATE',    semantic:true, aiExposed:true, domain:'',desc:'Daily snapshot date',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'outstanding_amt',      dbType:'Decimal(22,4)',           pk:false,indexed:false,nullable:false,op:false,suggested:'MEASURE', semantic:true, aiExposed:true, domain:'',desc:'Outstanding balance',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'past_due_days_nbr',    dbType:'UInt16',                  pk:false,indexed:true, nullable:false,op:false,suggested:'MEASURE', semantic:true, aiExposed:true, domain:'',desc:'Days past due',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'risk_rating_cd',       dbType:'LowCardinality(String)', pk:false,indexed:true, nullable:true, op:false,suggested:'CODE',    semantic:true, aiExposed:true, domain:'',desc:'Risk rating',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'performance_status_cd',dbType:'LowCardinality(String)', pk:false,indexed:true, nullable:false,op:false,suggested:'CODE',    semantic:true, aiExposed:true, domain:'',desc:'CURRENT/WATCH/SUBSTANDARD/DOUBTFUL/LOSS',effectiveFrom:TODAY,effectiveTo:''},
  ],
  'analytics.variance_result_cache': [
    {cd:'run_id',       dbType:'UUID',                   pk:false,indexed:true, nullable:false,op:false,suggested:'IDENTIFIER',semantic:false,aiExposed:true, domain:'',desc:'Variance run ID',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'report_id',    dbType:'LowCardinality(String)', pk:false,indexed:true, nullable:false,op:false,suggested:'CODE',    semantic:false,aiExposed:true, domain:'',desc:'Report type',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'period_cd',    dbType:'LowCardinality(String)', pk:false,indexed:true, nullable:false,op:false,suggested:'DATE',    semantic:true, aiExposed:true, domain:'FISCAL_PERIOD',desc:'Fiscal period',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'dimension_key',dbType:'String',                  pk:false,indexed:true, nullable:false,op:false,suggested:'CODE',    semantic:false,aiExposed:false,domain:'',desc:'Dimension combination JSON key',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'current_amt',  dbType:'Decimal(22,4)',           pk:false,indexed:false,nullable:false,op:false,suggested:'MEASURE', semantic:true, aiExposed:true, domain:'',desc:'Current period value',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'prior_amt',    dbType:'Decimal(22,4)',           pk:false,indexed:false,nullable:false,op:false,suggested:'MEASURE', semantic:true, aiExposed:true, domain:'',desc:'Prior period value',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'variance_amt', dbType:'Decimal(22,4)',           pk:false,indexed:false,nullable:false,op:false,suggested:'MEASURE', semantic:true, aiExposed:true, domain:'',desc:'Variance (current - prior)',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'variance_pct', dbType:'Float64',                 pk:false,indexed:false,nullable:true, op:false,suggested:'MEASURE', semantic:true, aiExposed:true, domain:'',desc:'Variance %',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'driver_cd',    dbType:'LowCardinality(String)', pk:false,indexed:true, nullable:true, op:false,suggested:'CODE',    semantic:true, aiExposed:true, domain:'',desc:'Variance driver attribution',effectiveFrom:TODAY,effectiveTo:''},
  ],
  'ref.country_master': [
    {cd:'country_cd',         dbType:'char(3)',       pk:true, indexed:true, nullable:false,op:false,suggested:'CODE',      semantic:true, aiExposed:true, domain:'ISO_COUNTRY',desc:'ISO 3166-1 alpha-3 (PK)',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'country_nm',         dbType:'varchar(100)',  pk:false,indexed:true, nullable:false,op:false,suggested:'DIMENSION', semantic:true, aiExposed:true, domain:'',          desc:'Full country name',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'iso2_cd',            dbType:'char(2)',       pk:false,indexed:true, nullable:true, op:false,suggested:'CODE',      semantic:true, aiExposed:false,domain:'',          desc:'ISO 2 code',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'region_cd',          dbType:'varchar(20)',   pk:false,indexed:true, nullable:true, op:false,suggested:'DIMENSION', semantic:true, aiExposed:true, domain:'',          desc:'UN region',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'sp_rating',          dbType:'varchar(10)',   pk:false,indexed:true, nullable:true, op:false,suggested:'CODE',      semantic:true, aiExposed:true, domain:'',          desc:'S&P rating',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'moodys_rating',      dbType:'varchar(10)',   pk:false,indexed:true, nullable:true, op:false,suggested:'CODE',      semantic:true, aiExposed:true, domain:'',          desc:'Moodys rating',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'sanction_status',    dbType:'varchar(30)',   pk:false,indexed:true, nullable:false,op:false,suggested:'CODE',      semantic:true, aiExposed:true, domain:'',          desc:'OFAC sanction status',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'is_fatf_member',     dbType:'boolean',       pk:false,indexed:true, nullable:false,op:false,suggested:'CODE',      semantic:true, aiExposed:false,domain:'ENUM_LIST',   desc:'FATF member flag',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'is_regulatory_jurisdiction',dbType:'boolean',pk:false,indexed:true, nullable:false,op:false,suggested:'CODE',     semantic:true, aiExposed:false,domain:'ENUM_LIST',   desc:'BHC regulatory jurisdiction',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'currency_cd',        dbType:'char(3)',       pk:false,indexed:true, nullable:true, op:false,suggested:'CODE',      semantic:true, aiExposed:false,domain:'ISO_CURRENCY',desc:'Local currency',effectiveFrom:TODAY,effectiveTo:''},
    {cd:'effective_from_dt',  dbType:'date',          pk:false,indexed:false,nullable:false,op:false,suggested:'DATE',      semantic:false,aiExposed:false,domain:'',          desc:'Record effective from',effectiveFrom:TODAY,effectiveTo:''},
  ],
  'ref.organization_hierarchy': [
    {cd:'org_node_cd',      dbType:'varchar(20)', pk:true,  indexed:true,  nullable:false, op:false, suggested:'IDENTIFIER', semantic:true,  aiExposed:true,  domain:'',           desc:'Unique org node code',                  effectiveFrom:TODAY, effectiveTo:''},
    {cd:'org_node_nm',      dbType:'varchar(200)',pk:false, indexed:false, nullable:false, op:false, suggested:'DIMENSION',  semantic:true,  aiExposed:true,  domain:'',           desc:'Org node full name (display attribute)', effectiveFrom:TODAY, effectiveTo:''},
    {cd:'parent_cd',        dbType:'varchar(20)', pk:false, indexed:true,  nullable:true,  op:false, suggested:'CODE',       semantic:true,  aiExposed:true,  domain:'',           desc:'Parent node code (self-referential FK)',effectiveFrom:TODAY, effectiveTo:''},
    {cd:'node_level_nbr',   dbType:'integer',     pk:false, indexed:true,  nullable:false, op:false, suggested:'MEASURE',    semantic:true,  aiExposed:true,  domain:'',           desc:'Hierarchy depth level',                 effectiveFrom:TODAY, effectiveTo:''},
    {cd:'is_regulatory_flg',dbType:'boolean',     pk:false, indexed:true,  nullable:false, op:false, suggested:'DIMENSION',  semantic:true,  aiExposed:true,  domain:'',           desc:'Participates in regulatory scope',       effectiveFrom:TODAY, effectiveTo:''},
    {cd:'lei_cd',           dbType:'char(20)',    pk:false, indexed:true,  nullable:true,  op:false, suggested:'CODE',       semantic:true,  aiExposed:true,  domain:'',           desc:'Legal Entity Identifier (GLEIF)',        effectiveFrom:TODAY, effectiveTo:''},
    {cd:'node_type_cd',     dbType:'varchar(20)', pk:false, indexed:true,  nullable:false, op:true,  suggested:'CODE',       semantic:false, aiExposed:true,  domain:'',           desc:'Node classification (operational)',      effectiveFrom:TODAY, effectiveTo:''},
    {cd:'created_ts',       dbType:'timestamptz', pk:false, indexed:false, nullable:false, op:true,  suggested:'—',          semantic:false, aiExposed:false, domain:'',           desc:'Row creation timestamp',                effectiveFrom:TODAY, effectiveTo:''},
    {cd:'updated_ts',       dbType:'timestamptz', pk:false, indexed:false, nullable:true,  op:true,  suggested:'—',          semantic:false, aiExposed:false, domain:'',           desc:'Last update timestamp',                 effectiveFrom:TODAY, effectiveTo:''},
    {cd:'version_nbr',      dbType:'integer',     pk:false, indexed:false, nullable:false, op:true,  suggested:'—',          semantic:false, aiExposed:false, domain:'',           desc:'Optimistic lock counter',               effectiveFrom:TODAY, effectiveTo:''},
  
    {cd:'country_cd',dbType:'char(3)',pk:false,indexed:true,nullable:true,op:false,suggested:'CODE',semantic:true,aiExposed:true,domain:'ISO_COUNTRY',desc:'Jurisdiction country — FK to country_master',effectiveFrom:TODAY,effectiveTo:''},],
}

// Build a generic set of governance columns for any object not in DB_COLUMNS
const GOV_SUFFIX = [
  {cd:'created_ts',       dbType:'timestamptz', pk:false,indexed:false,nullable:false,op:true,suggested:'—',semantic:false,aiExposed:false,domain:'',desc:'Row creation timestamp',    effectiveFrom:TODAY,effectiveTo:''},
  {cd:'created_by',       dbType:'varchar(100)',pk:false,indexed:false,nullable:false,op:true,suggested:'—',semantic:false,aiExposed:false,domain:'',desc:'Created by user',            effectiveFrom:TODAY,effectiveTo:''},
  {cd:'updated_ts',       dbType:'timestamptz', pk:false,indexed:false,nullable:true, op:true,suggested:'—',semantic:false,aiExposed:false,domain:'',desc:'Last update timestamp',      effectiveFrom:TODAY,effectiveTo:''},
  {cd:'updated_by',       dbType:'varchar(100)',pk:false,indexed:false,nullable:true, op:true,suggested:'—',semantic:false,aiExposed:false,domain:'',desc:'Last updated by user',        effectiveFrom:TODAY,effectiveTo:''},
  {cd:'version_nbr',      dbType:'integer',     pk:false,indexed:false,nullable:false,op:true,suggested:'—',semantic:false,aiExposed:false,domain:'',desc:'Optimistic lock counter',    effectiveFrom:TODAY,effectiveTo:''},
  {cd:'lifecycle_status_cd',dbType:'varchar(30)',pk:false,indexed:true, nullable:false,op:true,suggested:'—',semantic:false,aiExposed:true, domain:'',desc:'Row lifecycle status',      effectiveFrom:TODAY,effectiveTo:''},
]

// ── Attribute ID — numeric, sequential per data asset ──────────────────────
// Each DATA_ASSET assigns IDs 1..N to its attributes in object declaration order.
// The map key is schema.obj.cd → numeric string with asset prefix.
// Built lazily after DATA_ASSETS is defined (see below).
const makeAttrId = (schema, obj, cd, _map) => {
  if (_map) {
    const key = `${schema}.${obj}.${cd}`
    return _map[key] || '—'
  }
  // fallback during startup before map is built
  return '—'
}
// ATTR_ID_MAP is populated after DATA_ASSETS is declared (see below)

// ── Data Asset groupings (business domain view for Data Catalog LHP) ─────────
// Maps domain label → array of catalog keys that belong to it
const DATA_ASSETS = [
  {
    id:'GENERAL_LEDGER', label:'General Ledger', icon:'📊',
    desc:'Balance positions, account hierarchies, period-end entries',
    objects:['core.gl_balance'],
  },
  {
    id:'CUSTOMER',       label:'Customer',       icon:'👤',
    desc:'Customer master, relationship, classification, exposure',
    objects:['core.customer_master'],
  },
  {
    id:'ANALYTICS',      label:'Analytics & Variance', icon:'📊',
    desc:'ClickHouse analytics tables — pre-aggregated GL, loan performance, variance cache',
    objects:['analytics.gl_balance_daily_agg','analytics.loan_performance_daily','analytics.variance_result_cache'],
  },
  {
    id:'LOANS',          label:'Loans & Credit', icon:'💳',
    desc:'Loan facilities, credit exposure, risk ratings, regulatory Y-14Q-H',
    objects:['core.loan_contract'],
  },
  {
    id:'ORGANISATION',   label:'Organisation',   icon:'🏛️',
    desc:'Legal entity structure, hierarchy, regulatory scope',
    objects:['ref.organization_hierarchy'],
  },
  {
    id:'FISCAL_CALENDAR',label:'Fiscal Calendar',icon:'📅',
    desc:'Fiscal periods, regulatory submission windows, period status',
    objects:['ref.fiscal_period'],
  },
  {
    id:'REFERENCE',      label:'Reference & Regulatory', icon:'🌍',
    desc:'Country master, sanction lists, credit ratings — reference data powering filter lookups and regulatory classification',
    objects:['ref.country_master'],
  },
]

// ── Object Inventory (what the DB has vs what is registered) ────────────────
// st: REGISTERED | NEW | UPDATE_AVAILABLE | NOT_REQUIRED
// ── Object Inventory ── full set of physical objects across all schemas ──────
// st: REGISTERED | PENDING_REGISTRATION | NEW_OBJECT | NOT_ELIGIBLE
// sem / ai / cat: true = registered for that purpose, false = not, null = n/a
const OBJECT_INVENTORY = [
  // core schema
  {schema:'analytics',obj:'gl_balance_daily_agg', type:'TABLE',  st:'REGISTERED',       sem:true,  ai:true,  cat:true,  regBy:'system',    regAt:'May 25 2026',attrTotal:9,  attrReg:9,  note:'ClickHouse — pre-aggregated GL. Primary Lexie AI variance source.'},
  {schema:'analytics',obj:'loan_performance_daily',type:'TABLE', st:'REGISTERED',       sem:true,  ai:true,  cat:true,  regBy:'j.chen',    regAt:'May 25 2026',attrTotal:6,  attrReg:6,  note:'ClickHouse — daily loan performance. Y-14Q-H and stress-test feed.'},
  {schema:'analytics',obj:'variance_result_cache', type:'TABLE', st:'REGISTERED',       sem:false, ai:true,  cat:false, regBy:'system',    regAt:'May 25 2026',attrTotal:9,  attrReg:9,  note:'ClickHouse — variance pipeline output cache. Read by Lexie AI.'},
  {schema:'core',obj:'gl_balance',            type:'TABLE',  st:'REGISTERED',         sem:true,  ai:true,  cat:true,  regBy:'m.johnson', regAt:'2026-05-20', attrTotal:19, attrReg:8,  note:''},
  {schema:'core',obj:'customer_master',        type:'TABLE',  st:'REGISTERED',         sem:true,  ai:true,  cat:true,  regBy:'j.chen',    regAt:'2026-05-18', attrTotal:10, attrReg:6,  note:''},
  {schema:'core',obj:'loan_contract',          type:'TABLE',  st:'REGISTERED',         sem:true,  ai:true,  cat:true,  regBy:'j.chen',    regAt:'May 22 2026',attrTotal:15, attrReg:15, note:'Primary loan facility register — regulatory reporting source (Y-14Q-H)'},
  {schema:'core',obj:'deposit_account',        type:'TABLE',  st:'NEW_OBJECT',         sem:null,  ai:null,  cat:null,  regBy:null,        regAt:null,         attrTotal:18, attrReg:0,  note:''},
  {schema:'core',obj:'security_position',      type:'TABLE',  st:'NEW_OBJECT',         sem:null,  ai:null,  cat:null,  regBy:null,        regAt:null,         attrTotal:16, attrReg:0,  note:''},
  // ref schema
  {schema:'ref', obj:'country_master',         type:'TABLE',  st:'REGISTERED',         sem:true,  ai:true,  cat:true,  regBy:'system',    regAt:'May 01 2026', attrTotal:11, attrReg:11, note:'Country reference · OFAC + AAA rating source for filter lookups. Replicated to CH.'},
  {schema:'ref', obj:'organization_hierarchy', type:'TABLE',  st:'REGISTERED',         sem:true,  ai:true,  cat:true,  regBy:'s.patel',   regAt:'2026-05-10', attrTotal:10, attrReg:6,  note:''},
  {schema:'ref', obj:'fiscal_period',          type:'TABLE',  st:'REGISTERED',         sem:true,  ai:true,  cat:true,  regBy:'system',    regAt:'2026-04-01', attrTotal:8,  attrReg:5,  note:''},
  {schema:'ref', obj:'currency',               type:'TABLE',  st:'NEW_OBJECT',         sem:null,  ai:null,  cat:null,  regBy:null,        regAt:null,         attrTotal:6,  attrReg:0,  note:''},
  {schema:'ref', obj:'country',                type:'TABLE',  st:'NEW_OBJECT',         sem:null,  ai:null,  cat:null,  regBy:null,        regAt:null,         attrTotal:7,  attrReg:0,  note:''},
  // report schema
  {schema:'report',obj:'submission_log',       type:'TABLE',  st:'PENDING_REGISTRATION',sem:true, ai:true,  cat:true,  regBy:'m.johnson', regAt:null,         attrTotal:14, attrReg:0,  note:'Pending governance approval'},
  {schema:'report',obj:'report_definition',    type:'TABLE',  st:'NEW_OBJECT',         sem:null,  ai:null,  cat:null,  regBy:null,        regAt:null,         attrTotal:9,  attrReg:0,  note:''},
  // intelligence schema
  {schema:'intelligence',obj:'variance_analysis',type:'VIEW', st:'NEW_OBJECT',         sem:null,  ai:null,  cat:null,  regBy:null,        regAt:null,         attrTotal:11, attrReg:0,  note:''},
  // meta schema — AI only, not semantic (governance/operational objects)
  {schema:'meta', obj:'workflow_task',          type:'TABLE',  st:'REGISTERED',         sem:false, ai:true,  cat:false, regBy:'a.kim',     regAt:'2026-03-01', attrTotal:22, attrReg:22, note:'AI-only: Lexie can answer workflow questions'},
  {schema:'meta', obj:'attribute_catalog',      type:'TABLE',  st:'REGISTERED',         sem:false, ai:true,  cat:false, regBy:'system',    regAt:'2026-04-01', attrTotal:28, attrReg:28, note:'AI-only: Lexie uses this for metadata context'},
  // logic schema — not eligible (operational engine internals)
  {schema:'logic',obj:'rule_catalog',           type:'TABLE',  st:'NOT_ELIGIBLE',       sem:false, ai:false, cat:false, regBy:null,        regAt:null,         attrTotal:22, attrReg:0,  note:'Rules engine internal — not for semantic exposure'},
  {schema:'logic',obj:'dag_result_store',       type:'TABLE',  st:'NOT_ELIGIBLE',       sem:false, ai:false, cat:false, regBy:null,        regAt:null,         attrTotal:14, attrReg:0,  note:'DAG bridge table — served via semantic-service indirectly'},
  // iam schema — not eligible (security boundary)
  {schema:'iam',  obj:'user_profile',           type:'TABLE',  st:'NOT_ELIGIBLE',       sem:false, ai:false, cat:false, regBy:null,        regAt:null,         attrTotal:12, attrReg:0,  note:'Security boundary — no semantic or AI exposure'},
  {schema:'iam',  obj:'api_key',                type:'TABLE',  st:'NOT_ELIGIBLE',       sem:false, ai:false, cat:false, regBy:null,        regAt:null,         attrTotal:8,  attrReg:0,  note:'Security boundary — credentials table'},
  // workspace schema — not eligible
  {schema:'workspace',obj:'scratch_table',      type:'TABLE',  st:'NOT_ELIGIBLE',       sem:false, ai:false, cat:false, regBy:null,        regAt:null,         attrTotal:5,  attrReg:0,  note:'Analyst sandbox — transient, TTL-governed'},
]

// ── Tenant Workspaces (Logical Hierarchy / Semantic Layer folder by tenant) ──
const TENANT_WORKSPACES = [
  {
    id:'WS-ALL', tenant:'ALL (Global)', desc:'Default global workspace — all tenants see these objects',
    objects:['core.gl_balance','ref.organization_hierarchy','ref.fiscal_period'],
    cubes:['core_gl_balance','ref_org_hierarchy','ref_fiscal_period'],
    st:'ACTIVE', createdBy:'system', updatedAt:'2026-04-01',
  },
  {
    id:'WS-BHC-A', tenant:'BHC_A001 — Bank Holding Co Alpha', desc:'Tenant-specific workspace for BHC Alpha. Includes full GL scope plus customer master.',
    objects:['core.gl_balance','core.customer_master','ref.organization_hierarchy','ref.fiscal_period'],
    cubes:['core_gl_balance','ref_org_hierarchy','ref_fiscal_period'],
    st:'ACTIVE', createdBy:'s.patel', updatedAt:'2026-05-10',
  },
  {
    id:'WS-BHC-B', tenant:'BHC_B002 — Bank Holding Co Beta', desc:'Beta tenant workspace. Restricted to organisation and period reference data pending onboarding.',
    objects:['ref.organization_hierarchy','ref.fiscal_period'],
    cubes:['ref_org_hierarchy','ref_fiscal_period'],
    st:'REVIEW', createdBy:'j.chen', updatedAt:'2026-05-18',
  },
]

// ── Build ATTR_ID_MAP: numeric IDs per data asset ─────────────────────────
// Each DATA_ASSET assigns sequential IDs to its attributes.
// ID format: {assetPrefix}-{NNN} e.g. GL-001, CU-002
// The same physical attribute can appear in multiple assets and gets different IDs per context.
// ATTR_ID_MAP key: "schema.obj.cd" → {id: 'GL-001', seq: 1, prefix: 'GL'}
const ASSET_PREFIXES = {
  'GENERAL_LEDGER':  'GL',
  'CUSTOMER':        'CU',
  'ORGANISATION':    'OR',
  'FISCAL_CALENDAR': 'FP',
}
const ATTR_ID_MAP = {}
;(function buildAttrIds() {
  DATA_ASSETS.forEach(asset => {
    const pfx = ASSET_PREFIXES[asset.id] || asset.id.slice(0,2)
    let seq = 1
    asset.objects.forEach(objKey => {
      const cat = CATALOG[objKey]
      if (!cat) return
      ;(cat.attrs||[]).forEach(a => {
        const key = `${cat.schema}.${cat.obj}.${a.cd}`
        if (!ATTR_ID_MAP[key]) { // first asset wins for the primary ID
          ATTR_ID_MAP[key] = {
            id: `${pfx}-${String(seq).padStart(3,'0')}`,
            seq,
            prefix: pfx,
            asset: asset.label,
          }
        }
        a.attrId  = ATTR_ID_MAP[key].id
        a.attrSeq = ATTR_ID_MAP[key].seq
        seq++
      })
    })
  })
  // Attrs not in any data asset get schema-prefix IDs
  Object.values(CATALOG).forEach(cat => {
    ;(cat.attrs||[]).forEach(a => {
      if (!a.attrId) {
        a.attrId  = `${cat.schema.slice(0,2).toUpperCase()}-${cat.obj.slice(0,3).toUpperCase()}-???`
        a.attrSeq = 999
      }
    })
  })
})()

// Tenant CDE overrides (tenant can tag/retag attrs organically or manually)
// key: "schema.obj.cd|tenant" → {cde:'CDE'|'DE'|null, source:'ORGANIC'|'HUMAN', taggedBy, taggedAt}
const TENANT_CDE_TAGS = {
  'core.gl_balance.balance_amt|BHC_A001': {cde:'CDE',source:'ORGANIC',taggedBy:'system',taggedAt:'2026-04-01'},
  'core.gl_balance.legal_entity_cd|BHC_A001': {cde:'CDE',source:'ORGANIC',taggedBy:'system',taggedAt:'2026-04-01'},
  'core.customer_master.customer_nm|BHC_A001': {cde:'DE', source:'HUMAN', taggedBy:'j.chen',taggedAt:'2026-05-10'},
  'ref.organization_hierarchy.org_node_cd|BHC_B002': {cde:'CDE',source:'HUMAN',taggedBy:'s.patel',taggedAt:'2026-05-18'},
}

const HIERARCHIES = [
  {cd:'ENTITY_HIERARCHY', nm:'Legal Entity Hierarchy', tenant:'ALL', levels:[
    {n:1,label:'Bank Holding Company',attr:'org_node_nm',cd:'org_node_cd',obj:'ref.organization_hierarchy'},
    {n:2,label:'Bank / Subsidiary',   attr:'org_node_nm',cd:'org_node_cd',obj:'ref.organization_hierarchy'},
    {n:3,label:'Division / Region',   attr:'org_node_nm',cd:'org_node_cd',obj:'ref.organization_hierarchy'},
  ], usedBy:['Y-9C Schedule HC','Variance Attribution','Rules Authoring'], st:'ACTIVE'},
  {cd:'PERIOD_HIERARCHY', nm:'Fiscal Period Hierarchy', tenant:'ALL', levels:[
    {n:1,label:'Fiscal Year',  attr:'fiscal_year_nbr',cd:'fiscal_year_nbr',obj:'ref.fiscal_period'},
    {n:2,label:'Fiscal Period',attr:'period_cd',       cd:'period_cd',       obj:'ref.fiscal_period'},
  ], usedBy:['Variance Attribution','Analytical Reporting'], st:'ACTIVE'},
]

const RELATIONSHIPS = [
  {cd:'GL_TO_ORG',    from:'core.gl_balance',from_col:'legal_entity_cd',to:'ref.organization_hierarchy',to_col:'org_node_cd',type:'MANY_TO_ONE',st:'ACTIVE'},
  {cd:'GL_TO_PERIOD', from:'core.gl_balance',from_col:'period_cd',       to:'ref.fiscal_period',         to_col:'period_cd',   type:'MANY_TO_ONE',st:'ACTIVE'},
]

const WF = [
  {id:1,obj:'core.loan_contract',type:'OBJECT_REGISTRATION', by:'j.chen',  at:'May 22',st:'APPROVED',pri:'HIGH'},
  {id:2,obj:'CUST_NAME_TO_ID pairing',type:'PAIRING_ACTIVATION',by:'s.patel',at:'May 22',st:'PENDING',pri:'HIGH'},
  {id:3,obj:'ref.organization_hierarchy',type:'ATTRIBUTE_UPDATE',by:'m.johnson',at:'May 21',st:'APPROVED',pri:'MEDIUM'},
  {id:4,obj:'GL_ACCT_DESC_TO_CD',type:'PAIRING_ACTIVATION',by:'a.kim',at:'May 20',st:'PENDING',pri:'MEDIUM'},
]

// Client logical name override requests (feeds meta.attribute_logical_name_override)
const LN_OVERRIDE_REQUESTS = [
  {id:'LNO-001', tenant:'BHC_A001', schema_cd:'core', object_cd:'gl_balance', attribute_cd:'legal_entity_cd',
   current_short:'Legal Entity CD', current_long:'Legal Entity Code',
   proposed_short:'LE Code', proposed_long:'Legal Entity Code',
   reason:'Our users refer to legal entities as "LE" universally. Aligning UI labels reduces confusion.',
   by:'a.ramirez@bhca.com', at:'May 24', st:'PENDING', pri:'MEDIUM'},
  {id:'LNO-002', tenant:'BHC_B002', schema_cd:'core', object_cd:'loan_contract', attribute_cd:'outstanding_amt',
   current_short:'Outstanding Amt', current_long:'Current Drawn/Outstanding Balance',
   proposed_short:'Net Exposure', proposed_long:'Net Credit Exposure in Functional Currency',
   reason:'Regulatory capital reporting uses "Net Exposure" terminology. Aligns with Y-14Q-H column header.',
   by:'t.kim@bhcb.com', at:'May 23', st:'PENDING', pri:'HIGH'},
  {id:'LNO-002b', tenant:'BHC_B002', schema_cd:'core', object_cd:'gl_balance', attribute_cd:'balance_amt',
   current_short:'Balance Amt', current_long:'Ledger Balance Amount',
   proposed_short:'Net Balance', proposed_long:'Net Balance in Functional Currency',
   reason:'Regulatory reporting uses "Net Balance" terminology. Current label causes confusion in dashboards.',
   by:'t.kim@bhcb.com', at:'May 23', st:'PENDING', pri:'HIGH'},
  {id:'LNO-003', tenant:'BHC_A001', schema_cd:'core', object_cd:'customer_master', attribute_cd:'customer_type_cd',
   current_short:'Cust Type CD', current_long:'Customer Classification Code',
   proposed_short:'Client Type', proposed_long:'Client Classification Type',
   reason:'Our CRM uses "Client" not "Customer". Consistent terminology improves training adoption.',
   by:'s.patel@bhca.com', at:'May 22', st:'APPROVED', pri:'LOW'},
]

const INITIAL_RELS = [
  {cd:'GL_TO_PERIOD',     from:'core.gl_balance',       from_col:'period_cd',  to:'ref.fiscal_period',         to_col:'period_cd',  type:'MANY_TO_ONE', st:'ACTIVE'},
  {cd:'GL_TO_ORG',        from:'core.gl_balance',       from_col:'legal_entity_cd', to:'ref.organization_hierarchy', to_col:'org_node_cd', type:'MANY_TO_ONE', st:'ACTIVE'},
  {cd:'LOAN_TO_CUSTOMER', from:'core.loan_contract',    from_col:'customer_id',to:'core.customer_master',       to_col:'customer_id',type:'MANY_TO_ONE', st:'ACTIVE'},
  {cd:'LOAN_TO_ORG',      from:'core.loan_contract',    from_col:'legal_entity_cd', to:'ref.organization_hierarchy', to_col:'org_node_cd', type:'MANY_TO_ONE', st:'PENDING'},
  {cd:'CH_GL_AGG_TO_PERIOD',from:'analytics.gl_balance_daily_agg',from_col:'period_cd',  to:'ref.fiscal_period',         to_col:'period_cd',  type:'MANY_TO_ONE', st:'ACTIVE',  crossEngine:true},
  {cd:'CH_GL_AGG_TO_ORG',   from:'analytics.gl_balance_daily_agg',from_col:'legal_entity_cd',to:'ref.organization_hierarchy',to_col:'org_node_cd',type:'MANY_TO_ONE',st:'ACTIVE', crossEngine:true},
  {cd:'CH_LOAN_PERF_TO_LOAN',from:'analytics.loan_performance_daily',from_col:'loan_id',to:'core.loan_contract',        to_col:'loan_id',    type:'MANY_TO_ONE', st:'ACTIVE',  crossEngine:true},
  {cd:'CUSTOMER_TO_COUNTRY', from:'core.customer_master',          from_col:'country_cd', to:'ref.country_master',     to_col:'country_cd', type:'MANY_TO_ONE', st:'ACTIVE'},
  {cd:'ORG_TO_COUNTRY',      from:'ref.organization_hierarchy',    from_col:'country_cd', to:'ref.country_master',     to_col:'country_cd', type:'MANY_TO_ONE', st:'ACTIVE'},
  {cd:'GL_TO_COUNTRY',       from:'core.gl_balance',               from_col:'country_cd', to:'ref.country_master',     to_col:'country_cd', type:'MANY_TO_ONE', st:'ACTIVE'},
]

// ══════════════════════════════════════════════════════════════════════
// DESIGN ATOMS
// ══════════════════════════════════════════════════════════════════════
const semClr = s => s==='MEASURE'?{c:L.teal,bg:L.tealBg}:s==='IDENTIFIER'?{c:L.pur,bg:L.purBg}:s==='CODE'?{c:L.blue,bg:L.blueBg}:s==='DATE'?{c:L.amb,bg:L.ambBg}:{c:L.t3,bg:L.s4}
const stClr  = s => s==='ACTIVE'||s==='APPROVED'?{c:L.grn,bg:L.grnBg}:s==='PENDING'||s==='REVIEW'?{c:L.amb,bg:L.ambBg}:s==='REJECTED'?{c:L.cor,bg:L.corBg}:{c:L.t4,bg:L.s4}
const priClr = p => p==='HIGH'?{c:L.cor,bg:L.corBg}:p==='MEDIUM'?{c:L.amb,bg:L.ambBg}:{c:L.t3,bg:L.s4}
const stgClr = s => s==='CACHED_LOOKUP'?{c:L.teal,bg:L.tealBg}:s==='INLINE_MAP'?{c:L.blue,bg:L.blueBg}:s==='RUNTIME_QUERY'?{c:L.amb,bg:L.ambBg}:{c:L.t3,bg:L.s4}

const Chip = ({text,c,bg,sz=11}) => (
  <span style={{display:'inline-flex',alignItems:'center',padding:'2px 8px',borderRadius:4,
    fontSize:sz,fontWeight:600,background:bg,color:c,letterSpacing:'0.02em',
    whiteSpace:'nowrap',lineHeight:1.6}}>{text}</span>
)
const SBadge  = ({st})  => { const {c,bg}=stClr(st);  return <Chip text={st}   c={c} bg={bg}/> }
const SemBadge= ({s})   => { const {c,bg}=semClr(s);  return <Chip text={s}    c={c} bg={bg} sz={10}/> }
const StgBadge= ({s})   => { const {c,bg}=stgClr(s);  return <Chip text={s}    c={c} bg={bg}/> }

const Btn = ({label,icon:Icon,primary,small,danger,onClick,disabled}) => (
  <button onClick={onClick} disabled={disabled} style={{
    display:'inline-flex',alignItems:'center',gap:6,cursor:disabled?'not-allowed':'pointer',
    padding:small?'5px 11px':'8px 15px',borderRadius:6,border:'none',
    fontSize:small?11:13,fontWeight:600,opacity:disabled?.5:1,
    background:primary?L.teal:danger?L.cor:L.s1,
    color:primary?'#fff':danger?'#fff':L.t2,
    boxShadow:primary?`0 0 0 1px ${L.teal}`:danger?`0 0 0 1px ${L.cor}`:`0 0 0 1px ${L.bd}`,
  }}>{Icon&&<Icon size={small?11:14}/>}{label}</button>
)

const PageHdr = ({title,sub,icon:Icon,action}) => (
  <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',marginBottom:24}}>
    <div style={{display:'flex',alignItems:'flex-start',gap:12}}>
      {Icon&&<div style={{width:36,height:36,borderRadius:9,background:L.tealBg,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,marginTop:2}}><Icon size={18} color={L.teal}/></div>}
      <div>
        <h1 style={{margin:0,fontSize:19,fontWeight:700,color:L.t1,lineHeight:1.2}}>{title}</h1>
        {sub&&<p style={{margin:'5px 0 0',fontSize:12,color:L.t3,lineHeight:1.55,maxWidth:560}}>{sub}</p>}
      </div>
    </div>
    {action&&<div style={{flexShrink:0,marginLeft:16}}>{action}</div>}
  </div>
)

const Card = ({title,action,children,mt=0,accent,noPad}) => (
  <div style={{background:L.s1,border:`1px solid ${accent||L.bd}`,borderRadius:10,
    padding:noPad?0:20,marginTop:mt,overflow:noPad?'hidden':undefined}}>
    {title&&<div style={{display:'flex',alignItems:'center',justifyContent:'space-between',
      marginBottom:14,padding:noPad?'14px 16px 0':0}}>
      <span style={{fontSize:13,fontWeight:600,color:L.t1}}>{title}</span>
      {action}
    </div>}
    {children}
  </div>
)

const StatCard = ({value,label,icon:Icon,color}) => (
  <div style={{flex:1,background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:'16px 18px'}}>
    <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:8}}>
      <span style={{fontSize:26,fontWeight:700,color:L.t1}}>{value}</span>
      <div style={{width:34,height:34,borderRadius:8,background:color+'22',display:'flex',alignItems:'center',justifyContent:'center'}}>
        <Icon size={16} color={color}/>
      </div>
    </div>
    <div style={{fontSize:11,color:L.t3,lineHeight:1.4}}>{label}</div>
  </div>
)

// Horizontal tabs component (Governance style)
const HorizTabs = ({tabs,active,onChange}) => (
  <div style={{display:'flex',borderBottom:`2px solid ${L.bd}`,marginBottom:20,gap:0}}>
    {tabs.map(t => {
      const on = active===t.id
      return (
        <button key={t.id} onClick={()=>onChange(t.id)} style={{
          display:'flex',alignItems:'center',gap:7,padding:'10px 18px',
          border:'none',cursor:'pointer',fontSize:13,fontWeight:on?700:400,
          color:on?L.teal:L.t3,background:'transparent',
          borderBottom:on?`3px solid ${L.teal}`:'3px solid transparent',
          marginBottom:-2,transition:'color .15s',
        }}
        onMouseEnter={e=>{if(!on)e.currentTarget.style.color=L.t2}}
        onMouseLeave={e=>{if(!on)e.currentTarget.style.color=L.t3}}>
          {t.icon&&<t.icon size={14}/>}{t.label}
          {t.badge!=null&&<span style={{fontSize:9,fontWeight:700,background:on?L.teal:L.bd,
            color:on?'#fff':L.t3,borderRadius:10,padding:'1px 5px',marginLeft:2}}>{t.badge}</span>}
        </button>
      )
    })}
  </div>
)

const SelectInput = ({label,value,onChange,opts,options,placeholder,req,disabled}) => {
  const items = opts||options||[]
  return (
    <div>
      <label style={{display:'block',fontSize:11,fontWeight:600,color:L.t2,marginBottom:5}}>
        {label}{req&&<span style={{color:L.cor}}> *</span>}
      </label>
      <select value={value} onChange={e=>onChange(e.target.value)} disabled={disabled}
        style={{width:'100%',padding:'8px 10px',border:`1px solid ${L.bd}`,borderRadius:6,
          fontSize:13,color:value?L.t1:L.t4,background:L.s1,outline:'none',
          opacity:disabled?0.5:1}}>
        <option value="">{placeholder||'Select…'}</option>
        {items.map(o=>{
          const val = o?.value!==undefined?o.value:(o?.v!==undefined?o.v:o)
          const lbl = o?.label!==undefined?o.label:(o?.l!==undefined?o.l:o)
          return <option key={String(val)} value={String(val)}>{lbl}</option>
        })}
      </select>
    </div>
  )
}

const TextInput = ({label,value,onChange,placeholder,req,mono}) => (
  <div>
    <label style={{display:'block',fontSize:11,fontWeight:600,color:L.t2,marginBottom:5}}>
      {label}{req&&<span style={{color:L.cor}}> *</span>}
    </label>
    <input value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
      style={{width:'100%',padding:'8px 10px',border:`1px solid ${L.bd}`,borderRadius:6,
        fontSize:mono?12:13,color:L.t1,fontFamily:mono?L.mono:L.font,
        boxSizing:'border-box',outline:'none'}}/>
  </div>
)

const TextArea = ({label,value,onChange,placeholder,req,rows=3}) => (
  <div>
    <label style={{display:'block',fontSize:11,fontWeight:600,color:L.t2,marginBottom:5}}>
      {label}{req&&<span style={{color:L.cor}}> *</span>}
    </label>
    <textarea value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} rows={rows}
      style={{width:'100%',padding:'8px 10px',border:`1px solid ${L.bd}`,borderRadius:6,
        fontSize:13,color:L.t1,resize:'vertical',boxSizing:'border-box',outline:'none',lineHeight:1.6}}/>
  </div>
)

const InfoBanner = ({text,color=L.teal,bg=L.tealBg}) => (
  <div style={{padding:'9px 14px',background:bg,border:`1px solid ${color}44`,borderRadius:7,
    fontSize:12,color:color==='#b83830'?L.corDk:L.t2,lineHeight:1.6,marginTop:8}}>{text}</div>
)

const DateInput = ({label,value,onChange,req}) => (
  <div>
    <label style={{display:'block',fontSize:11,fontWeight:600,color:L.t2,marginBottom:5}}>
      {label}{req&&<span style={{color:L.cor}}> *</span>}
    </label>
    <input type="date" value={value||''} onChange={e=>onChange(e.target.value)}
      style={{width:'100%',padding:'8px 10px',border:`1px solid ${L.bd}`,borderRadius:6,
        fontSize:13,color:L.t1,fontFamily:L.font,outline:'none',boxSizing:'border-box'}}/>
  </div>
)

// ── Inventory status config — used by RegisterScreen inventory grid ───────
const INV_ST = {
  REGISTERED:           {c:'#2d6a10', bg:'#e5f3db', label:'Registered'},
  PENDING_REGISTRATION: {c:'#B87414', bg:'#faeeda', label:'Pending'},
  NEW_OBJECT:           {c:'#2265B8', bg:'#e4eef9', label:'New Object'},
  HAS_UPDATE:           {c:'#9A6700', bg:'#fbf1d6', label:'Has Updates'},
  NOT_ELIGIBLE:         {c:'#7a9cc8', bg:'#E4EEF9', label:'Not Eligible'},
}
// Registration-queue helpers (single source of truth = OBJECT_INVENTORY).
// "Has Updates" = already REGISTERED but unregistered attributes remain (attrReg < attrTotal).
const regDispStatus   = o => (o.st==='REGISTERED' && o.attrReg < o.attrTotal) ? 'HAS_UPDATE' : o.st
const isRegActionable  = o => o.st==='NEW_OBJECT' || o.st==='PENDING_REGISTRATION' || o.st==='NOT_ELIGIBLE' || (o.st==='REGISTERED' && o.attrReg < o.attrTotal)

// ── CheckMark — Semantic/AI/Catalog registration checkmark ───────────────

// ── Connection config ──────────────────────────────────────────────────────
const CONN_CFG = {
  'lextr-pg':  {label:'PG',  color:'#1D9E75', bg:'#E1F5EE', full:'Lextr PostgreSQL'},
  'lextr-ch':  {label:'CH',  color:'#BA7517', bg:'#FAEEDA', full:'Lextr ClickHouse'},
  'client':    {label:'EXT', color:'#534AB7', bg:'#EEEDFE', full:'Client (federated)'},
}
const connCfg = (id) => CONN_CFG[id] || CONN_CFG['lextr-pg']

// ── EngineBadge — small pill showing PG / CH / EXT ────────────────────────
const EngineBadge = ({connectionId, tiny}) => {
  const cfg = connCfg(connectionId)
  return (
    <span title={cfg.full} style={{
      display:'inline-flex', alignItems:'center',
      padding: tiny ? '1px 5px' : '2px 7px',
      borderRadius:10,
      fontSize: tiny ? 8 : 9,
      fontWeight:700, fontFamily:L.mono,
      color:cfg.color, background:cfg.bg,
      border:`1px solid ${cfg.color}44`,
      whiteSpace:'nowrap', flexShrink:0,
    }}>{cfg.label}</span>
  )
}

// ── isCrossEngine: both objects must have different connectionId ───────────
const isCrossEngineRel = (rel) => {
  const fromConn = CATALOG[rel.from]?.connectionId || 'lextr-pg'
  const toConn   = CATALOG[rel.to]?.connectionId   || 'lextr-pg'
  return fromConn !== toConn || rel.crossEngine
}


// ── OPA Policy Engine (mock) ───────────────────────────────────────────────
// Simulates Open Policy Agent evaluation. In production this calls the
// OPA REST API: POST /v1/data/lextr/semantic/allow  { input: context }
const OPA_POLICIES = {
  'POL-CE-001': {
    id:          'POL-CE-001',
    name:        'Cross-engine relationship prohibition',
    description: 'Semantic relationships between objects on different physical engines (PostgreSQL ↔ ClickHouse) are not permitted without explicit federation approval. Cross-engine joins bypass the semantic layer governance surface and cannot be audited end-to-end.',
    scope:       ['RELATIONSHIP_REGISTRATION'],
    severity:    'BLOCK',
    exception_path: 'Submit a Policy Exception via Workflow Queue → Approval Queue',
  },
  'POL-CE-002': {
    id:          'POL-CE-002',
    name:        'Cross-engine attribute pairing prohibition',
    description: 'Attribute pairings that reference display or filter attributes across different physical engines are not permitted. Pairing resolution requires a consistent execution path — mixed-engine pairings produce unpredictable latency and cannot be cached uniformly.',
    scope:       ['PAIRING_REGISTRATION'],
    severity:    'BLOCK',
    exception_path: 'Submit a Policy Exception via Workflow Queue → Approval Queue',
  },
  'POL-SV-001': {
    id:          'POL-SV-001',
    name:        'Stale lookup value prohibition',
    description: 'Filter lookups containing INACTIVE_IN_SOURCE values may not be used in new rule bindings or regulatory pipelines until stale values are formally retired or re-certified. Existing bindings continue under a grace period but generate governance alerts. Root cause: multi-point failure pattern where booking system inactivation is not reflected in lookup — reporting continues in error.',
    scope:       ['FILTER_LOOKUP_BINDING','RULE_REGISTRATION','PIPELINE_EXECUTION'],
    severity:    'WARN_ON_USE',   // BLOCK for new bindings, WARN for existing
    exception_path: 'Retire the inactive value (creates workflow task) or re-certify with documented justification via Workflow Queue.',
    gracePeriodDays: 14,          // existing bindings warned for 14 days then blocked
    autoRetireAfterDays: 180,     // value auto-retired if not seen in source for 180 days
  },
  'POL-SV-002': {
    id:          'POL-SV-002',
    name:        'Overdue lookup review prohibition',
    description: 'Filter lookups whose review period has elapsed without certification may not be used in new regulatory pipeline bindings. The review period is set by the reporting team on each lookup. Failure to review is itself a governance finding — it replicates the audit condition where the team did not know a stale value was in scope.',
    scope:       ['FILTER_LOOKUP_BINDING','PIPELINE_EXECUTION'],
    severity:    'BLOCK',
    exception_path: 'Certify the lookup values via Filter Lookups → Certify values button. Requires governance workflow approval.',
    reviewGraceDays: 7,           // 7 days past nextReview before blocking kicks in
  },
  'POL-CE-003': {
    id:          'POL-CE-003',
    name:        'Cross-engine workspace query prohibition',
    description: 'Query Studio workspaces may not mix PostgreSQL and ClickHouse attributes in the same query session. Queries must execute on a single engine. Use pre-aggregated ClickHouse tables (analytics schema) or PostgreSQL transactional tables — not both simultaneously.',
    scope:       ['QUERY_EXECUTION'],
    severity:    'BLOCK',
    exception_path: 'Request a Federation Exception via Workflow Queue. Approved workspaces may use the MATERIALISE_SMALLER cross-engine policy.',
  },
}

// Returns null (allowed) or the policy object (blocked)
const opaEvaluate = (policyId, context) => {
  const pol = OPA_POLICIES[policyId]
  if (!pol) return null
  // Evaluate: is this a cross-engine operation?
  const { fromConn, toConn, srcConn, wsEngines } = context
  if (policyId === 'POL-CE-001' && fromConn && toConn && fromConn !== toConn) return pol
  if (policyId === 'POL-CE-002' && srcConn && toConn && srcConn !== toConn)   return pol
  if (policyId === 'POL-CE-003' && wsEngines && new Set(wsEngines).size > 1)   return pol
  if (policyId === 'POL-SV-001') { const {inactiveCount}=context; if(inactiveCount>0) return pol }
  if (policyId === 'POL-SV-002') { const {reviewOverdue}=context; if(reviewOverdue) return pol }
  return null
}

// ── PolicyBlock component ─────────────────────────────────────────────────
const PolicyBlock = ({policy, context, compact}) => {
  if (!policy) return null
  const cfg = connCfg(context?.fromConn||'lextr-pg')
  const cfg2= connCfg(context?.toConn||context?.srcConn||'lextr-ch')
  return (
    <div style={{
      padding: compact ? '10px 14px' : '16px 18px',
      background:'#FCEBEB', border:'1px solid #F09595',
      borderRadius:9, marginBottom:compact?0:16,
    }}>
      {/* Header */}
      <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:compact?4:10}}>
        <div style={{width:22,height:22,borderRadius:5,background:'#E24B4A',
          display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
          <Shield size={13} color="#fff"/>
        </div>
        <span style={{fontSize:compact?11:13,fontWeight:700,color:'#501313'}}>
          Blocked by governance policy
        </span>
        <span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,
          color:'#A32D2D',background:'#F7C1C1',padding:'2px 7px',borderRadius:3,
          border:'1px solid #F09595',marginLeft:'auto'}}>
          {policy.id}
        </span>
      </div>
      {/* Policy name */}
      <div style={{fontSize:compact?11:12,fontWeight:700,color:'#791F1F',marginBottom:compact?4:8}}>
        {policy.name}
      </div>
      {/* Engine context */}
      <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:compact?4:10}}>
        <EngineBadge connectionId={context?.fromConn||context?.srcConn||'lextr-pg'}/>
        <span style={{fontSize:11,color:'#A32D2D',fontWeight:700}}>↔</span>
        <EngineBadge connectionId={context?.toConn||'lextr-ch'}/>
        <span style={{fontSize:11,color:'#791F1F',marginLeft:4}}>cross-engine operation blocked</span>
      </div>
      {!compact&&(
        <>
          <div style={{fontSize:12,color:'#791F1F',lineHeight:1.6,marginBottom:10,
            padding:'8px 10px',background:'#F7C1C1',borderRadius:6}}>
            {policy.description}
          </div>
          <div style={{display:'flex',alignItems:'center',gap:8,flexWrap:'wrap'}}>
            <div style={{fontSize:11,fontWeight:700,color:'#A32D2D'}}>To request an exception:</div>
            <div style={{fontSize:11,color:'#791F1F'}}>{policy.exception_path}</div>
            <button onClick={()=>window.alert&&undefined}
              style={{marginLeft:'auto',padding:'5px 12px',borderRadius:6,
                border:'1px solid #E24B4A',background:'transparent',
                cursor:'pointer',fontSize:11,fontWeight:700,color:'#A32D2D'}}>
              Request exception →
            </button>
          </div>
        </>
      )}
    </div>
  )
}

function CheckMark({val, disabled}) {
  if (disabled || val===null || val===undefined)
    return <span style={{color:L.bd,fontSize:14,display:'block',textAlign:'center'}}>—</span>
  if (val===true)
    return <span style={{color:'#2d6a10',fontSize:13,fontWeight:700,display:'block',textAlign:'center'}}>✓</span>
  return <span style={{color:L.cor,fontSize:12,fontWeight:700,display:'block',textAlign:'center'}}>✗</span>
}

// ── Shared sub-LHP design tokens (light theme, matches main sidebar) ─────
// Used by CatalogScreen and any future capability with an inner tree panel.
const SL = {
  bg:         '#ffffff',
  border:     '#c8d9ee',
  div:        '#ddeaf8',
  hov:        '#eef3fa',
  schema:     '#1e3a5f',
  objNm:      '#0e1e35',
  attrNm:     '#4a6fa5',
  dim:        '#7a9cc8',
  sectionBg:  '#eef3fa',
  selObj:     '#e4eef9',
  selAttr:    '#eeedfe',
  selTeal:    '#e8f6f0',
  accentObj:  '#2265B8',
  accentAttr: '#6657CC',
  accentAsset:'#1D9E75',
}

// Simple graph stub (placeholder for Cytoscape reusable component)

const Toggle = ({on, onChange, label, onColor='#1D9E75'}) => (
  <div onClick={()=>onChange(!on)} style={{
    display:'inline-flex',alignItems:'center',gap:5,cursor:'pointer',userSelect:'none',
    padding:'3px 9px',borderRadius:12,
    border:`1px solid ${on?onColor:'#c8d9ee'}`,
    background:on?onColor+'18':'#e4eef9',
  }}>
    <div style={{width:8,height:8,borderRadius:4,background:on?onColor:'#7a9cc8'}}/>
    <span style={{fontSize:10,fontWeight:700,color:on?onColor:'#7a9cc8'}}>{on?label:'Off'}</span>
  </div>
)

const MiniLineageGraph = ({objKey}) => {
  const obj = CATALOG[objKey]
  if (!obj) return null
  const rels = obj.relationships||[]
  return (
    <div style={{background:L.nv,borderRadius:8,padding:16,minHeight:140,position:'relative'}}>
      <div style={{fontSize:10,fontWeight:700,color:'#5a7898',textTransform:'uppercase',letterSpacing:'.07em',marginBottom:12}}>
        Lineage graph — {objKey}
        <span style={{marginLeft:8,fontSize:9,color:'#3d5a7a'}}>(Full Cytoscape graph via Lextr Lineage component)</span>
      </div>
      <div style={{display:'flex',alignItems:'center',gap:12,flexWrap:'wrap'}}>
        {/* Center node */}
        <div style={{padding:'8px 14px',background:'#1D9E7530',border:`2px solid ${L.teal}`,
          borderRadius:8,color:L.teal,fontSize:12,fontWeight:700,fontFamily:L.mono}}>
          {objKey}
        </div>
        {rels.map(r=>(
          <div key={r.to} style={{display:'flex',alignItems:'center',gap:8}}>
            <ArrowRight size={14} color='#5a7898'/>
            <div style={{padding:'6px 12px',background:'#2878CC20',border:`1px solid ${L.blue}`,
              borderRadius:6,color:L.blue,fontSize:11,fontFamily:L.mono}}>
              {r.to}
            </div>
            <span style={{fontSize:9,color:'#5a7898'}}>{r.type}</span>
          </div>
        ))}
        {rels.length===0&&<span style={{color:'#5a7898',fontSize:11}}>No joins registered</span>}
      </div>
      {obj.usedBy?.length>0&&(
        <div style={{marginTop:12,paddingTop:10,borderTop:'1px solid #1e3a5f'}}>
          <span style={{fontSize:10,color:'#5a7898',fontWeight:600}}>USED BY: </span>
          {(obj.usedBy||[]).map(u=><span key={u} style={{fontSize:10,background:'#1e3a5f',color:'#a8c4dc',borderRadius:4,padding:'2px 7px',marginLeft:6}}>{u}</span>)}
        </div>
      )}
    </div>
  )
}


// ── Governance-style random draft ID ──────────────────────────────────────
// Generates IDs like REG-M99NJ8, REL-P4KWZ2, PAIR-X8BNQ5 (same format as
// Lextr Governance: PRE-M99NJ8, POL-M98UNE, KH-M976B5)
const GOVID_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
const randId = (prefix) => {
  let s = ''
  for (let i=0;i<6;i++) s+=GOVID_CHARS[Math.floor(Math.random()*GOVID_CHARS.length)]
  return `${prefix}-${s}`
}

// ── illustrative append-only governance history for catalog-style inventory items ──
function govEvents({name, kind='Object', status='ACTIVE', by='a.rao', team='Data Governance', seed=0}){
  const D=(off)=>{ const b=new Date('2026-05-22T00:00:00Z'); b.setDate(b.getDate()-off-(seed%9)); return b.toISOString().slice(0,10) }
  const st=(status||'ACTIVE').toString().toUpperCase()
  const live=['ACTIVE','CERTIFIED','PUBLISHED','APPROVED','REGISTERED','VERIFIED'].includes(st)
  const ev=[]
  if (live) ev.push({t:'Activated', badge:'ACTIVE', date:D(2), desc:`${kind} active and governed.`, by, team})
  else      ev.push({t:'In review', badge:'AUTHORING', date:D(2), desc:`${kind} pending governance approval (${st}).`, by, team})
  ev.push({t:'Reviewed', badge:'WORKFLOW', date:D(9), desc:'Definition reviewed by data governance.', by:'m.lin', team:'Data Governance'})
  ev.push({t:'Registered', badge:'WORKFLOW', date:D(16), desc:`${name} registered into the catalog.`, by, team})
  ev.push({t:'Created (draft)', badge:'DRAFT', date:D(25), desc:`${name} drafted.`, by, team})
  return ev
}
// reusable history icon-button for inventory rows
function HistBtn({onClick, color}){
  return <button onClick={(e)=>{e.stopPropagation();onClick()}} title="History" style={{background:'none',border:'none',cursor:'pointer',color:color||'#9bb0cc',padding:4,display:'flex',alignItems:'center'}}
    onMouseEnter={e=>e.currentTarget.style.color='#0E7C7B'} onMouseLeave={e=>e.currentTarget.style.color=color||'#9bb0cc'}><History size={15}/></button>
}
// tenant scope: GLOBAL (shared) vs a specific client tenant
const TENANTS = ['GLOBAL','BHC_A001','BHC_B002']
function TenantChip({tenant, sz=9}){
  const g = !tenant || tenant==='GLOBAL'
  return <span style={{display:'inline-flex',alignItems:'center',gap:4,padding:'2px 7px',borderRadius:4,fontSize:sz,fontWeight:700,whiteSpace:'nowrap',
    color:g?'#0F6E56':'#534AB7', background:g?'#E1F5EE':'#EEEDFE'}} title={g?'Global — shared across all tenants':`Client tenant ${tenant}`}>{g?<Globe size={sz+2}/>:<User size={sz+2}/>}{g?'GLOBAL':tenant}</span>
}

// ── Governance-style inline tab strip ─────────────────────────────────────
// Matches the Lextr Governance tab pattern exactly:
//   [Base Tab | Base Tab | ● DRAFT-ID × | ● DRAFT-ID × | + Create New]
// base:   [{id, label}]  — non-closeable left tabs (Inventory, ER Diagram…)
// drafts: [{id}]          — closeable amber-dot draft tabs
// activeId: currently selected id (null = first base tab)
function GovTabStrip({base, drafts, activeId, onSelect, onClose, addLabel, onAdd}) {
  return (
    <div style={{
      display:'flex', alignItems:'stretch',
      borderBottom:`1px solid ${L.bd}`, marginBottom:20,
      overflowX:'auto', flexShrink:0,
    }}>
      {/* Base (non-closeable) tabs */}
      {base.map(t=>{
        const on = activeId===t.id
        return (
          <button key={String(t.id)} onClick={()=>onSelect(t.id)} style={{
            padding:'9px 18px', border:'none', cursor:'pointer',
            background:'transparent', fontSize:13,
            fontWeight:on?600:400, color:on?L.teal:L.t3,
            borderBottom:on?`2px solid ${L.teal}`:'2px solid transparent',
            whiteSpace:'nowrap', flexShrink:0, transition:'background .1s',
          }}
          onMouseEnter={e=>{if(!on)e.currentTarget.style.background=L.s3}}
          onMouseLeave={e=>{if(!on)e.currentTarget.style.background='transparent'}}>
            {t.label}
          </button>
        )
      })}

      {/* Draft (closeable, amber-dot) tabs */}
      {drafts.map(d=>{
        const on = activeId===d.id
        return (
          <div key={d.id} onClick={()=>onSelect(d.id)} style={{
            display:'flex', alignItems:'center', gap:7,
            padding:'0 14px', cursor:'pointer', flexShrink:0,
            background:on?L.ambBg+'80':'transparent',
            borderBottom:on?`2px solid ${L.amb}`:'2px solid transparent',
            transition:'background .1s',
          }}
          onMouseEnter={e=>{if(!on)e.currentTarget.style.background=L.s3}}
          onMouseLeave={e=>{if(!on)e.currentTarget.style.background=on?L.ambBg+'80':'transparent'}}>
            <span style={{color:L.amb,fontSize:10,lineHeight:1,flexShrink:0}}>●</span>
            <span style={{
              fontSize:13, fontWeight:on?600:400, color:on?L.t1:L.t3,
              whiteSpace:'nowrap',
            }}>{d.id}</span>
            <button onClick={e=>{e.stopPropagation();onClose(d.id)}} style={{
              background:'none', border:'none', cursor:'pointer', lineHeight:1,
              color:L.t4, fontSize:16, padding:'0 2px',
              display:'flex', alignItems:'center',
            }}
            onMouseEnter={e=>e.currentTarget.style.color=L.cor}
            onMouseLeave={e=>e.currentTarget.style.color=L.t4}>×</button>
          </div>
        )
      })}

      {/* + New action tab — always last */}
      <button onClick={onAdd} style={{
        display:'flex', alignItems:'center', gap:6,
        padding:'9px 16px', border:'none', cursor:'pointer',
        background:'transparent', fontSize:13, fontWeight:400, color:L.teal,
        borderBottom:'2px solid transparent', flexShrink:0, transition:'background .1s',
      }}
      onMouseEnter={e=>e.currentTarget.style.background=L.tealBg}
      onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
        <Plus size={13} style={{flexShrink:0}}/>{addLabel}
      </button>
    </div>
  )
}

// ── Governance-style draft action bar (two-row, matches screenshots exactly) ──
function DraftActionBar({id, accentColor, onDiscard, onSaveDraft, onSubmit, blocked, incomplete, incompleteMsg}) {
  const col = accentColor || L.amb
  const btnBase = {cursor:'pointer', borderRadius:6, fontSize:12, fontWeight:500}
  const isDisabled = blocked || incomplete
  return (
    <Fragment>
      {/* Row 1 — compact identity + main actions */}
      <div style={{
        display:'flex', alignItems:'center', gap:10,
        padding:'8px 16px', marginBottom:8,
        background:L.s1, border:`1px solid ${L.bd}`, borderRadius:8,
      }}>
        <span style={{color:L.amb,fontSize:12,lineHeight:1}}>●</span>
        <span style={{fontSize:13,fontWeight:500,color:L.t2}}>Draft</span>
        <span style={{
          fontFamily:L.mono,fontSize:11,fontWeight:700,color:col,
          background:L.s3,padding:'2px 8px',borderRadius:4,border:`1px solid ${col}44`,
        }}>{id}</span>
        {blocked&&(
          <span style={{display:'flex',alignItems:'center',gap:5,fontSize:11,fontWeight:700,
            color:'#A32D2D',background:'#FCEBEB',padding:'3px 9px',borderRadius:5,
            border:'1px solid #F09595'}}>
            <Shield size={11}/> Blocked by policy
          </span>
        )}
        {incomplete&&!blocked&&(
          <span style={{fontSize:11,color:L.t3,fontStyle:'italic'}}>
            {incompleteMsg||'Complete required fields to submit'}
          </span>
        )}
        <div style={{flex:1}}/>
        <button onClick={onDiscard} style={{...btnBase,padding:'5px 14px',border:`1px solid ${L.bd}`,background:L.s1,color:L.t2}}>Discard</button>
        <button onClick={onSaveDraft} style={{...btnBase,padding:'5px 14px',border:`1px solid ${L.bd}`,background:L.s1,color:L.t2}}>Save Draft</button>
        <button onClick={isDisabled?undefined:onSubmit}
          style={{...btnBase,padding:'5px 16px',border:'none',
            background:blocked?'#B4B2A9':incomplete?L.s4:L.teal,
            color:incomplete?L.t3:'#fff',
            cursor:isDisabled?'not-allowed':'pointer',
            opacity:isDisabled?0.7:1}}>
          {blocked?'Blocked — policy violation':incomplete?'Submit for Approval':'Submit for Approval'}
        </button>
      </div>

    </Fragment>
  )
}

// ══════════════════════════════════════════════════════════════════════
// SCREEN 1: SEMANTIC HUB
// ══════════════════════════════════════════════════════════════════════
function HubScreen({onNav}) {
  const objCount = OBJECTS.length
  const attrCount = OBJECTS.reduce((s,k)=>s+(CATALOG[k]?.attrs?.length||0),0)
  const pending = WF.filter(w=>w.st==='PENDING').length
  const pairings = PAIRINGS.filter(p=>p.st==='ACTIVE').length
  return (
    <div>
      <PageHdr title="Semantic Hub" icon={LayoutDashboard}
        sub="Registration portal for existing DB objects · Data catalog · Attribute pairing · Logical hierarchy"
        action={<Btn label="Register Object" icon={Plus} primary onClick={()=>onNav('register')}/>}/>

      <div style={{display:'flex',gap:10,marginBottom:12}}>
        <StatCard value={objCount}   label="Objects registered in catalog"  icon={Table2}     color={L.teal}/>
        <StatCard value={attrCount}  label="Attributes catalogued"          icon={Columns}    color={L.blue}/>
        <StatCard value={pairings}   label="Active attribute pairings"      icon={Link2}      color={L.pur}/>
        <StatCard value={HIERARCHIES.length} label="Logical hierarchies"   icon={TreePine}   color={L.amb}/>
        <StatCard value={pending}    label="Pending governance approvals"   icon={Clock}      color={L.cor}/>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1.4fr',gap:12,marginBottom:12}}>
        <Card title="Semantic layer — what this portal does">
          {[
            {icon:Table2,   color:L.teal,label:'Register existing DB objects', sub:'Tables/views already in PostgreSQL — describe them for AI and consumers'},
            {icon:Columns,  color:L.blue,label:'Register attributes',          sub:'Column-level metadata, domain values, AI context — prerequisite for pairing'},
            {icon:Link2,    color:L.pur, label:'Establish attribute pairings', sub:'display_attr → filter_attr cross-column substitution for optimized SQL'},
            {icon:Network,  color:L.amb, label:'Define join relationships',    sub:'Becomes semantic-service YAML joins section — registered here, not in backend'},
            {icon:TreePine, color:L.grn, label:'Build logical hierarchies',    sub:'Canonical 2–3 level attribute trees available across all capabilities'},
          ].map(({icon:Icon,color,label,sub})=>(
            <div key={label} style={{display:'flex',gap:10,padding:'8px 0',borderBottom:`1px solid ${L.bd2}`}}>
              <div style={{width:28,height:28,borderRadius:7,background:color+'18',
                display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                <Icon size={13} color={color}/>
              </div>
              <div>
                <div style={{fontSize:12,fontWeight:600,color:L.t1}}>{label}</div>
                <div style={{fontSize:11,color:L.t3,marginTop:1}}>{sub}</div>
              </div>
            </div>
          ))}
        </Card>

        <Card title="Recent workflow activity">
          {WF.map(w=>(
            <div key={w.id} style={{display:'flex',alignItems:'center',gap:10,
              padding:'9px 0',borderBottom:`1px solid ${L.bd2}`}}>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:12,fontWeight:600,color:L.t1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{w.obj}</div>
                <div style={{fontSize:11,color:L.t3,marginTop:2}}>{w.type} · {w.by} · {w.at}</div>
              </div>
              <SBadge st={w.st}/>
            </div>
          ))}
          <div style={{marginTop:12}}><Btn label="View all" icon={ChevronRight} small onClick={()=>onNav('workflow')}/></div>
        </Card>
      </div>

      <Card title="Quick navigation">
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
          {[
            {label:'Data Catalog',        Icon:BookOpen,    color:L.blue, sub:'Browse registered objects and attributes', id:'catalog'},
            {label:'Register Object',     Icon:Plus,        color:L.teal, sub:'Register existing table + attributes',    id:'register'},
            {label:'Relationship Mgmt',   Icon:Network,     color:L.amb,  sub:'JOIN definitions for semantic-service YAML',      id:'relationships'},
            {label:'Attribute Pairing',   Icon:Link2,       color:L.pur,  sub:'Manage display→filter substitutions',     id:'pairings'},
            {label:'Filter Lookups',      Icon:Filter,      color:L.teal, sub:'Cross-engine semi-join filter sets',      id:'lookups'},
            {label:'Semantic Workspaces', Icon:Globe,       color:L.grn,  sub:'Prototype only — not in development manifest',    id:'hierarchy'},
            {label:'Query Studio',        Icon:Play,        color:L.teal, sub:'Test semantic queries with trace',        id:'query'},
            {label:'Workflow Queue',      Icon:CheckSquare, color:L.cor,  sub:`${pending} pending approvals`,            id:'workflow'},
            {label:'Downstream Consumption',Icon:GitBranch, color:L.blue, sub:'Configure consumption-layer exposures (placeholder)', id:'consumption'},
            {label:'Data Quality',        Icon:Shield,    color:L.pur,  sub:'DQ matrix, rules & rule requests (placeholder)', id:'dq'},
            {label:'Data Profiling',      Icon:BarChart2, color:L.blue, sub:'Attribute profiling results (placeholder)', id:'profiling'},
            {label:'Data Observability',  Icon:Activity,  color:L.cor,  sub:'Pipeline & store signals (placeholder)', id:'observability'},
          ].map(({label,Icon,color,sub,id,wt})=>(
            <div key={id} onClick={()=>onNav(id)} style={{padding:'13px',borderRadius:8,
              border:`1px solid ${L.bd}`,cursor:'pointer',transition:'border-color .15s'}}
              onMouseEnter={e=>e.currentTarget.style.borderColor=color}
              onMouseLeave={e=>e.currentTarget.style.borderColor=L.bd}>
              <div style={{width:28,height:28,borderRadius:7,background:color+'1a',
                display:'flex',alignItems:'center',justifyContent:'center',marginBottom:9}}>
                <Icon size={13} color={color}/>
              </div>
              <div style={{fontSize:12,fontWeight:600,color:L.t1}}>{label}</div>
              <div style={{fontSize:11,color:L.t3,marginTop:2,lineHeight:1.4}}>{sub}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════
// SCREEN 2: DATA CATALOG (Read-Only) — dual-view LHP
// lhpView='technical' → Schema→Table tree
// lhpView='asset'     → Domain→Object tree
// ══════════════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════════════
// SCREEN 2: DATA CATALOG (Read-Only)
// LHP: Technical (Schema→Table→Attribute leaf) | Data Asset (Asset→Attribute leaf)
// Attr grid: toggle Physical name | Logical name | Both
// Attrs tagged CDE (critical data element) or DE (data element) by tenant
// ══════════════════════════════════════════════════════════════════════
function CatalogScreen() {
  const [lhpView,   setLhpView]   = useState('technical')
  const [catSearch,  setCatSearch]  = useState('')
  const [selTenant, setSelTenant] = useState('ALL')
  const [nameMode,  setNameMode]  = useState('both')

  // Selection — either an object OR an attribute leaf
  // selType: 'object' | 'attribute'
  const [selType,     setSelType]     = useState(null)
  const [selObjKey,   setSelObjKey]   = useState(null)  // schema.obj
  const [selAttrKey,  setSelAttrKey]  = useState(null)  // schema.obj.attrCd
  const [attrSearch,  setAttrSearch]  = useState('')

  // LHP expand state
  const [expandedSchemas, setExpandedSchemas] = useState({core:true,ref:true})
  const [expandedObjs,    setExpandedObjs]    = useState({})
  const [expandedAssets,  setExpandedAssets]  = useState({[DATA_ASSETS[0].id]:true})

  // Object-level tab (only shown when selType==='object')
  const [objTab, setObjTab] = useState('overview')
  const [histCat, setHistCat] = useState(false)

  // Derived
  const activeObj  = selObjKey ? CATALOG[selObjKey] : null
  const activeAttr = useMemo(()=>{
    if (!selAttrKey) return null
    const parts = selAttrKey.split('.')
    const cd = parts[parts.length-1]
    const objKey = parts.slice(0,-1).join('.')
    return { cd, ...(CATALOG[objKey]?.attrs||[]).find(a=>a.cd===cd), objKey }
  },[selAttrKey])

  const bySchema = useMemo(()=>{
    const m={}
    OBJECTS.forEach(k=>{ const s=CATALOG[k].schema; if(!m[s])m[s]=[]; m[s].push(k) })
    return m
  },[])

  const getEffCde = (schema,obj,cd) => {
    const tk=`${schema}.${obj}.${cd}|${selTenant}`, ak=`${schema}.${obj}.${cd}|ALL`
    if (TENANT_CDE_TAGS[tk]) return TENANT_CDE_TAGS[tk]
    if (TENANT_CDE_TAGS[ak]) return TENANT_CDE_TAGS[ak]
    const a=CATALOG[`${schema}.${obj}`]?.attrs?.find(x=>x.cd===cd)
    return a?.cde?{cde:a.cde,source:a.cdeSource||'HUMAN'}:null
  }

  const cdeColor = c => c==='CDE'?{c:'#7B2FBE',bg:'#F0E6FF'}:c==='DE'?{c:'#0E6BA8',bg:'#E0F0FF'}:{c:'#7a9cc8',bg:'#E4EEF9'}

  const CdeBadge = ({cde,tiny}) => {
    if (!cde) return null
    const {c,bg}=cdeColor(cde)
    return <span style={{display:'inline-flex',alignItems:'center',
      padding:tiny?'1px 4px':'2px 6px',borderRadius:3,fontSize:tiny?8:10,
      fontWeight:800,background:bg,color:c,letterSpacing:'0.04em',whiteSpace:'nowrap',marginLeft:3}}>{cde}</span>
  }

  // LHP item selection handlers
  const pickObj  = (k) => { setSelObjKey(k); setSelType('object');    setSelAttrKey(null); setObjTab('overview'); setAttrSearch('') }
  const pickAttr = (objKey,cd) => {
    const aKey=`${objKey}.${cd}`
    if (selAttrKey===aKey) { setSelAttrKey(null); setSelType('object'); return }
    setSelObjKey(objKey); setSelAttrKey(aKey); setSelType('attribute'); setAttrSearch('')
  }

  // Attribute-level tabs
  const attrTabs = [
    {id:'detail',  label:'Detail',      icon:Info},
    {id:'ops',     label:'Operational', icon:Settings},
    {id:'dq',      label:'Data Quality',icon:Shield, badge:cxRules.all().filter(r=>r.obj===activeAttr?.objKey&&((r.attrs&&r.attrs.includes(activeAttr?.ln||activeAttr?.cd))||r.attr===(activeAttr?.ln||activeAttr?.cd))).length||undefined},
    {id:'usage',   label:'Usage',       icon:Activity},
    {id:'ai',      label:'AI Context',  icon:Zap},
    {id:'cde',     label:'CDE / DE',    icon:Tag},
  ]
  const [attrTab, setAttrTab] = useState('detail')

  // Object-level tabs
  const objTabs = [
    {id:'overview', label:'Overview',        icon:Info},
    {id:'attrs',    label:'Attributes',      icon:Columns, badge:activeObj?.attrs?.length},
    {id:'dq',       label:'Data Quality',    icon:Shield, badge:cxRules.all().filter(r=>r.obj===selObjKey).length||undefined},
    {id:'lineage',  label:'Lineage & Usage', icon:Activity},
    {id:'ai',       label:'AI Context',      icon:Zap},
    {id:'rels',     label:'Relationships',   icon:Network},
  ]

  // ── LHP style helpers (dark navy matching main LHP) ──────────────────────
  // Sub-LHP uses global SL tokens
  const filteredAttrs = useMemo(()=>{
    if (!activeObj) return []
    return (activeObj.attrs||[]).filter(a=>!attrSearch||
      a.cd.toLowerCase().includes(attrSearch.toLowerCase())||
      (a.ln||'').toLowerCase().includes(attrSearch.toLowerCase())||
      (a.attrId||'').toLowerCase().includes(attrSearch.toLowerCase())||
      a.desc.toLowerCase().includes(attrSearch.toLowerCase()))
  },[activeObj,attrSearch])

  return (
    <div>
      <PageHdr title="Data Catalog" icon={BookOpen}
        sub="Select an attribute from the tree to see its full detail. Select a table to browse all attributes."
        action={<InfoBanner text="Read-only — use Register Object to update" color={L.amb} bg={L.ambBg}/>}/>

      {/* Toolbar */}
      <div style={{display:'flex',gap:10,marginBottom:12,alignItems:'center',flexWrap:'wrap'}}>
        <div style={{display:'flex',alignItems:'center',gap:6}}>
          <span style={{fontSize:11,fontWeight:600,color:L.t2}}>Tenant:</span>
          {['ALL','BHC_A001','BHC_B002'].map(t=>(
            <button key={t} onClick={()=>setSelTenant(t)} style={{
              padding:'4px 11px',borderRadius:12,fontSize:11,fontWeight:600,cursor:'pointer',
              border:`1px solid ${selTenant===t?L.blue:L.bd}`,
              background:selTenant===t?L.blueBg:L.s1,color:selTenant===t?L.blue:L.t3}}>{t}</button>
          ))}
        </div>
        <div style={{width:1,height:18,background:L.bd}}/>
        <div style={{display:'flex',alignItems:'center',gap:6}}>
          <span style={{fontSize:11,fontWeight:600,color:L.t2}}>Names:</span>
          {[{id:'physical',l:'Physical'},{id:'logical',l:'Logical'},{id:'both',l:'Both'}].map(n=>(
            <button key={n.id} onClick={()=>setNameMode(n.id)} style={{
              padding:'4px 11px',borderRadius:12,fontSize:11,fontWeight:600,cursor:'pointer',
              border:`1px solid ${nameMode===n.id?L.pur:L.bd}`,
              background:nameMode===n.id?L.purBg:L.s1,color:nameMode===n.id?L.purDk:L.t3}}>{n.l}</button>
          ))}
        </div>
        <div style={{flex:1}}/>
        <span style={{padding:'2px 7px',borderRadius:3,background:'#F0E6FF',color:'#7B2FBE',fontWeight:800,fontSize:10}}>CDE</span>
        <span style={{fontSize:10,color:L.t3}}>= Regulatory</span>
        <span style={{marginLeft:6,padding:'2px 7px',borderRadius:3,background:'#E0F0FF',color:'#0E6BA8',fontWeight:800,fontSize:10}}>DE</span>
        <span style={{fontSize:10,color:L.t3}}>= Analytical / operational</span>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'240px 1fr',gap:12}}>

        {/* ═══════════════════════════════════════════════════════════
            SUB-LHP — light theme, matches main sidebar
        ═══════════════════════════════════════════════════════════ */}
        <div style={{background:SL.bg,borderRadius:10,overflow:'hidden',
          display:'flex',flexDirection:'column',maxHeight:'calc(100vh - 210px)',
          border:`1px solid ${SL.border}`}}>

          {/* View toggle */}
          <div style={{display:'flex',background:SL.sectionBg,borderBottom:`1px solid ${SL.div}`,flexShrink:0}}>
            {[{id:'technical',label:'Technical'},{id:'asset',label:'Data Asset'}].map(v=>{
              const on=lhpView===v.id
              return (
                <button key={v.id} onClick={()=>setLhpView(v.id)} style={{
                  flex:1,padding:'9px 4px',border:'none',cursor:'pointer',fontSize:11,fontWeight:700,
                  background:on?SL.selObj:'transparent',
                  color:on?SL.accentObj:SL.dim,
                  borderBottom:on?`2px solid ${SL.accentObj}`:'2px solid transparent',
                }}>{v.label}</button>
              )
            })}
          </div>
          {/* Mode hint */}
          <div style={{padding:'4px 12px',background:SL.sectionBg,borderBottom:`1px solid ${SL.div}`,flexShrink:0,fontSize:9,color:SL.dim,letterSpacing:'.04em'}}>
            {lhpView==='technical'?'Schema → Table → Attribute':'Data Asset → Attribute'}
          </div>
          {/* Search box */}
          <div style={{padding:'6px 10px',background:SL.bg,borderBottom:`1px solid ${SL.div}`,flexShrink:0}}>
            <div style={{position:'relative'}}>
              <Search size={11} style={{position:'absolute',left:8,top:'50%',transform:'translateY(-50%)',color:SL.dim,pointerEvents:'none'}}/>
              <input
                value={catSearch} onChange={e=>setCatSearch(e.target.value)}
                placeholder="Search objects and attributes…"
                style={{width:'100%',padding:'5px 26px 5px 26px',borderRadius:6,
                  border:`1px solid ${catSearch?SL.accentAttr:SL.div}`,
                  background:SL.sectionBg,fontSize:11,color:SL.attrNm,
                  outline:'none',boxSizing:'border-box',fontFamily:'inherit'}}/>
              {catSearch&&<button onClick={()=>setCatSearch('')}
                style={{position:'absolute',right:6,top:'50%',transform:'translateY(-50%)',
                  background:'none',border:'none',cursor:'pointer',color:SL.dim,fontSize:12,padding:0}}>✕</button>}
            </div>
            {catSearch&&<div style={{fontSize:9,color:SL.dim,marginTop:3}}>
              {(()=>{
                const q=catSearch.toLowerCase()
                const objHits=Object.keys(CATALOG).filter(k=>k.toLowerCase().includes(q)||CATALOG[k].logicalShortNm?.toLowerCase().includes(q)||CATALOG[k].logicalLongNm?.toLowerCase().includes(q)).length
                const attrHits=Object.values(CATALOG).flatMap(o=>o.attrs||[]).filter(a=>a.cd.toLowerCase().includes(q)||a.ln?.toLowerCase().includes(q)||a.desc?.toLowerCase().includes(q)).length
                return `${objHits} object${objHits!==1?'s':''} · ${attrHits} attribute${attrHits!==1?'s':''}`
              })()}
            </div>}
          </div>

          {/* Tree */}
          <div style={{flex:1,overflow:'auto'}}>

            {/* Technical tree */}
            {lhpView==='technical' && (()=>{
              const q = catSearch.toLowerCase()
              const filteredSchema = Object.entries(bySchema).reduce((acc,[schema,objs])=>{
                const matched = objs.filter(k=>{
                  if(!q) return true
                  const o = CATALOG[k]
                  const objMatch = k.toLowerCase().includes(q)
                    || o?.logicalShortNm?.toLowerCase().includes(q)
                    || o?.logicalLongNm?.toLowerCase().includes(q)
                  const attrMatch = (o?.attrs||[]).some(a=>
                    a.cd.toLowerCase().includes(q) || a.ln?.toLowerCase().includes(q) || (a.desc||'').toLowerCase().includes(q))
                  return objMatch || attrMatch
                })
                if(matched.length) acc[schema] = matched
                return acc
              },{})
              const entries = q ? Object.entries(filteredSchema) : Object.entries(bySchema)
              if(q && entries.length===0) return (
                <div style={{padding:'24px 16px',textAlign:'center',color:SL.dim,fontSize:11}}>
                  No objects or attributes match <strong style={{color:SL.attrNm}}>"{catSearch}"</strong>
                </div>
              )
              return entries.map(([schema,keys])=>{
              const schOpen=expandedSchemas[schema]
              return (
                <div key={schema}>
                  {/* Schema header */}
                  <div onClick={()=>setExpandedSchemas(p=>({...p,[schema]:!p[schema]}))}
                    style={{padding:'6px 14px',cursor:'pointer',userSelect:'none',
                      display:'flex',alignItems:'center',gap:6,
                      background:SL.sectionBg,
                      borderBottom:`1px solid ${SL.div}`,borderTop:`1px solid ${SL.div}`}}>
                    <span style={{fontSize:9,color:SL.dim}}>{schOpen?'▾':'▸'}</span>
                    <Database size={9} color={SL.dim}/>
                    <span style={{fontSize:9,fontWeight:700,color:SL.schema,textTransform:'uppercase',letterSpacing:'.08em',flex:1}}>{schema}</span>
                    <span style={{fontSize:8,color:SL.dim}}>{keys.length}</span>
                  </div>

                  {schOpen && (keys||[]).map(k=>{
                    const o=CATALOG[k]
                    const objOpen=expandedObjs[k]
                    const onObj=selObjKey===k&&selType==='object'
                    return (
                      <div key={k}>
                        {/* Table row */}
                        <div style={{
                          display:'flex',alignItems:'center',padding:'7px 14px 7px 22px',
                          cursor:'pointer',borderBottom:`1px solid ${SL.div}`,gap:6,
                          background:onObj?SL.selObj:SL.hov,
                          borderLeft:onObj?`3px solid ${L.blue}`:'3px solid transparent',
                        }}
                        onMouseEnter={e=>{if(!onObj)e.currentTarget.style.background=SL.hov}}
                        onMouseLeave={e=>{if(!onObj)e.currentTarget.style.background='transparent'}}
                        onClick={()=>{pickObj(k);setExpandedObjs(p=>({...p,[k]:!p[k]}))}}>
                          <span style={{fontSize:9,color:SL.dim,flexShrink:0}}>{objOpen?'▾':'▸'}</span>
                          <Table2 size={10} color={onObj?L.blue:SL.dim}/>
                          <div style={{flex:1,minWidth:0,overflow:'hidden'}}>
                            {o.logicalShortNm&&<div style={{fontSize:9,fontWeight:700,
                              color:onObj?'rgba(255,255,255,0.85)':L.tealDk,
                              lineHeight:1.2,marginBottom:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                              {o.logicalShortNm}</div>}
                            <div style={{fontFamily:L.mono,fontSize:10,
                              color:onObj?'rgba(255,255,255,0.7)':SL.objNm,
                              overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{o.obj}</div>
                          </div>
                          {o.connectionId==='lextr-ch'&&<EngineBadge connectionId="lextr-ch" tiny/>}
                        </div>

                        {/* Attribute leaves */}
                        {objOpen&&(o.attrs||[]).map(a=>{
                          const aKey=`${k}.${a.cd}`
                          const onA=selAttrKey===aKey
                          const cdeInfo=getEffCde(o.schema,o.obj,a.cd)
                          const dispName=nameMode==='logical'?(a.ln||a.cd):nameMode==='physical'?a.cd:`${a.cd}`
                          return (
                            <div key={a.cd} onClick={()=>pickAttr(k,a.cd)}
                              style={{display:'flex',alignItems:'center',
                                padding:'5px 14px 5px 38px',cursor:'pointer',
                                borderBottom:`1px solid ${SL.div}`,gap:4,
                                background:onA?SL.selAttr:'transparent',
                                borderLeft:onA?`3px solid ${L.pur}`:'3px solid transparent',
                              }}
                              onMouseEnter={e=>{if(!onA)e.currentTarget.style.background=SL.hov}}
                              onMouseLeave={e=>{if(!onA)e.currentTarget.style.background='transparent'}}>
                              <span style={{fontFamily:L.mono,fontSize:9,
                                color:onA?SL.accentAttr:SL.attrNm,flex:1,minWidth:0,
                                overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{dispName}</span>
                              {a.pk&&<span style={{fontSize:7,fontWeight:800,color:L.pur,flexShrink:0}}>PK</span>}
                              {a.indexed&&!a.pk&&<span style={{fontSize:7,fontWeight:800,color:L.grn,flexShrink:0}}>IDX</span>}
                              {cdeInfo?.cde&&<CdeBadge cde={cdeInfo.cde} tiny/>}
                            </div>
                          )
                        })}
                      </div>
                    )
                  })}
                </div>
              )
            })
            })()}

            {/* Data Asset tree */}
            {lhpView==='asset' && (()=>{
              const q=catSearch.toLowerCase()
              const filteredAssets = DATA_ASSETS.map(asset=>({
                ...asset,
                attrs: asset.objects.flatMap(k=>{
                  const o=CATALOG[k]; if(!o) return []
                  return (o.attrs||[]).filter(a=>!q||a.cd.toLowerCase().includes(q)||a.ln?.toLowerCase().includes(q)||(a.desc||'').toLowerCase().includes(q)).map(a=>({...a,objKey:k}))
                })
              })).filter(asset=>!q||asset.attrs.length>0||asset.label.toLowerCase().includes(q))
              if(q && filteredAssets.every(a=>a.attrs.length===0)) return (
                <div style={{padding:'24px 16px',textAlign:'center',color:SL.dim,fontSize:11}}>
                  No attributes match <strong style={{color:SL.attrNm}}>"{catSearch}"</strong>
                </div>
              )
              return filteredAssets.map(asset=>{
              const open=expandedAssets[asset.id]
              const allAttrs=asset.objects.flatMap(k=>{
                const o=CATALOG[k]; if(!o) return []
                return (o.attrs||[]).map(a=>({...a,objKey:k,schema:o.schema,obj:o.obj}))
              })
              return (
                <div key={asset.id}>
                  {/* Asset header */}
                  <div onClick={()=>setExpandedAssets(p=>({...p,[asset.id]:!p[asset.id]}))}
                    style={{padding:'8px 14px',cursor:'pointer',userSelect:'none',
                      display:'flex',alignItems:'center',gap:8,
                      background:open?SL.selTeal:SL.sectionBg,
                      borderBottom:`1px solid ${SL.div}`,borderTop:`1px solid ${SL.div}`,
                      borderLeft:open?`3px solid ${L.teal}`:'3px solid transparent',}}>
                    <span style={{fontSize:14}}>{asset.icon}</span>
                    <div style={{flex:1}}>
                      <div style={{fontSize:11,fontWeight:700,color:open?'#fff':SL.objNm,lineHeight:1.2}}>{asset.label}</div>
                      <div style={{fontSize:9,color:SL.dim,marginTop:1}}>{allAttrs.length} attrs</div>
                    </div>
                    <span style={{fontSize:10,color:SL.dim}}>{open?'▾':'▸'}</span>
                  </div>
                  {open&&(allAttrs||[]).map((a,i)=>{
                    const aKey=`${a.objKey}.${a.cd}`; const onA=selAttrKey===aKey
                    const cdeInfo=getEffCde(a.schema,a.obj,a.cd)
                    const dispName=nameMode==='logical'?(a.ln||a.cd):nameMode==='physical'?a.cd:a.cd
                    return (
                      <div key={aKey} onClick={()=>pickAttr(a.objKey,a.cd)}
                        style={{display:'flex',alignItems:'center',padding:'5px 14px 5px 28px',
                          cursor:'pointer',borderBottom:`1px solid ${SL.div}`,gap:5,
                          background:onA?SL.selAttr:'transparent',
                          borderLeft:onA?`3px solid ${L.pur}`:'3px solid transparent',}}
                        onMouseEnter={e=>{if(!onA)e.currentTarget.style.background=SL.hov}}
                        onMouseLeave={e=>{if(!onA)e.currentTarget.style.background='transparent'}}>
                        <span style={{fontFamily:L.mono,fontSize:9,color:onA?SL.accentAttr:SL.dim,fontWeight:700,minWidth:44,flexShrink:0}}>{a.attrId||'—'}</span>
                        <span style={{fontFamily:L.mono,fontSize:9,color:onA?SL.accentAttr:SL.attrNm,flex:1,minWidth:0,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{dispName}</span>
                        {a.pk&&<span style={{fontSize:7,fontWeight:800,color:L.pur,flexShrink:0}}>PK</span>}
                        {cdeInfo?.cde&&<CdeBadge cde={cdeInfo.cde} tiny/>}
                      </div>
                    )
                  })}
                </div>
              )
            })
            })()}
          </div>

          {/* LHP footer */}
          <div style={{padding:'6px 14px',background:SL.sectionBg,borderTop:`1px solid ${SL.div}`,fontSize:9,color:SL.dim,flexShrink:0}}>
            {OBJECTS.length} tables · {OBJECTS.reduce((s,k)=>s+(CATALOG[k]?.attrs?.length||0),0)} attributes
          </div>
        </div>

        {/* ═══════════════════════════════════════════════════════════
            RIGHT PANEL — context-driven by LHP selection
            If attribute selected → show attribute detail
            If object selected  → show object detail tabs
        ═══════════════════════════════════════════════════════════ */}
        <div>

          {/* No selection */}
          {!selObjKey&&!selAttrKey&&(
            <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:'48px',textAlign:'center'}}>
              <BookOpen size={32} color={L.t4} style={{marginBottom:12}}/>
              <div style={{fontSize:14,fontWeight:600,color:L.t2,marginBottom:6}}>Select from the catalog tree</div>
              <div style={{fontSize:12,color:L.t3}}>Click a <strong>table</strong> to browse all its attributes, or click an <strong>attribute leaf</strong> to view its full detail.</div>
            </div>
          )}

          {/* ── ATTRIBUTE SELECTED → full attribute detail panel ── */}
          {selType==='attribute'&&activeAttr&&(()=>{
            const a = activeAttr
            const objKey = a.objKey
            const obj = CATALOG[objKey]
            const cdeInfo = obj ? getEffCde(obj.schema,obj.obj,a.cd) : null
            const dom = a.domain ? DOMAINS[a.domain] : null
            return (
              <div>
                {/* Attribute header */}
                <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:'14px 20px',marginBottom:10}}>
                  <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8,flexWrap:'wrap'}}>
                    <span style={{fontFamily:L.mono,fontSize:10,background:L.purBg,color:L.purDk,padding:'3px 9px',borderRadius:5,fontWeight:700}}>{a.attrId||'—'}</span>
                    <span style={{fontFamily:L.mono,fontSize:16,fontWeight:800,color:L.t1}}>{a.cd}</span>
                    {a.pk&&<Chip text="PRIMARY KEY" c={L.pur} bg={L.purBg}/>}
                    {a.indexed&&!a.pk&&<Chip text="INDEXED" c={L.grn} bg={L.grnBg}/>}
                    <SemBadge s={a.semantic}/>
                    {cdeInfo?.cde&&<span style={{padding:'3px 9px',borderRadius:5,fontSize:11,fontWeight:800,
                      background:cdeInfo.cde==='CDE'?'#F0E6FF':'#E0F0FF',
                      color:cdeInfo.cde==='CDE'?'#7B2FBE':'#0E6BA8'}}>{cdeInfo.cde}</span>}
                  </div>
                  <div style={{fontSize:13,fontStyle:'italic',color:L.t2,marginBottom:6}}>{a.ln||'—'}</div>
                  <div style={{fontSize:12,color:L.t3,lineHeight:1.5}}>{a.desc}</div>
                  <div style={{display:'flex',gap:12,marginTop:8,fontSize:11,color:L.t3,flexWrap:'wrap'}}>
                    <span>Table: <strong style={{color:L.t2,fontFamily:L.mono,fontSize:10}}>{objKey}</strong></span>
                    <span>Type: <strong style={{color:L.t2,fontFamily:L.mono,fontSize:10}}>{a.type}</strong></span>
                    <span>Nullable: <strong style={{color:L.t2}}>{a.nullable?'Yes':'No'}</strong></span>
                    {cdeInfo?.source&&<span>Source: <strong style={{color:L.t2}}>{cdeInfo.source}</strong></span>}
                  </div>
                </div>

                {/* Attribute tabs */}
                <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:'14px 20px'}}>
                  <HorizTabs tabs={attrTabs} active={attrTab} onChange={setAttrTab}/>

                  {attrTab==='detail'&&(
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                      {[
                        ['Attribute ID',   a.attrId||'—'],
                        ['Physical name',  a.cd],
                        ['Logical name',   a.ln||'—'],
                        ['DB type',        a.type],
                        ['Semantic role',  a.semantic],
                        ['Domain',         a.domain||'None'],
                        ['PK',             a.pk?'Yes':'No'],
                        ['Indexed',        a.indexed?'Yes':'No'],
                      ].map(([k,v])=>(
                        <div key={k} style={{padding:'9px 12px',background:L.s3,borderRadius:7,border:`1px solid ${L.bd}`}}>
                          <div style={{fontSize:9,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>{k}</div>
                          <div style={{fontSize:12,color:L.t1,fontFamily:['Physical name','DB type','Attribute ID'].includes(k)?L.mono:L.font}}>{v}</div>
                        </div>
                      ))}
                      {dom&&(
                        <div style={{gridColumn:'span 2',padding:'9px 12px',background:L.ambBg,borderRadius:7,border:`1px solid ${L.amb}44`}}>
                          <div style={{fontSize:9,fontWeight:700,color:L.ambDk,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:6}}>Domain allowed values ({dom.length})</div>
                          <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                            {(dom||[]).map(d=><div key={d.v} style={{padding:'3px 8px',borderRadius:4,background:'#fff',border:`1px solid ${L.amb}44`}}>
                              <span style={{fontSize:10,fontFamily:L.mono,fontWeight:700,color:L.ambDk}}>{d.v}</span>
                              <span style={{fontSize:10,color:L.t3,marginLeft:5}}>{d.l}</span>
                            </div>)}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {attrTab==='ops'&&(
                    <div>
                      {/* Insert / Update / Delete mode chips */}
                      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:10,marginBottom:14}}>
                        {[
                          {label:'Insert mode',   val:a.insMode,  icon:'↓', hint:'How rows are created'},
                          {label:'Update mode',   val:a.updMode,  icon:'↺', hint:'How existing rows are changed'},
                          {label:'Delete mode',   val:a.delMode,  icon:'✕', hint:'How rows are removed'},
                        ].map(({label,val,icon,hint})=>{
                          const modeClr = v =>
                            v==='IMMUTABLE'      ? {c:'#8b5cf6',bg:'#f3f0ff'} :
                            v==='ETL_BATCH'      ? {c:L.teal,   bg:L.tealBg}  :
                            v==='API'            ? {c:L.blue,   bg:L.blueBg}  :
                            v==='MANUAL'         ? {c:L.amb,    bg:L.ambBg}   :
                            v==='SOFT_DELETE'    ? {c:L.cor,    bg:L.corBg}   :
                            v==='NONE'||v==='N/A'? {c:L.t4,     bg:L.s4}      :
                                                   {c:L.t3,     bg:L.s3}
                          const {c:mc,bg:mb} = modeClr(val||'—')
                          return (
                            <div key={label} style={{padding:'10px 12px',background:L.s1,border:`1px solid ${L.bd}`,borderRadius:8}}>
                              <div style={{fontSize:9,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:5}}>
                                <span style={{marginRight:4}}>{icon}</span>{label}
                                <span style={{fontWeight:400,marginLeft:4}}>· {hint}</span>
                              </div>
                              <span style={{display:'inline-block',padding:'3px 10px',borderRadius:10,
                                fontSize:11,fontWeight:700,background:mb,color:mc}}>
                                {val||'—'}
                              </span>
                            </div>
                          )
                        })}
                      </div>

                      {/* Who & When grid */}
                      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:14}}>
                        {[
                          {label:'Created by',      val:a.createdBy,   sub:'Service account or role that inserts rows'},
                          {label:'Created when',    val:a.createdTs,   sub:'Timestamp expression at insert time'},
                          {label:'Updated by',      val:a.updatedBy,   sub:'Service account or role that updates rows'},
                          {label:'Updated when',    val:a.updatedTs,   sub:'Timestamp expression at update time'},
                        ].map(({label,val,sub})=>(
                          <div key={label} style={{padding:'10px 12px',background:L.s3,borderRadius:8,border:`1px solid ${L.bd}`}}>
                            <div style={{fontSize:9,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>{label}</div>
                            <div style={{fontSize:12,fontWeight:600,color:val?L.t1:L.t4,fontFamily:val?L.mono:L.font,marginBottom:2}}>{val||'—'}</div>
                            <div style={{fontSize:10,color:L.t4}}>{sub}</div>
                          </div>
                        ))}
                      </div>

                      {/* Source system + flags row */}
                      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:10,marginBottom:14}}>
                        <div style={{padding:'10px 12px',background:L.s3,borderRadius:8,border:`1px solid ${L.bd}`}}>
                          <div style={{fontSize:9,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>Source system</div>
                          <span style={{fontFamily:L.mono,fontSize:11,fontWeight:700,color:L.blueDk,
                            background:L.blueBg,padding:'2px 7px',borderRadius:4}}>{a.srcSystem||'—'}</span>
                        </div>
                        <div style={{padding:'10px 12px',background:L.s3,borderRadius:8,border:`1px solid ${L.bd}`}}>
                          <div style={{fontSize:9,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>Null on insert</div>
                          <span style={{fontWeight:700,fontSize:12,color:a.nullOnIns?L.amb:L.grn}}>{a.nullOnIns?'Allowed':'Required'}</span>
                        </div>
                        <div style={{padding:'10px 12px',background:L.s3,borderRadius:8,border:`1px solid ${L.bd}`}}>
                          <div style={{fontSize:9,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>Immutable</div>
                          <span style={{fontWeight:700,fontSize:12,color:a.immutable?'#8b5cf6':L.t2}}>{a.immutable?'Yes — never updated':'No'}</span>
                        </div>
                        <div style={{padding:'10px 12px',background:L.s3,borderRadius:8,border:`1px solid ${L.bd}`}}>
                          <div style={{fontSize:9,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>Op column</div>
                          <span style={{fontWeight:700,fontSize:12,color:a.op?L.amb:L.teal}}>{a.op?'Operational':'Business'}</span>
                        </div>
                      </div>

                      {/* Notes */}
                      {a.notes&&(
                        <div style={{padding:'10px 14px',background:'#fffbf0',border:`1px solid ${L.amb}33`,borderRadius:8}}>
                          <div style={{fontSize:9,fontWeight:700,color:L.ambDk,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:4}}>
                            ⚙ Operational notes
                          </div>
                          <div style={{fontSize:12,color:L.t1,lineHeight:1.6}}>{a.notes}</div>
                        </div>
                      )}
                      {!a.insMode&&(
                        <div style={{padding:'12px',background:L.s3,borderRadius:8,border:`1px solid ${L.bd}`,color:L.t4,fontSize:12,fontStyle:'italic'}}>
                          Operational metadata not yet registered for this attribute. Use Register Object → Attributes tab to add it.
                        </div>
                      )}
                    </div>
                  )}

                  {attrTab==='dq'&&activeAttr&&(
                    <CatalogAttrDqTab objKey={activeAttr.objKey} attrLn={activeAttr.ln||activeAttr.cd}/>
                  )}

                  {attrTab==='usage'&&(
                    <div>
                      <div style={{marginBottom:12}}>
                        <div style={{fontSize:11,fontWeight:700,color:L.t2,marginBottom:6}}>Used in pairings</div>
                        <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                          {PAIRINGS.filter(p=>p.dispAttr===a.cd||p.filtAttr===a.cd).map(p=>(
                            <div key={p.cd} style={{padding:'5px 10px',borderRadius:6,background:L.purBg,border:`1px solid ${L.pur}44`}}>
                              <span style={{fontSize:11,fontWeight:600,color:L.purDk}}>{p.cd}</span>
                              <span style={{fontSize:10,color:L.t3,marginLeft:6}}>{p.dispAttr===a.cd?'display attr':'filter attr'}</span>
                            </div>
                          ))}
                          {!PAIRINGS.some(p=>p.dispAttr===a.cd||p.filtAttr===a.cd)&&
                            <span style={{fontSize:12,color:L.t4}}>Not used in any pairing</span>}
                        </div>
                      </div>
                      <div>
                        <div style={{fontSize:11,fontWeight:700,color:L.t2,marginBottom:6}}>Parent object usage</div>
                        <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                          {(obj?.usedBy||[]).map(u=><Chip key={u} text={u} c={L.blue} bg={L.blueBg}/>)}
                          {!(obj?.usedBy?.length)&&<span style={{fontSize:12,color:L.t4}}>No consumers registered</span>}
                        </div>
                      </div>
                    </div>
                  )}

                  {attrTab==='ai'&&(
                    <div style={{fontSize:12,color:L.t2,lineHeight:1.6}}>
                      <div style={{fontWeight:600,marginBottom:4}}>AI context for this attribute</div>
                      <div style={{padding:'10px 12px',background:L.s3,borderRadius:6,border:`1px solid ${L.bd}`}}>
                        {a.aiCtx||`No AI context registered for ${a.cd}. Register this attribute via Register Object → Attributes tab to add AI context.`}
                      </div>
                    </div>
                  )}

                  {attrTab==='cde'&&(
                    <div>
                      <div style={{fontSize:11,fontWeight:700,color:L.t2,marginBottom:8,display:'flex',alignItems:'center',gap:6}}>
                        <Tag size={12}/> Classification for tenant: <strong>{selTenant}</strong>
                        {cdeInfo?.source&&<Chip text={`${cdeInfo.source}${cdeInfo.taggedBy?' · '+cdeInfo.taggedBy:''}`} c={cdeInfo.source==='ORGANIC'?L.grn:L.blue} bg={cdeInfo.source==='ORGANIC'?L.grnBg:L.blueBg}/>}
                      </div>
                      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:10}}>
                        {[
                          {v:'CDE',label:'Critical Data Element',sub:'Used directly/indirectly in regulatory report construction',bg:'#F0E6FF',c:'#7B2FBE'},
                          {v:'DE', label:'Data Element',          sub:'Analytical / operational — does not impact regulatory reports',bg:'#E0F0FF',c:'#0E6BA8'},
                          {v:null, label:'Unclassified',          sub:'Not yet tagged for this tenant and purpose',                  bg:L.s4,c:L.t3},
                        ].map(opt=>{
                          const isActive=cdeInfo?.cde===opt.v
                          return (
                            <div key={String(opt.v)} onClick={()=>api.tagCde({schema:activeObj.schema,object:activeObj.obj,attribute:a.cd,cde:opt.v,tenant:selTenant})}
                              style={{padding:'10px',borderRadius:7,cursor:'pointer',
                                border:`2px solid ${isActive?opt.c:L.bd}`,background:isActive?opt.bg:L.s1}}>
                              <div style={{fontSize:12,fontWeight:700,color:isActive?opt.c:L.t2,marginBottom:4}}>{opt.label}</div>
                              <div style={{fontSize:11,color:L.t3,lineHeight:1.4}}>{opt.sub}</div>
                            </div>
                          )
                        })}
                      </div>
                      <InfoBanner text="CDE tagging can be ORGANIC (system-detected from rule → report utilization chain) or HUMAN (manually tagged by data steward). Organic tagging happens automatically as rules are authored and reports are registered." color={L.teal} bg={L.tealBg}/>
                    </div>
                  )}
                </div>
              </div>
            )
          })()}

          {/* ── OBJECT SELECTED → object detail with attribute grid ── */}
          {selType==='object'&&activeObj&&(
            <Fragment>
              <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:'14px 20px',marginBottom:10}}>
                <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6,flexWrap:'wrap'}}>
                  <div>
                    {activeObj?.logicalShortNm&&(
                      <div style={{fontSize:12,fontWeight:700,color:L.tealDk,marginBottom:2}}>{activeObj.logicalShortNm}
                        <span style={{fontSize:10,fontWeight:400,color:L.t4,marginLeft:8}}>{activeObj.logicalLongNm}</span>
                      </div>
                    )}
                    <div style={{display:'flex',alignItems:'center',gap:8}}>
                      <span style={{fontFamily:L.mono,fontSize:13,fontWeight:700,color:L.t1}}>{selObjKey}</span>
                      <EngineBadge connectionId={activeObj?.connectionId||'lextr-pg'}/>
                    </div>
                  </div>
                  <SBadge st={activeObj.st}/>
                  <Chip text={activeObj.type} c={L.blue} bg={L.blueBg}/>
                  <Chip text={`AI: ${activeObj.aiTier}`}
                    c={activeObj.aiTier==='ALLOWED'?L.grn:activeObj.aiTier==='RESTRICTED'?L.amb:L.cor}
                    bg={activeObj.aiTier==='ALLOWED'?L.grnBg:activeObj.aiTier==='RESTRICTED'?L.ambBg:L.corBg}/>
                  <TenantChip tenant="GLOBAL"/>
                  <div style={{marginLeft:'auto'}}><HistBtn onClick={()=>setHistCat(true)}/></div>
                </div>
                <p style={{margin:'0 0 8px',fontSize:12,color:L.t2,lineHeight:1.5}}>{activeObj.desc}</p>
                <div style={{display:'flex',gap:14,fontSize:11,color:L.t3,flexWrap:'wrap'}}>
                  <span><User size={10} style={{verticalAlign:'middle',marginRight:3}}/>{activeObj.owner}</span>
                  <span><Calendar size={10} style={{verticalAlign:'middle',marginRight:3}}/>{activeObj.updated}</span>
                  <span><BarChart2 size={10} style={{verticalAlign:'middle',marginRight:3}}/>{activeObj.rows}</span>
                  <span><Columns size={10} style={{verticalAlign:'middle',marginRight:3}}/><strong style={{color:L.t1}}>{activeObj.attrs?.length||0}</strong> attrs — click an attribute in the tree for its detail</span>
                </div>
              </div>

              <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:'14px 20px'}}>
                <HorizTabs tabs={objTabs} active={objTab} onChange={setObjTab}/>

                {objTab==='overview'&&(
                  <div>
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:10}}>
                      {[['Grain',activeObj.grain],['Schema',activeObj.schema],['Type',activeObj.type],['AI Tier',activeObj.aiTier]].map(([k,v])=>(
                        <div key={k} style={{padding:'9px 12px',background:L.s3,borderRadius:7,border:`1px solid ${L.bd}`}}>
                          <div style={{fontSize:9,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>{k}</div>
                          <div style={{fontSize:12,color:L.t1}}>{v}</div>
                        </div>
                      ))}
                      <div style={{gridColumn:'span 2',padding:'9px 12px',background:L.s3,borderRadius:7,border:`1px solid ${L.bd}`}}>
                        <div style={{fontSize:9,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:5}}>USED BY</div>
                        <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                          {(activeObj.usedBy||[]).map(u=><Chip key={u} text={u} c={L.blue} bg={L.blueBg}/>)}
                          {!(activeObj.usedBy?.length)&&<span style={{fontSize:12,color:L.t4}}>No consumers registered yet</span>}
                        </div>
                      </div>
                    </div>
                    {activeObj.opProfile&&(
                      <div style={{padding:'12px 14px',background:L.s3,border:`1px solid ${L.bd}`,borderRadius:10}}>
                        <div style={{fontSize:11,fontWeight:700,color:L.t2,marginBottom:10,display:'flex',alignItems:'center',gap:6}}>
                          <Settings size={12} color={L.t3}/> Operational profile
                        </div>
                        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:8}}>
                          {[
                            ['Insert modes',   (activeObj.opProfile.insertModes||[]).join(', ')],
                            ['Update modes',   (activeObj.opProfile.updateModes||[]).join(', ')],
                            ['Delete modes',   (activeObj.opProfile.deleteModes||[]).join(', ')],
                            ['Source systems', (activeObj.opProfile.srcSystems||[]).join(', ')],
                          ].map(([k,v])=>(
                            <div key={k} style={{padding:'7px 10px',background:L.s1,borderRadius:6,border:`1px solid ${L.bd2}`}}>
                              <div style={{fontSize:9,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.06em',marginBottom:2}}>{k}</div>
                              <div style={{fontSize:11,fontWeight:600,color:L.t1}}>{v||'—'}</div>
                            </div>
                          ))}
                        </div>
                        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:8}}>
                          {[
                            ['ETL / load frequency', activeObj.opProfile.etlFrequency],
                            ['Latency P99',          activeObj.opProfile.latencyP99],
                            ['Retention policy',     activeObj.opProfile.retentionPolicy],
                          ].map(([k,v])=>(
                            <div key={k} style={{padding:'7px 10px',background:L.s1,borderRadius:6,border:`1px solid ${L.bd2}`}}>
                              <div style={{fontSize:9,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.06em',marginBottom:2}}>{k}</div>
                              <div style={{fontSize:11,color:L.t1,lineHeight:1.4}}>{v||'—'}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {objTab==='attrs'&&(
                  <div>
                    <div style={{display:'flex',alignItems:'center',gap:7,marginBottom:10,padding:'6px 10px',background:L.s3,border:`1px solid ${L.bd}`,borderRadius:7}}>
                      <Search size={11} color={L.t4}/>
                      <input value={attrSearch} onChange={e=>setAttrSearch(e.target.value)}
                        placeholder="Search ID, physical, logical, description — or click attribute in tree for full detail"
                        style={{border:'none',outline:'none',flex:1,fontSize:12,color:L.t1,background:'transparent'}}/>
                      {attrSearch&&<button onClick={()=>setAttrSearch('')} style={{border:'none',background:'none',cursor:'pointer',color:L.t4}}>✕</button>}
                    </div>
                    <div style={{border:`1px solid ${L.bd}`,borderRadius:8,overflow:'hidden'}}>
                      <div style={{display:'grid',gridTemplateColumns:'68px 1.1fr 1.4fr 0.8fr 1fr 0.4fr 0.4fr 0.7fr 60px',
                        padding:'7px 10px',background:L.s3,borderBottom:`1px solid ${L.bd}`,
                        fontSize:9,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.05em',gap:6}}>
                        {['ID','Physical','Logical','Type','Semantic','PK','IDX','Domain','CDE'].map(h=><span key={h}>{h}</span>)}
                      </div>
                      {filteredAttrs.map((a,i)=>{
                        const cdeInfo=getEffCde(activeObj.schema,activeObj.obj,a.cd)
                        return (
                          <div key={a.cd} onClick={()=>pickAttr(selObjKey,a.cd)}
                            style={{display:'grid',gridTemplateColumns:'68px 1.1fr 1.4fr 0.8fr 1fr 0.4fr 0.4fr 0.7fr 60px',
                              padding:'8px 10px',borderBottom:`1px solid ${L.bd2}`,fontSize:11,
                              alignItems:'center',gap:6,cursor:'pointer',
                              background:i%2?L.s2:L.s1}}
                            onMouseEnter={e=>e.currentTarget.style.background=L.blueBg}
                            onMouseLeave={e=>e.currentTarget.style.background=i%2?L.s2:L.s1}>
                            <span style={{fontFamily:L.mono,fontSize:9,color:L.purDk,fontWeight:700}}>{a.attrId||'—'}</span>
                            <span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:L.t1}}>{a.cd}</span>
                            <span style={{fontSize:11,color:L.t3,fontStyle:'italic'}}>{a.ln||'—'}</span>
                            <span style={{fontFamily:L.mono,fontSize:9,color:L.t3}}>{a.type}</span>
                            <SemBadge s={a.semantic}/>
                            <span style={{color:a.pk?L.grn:L.bd,fontWeight:700,textAlign:'center'}}>{a.pk?'✓':'—'}</span>
                            <span style={{color:a.indexed?L.grn:L.bd,fontWeight:700,textAlign:'center'}}>{a.indexed?'✓':'—'}</span>
                            <span style={{fontSize:9,color:a.domain?L.ambDk:L.t4}}>{a.domain||'—'}</span>
                            {cdeInfo?.cde?<CdeBadge cde={cdeInfo.cde}/>:<span style={{color:L.t4,fontSize:9}}>—</span>}
                          </div>
                        )
                      })}
                      {filteredAttrs.length===0&&<div style={{padding:'18px',textAlign:'center',color:L.t4,fontSize:12}}>No matches for "{attrSearch}"</div>}
                    </div>
                    <div style={{marginTop:8,fontSize:11,color:L.t3}}>Click any attribute row to see its full detail, CDE/DE classification, and usage.</div>
                  </div>
                )}

                {objTab==='dq'&&<CatalogDqTab objKey={selObjKey}/>}

                {objTab==='lineage'&&<MiniLineageGraph objKey={selObjKey}/>}

                {objTab==='ai'&&(
                  <div style={{fontSize:12,color:L.t2,lineHeight:1.6}}>
                    <div style={{fontWeight:600,marginBottom:4}}>AI Business Context</div>
                    <div style={{padding:'10px 12px',background:L.s3,borderRadius:6,border:`1px solid ${L.bd}`}}>
                      {selObjKey==='core.gl_balance'?'General ledger balance positions for all legal entities. Primary source for Y-9C HC schedules. Always filter by legal_entity_cd and period_cd.':'AI context not registered. Complete Object Registration to enable AI-assisted querying.'}
                    </div>
                  </div>
                )}

                {objTab==='rels'&&(
                  <div>
                    {activeObj.relationships?.length
                      ?(activeObj.relationships||[]).map(r=>(
                        <div key={r.to} style={{padding:'10px',marginBottom:6,background:L.s3,borderRadius:7,border:`1px solid ${L.bd}`}}>
                          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}>
                            <Chip text={selObjKey?.split('.')[1]} c={L.teal} bg={L.tealBg}/>
                            <ArrowRight size={12} color={L.t3}/>
                            <Chip text={r.to.split('.')[1]} c={L.blue} bg={L.blueBg}/>
                            <Chip text={r.type} c={L.t3} bg={L.s4}/>
                          </div>
                          <div style={{fontFamily:L.mono,fontSize:11,color:L.t3}}>ON {r.on}</div>
                        </div>
                      ))
                      :<div style={{color:L.t4,fontSize:12}}>No relationships registered.</div>
                    }
                  </div>
                )}
              </div>
            </Fragment>
          )}
        </div>
      </div>

      <Drawer open={!!histCat} onClose={()=>setHistCat(false)} eyebrow="Object · History"
        title={activeObj?(activeObj.logicalShortNm||selObjKey):''} sub={selObjKey||''}
        footer="Append-only governance log — who · what · when. Illustrative in this prototype.">
        {activeObj && <HistoryTimeline events={govEvents({name:selObjKey, kind:'Object', status:activeObj.st, by:activeObj.owner||'a.rao', seed:(selObjKey||'').length})}/>}
      </Drawer>
    </div>
  )
}



// ── RegisterWizard — self-contained wizard with own state ─────────────────
// Each draft tab mounts its own RegisterWizard, preserving state independently
const StatusPill = ({st}) => {
  const c = INV_ST[st] || INV_ST.NEW_OBJECT
  return <span style={{padding:'1px 7px',borderRadius:10,fontSize:9,fontWeight:700,color:c.c,background:c.bg,whiteSpace:'nowrap'}}>{c.label}</span>
}

// Governed object picker — replaces the free-text object-code field. Sources the
// registration-actionable subset of OBJECT_INVENTORY; NOT_ELIGIBLE shown disabled with reason.
function ObjectPicker({schema, objType, objCd, onPick}) {
  const [open, setOpen] = useState(false)
  const list = OBJECT_INVENTORY.filter(o => isRegActionable(o) && (!schema || o.schema===schema) && (!objType || o.type===objType))
  const grouped = list.reduce((m,o)=>{(m[o.schema]=m[o.schema]||[]).push(o);return m},{})
  const selected = objCd ? OBJECT_INVENTORY.find(o=>o.schema===schema && o.obj===objCd) : null
  const selKey = selected ? selected.schema+'.'+selected.obj : ''
  return (
    <div>
      <label style={{display:'block',fontSize:11,fontWeight:700,color:L.t2,marginBottom:4}}>
        Object <span style={{fontSize:9,fontWeight:400,color:L.t3}}>· {schema} / {objType} — select from the governed inventory list (no free text)</span>
        <span style={{color:'#E24B4A'}}> *</span>
      </label>
      <div style={{position:'relative'}}>
        <button type="button" onClick={()=>setOpen(o=>!o)}
          style={{width:'100%',display:'flex',alignItems:'center',justifyContent:'space-between',gap:8,
            padding:'8px 10px',borderRadius:6,fontSize:12,fontFamily:'inherit',cursor:'pointer',
            border:'1px solid '+(selKey?L.teal:L.bd),background:'#fff',color:selKey?L.t1:L.t4,boxSizing:'border-box'}}>
          <span style={{display:'flex',alignItems:'center',gap:8,minWidth:0}}>
            {selKey ? (<>
              <span style={{fontFamily:L.mono,fontSize:11,color:L.t3}}>{selected.schema}.</span>
              <span style={{fontFamily:L.mono,fontWeight:700,color:L.t1}}>{selected.obj}</span>
              <StatusPill st={regDispStatus(selected)}/>
            </>) : 'Select an object to register\u2026'}
          </span>
          <span style={{color:L.t4,fontSize:10}}>{open?'\u25B2':'\u25BC'}</span>
        </button>
        {open && (
          <div style={{position:'absolute',top:'calc(100% + 4px)',left:0,right:0,zIndex:50,maxHeight:300,overflowY:'auto',
            background:'#fff',border:'1px solid '+L.bd,borderRadius:8,boxShadow:'0 8px 24px rgba(20,49,61,.16)'}}>
            <div style={{padding:'7px 10px',fontSize:10,color:L.t3,borderBottom:'1px solid '+L.bd2,background:L.s2}}>
              Synced with Object Inventory \u00b7 {schema} / {objType} \u00b7 New, Has-Update, Pending &amp; Not-Eligible only
            </div>
            {list.length===0 && (
              <div style={{padding:'16px',fontSize:11,color:L.t4,textAlign:'center'}}>No registerable objects in <b>{schema}</b> / {objType}. Adjust Schema or Object type above.</div>
            )}
            {Object.entries(grouped).map(([sch,rows])=>(
              <div key={sch}>
                <div style={{padding:'5px 10px',background:L.s3,fontSize:9,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.06em'}}>{sch}</div>
                {rows.map(o=>{
                  const ds = regDispStatus(o); const inelig = o.st==='NOT_ELIGIBLE'
                  return (
                    <div key={o.obj} title={inelig?o.note:''}
                      onClick={()=>{ if(inelig) return; onPick(o); setOpen(false) }}
                      style={{display:'flex',alignItems:'center',gap:8,padding:'8px 10px',borderBottom:'1px solid '+L.bd2,
                        cursor:inelig?'not-allowed':'pointer',opacity:inelig?.55:1,
                        background:selKey===o.schema+'.'+o.obj?L.tealBg:'#fff'}}
                      onMouseEnter={e=>{if(!inelig)e.currentTarget.style.background=L.blueBg}}
                      onMouseLeave={e=>{e.currentTarget.style.background=selKey===o.schema+'.'+o.obj?L.tealBg:'#fff'}}>
                      <span style={{fontFamily:L.mono,fontSize:12,fontWeight:700,color:L.t1,flex:1,minWidth:0,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{o.obj}</span>
                      <span style={{fontSize:10,color:L.t4}}>{o.type}</span>
                      <span style={{fontSize:10,color:L.t4,fontFamily:L.mono}}>{o.attrReg}/{o.attrTotal} attrs</span>
                      <StatusPill st={ds}/>
                    </div>
                  )
                })}
              </div>
            ))}
          </div>
        )}
      </div>
      {selKey && objCd
        ? <div style={{fontSize:10,color:L.t3,marginTop:4}}>Resolved physical name <code style={{fontFamily:L.mono,color:L.tealDk}}>{schema}.{objCd}</code> \u2014 validated against Object Inventory.</div>
        : <div style={{fontSize:10,color:'#B87414',marginTop:4}}>An object must be selected from the inventory before registration can proceed.</div>}
    </div>
  )
}

function RegisterWizard({id, initCtx, onClose, onNav}) {
  const [wizTab, setWizTab] = useState('object')
  const [form, setForm] = useState({
    schema:         initCtx?.schema || 'core',
    objCd:          initCtx?.obj    || '',
    objType:        initCtx?.type   || 'TABLE',
    logicalShortNm: '',
    logicalLongNm:  '',
    grain:'', desc:'',
    aiTier:'ALLOWED', aiCtx:'', aiGuide:'',
    routing:'CUBE_DIRECT', dagFlow:'',
    regSemantic: initCtx?.sem !== undefined ? initCtx.sem : true,
    regAI:       initCtx?.ai  !== undefined ? initCtx.ai  : true,
    regCatalog:  initCtx?.cat !== undefined ? initCtx.cat : true,
    effectiveFrom:TODAY, effectiveTo:'',
  })
  const [attrRows,     setAttrRows]     = useState([])
  const [introspected, setIntrospected] = useState(false)
  const [attrFilter,   setAttrFilter]   = useState('ALL')
  const [expandRow,    setExpandRow]    = useState(null)
  const [bulkDate,     setBulkDate]     = useState(TODAY)
  const [showBulkDate, setShowBulkDate] = useState(false)

  const f = (k,v) => setForm(p=>({...p,[k]:v}))
  const introspect = () => {
    // PRODUCTION: call api.introspectObject(form.schema, form.objCd) and use response.
    // Falls back to DB_COLUMNS mock data when offline/dev.
    const key = `${form.schema}.${form.objCd}`
    const knownCols = DB_COLUMNS[key]
    const cols = knownCols || [
      // Single PK placeholder + governance suffix for objects not yet in DB_COLUMNS
      {cd:`${form.objCd}_id`, dbType:'bigint',       pk:true,  indexed:true,  nullable:false, op:false, suggested:'IDENTIFIER', semantic:true,  aiExposed:true,  domain:'', desc:`Surrogate primary key for ${form.schema}.${form.objCd}`, effectiveFrom:TODAY, effectiveTo:'', aiCtx:'', domainMode:'NONE', domainEnum:'', domainRefTable:''},
      ...GOV_SUFFIX.map(col=>({...col, aiCtx:'', domainMode:'NONE', domainEnum:'', domainRefTable:''})),
    ]
    setAttrRows(cols.map(col=>({...col,
      semanticRole:     col.suggested!=='—' ? col.suggested : 'DIMENSION',
      aiCtx:            col.aiCtx          || '',
      domainMode:       col.domainMode     || (col.domain ? 'REF_DOMAIN' : 'NONE'),
      domainEnum:       col.domainEnum     || '',
      domainRefTable:   col.domainRefTable || '',
      logicalShortNm:   col.logicalShortNm || '',
      logicalLongNm:    col.logicalLongNm  || '',
    })))
    setIntrospected(true)
  }
  const updateAttr  = (i,k,v) => setAttrRows(p=>p.map((r,j)=>j===i?{...r,[k]:v}:r))
  const bulkToggle  = (k,v)   => setAttrRows(p=>p.map(r=>({...r,[k]:v})))
  const applyBulk   = ()      => { setAttrRows(p=>p.map(r=>({...r,effectiveFrom:bulkDate}))); setShowBulkDate(false) }

  const semanticCount = attrRows.filter(r=>r.semantic).length
  const aiOnlyCount   = attrRows.filter(r=>!r.semantic&&r.aiExposed).length
  const excludedCount = attrRows.filter(r=>!r.semantic&&!r.aiExposed).length
  const filteredRows  = attrRows.filter(r=>
    attrFilter==='ALL'      ? true :
    attrFilter==='SEMANTIC' ? r.semantic :
    attrFilter==='AI_ONLY'  ? (!r.semantic&&r.aiExposed) :
    attrFilter==='EXCLUDED' ? (!r.semantic&&!r.aiExposed) : true)
  const completePct = [
    form.schema&&form.objCd&&form.grain,
    introspected&&attrRows.length>0,
    form.aiCtx&&form.aiGuide,
    true, false,
  ].filter(Boolean).length / 4 * 100
  const wizTabs = [
    {id:'object', label:'Object',     icon:Table2},
    {id:'attrs',  label:'Attributes', icon:Columns, badge:attrRows.length||undefined},
    {id:'ai',     label:'AI Context', icon:Zap},
    {id:'review', label:'Review',     icon:Check},
  ]

  return (
    <div>
      <DraftActionBar id={id} accentColor={L.teal}
        onDiscard={onClose}
        onSaveDraft={()=>api.saveRegistrationDraft({draftId:id,form,attrRows})}
        onSubmit={()=>api.submitRegistrationForApproval({draftId:id,form,attrRows})}/>
      {/* Context banner when pre-filled from inventory */}
      {form.objCd&&(
        <div style={{display:'flex',alignItems:'center',gap:10,padding:'9px 14px',marginBottom:14,
          background:L.blueBg,border:`1px solid ${L.blue}44`,borderRadius:7}}>
          <Info size={13} color={L.blue}/>
          <span style={{fontSize:12,color:L.blueDk}}>
            Context loaded from inventory: <strong style={{fontFamily:L.mono}}>{form.schema}.{form.objCd}</strong>
          </span>
          <button onClick={()=>{setForm(p=>({...p,schema:'core',objCd:'',objType:'TABLE',grain:'',desc:''}));setAttrRows([]);setIntrospected(false)}}
            style={{marginLeft:'auto',padding:'3px 9px',borderRadius:5,border:`1px solid ${L.bd}`,background:L.s1,cursor:'pointer',fontSize:11,color:L.t3}}>
            Clear
          </button>
        </div>
      )}

      {/* Completeness bar */}
      <div style={{marginBottom:16}}>
        <div style={{display:'flex',justifyContent:'space-between',fontSize:11,color:L.t3,marginBottom:4}}>
          <span>Registration completeness</span>
          <span style={{fontWeight:700,color:L.t1}}>{Math.round(completePct)}%</span>
        </div>
        <div style={{height:4,background:L.s4,borderRadius:2}}>
          <div style={{width:`${completePct}%`,height:'100%',background:L.teal,borderRadius:2,transition:'width .3s'}}/>
        </div>
      </div>

      <HorizTabs tabs={wizTabs} active={wizTab} onChange={setWizTab}/>

      {/* ── Object tab ── */}
      {wizTab==='object'&&(
        <div>
          <h3 style={{margin:'0 0 16px',fontSize:14,fontWeight:700,color:L.t1}}>Object metadata</h3>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
            <SelectInput label="Schema" req value={form.schema} onChange={v=>setForm(p=>({...p,schema:v,objCd:''}))}
              opts={['staging','core','ref','meta','logic','provenance','intelligence','workspace','report','iam']}/>
            <SelectInput label="Object type" req value={form.objType} onChange={v=>setForm(p=>({...p,objType:v,objCd:''}))}
              opts={['TABLE','VIEW','MATERIALIZED_VIEW','SEMANTIC_VIEW','EXTERNAL_TABLE']}/>
            <div style={{gridColumn:'span 2'}}>
              <ObjectPicker schema={form.schema} objType={form.objType} objCd={form.objCd}
                onPick={o=>setForm(p=>({...p,schema:o.schema,objType:o.type,objCd:o.obj}))}/>
            </div>
            <SelectInput label="AI governance tier" value={form.aiTier} onChange={v=>f('aiTier',v)}
              opts={['ALLOWED','RESTRICTED','EXCLUDED']}/>

            {/* ── Logical names — Lextr 32-char standard ── */}
            <div style={{gridColumn:'span 2',display:'grid',gridTemplateColumns:'1fr 1fr',gap:12,
              padding:'14px',background:L.tealBg,borderRadius:8,border:`1px solid ${L.teal}33`}}>
              <div>
                <label style={{display:'block',fontSize:11,fontWeight:700,color:L.tealDk,marginBottom:4}}>
                  Logical short name <span style={{fontSize:9,fontWeight:400,color:L.t3}}>(≤ 32 chars · Lextr standard)</span>
                </label>
                <input value={form.logicalShortNm}
                  onChange={e=>setForm(p=>({...p,logicalShortNm:e.target.value.slice(0,32)}))}
                  placeholder="e.g. Daily GL Bal Agg"
                  style={{width:'100%',padding:'7px 10px',borderRadius:6,fontSize:12,color:L.t1,fontFamily:'inherit',
                    border:`1px solid ${form.logicalShortNm.length>28?'#E24B4A':L.teal+'66'}`,
                    boxSizing:'border-box',background:'#fff'}}/>
                <div style={{display:'flex',justifyContent:'space-between',marginTop:3}}>
                  <span style={{fontSize:10,color:L.t3}}>Shown in Catalog tree, QS, Governance, and Filter Lookup selectors</span>
                  <span style={{fontSize:10,fontFamily:L.mono,
                    color:form.logicalShortNm.length>28?'#A32D2D':L.t4}}>
                    {form.logicalShortNm.length}/32
                  </span>
                </div>
              </div>
              <div>
                <label style={{display:'block',fontSize:11,fontWeight:700,color:L.tealDk,marginBottom:4}}>
                  Logical long name <span style={{fontSize:9,fontWeight:400,color:L.t3}}>(full description)</span>
                </label>
                <input value={form.logicalLongNm}
                  onChange={e=>setForm(p=>({...p,logicalLongNm:e.target.value}))}
                  placeholder="e.g. Daily General Ledger Balance Aggregate"
                  style={{width:'100%',padding:'7px 10px',borderRadius:6,fontSize:12,color:L.t1,fontFamily:'inherit',
                    border:`1px solid ${L.teal}66`,boxSizing:'border-box',background:'#fff'}}/>
                <div style={{fontSize:10,color:L.t3,marginTop:3}}>Shown in Catalog panel header and documentation</div>
              </div>
            </div>

            <div style={{gridColumn:'span 2'}}>
              <TextInput label="Grain statement" req value={form.grain} onChange={v=>f('grain',v)}
                placeholder="One row per legal-entity, account, currency, and fiscal period"/>
            </div>
            <div style={{gridColumn:'span 2'}}>
              <TextArea label="Business description" req value={form.desc} onChange={v=>f('desc',v)}
                placeholder="Describe the business purpose of this object…" rows={3}/>
            </div>

            {/* ── Registration scope — the key differentiator ── */}
            <div style={{gridColumn:'span 2',padding:'14px',background:L.s3,borderRadius:8,border:`1px solid ${L.bd}`}}>
              <div style={{fontSize:12,fontWeight:700,color:L.t1,marginBottom:4}}>
                Registration scope — select what this object should be registered for
              </div>
              <div style={{fontSize:11,color:L.t3,marginBottom:12,lineHeight:1.5}}>
                Objects can be registered independently for each purpose.
                Example: a workflow table can be registered for AI (Lexie can answer questions about workflows) but not for Semantic layer (not exposed via semantic-service) or Data Catalog (internal/operational).
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:10}}>
                {[
                  {key:'regSemantic',label:'Semantic Layer',    icon:Layers,   color:L.pur,
                    desc:'Register in semantic-service. Appears as dimensions/measures for consumers and dashboards.'},
                  {key:'regAI',      label:'AI Context',        icon:Zap,      color:L.teal,
                    desc:'Register for Lexie AI. Enables AI-assisted querying and attribute context.'},
                  {key:'regCatalog', label:'Data Catalog',      icon:BookOpen, color:L.blue,
                    desc:'Visible in the read-only Data Catalog discovery portal.'},
                ].map(({key,label,icon:Icon,color,desc})=>(
                  <div key={key} onClick={()=>f(key,!form[key])}
                    style={{padding:'12px',borderRadius:8,cursor:'pointer',
                      border:`2px solid ${form[key]?color:L.bd}`,
                      background:form[key]?color+'10':L.s1}}>
                    <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
                      <div style={{width:28,height:28,borderRadius:7,
                        background:form[key]?color+'22':L.s4,
                        display:'flex',alignItems:'center',justifyContent:'center'}}>
                        <Icon size={14} color={form[key]?color:L.t4}/>
                      </div>
                      <div style={{flex:1}}>
                        <div style={{fontSize:12,fontWeight:700,color:form[key]?color:L.t2}}>{label}</div>
                      </div>
                      <div style={{width:18,height:18,borderRadius:9,
                        border:`2px solid ${form[key]?color:L.bd}`,
                        background:form[key]?color:'transparent',
                        display:'flex',alignItems:'center',justifyContent:'center'}}>
                        {form[key]&&<Check size={10} color="#fff"/>}
                      </div>
                    </div>
                    <div style={{fontSize:11,color:L.t3,lineHeight:1.4}}>{desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Effective dating */}
            <div style={{gridColumn:'span 2',padding:'12px 14px',background:L.s3,borderRadius:8,border:`1px solid ${L.bd}`}}>
              <div style={{fontSize:11,fontWeight:700,color:L.t2,marginBottom:10,display:'flex',alignItems:'center',gap:5}}>
                <Calendar size={12} color={L.teal}/> Effective dating
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
                <DateInput label="Effective from" req value={form.effectiveFrom} onChange={v=>f('effectiveFrom',v)}/>
                <DateInput label="Effective to (blank = indefinite)" value={form.effectiveTo} onChange={v=>f('effectiveTo',v)}/>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Attributes tab ── */}
      {wizTab==='attrs'&&(
        <div>
          <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',marginBottom:14}}>
            <div>
              <h3 style={{margin:'0 0 4px',fontSize:14,fontWeight:700,color:L.t1}}>Attribute registration</h3>
              <p style={{margin:0,fontSize:12,color:L.t3,lineHeight:1.5}}>
                Load all physical columns from the DB. Configure Semantic and AI exposure per attribute.
                Operational columns auto-suggested as excluded from Semantic but can remain AI-exposed.
              </p>
            </div>
            {form.objCd
              ?<Btn label={`Load ${form.schema}.${form.objCd}`} icon={Database} primary small onClick={introspect}/>
              :<span style={{fontSize:12,color:L.t4,padding:'6px 0'}}>Set object code in Object tab first</span>}
          </div>

          {!introspected&&(
            <div style={{padding:'40px',textAlign:'center',background:L.s3,borderRadius:10,border:`2px dashed ${L.bd}`}}>
              <Database size={28} color={L.t4} style={{marginBottom:10}}/>
              <div style={{fontSize:13,fontWeight:600,color:L.t2,marginBottom:4}}>No attributes loaded</div>
              <div style={{fontSize:12,color:L.t3,marginBottom:16}}>
                Click "Load" to pull all columns for <code style={{fontSize:11}}>{form.schema}.{form.objCd||'(object code)'}</code> from PostgreSQL information_schema.
              </div>
              {form.objCd&&<Btn label={`Load columns for ${form.schema}.${form.objCd}`} icon={Database} primary onClick={introspect}/>}
            </div>
          )}

          {introspected&&attrRows.length>0&&(
            <Fragment>
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:10,flexWrap:'wrap'}}>
                {[
                  {id:'ALL',     label:`All (${attrRows.length})`,   color:L.t3, bg:L.s4},
                  {id:'SEMANTIC',label:`Semantic (${semanticCount})`,color:L.teal,bg:L.tealBg},
                  {id:'AI_ONLY', label:`AI only (${aiOnlyCount})`,  color:L.blue,bg:L.blueBg},
                  {id:'EXCLUDED',label:`Excluded (${excludedCount})`,color:L.cor,bg:L.corBg},
                ].map(({id,label,color,bg})=>(
                  <button key={id} onClick={()=>setAttrFilter(id)} style={{
                    padding:'4px 10px',borderRadius:12,fontSize:11,fontWeight:700,cursor:'pointer',
                    border:`1px solid ${attrFilter===id?color:L.bd}`,
                    background:attrFilter===id?bg:L.s1,color:attrFilter===id?color:L.t3}}>
                    {label}
                  </button>
                ))}
                <div style={{flex:1}}/>
                <button onClick={()=>bulkToggle('semantic',true)}  style={{padding:'4px 9px',borderRadius:5,border:`1px solid ${L.teal}`,background:L.tealBg,cursor:'pointer',fontSize:10,fontWeight:700,color:L.tealDk}}>Sem ON</button>
                <button onClick={()=>bulkToggle('semantic',false)} style={{padding:'4px 9px',borderRadius:5,border:`1px solid ${L.bd}`,background:L.s3,cursor:'pointer',fontSize:10,fontWeight:700,color:L.t3}}>Sem OFF</button>
                <button onClick={()=>bulkToggle('aiExposed',true)} style={{padding:'4px 9px',borderRadius:5,border:`1px solid ${L.blue}`,background:L.blueBg,cursor:'pointer',fontSize:10,fontWeight:700,color:L.blueDk}}>AI ON</button>
                <button onClick={()=>setShowBulkDate(!showBulkDate)} style={{padding:'4px 9px',borderRadius:5,border:`1px solid ${L.bd}`,background:L.s3,cursor:'pointer',fontSize:10,fontWeight:700,color:L.t2,display:'flex',alignItems:'center',gap:4}}>
                  <Calendar size={10}/> Date
                </button>
              </div>

              {showBulkDate&&(
                <div style={{padding:'9px 12px',background:L.s3,borderRadius:7,border:`1px solid ${L.bd}`,marginBottom:10,display:'flex',alignItems:'center',gap:10}}>
                  <span style={{fontSize:12,color:L.t2,fontWeight:600}}>Set effective from for all visible rows:</span>
                  <input type="date" value={bulkDate} onChange={e=>setBulkDate(e.target.value)}
                    style={{padding:'5px 8px',border:`1px solid ${L.bd}`,borderRadius:5,fontSize:12,color:L.t1,fontFamily:L.font,outline:'none'}}/>
                  <Btn label="Apply" primary small onClick={applyBulk}/>
                  <button onClick={()=>setShowBulkDate(false)} style={{padding:'4px 8px',border:`1px solid ${L.bd}`,borderRadius:5,background:L.s1,cursor:'pointer',fontSize:11,color:L.t3}}>Cancel</button>
                </div>
              )}

              <div style={{border:`1px solid ${L.bd}`,borderRadius:8,overflow:'hidden',fontSize:12}}>
                <div style={{display:'grid',gridTemplateColumns:'22px 1.5fr 1fr 1fr 90px 80px 1fr 95px 18px',
                  padding:'7px 12px',background:L.s3,borderBottom:`1px solid ${L.bd}`,
                  fontSize:9,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.05em',gap:6,alignItems:'center'}}>
                  <span/><span>Attribute</span><span>DB Type</span><span>Role</span>
                  <span style={{color:L.teal,textAlign:'center'}}>Semantic</span>
                  <span style={{color:L.blue,textAlign:'center'}}>AI</span>
                  <span>Domain</span><span>Eff. From</span><span/>
                </div>
                {filteredRows.map((r,rawIdx)=>{
                  const actualIdx=attrRows.indexOf(r); const isExp=expandRow===actualIdx
                  const bg=r.op?(rawIdx%2?'#fdf6f0':'#fef9f4'):(rawIdx%2?L.s2:L.s1)
                  return (
                    <div key={r.cd} style={{borderBottom:`1px solid ${L.bd2}`}}>
                      <div style={{display:'grid',gridTemplateColumns:'22px 1.5fr 1fr 1fr 90px 80px 1fr 95px 18px',
                        padding:'7px 12px',alignItems:'center',gap:6,background:bg}}>
                        <button onClick={()=>setExpandRow(isExp?null:actualIdx)}
                          style={{width:16,height:16,borderRadius:3,border:`1px solid ${L.bd}`,background:L.s1,cursor:'pointer',fontSize:10,color:L.t3,display:'flex',alignItems:'center',justifyContent:'center'}}>
                          {isExp?'−':'+'}
                        </button>
                        <div>
                          {r.logicalShortNm&&(
                            <div style={{fontSize:10,fontWeight:700,color:L.tealDk,marginBottom:1,lineHeight:1.2}}>{r.logicalShortNm}</div>
                          )}
                          <div style={{display:'flex',alignItems:'center',gap:5}}>
                            <span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:r.semantic?L.t1:L.t4}}>{r.cd}</span>
                            {r.pk&&<Chip text="PK" c={L.pur} bg={L.purBg} sz={8}/>}
                            {r.indexed&&!r.pk&&<Chip text="IDX" c={L.grn} bg={L.grnBg} sz={8}/>}
                            {r.op&&<Chip text="op" c={L.amb} bg={L.ambBg} sz={8}/>}
                          </div>
                          <div style={{fontSize:9,color:L.t4,marginTop:1}}>{r.logicalLongNm?r.logicalLongNm.slice(0,38):(r.desc||'').slice(0,38)}{((r.logicalLongNm||r.desc||'').length>38?'…':'')}</div>
                        </div>
                        <span style={{fontFamily:L.mono,fontSize:9,color:L.t3}}>{r.dbType}</span>
                        <select value={r.semanticRole} onChange={e=>updateAttr(actualIdx,'semanticRole',e.target.value)}
                          disabled={!r.semantic}
                          style={{padding:'3px 4px',border:`1px solid ${L.bd}`,borderRadius:4,fontSize:9,color:r.semantic?L.t1:L.t4,background:r.semantic?L.s1:L.s4,outline:'none',width:'100%',opacity:r.semantic?1:.5}}>
                          {['IDENTIFIER','DIMENSION','MEASURE','CODE','DATE','FLAG','TEXT','—'].map(o=><option key={o}>{o}</option>)}
                        </select>
                        <div style={{display:'flex',justifyContent:'center'}}>
                          <Toggle on={r.semantic}   onChange={v=>updateAttr(actualIdx,'semantic',v)}  label="Sem" onColor={L.teal}/>
                        </div>
                        <div style={{display:'flex',justifyContent:'center'}}>
                          <Toggle on={r.aiExposed}  onChange={v=>updateAttr(actualIdx,'aiExposed',v)} label="AI"  onColor={L.blue}/>
                        </div>
                        <select value={r.domain||''} onChange={e=>updateAttr(actualIdx,'domain',e.target.value)}
                          style={{padding:'3px 4px',border:`1px solid ${L.bd}`,borderRadius:4,fontSize:9,color:r.domain?L.ambDk:L.t4,background:L.s1,outline:'none',width:'100%'}}>
                          <option value="">None</option>
                          {Object.keys(DOMAINS).map(d=><option key={d} value={d}>{d}</option>)}
                        </select>
                        <input type="date" value={r.effectiveFrom} onChange={e=>updateAttr(actualIdx,'effectiveFrom',e.target.value)}
                          style={{padding:'3px 4px',border:`1px solid ${L.bd}`,borderRadius:4,fontSize:9,color:L.t2,fontFamily:L.font,outline:'none',width:'100%'}}/>
                        <div style={{width:8,height:8,borderRadius:4,margin:'0 auto',background:r.semantic?L.teal:r.aiExposed?L.blue:L.t4}}/>
                      </div>
                      {isExp&&(
                        <div style={{padding:'12px 14px 14px 50px',background:r.op?'#fdf0e8':L.s3,borderTop:`1px solid ${L.bd2}`}}>
                          {/* Row A — Logical Names (admin-set; client can request override via workflow) */}
                          <div style={{display:'grid',gridTemplateColumns:'1fr 2fr',gap:10,marginBottom:10,
                            padding:'10px 12px',background:'#f8fffe',border:`1px solid ${L.teal}33`,borderRadius:7}}>
                            <div>
                              <label style={{display:'block',fontSize:10,fontWeight:700,color:L.tealDk,marginBottom:3}}>
                                Logical short name <span style={{color:L.t4,fontWeight:400}}>≤ 32 chars</span>
                              </label>
                              <input value={r.logicalShortNm||''} onChange={e=>updateAttr(actualIdx,'logicalShortNm',e.target.value)}
                                maxLength={32} placeholder="e.g. Acct CD"
                                style={{width:'100%',padding:'5px 8px',border:`1px solid ${L.teal}55`,borderRadius:5,
                                  fontSize:12,color:L.t1,fontFamily:L.font,outline:'none',boxSizing:'border-box'}}/>
                              <div style={{fontSize:9,color:L.t4,marginTop:3}}>
                                Abbreviations OK · used in column headers, chips
                              </div>
                            </div>
                            <div>
                              <label style={{display:'block',fontSize:10,fontWeight:700,color:L.tealDk,marginBottom:3}}>
                                Logical long name <span style={{color:L.t4,fontWeight:400}}>fully expanded, no abbreviations</span>
                              </label>
                              <input value={r.logicalLongNm||''} onChange={e=>updateAttr(actualIdx,'logicalLongNm',e.target.value)}
                                placeholder="e.g. Chart of Accounts Code"
                                style={{width:'100%',padding:'5px 8px',border:`1px solid ${L.teal}55`,borderRadius:5,
                                  fontSize:12,color:L.t1,fontFamily:L.font,outline:'none',boxSizing:'border-box'}}/>
                              <div style={{fontSize:9,color:L.t4,marginTop:3}}>
                                Used by AI (prompt context), report labels, API display names
                              </div>
                            </div>
                          </div>
                          {/* Row B — Description + AI Context */}
                          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:10}}>
                            <div>
                              <label style={{display:'block',fontSize:10,fontWeight:600,color:L.t2,marginBottom:3}}>
                                Business description
                              </label>
                              <textarea value={r.desc} onChange={e=>updateAttr(actualIdx,'desc',e.target.value)}
                                rows={2} placeholder="What does this attribute represent in business terms?"
                                style={{width:'100%',padding:'5px 8px',border:`1px solid ${L.bd}`,borderRadius:5,
                                  fontSize:11,color:L.t1,fontFamily:L.font,outline:'none',resize:'vertical',boxSizing:'border-box'}}/>
                            </div>
                            <div>
                              <label style={{display:'block',fontSize:10,fontWeight:600,color:L.blueDk,marginBottom:3}}>
                                <span style={{color:L.blue}}>⚡</span> AI context <span style={{color:L.t4,fontWeight:400}}>(how Lexie uses this attribute)</span>
                              </label>
                              <textarea value={r.aiCtx||''} onChange={e=>updateAttr(actualIdx,'aiCtx',e.target.value)}
                                rows={2} placeholder="e.g. 'Use this for all balance queries. Positive = asset, negative = liability.'"
                                style={{width:'100%',padding:'5px 8px',border:`1px solid ${L.blue}55`,borderRadius:5,
                                  fontSize:11,color:L.t1,fontFamily:L.font,outline:'none',resize:'vertical',
                                  background:L.blueBg,boxSizing:'border-box'}}/>
                            </div>
                          </div>
                          {/* Row B — Domain values configuration */}
                          <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:7,padding:'10px 12px'}}>
                            <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
                              <span style={{fontSize:10,fontWeight:700,color:L.t2,textTransform:'uppercase',letterSpacing:'.06em'}}>Domain values</span>
                              {/* Mode toggle */}
                              {[
                                {v:'NONE',      l:'None'},
                                {v:'ENUM_LIST',  l:'Enumerated list'},
                                {v:'REF_DOMAIN', l:'Reference domain'},
                              ].map(({v,l})=>(
                                <button key={v} onClick={()=>updateAttr(actualIdx,'domainMode',v)} style={{
                                  padding:'3px 9px',borderRadius:10,fontSize:10,fontWeight:700,cursor:'pointer',
                                  border:`1px solid ${(r.domainMode||'NONE')===v?L.amb:L.bd}`,
                                  background:(r.domainMode||'NONE')===v?L.ambBg:L.s1,
                                  color:(r.domainMode||'NONE')===v?L.ambDk:L.t3,
                                }}>{l}</button>
                              ))}
                              <div style={{flex:1}}/>
                              <input type="date" value={r.effectiveTo||''} onChange={e=>updateAttr(actualIdx,'effectiveTo',e.target.value)}
                                style={{padding:'3px 6px',border:`1px solid ${L.bd}`,borderRadius:4,fontSize:10,color:L.t2,fontFamily:L.font,outline:'none'}}/>
                              <span style={{fontSize:10,color:L.t4}}>eff. to</span>
                            </div>
                            {/* NONE */}
                            {(r.domainMode||'NONE')==='NONE'&&(
                              <p style={{margin:0,fontSize:11,color:L.t4,fontStyle:'italic'}}>No domain constraint — free-form values.</p>
                            )}
                            {/* BOOLEAN — v2.10.0: registered as a two-value ENUM_LIST, polarity is per-attribute */}
                            {(r.domainMode||'NONE')==='ENUM_LIST'&&r.dbType==='boolean'&&(
                              <div style={{marginBottom:8,padding:'8px 10px',background:L.ambBg,border:`1px solid ${L.amb}55`,borderRadius:6}}>
                                <div style={{fontSize:10,fontWeight:700,color:L.ambDk,marginBottom:6}}>
                                  BOOLEAN — two-value domain. Polarity is attribute-specific and must be stated (Y may mean Accepted here and Delinquent elsewhere).
                                </div>
                                {(BOOLEAN_POLARITY[r.cd]||[{v:'Y',l:''},{v:'N',l:''}]).map(({v,l})=>(
                                  <div key={v} style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}>
                                    <span style={{fontFamily:L.mono,fontWeight:800,fontSize:11,minWidth:18,
                                      color:v==='Y'?L.grn:L.cor}}>{v}</span>
                                    <input defaultValue={l} placeholder={`Description when ${v}`}
                                      style={{flex:1,padding:'4px 8px',border:`1px solid ${L.bd}`,borderRadius:4,
                                        fontSize:11,color:L.t1,fontFamily:L.font,outline:'none'}}/>
                                  </div>
                                ))}
                              </div>
                            )}
                            {/* ENUM LIST */}
                            {(r.domainMode||'NONE')==='ENUM_LIST'&&(
                              <div>
                                <div style={{display:'flex',alignItems:'flex-start',gap:10}}>
                                  <div style={{flex:1}}>
                                    <label style={{fontSize:10,color:L.t3,fontWeight:600,display:'block',marginBottom:2}}>
                                      Allowed values <span style={{color:L.t4,fontWeight:400}}>(one per line: CODE = Label)</span>
                                    </label>
                                    <textarea
                                      value={r.domainEnum||''}
                                      onChange={e=>updateAttr(actualIdx,'domainEnum',e.target.value)}
                                      rows={3}
                                      placeholder={'ACTIVE = Active record\nINACTIVE = Soft-deleted\nPENDING = Awaiting approval'}
                                      style={{width:'100%',padding:'5px 8px',border:`1px solid ${L.bd}`,borderRadius:5,
                                        fontSize:11,fontFamily:L.mono,color:L.t1,outline:'none',resize:'vertical',boxSizing:'border-box'}}/>
                                  </div>
                                  {r.domainEnum&&(
                                    <div style={{minWidth:120}}>
                                      <label style={{fontSize:10,color:L.t3,fontWeight:600,display:'block',marginBottom:2}}>Preview</label>
                                      <div style={{display:'flex',flexDirection:'column',gap:3}}>
                                        {r.domainEnum.split('\n').filter(Boolean).slice(0,6).map((line,i)=>{
                                          const [code,...rest]=line.split('='); const lbl=rest.join('=').trim()
                                          return (
                                            <div key={i} style={{display:'flex',gap:5,alignItems:'center'}}>
                                              <span style={{fontFamily:L.mono,fontSize:9,fontWeight:700,color:L.ambDk,
                                                background:L.ambBg,padding:'1px 5px',borderRadius:3}}>{code.trim()}</span>
                                              {lbl&&<span style={{fontSize:10,color:L.t3}}>{lbl}</span>}
                                            </div>
                                          )
                                        })}
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </div>
                            )}
                            {/* REF DOMAIN */}
                            {(r.domainMode||'NONE')==='REF_DOMAIN'&&(
                              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                                <div>
                                  <label style={{fontSize:10,color:L.t3,fontWeight:600,display:'block',marginBottom:2}}>
                                    Registered domain set
                                  </label>
                                  <select value={r.domain||''} onChange={e=>updateAttr(actualIdx,'domain',e.target.value)}
                                    style={{width:'100%',padding:'5px 8px',border:`1px solid ${L.bd}`,borderRadius:5,
                                      fontSize:11,color:r.domain?L.ambDk:L.t4,background:L.s1,outline:'none'}}>
                                    <option value="">Select domain…</option>
                                    {Object.keys(DOMAINS).map(d=><option key={d} value={d}>{d}</option>)}
                                  </select>
                                  {r.domain&&DOMAINS[r.domain]&&(
                                    <div style={{display:'flex',gap:4,flexWrap:'wrap',marginTop:5}}>
                                      {DOMAINS[r.domain].slice(0,5).map(({v,l})=>(
                                        <span key={v} style={{fontFamily:L.mono,fontSize:9,fontWeight:700,color:L.ambDk,
                                          background:L.ambBg,padding:'1px 5px',borderRadius:3}}>{v}</span>
                                      ))}
                                      {DOMAINS[r.domain].length>5&&<span style={{fontSize:9,color:L.t4}}>+{DOMAINS[r.domain].length-5} more</span>}
                                    </div>
                                  )}
                                </div>
                                <div>
                                  <label style={{fontSize:10,color:L.t3,fontWeight:600,display:'block',marginBottom:2}}>
                                    Reference table <span style={{color:L.t4,fontWeight:400}}>(optional override)</span>
                                  </label>
                                  <input value={r.domainRefTable||''} onChange={e=>updateAttr(actualIdx,'domainRefTable',e.target.value)}
                                    placeholder="e.g. ref.organization_hierarchy"
                                    style={{width:'100%',padding:'5px 8px',border:`1px solid ${L.bd}`,borderRadius:5,
                                      fontSize:11,fontFamily:L.mono,color:L.t1,outline:'none'}}/>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
              <div style={{marginTop:8,display:'flex',gap:12,fontSize:11,color:L.t3}}>
                <span>{attrRows.length} total</span>·
                <span style={{color:L.teal,fontWeight:700}}>{semanticCount} semantic</span>·
                <span style={{color:L.blue,fontWeight:700}}>{aiOnlyCount} AI-only</span>·
                <span style={{color:L.t4}}>{excludedCount} excluded</span>
              </div>
            </Fragment>
          )}
        </div>
      )}

      {/* ── AI Context tab ── */}
      {wizTab==='ai'&&(
        <div>
          <h3 style={{margin:'0 0 6px',fontSize:14,fontWeight:700,color:L.t1}}>AI governance context</h3>
          <p style={{margin:'0 0 14px',fontSize:12,color:L.t3,lineHeight:1.6}}>
            Required for AI_ALLOWED and AI_RESTRICTED tiers. Determines how Lexie queries and reasons about this object.
          </p>
          <div style={{display:'grid',gap:14}}>
            <TextArea label="AI business context" req value={form.aiCtx} onChange={v=>f('aiCtx',v)} rows={5}
              placeholder="Explain the business meaning for AI reasoning. What does this object represent? What regulatory framework does it serve?"/>
            <TextArea label="AI prompt guidance" req value={form.aiGuide} onChange={v=>f('aiGuide',v)} rows={6}
              placeholder="Instruct AI on: mandatory filters, join requirements, aggregation rules, period-end conventions, regulatory constraints, edge cases."/>
          </div>
        </div>
      )}

      {/* ── Review tab ── */}
      {wizTab==='review'&&(
        <div>
          <h3 style={{margin:'0 0 16px',fontSize:14,fontWeight:700,color:L.t1}}>Review &amp; submit</h3>
          {[
            ['Schema',         form.schema],
            ['Object',         form.objCd||<span style={{color:L.cor}}>required</span>],
            ['Grain',          form.grain||<span style={{color:L.cor}}>required</span>],
            ['Effective from', form.effectiveFrom||<span style={{color:L.cor}}>required</span>],
            ['Register for',   <span style={{display:'flex',gap:8}}>
              {form.regSemantic&&<Chip text="Semantic Layer" c={L.pur} bg={L.purBg}/>}
              {form.regAI&&<Chip text="AI Context" c={L.teal} bg={L.tealBg}/>}
              {form.regCatalog&&<Chip text="Data Catalog" c={L.blue} bg={L.blueBg}/>}
              {!form.regSemantic&&!form.regAI&&!form.regCatalog&&<span style={{color:L.cor}}>None selected</span>}
            </span>],
            ['Attributes', attrRows.length>0
              ?<span style={{color:L.grn,fontWeight:600}}>✓ {attrRows.length} introspected · {semanticCount} semantic · {aiOnlyCount} AI-only</span>
              :<span style={{color:L.amb}}>⚠ Not yet introspected</span>],
            ['AI context',     form.aiCtx?<span style={{color:L.grn,fontWeight:600}}>✓ Provided</span>:<span style={{color:L.cor}}>✗ Required</span>],
          ].map(([l,v])=>(
            <div key={String(l)} style={{display:'flex',padding:'8px 0',borderBottom:`1px solid ${L.bd2}`}}>
              <span style={{width:160,fontSize:12,fontWeight:600,color:L.t2,flexShrink:0}}>{l}</span>
              <span style={{fontSize:12,color:L.t1}}>{v}</span>
            </div>
          ))}
          <InfoBanner text="Submitting creates meta.workflow_task (PENDING). On approval: the object is activated in the semantic-service for Semantic registrations; AI attributes loaded into meta.attribute_catalog; Data Catalog entry created. Effective dates applied at both object and attribute level." color={L.teal} bg={L.tealBg}/>
          <div style={{marginTop:16}}><Btn label="Submit for governance approval" icon={CheckSquare} primary onClick={()=>api.submitRegistrationForApproval({form,attrRows})}/></div>
        </div>
      )}

      {/* Wizard tab nav */}
      <div style={{display:'flex',justifyContent:'space-between',marginTop:22,paddingTop:16,borderTop:`1px solid ${L.bd}`}}>
        <Btn label="Back" onClick={()=>{const ts=wizTabs.map(t=>t.id);const i=ts.indexOf(wizTab);if(i>0)setWizTab(ts[i-1])}} disabled={wizTab===wizTabs[0].id}/>
        <div style={{display:'flex',gap:8}}>
          <Btn label="← Discard Draft" small onClick={onClose}/>
          <Btn label="Next" icon={ChevronRight} primary onClick={()=>{const ts=wizTabs.map(t=>t.id);const i=ts.indexOf(wizTab);if(i<ts.length-1)setWizTab(ts[i+1])}} disabled={wizTab===wizTabs[wizTabs.length-1].id}/>
        </div>
      </div>
    </div>
  )
}

function RegisterScreen({onNav}) {
  // ── Draft tab management ─────────────────────────────────────────────
  const [drafts,   setDrafts]   = useState([])    // [{id, ctx}]
  const [activeId, setActiveId] = useState(null)  // null = Inventory

  const openDraft = (ctx={}) => {
    const id = randId('REG')
    setDrafts(p=>[...p, {id, ctx}])
    setActiveId(id)
  }
  const closeDraft = (id) => {
    setDrafts(p=>{
      const rem = p.filter(d=>d.id!==id)
      if(activeId===id) setTimeout(()=>setActiveId(rem.length>0?rem[rem.length-1].id:null),0)
      return rem
    })
  }

  // ── Inventory filter state ────────────────────────────────────────────
  const [invSearch,  setInvSearch]  = useState('')
  const [invSchema,  setInvSchema]  = useState('ALL')
  const [invStatus,  setInvStatus]  = useState('ALL')
  const [invView,    setInvView]    = useState('QUEUE')   // QUEUE = registration-actionable subset · ALL = full inventory
  const [hovRow,     setHovRow]     = useState(null)
  const [histObj,    setHistObj]    = useState(null)

  const schemas  = ['ALL',...[...new Set(OBJECT_INVENTORY.map(o=>o.schema))]]
  const statuses = ['ALL','REGISTERED','PENDING_REGISTRATION','NEW_OBJECT','NOT_ELIGIBLE']
  const bySchemaInv = OBJECT_INVENTORY
    .filter(o=>(invView==='ALL'||isRegActionable(o))&&(invSchema==='ALL'||o.schema===invSchema)&&(invStatus==='ALL'||o.st===invStatus)&&(!invSearch||(o.obj+o.schema).includes(invSearch.toLowerCase())))
    .reduce((m,o)=>{(m[o.schema]=m[o.schema]||[]).push(o);return m},{})
  const totals = {
    all:   OBJECT_INVENTORY.length,
    new:   OBJECT_INVENTORY.filter(o=>o.st==='NEW_OBJECT').length,
    pend:  OBJECT_INVENTORY.filter(o=>o.st==='PENDING_REGISTRATION').length,
    reg:   OBJECT_INVENTORY.filter(o=>o.st==='REGISTERED').length,
    inelig:OBJECT_INVENTORY.filter(o=>o.st==='NOT_ELIGIBLE').length,
  }
  const COLS = '1.4fr 56px 0.65fr 1.3fr  56px 56px 56px  1fr 0.8fr  1.2fr 80px 44px'
  const HDR  = ['Object','Engine','Type','Status','Sem','AI','Catalog','Attrs','Registered By','Registered At','Action']  // logicalShortNm shown as subtitle in Object cell

  // Row click → opens a new draft tab with context pre-filled
  const initiateFromRow = (row) => openDraft({
    schema: row.schema, obj: row.obj, type: row.type,
    sem: row.sem===true||(row.sem===null&&!['iam','logic','workspace'].includes(row.schema)),
    ai:  row.ai===true||(row.ai===null),
    cat: row.cat===true||(row.cat===null&&!['iam','logic','workspace'].includes(row.schema)),
  })

  return (
    <div>
      <PageHdr title="Register Object" icon={Plus}
        sub="Registration queue — only objects that are New, have updates, pending, or not eligible (synced with the full Object Inventory). Object code is selected from the governed list, never free-typed. Toggle ‘All objects’ to view the entire inventory."/>
      <InfoBanner text="Registers EXISTING database objects. Physical tables/columns must already exist. Registration does not create or alter the physical schema. Objects can be registered for AI without being in the Semantic layer (e.g. workflow, metadata tables)." color={L.amber} bg={L.ambBg}/>
      <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:'20px 24px',marginTop:12}}>
        <GovTabStrip
          base={[{id:null, label:'Object Inventory'}]}
          drafts={drafts}
          activeId={activeId}
          onSelect={setActiveId}
          onClose={closeDraft}
          addLabel=" Register Object"
          onAdd={()=>openDraft()}/>
        {activeId===null&&(
          <div>
      {/* Summary pills */}
      <div style={{display:'flex',gap:8,marginBottom:14,flexWrap:'wrap',alignItems:'center'}}>
        {[
          {label:`${totals.reg} Registered`,     color:'#2d6a10',bg:'#e5f3db'},
          {label:`${totals.pend} Pending`,       color:'#B87414',bg:'#faeeda'},
          {label:`${totals.new} New`,            color:'#2265B8',bg:'#e4eef9'},
          {label:`${totals.inelig} Not Eligible`,color:'#7a9cc8',bg:'#E4EEF9'},
        ].map(({label,color,bg})=>(
          <span key={label} style={{padding:'3px 10px',borderRadius:12,fontSize:11,fontWeight:700,background:bg,color}}>{label}</span>
        ))}
        <div style={{flex:1}}/>
        {/* View toggle: registration queue vs full inventory */}
        <div style={{display:'inline-flex',border:`1px solid ${L.bd}`,borderRadius:7,overflow:'hidden'}}>
          {[['QUEUE','Registration queue'],['ALL','All objects']].map(([v,lbl])=>(
            <button key={v} onClick={()=>setInvView(v)} style={{border:'none',padding:'6px 11px',fontSize:11,fontWeight:700,cursor:'pointer',
              fontFamily:'inherit',background:invView===v?L.teal:'#fff',color:invView===v?'#fff':L.t3}}>{lbl}</button>
          ))}
        </div>
        {/* Filters */}
        <div style={{display:'flex',alignItems:'center',gap:6,padding:'6px 10px',background:L.s3,border:`1px solid ${L.bd}`,borderRadius:7}}>
          <Search size={12} color={L.t4}/>
          <input value={invSearch} onChange={e=>setInvSearch(e.target.value)} placeholder="Search objects…"
            style={{border:'none',outline:'none',fontSize:12,color:L.t1,background:'transparent',width:140}}/>
        </div>
        <select value={invSchema} onChange={e=>setInvSchema(e.target.value)}
          style={{padding:'6px 10px',border:`1px solid ${L.bd}`,borderRadius:6,fontSize:12,color:L.t1,background:L.s1,outline:'none'}}>
          {schemas.map(s=><option key={s}>{s}</option>)}
        </select>
        <select value={invStatus} onChange={e=>setInvStatus(e.target.value)}
          style={{padding:'6px 10px',border:`1px solid ${L.bd}`,borderRadius:6,fontSize:12,color:L.t1,background:L.s1,outline:'none'}}>
          {statuses.map(s=><option key={s} value={s}>{s.replace(/_/g,' ')}</option>)}
        </select>
      </div>

      {/* Column header */}
      <div style={{display:'grid',gridTemplateColumns:COLS,padding:'8px 14px',
        background:L.s3,borderRadius:'8px 8px 0 0',border:`1px solid ${L.bd}`,
        fontSize:9,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.06em',
        gap:6,alignItems:'center',borderBottom:'none'}}>
        {HDR.map(h=><span key={h} style={{textAlign:['Sem','AI','Catalog'].includes(h)?'center':'left'}}>{h}</span>)}<span/>
      </div>

      {/* Grouped by schema */}
      <div style={{border:`1px solid ${L.bd}`,borderRadius:'0 0 8px 8px',overflow:'hidden'}}>
        {Object.entries(bySchemaInv).length===0&&(
          <div style={{padding:'24px',textAlign:'center',color:L.t4,fontSize:12}}>No objects match current filter</div>
        )}
        {Object.entries(bySchemaInv).map(([schema,rows])=>(
          <div key={schema}>
            {/* Schema divider */}
            <div style={{display:'flex',alignItems:'center',gap:7,padding:'5px 14px',
              background:L.s4,borderBottom:`1px solid ${L.bd}`,borderTop:`1px solid ${L.bd2}`}}>
              <Database size={10} color={L.t3}/>
              <span style={{fontSize:10,fontWeight:700,color:L.t2,textTransform:'uppercase',letterSpacing:'.07em'}}>{schema}</span>
              <span style={{fontSize:9,color:L.t4}}>· {rows.length} objects</span>
            </div>
            {/* Object rows */}
            {rows.map((row,i)=>{
              const stcfg = INV_ST[regDispStatus(row)]||INV_ST.NEW_OBJECT
              const canAct = row.st==='NEW_OBJECT'||row.st==='PENDING_REGISTRATION'||row.st==='REGISTERED'
              const isHov  = hovRow===`${schema}.${row.obj}`
              const isInelig = row.st==='NOT_ELIGIBLE'
              return (
                <div key={row.obj}
                  onMouseEnter={()=>setHovRow(`${schema}.${row.obj}`)}
                  onMouseLeave={()=>setHovRow(null)}
                  style={{display:'grid',gridTemplateColumns:COLS,padding:'9px 14px',
                    borderBottom:`1px solid ${L.bd2}`,fontSize:12,alignItems:'center',gap:6,
                    background:isHov&&canAct?L.blueBg:i%2?L.s2:L.s1,
                    opacity:isInelig?.6:1,
                    cursor:canAct?'pointer':'default'}}
                  onClick={()=>canAct&&initiateFromRow(row)}>

                  {/* Object name */}
                  <div>
                    <div>
                      {CATALOG[`${row.schema}.${row.obj}`]?.logicalShortNm&&(
                        <div style={{fontSize:10,fontWeight:700,color:isHov&&canAct?L.blue:L.tealDk,lineHeight:1.2,marginBottom:1}}>
                          {CATALOG[`${row.schema}.${row.obj}`].logicalShortNm}</div>
                      )}
                      <div style={{display:'flex',alignItems:'center',gap:4}}>
                        <span style={{fontFamily:L.mono,fontSize:10,color:isHov&&canAct?L.blue:L.t2}}>{row.obj}</span>
                        <EngineBadge connectionId={CATALOG[`${row.schema}.${row.obj}`]?.connectionId||'lextr-pg'} tiny/>
                        <TenantChip tenant="GLOBAL" sz={7}/>
                      </div>
                    </div>
                    {row.note&&<div style={{fontSize:9,color:L.t3,marginTop:1}}>{row.note}</div>}
                  </div>

                  {/* Type */}
                  <Chip text={row.type} c={L.t3} bg={L.s4} sz={9}/>

                  {/* Status */}
                  <span style={{display:'inline-flex',alignItems:'center',padding:'2px 8px',borderRadius:4,
                    fontSize:10,fontWeight:700,background:stcfg.bg,color:stcfg.c,whiteSpace:'nowrap'}}>
                    {stcfg.label}
                  </span>

                  {/* Semantic ✓ */}
                  <CheckMark val={row.sem} disabled={isInelig}/>

                  {/* AI ✓ */}
                  <CheckMark val={row.ai} disabled={isInelig}/>

                  {/* Data Catalog ✓ */}
                  <CheckMark val={row.cat} disabled={isInelig}/>

                  {/* Attr count */}
                  <span style={{fontSize:11,color:L.t3}}>
                    {row.attrReg>0?<Fragment><strong style={{color:L.t1}}>{row.attrReg}</strong>/{row.attrTotal}</Fragment>:<span style={{color:L.t4}}>0/{row.attrTotal}</span>}
                  </span>

                  {/* Registered by */}
                  <span style={{fontSize:11,color:row.regBy?L.t2:L.t4}}>{row.regBy||'—'}</span>

                  {/* Registered at */}
                  <span style={{fontSize:11,color:row.regAt?L.t2:L.t4}}>{row.regAt||'—'}</span>

                  {/* Action */}
                  <div onClick={e=>e.stopPropagation()}>
                    {row.st==='NEW_OBJECT'&&(
                      <button onClick={()=>initiateFromRow(row)} style={{
                        padding:'4px 10px',borderRadius:5,border:`1px solid ${L.blue}`,
                        background:L.blueBg,cursor:'pointer',fontSize:11,fontWeight:700,color:L.blueDk,whiteSpace:'nowrap'}}>
                        Register
                      </button>
                    )}
                    {row.st==='PENDING_REGISTRATION'&&(
                      <button onClick={()=>initiateFromRow(row)} style={{
                        padding:'4px 10px',borderRadius:5,border:`1px solid ${L.amber}`,
                        background:L.ambBg,cursor:'pointer',fontSize:11,fontWeight:700,color:L.ambDk,whiteSpace:'nowrap'}}>
                        Continue
                      </button>
                    )}
                    {row.st==='REGISTERED'&&(
                      <div style={{display:'flex',gap:4}}>
                        <button onClick={()=>initiateFromRow(row)} style={{
                          padding:'4px 8px',borderRadius:5,border:`1px solid ${L.bd}`,
                          background:L.s1,cursor:'pointer',fontSize:11,fontWeight:600,color:L.t2,whiteSpace:'nowrap'}}>
                          Update
                        </button>
                        <button onClick={()=>onNav('catalog')} style={{
                          padding:'4px 8px',borderRadius:5,border:`1px solid ${L.bd}`,
                          background:L.s1,cursor:'pointer',fontSize:11,color:L.t3}}>View</button>
                      </div>
                    )}
                    {row.st==='NOT_ELIGIBLE'&&(
                      <span style={{fontSize:10,color:L.t4,fontStyle:'italic'}}>Excluded</span>
                    )}
                  </div>

                  {/* History */}
                  <div style={{display:'flex',justifyContent:'center'}} onClick={e=>e.stopPropagation()}><HistBtn onClick={()=>setHistObj(row)}/></div>
                </div>
              )
            })}
          </div>
        ))}
      </div>

      {/* Legend */}
      <div style={{marginTop:10,display:'flex',gap:16,fontSize:11,color:L.t3,alignItems:'center',flexWrap:'wrap'}}>
        <span><strong style={{color:L.t1}}>✓</strong> = registered for this purpose</span>
        <span><strong style={{color:L.cor}}>✗</strong> = explicitly excluded</span>
        <span style={{color:L.bd2}}>—</span> = not yet registered / n/a
        <div style={{flex:1}}/>
        <span style={{fontSize:10,color:L.t4}}>Click any row to initiate or update registration · AI can be registered independently of Semantic layer</span>
      </div>
          </div>
        )}
        {drafts.map(d=>(
          <div key={d.id} style={{display:activeId===d.id?'block':'none'}}>
            <RegisterWizard id={d.id} initCtx={d.ctx} onClose={()=>closeDraft(d.id)} onNav={onNav}/>
          </div>
        ))}
      </div>

      <Drawer open={!!histObj} onClose={()=>setHistObj(null)} eyebrow="Object · History"
        title={histObj?(CATALOG[`${histObj.schema}.${histObj.obj}`]?.logicalShortNm||histObj.obj):''}
        sub={histObj?`${histObj.schema}.${histObj.obj}`:''}
        footer="Append-only governance log — who · what · when. Illustrative in this prototype.">
        {histObj && <HistoryTimeline events={govEvents({name:histObj.obj, kind:'Object', status:histObj.st, by:histObj.regBy||'a.rao', seed:(histObj.obj||'').length})}/>}
      </Drawer>
    </div>
  )
}



function PairingCreateForm({id, onClose}) {
  const [srcObj,  setSrcObj]  = useState('')
  const [dispAttr,setDispAttr]= useState('')
  const [filtAttr,setFiltAttr]= useState('')
  const [strategy,setStrategy]= useState('CACHED_LOOKUP')
  const [cardinality,setCard] = useState('ONE_TO_ONE')
  const [bidir,setBidir]      = useState(false)

  const srcObjAttrs  = srcObj&&CATALOG[srcObj]?.attrs||[]
  const displayAttrs = srcObjAttrs.filter(a=>['DIMENSION','CODE'].includes(a.semantic)&&!a.indexed)
  const filterAttrs  = srcObjAttrs.filter(a=>a.indexed||a.pk)
  const canCreate    = srcObj&&dispAttr&&filtAttr&&dispAttr!==filtAttr
  // OPA: block cross-engine pairing (CH objects cannot be paired — pairing
  // execution runs on Lextr PG; CH data is not accessible at pairing resolution time)
  const pairOpaPolicy = opaEvaluate('POL-CE-002',{
    srcConn: CATALOG[srcObj]?.connectionId||'lextr-pg',
    toConn:  'lextr-pg',  // pairing resolution always runs on Lextr PG
  })
  const pairBlocked = !!pairOpaPolicy

  const createPairing = () => {
    if (!canCreate) return
    api.registerPairing({srcObj,dispAttr,filtAttr,strategy,cardinality,bidir}).then(()=>onClose())
  }
  return (
    <div>
      <DraftActionBar id={id} accentColor={L.pur}
        onDiscard={onClose} onSaveDraft={()=>api.savePairingDraft({draftId:id,srcObj,dispAttr,filtAttr,strategy})} onSubmit={pairBlocked?null:createPairing} blocked={pairBlocked}/>
      {pairOpaPolicy&&srcObj&&(
        <PolicyBlock policy={pairOpaPolicy}
          context={{srcConn:CATALOG[srcObj]?.connectionId||'lextr-pg', toConn:'lextr-pg'}}/>
      )}
      <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:24}}>
        <h3 style={{margin:'0 0 6px',fontSize:14,fontWeight:700,color:L.t1}}>Register attribute pairing</h3>
        <p style={{margin:'0 0 20px',fontSize:12,color:L.t3,lineHeight:1.6}}>
          Select the source object and choose display and filter attributes from the registered catalog.
        </p>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16,marginBottom:20}}>
          <div>
            <label style={{fontSize:11,color:L.t3,fontWeight:700,display:'block',marginBottom:4}}>Source object *</label>
            <select value={srcObj} onChange={e=>{setSrcObj(e.target.value);setDispAttr('');setFiltAttr('')}}
              style={{width:'100%',padding:'7px 10px',borderRadius:6,border:`1px solid ${pairOpaPolicy&&srcObj?'#E24B4A':L.bd}`,fontSize:12,background:L.s1}}>
              <option value="">Select registered object…</option>
              {Object.keys(CATALOG).map(k=>(
                <option key={k} value={k}>
                  {k}{CATALOG[k]?.connectionId==='lextr-ch'?' [CH — policy restricted]':''}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label style={{fontSize:11,color:L.t3,fontWeight:700,display:'block',marginBottom:4}}>Strategy</label>
            <select value={strategy} onChange={e=>setStrategy(e.target.value)}
              style={{width:'100%',padding:'7px 10px',borderRadius:6,border:`1px solid ${L.bd}`,fontSize:12,background:L.s1}}>
              {['CACHED_LOOKUP','RUNTIME_QUERY','VECTOR_SEARCH'].map(s=><option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label style={{fontSize:11,color:L.t3,fontWeight:700,display:'block',marginBottom:4}}>Display attribute *</label>
            <select value={dispAttr} onChange={e=>setDispAttr(e.target.value)} disabled={!srcObj}
              style={{width:'100%',padding:'7px 10px',borderRadius:6,border:`1px solid ${L.bd}`,fontSize:12,background:L.s1}}>
              <option value="">Select…</option>
              {displayAttrs.map(a=><option key={a.cd} value={a.cd}>{a.cd} ({a.type})</option>)}
            </select>
          </div>
          <div>
            <label style={{fontSize:11,color:L.t3,fontWeight:700,display:'block',marginBottom:4}}>Filter attribute *</label>
            <select value={filtAttr} onChange={e=>setFiltAttr(e.target.value)} disabled={!srcObj}
              style={{width:'100%',padding:'7px 10px',borderRadius:6,border:`1px solid ${L.bd}`,fontSize:12,background:L.s1}}>
              <option value="">Select…</option>
              {filterAttrs.map(a=><option key={a.cd} value={a.cd}>{a.cd} ({a.type})</option>)}
            </select>
          </div>
          <SelectInput label="Cardinality" value={cardinality} onChange={setCard}
            options={['ONE_TO_ONE','ONE_TO_MANY','MANY_TO_ONE'].map(v=>({value:v,label:v}))}/>
          <div style={{display:'flex',alignItems:'center',paddingTop:20}}>
            <Toggle on={bidir} onChange={setBidir} label="Bidirectional pairing" onColor={L.teal}/>
          </div>
        </div>
        {dispAttr&&filtAttr&&(
          <div style={{padding:'10px 14px',background:L.tealBg,borderRadius:7,border:`1px solid ${L.teal}44`,marginBottom:16}}>
            <span style={{fontSize:12,color:L.tealDk}}>
              Preview: <strong style={{fontFamily:L.mono}}>{dispAttr}</strong> → <strong style={{fontFamily:L.mono}}>{filtAttr}</strong>
              {bidir&&<span> (and reverse)</span>}
            </span>
          </div>
        )}
        <div style={{display:'flex',gap:8}}>
          <Btn label="Register Pairing" icon={Check} primary onClick={createPairing} disabled={!canCreate}/>
          <Btn label="Cancel" onClick={onClose}/>
        </div>
      </div>
    </div>
  )
}

function PairingsScreen({onNav}) {
  const [drafts,   setDrafts]   = useState([])
  const [activeId, setActiveId] = useState(null)
  const [simPairing,setSimPairing]=useState(PAIRINGS[0])
  const [simInput,  setSimInput] = useState('')
  const [simResult, setSimResult]= useState(null)
  const [pTab,      setPTab]     = useState('registry')
  const [histPair,  setHistPair] = useState(null)

  const openDraft  = () => { const id=randId('PAIR'); setDrafts(p=>[...p,{id}]); setActiveId(id) }
  const closeDraft = (id) => {
    setDrafts(p=>{ const rem=p.filter(d=>d.id!==id); if(activeId===id) setTimeout(()=>setActiveId(rem.length>0?rem[rem.length-1].id:null),0); return rem })
  }

  const resolve = () => {
    if (!simInput||!simPairing) return
    const ex = (simPairing.cd==='CUST_NAME_TO_ID'?[
      {d:'Coca Cola Inc of America',f:'123456789'},{d:'JPMorgan Chase & Co',f:'987654321'},
    ]:simPairing.cd==='ORG_NODE_NAME_TO_CD'?[
      {d:'Bank Holding Company Alpha',f:'BHC_A001'},{d:'Bank Holding Company Beta',f:'BHC_B002'},
    ]:[{d:'Loans and Leases - Commercial',f:'ACC_4210'}]).find(e=>e.d.toLowerCase().includes(simInput.toLowerCase()))
    setSimResult(ex||{d:simInput,f:null})
  }
  const cols = '1.8fr 1fr 1.2fr 1.2fr 1.3fr 0.8fr 1fr 1fr 46px'

  const currentBase = activeId!==null ? activeId : pTab
  return (
    <div>
      <PageHdr title="Attribute Pairings" icon={Link2}
        sub="display attribute → filter attribute cross-column substitution · pairing resolution hook · index-optimized SQL"/>
      <GovTabStrip
        base={[
          {id:'registry',label:`Pairing Inventory (${PAIRINGS.length})`},
          {id:'resolver',label:'Live Resolver'},
        ]}
        drafts={drafts}
        activeId={currentBase}
        onSelect={id=>{if(id==='registry'||id==='resolver'){setActiveId(null);setPTab(id)}else setActiveId(id)}}
        onClose={closeDraft}
        addLabel=" Register Pairing"
        onAdd={openDraft}/>

      {activeId===null&&pTab==='registry'&&(
        <Fragment>
          <div style={{border:`1px solid ${L.bd}`,borderRadius:10,overflow:'hidden',background:L.s1}}>
            <div style={{display:'grid',gridTemplateColumns:cols,padding:'9px 14px',background:L.s3,
              borderBottom:`1px solid ${L.bd}`,gap:8,fontSize:10,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.07em'}}>
              {['Pairing Code','Strategy','Display Attr','Filter Attr','Source Object','Bidir','Status','Cardinality'].map(h=><span key={h}>{h}</span>)}<span/>
            </div>
            {PAIRINGS.map(p=>(
              <div key={p.cd} style={{display:'grid',gridTemplateColumns:cols,padding:'9px 14px',
                borderBottom:`1px solid ${L.bd2}`,gap:8,fontSize:12,alignItems:'center',background:L.s1}}>
                <span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:L.purDk}}>{p.cd}</span>
                <Chip text={p.strategy} c={L.teal} bg={L.tealBg} sz={9}/>
                <span style={{fontSize:11,color:L.t2}}>{p.dispAttr}</span>
                <span style={{fontSize:11,color:L.t3}}>{p.filtAttr}</span>
                <span style={{fontSize:10,color:L.t3,fontFamily:L.mono}}>{p.srcObj}</span>
                <span style={{fontSize:10,color:p.bidir?L.grn:L.t4}}>{p.bidir?'✓':'—'}</span>
                <span style={{display:'inline-flex',padding:'2px 7px',borderRadius:4,fontSize:10,fontWeight:700,
                  background:p.st==='ACTIVE'?L.grnBg:L.ambBg,color:p.st==='ACTIVE'?L.grn:L.amb}}>{p.st}</span>
                <Chip text={p.cardinality} c={L.pur} bg={L.purBg} sz={9}/>
                <div style={{display:'flex',justifyContent:'center'}}><HistBtn onClick={()=>setHistPair(p)}/></div>
              </div>
            ))}
          </div>
          <InfoBanner text="Register display and filter attributes via Register Object → Attributes tab first. Both attributes must be registered before a pairing can be created." color={L.blue} bg={L.blueBg}/>
        </Fragment>
      )}

      {activeId===null&&pTab==='resolver'&&(
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
          <Card title="Test resolver">
            <div style={{marginBottom:12}}>
              <label style={{fontSize:11,color:L.t3,fontWeight:600,display:'block',marginBottom:4}}>Select pairing</label>
              <select value={simPairing?.cd||''} onChange={e=>setSimPairing(PAIRINGS.find(p=>p.cd===e.target.value)||PAIRINGS[0])}
                style={{width:'100%',padding:'7px 10px',borderRadius:6,border:`1px solid ${L.bd}`,fontSize:12,background:L.s1}}>
                {PAIRINGS.map(p=><option key={p.cd} value={p.cd}>{p.cd}</option>)}
              </select>
            </div>
            <div style={{marginBottom:12}}>
              <label style={{fontSize:11,color:L.t3,fontWeight:600,display:'block',marginBottom:4}}>Display value (natural language)</label>
              <div style={{display:'flex',gap:8}}>
                <input value={simInput} onChange={e=>setSimInput(e.target.value)}
                  placeholder={simPairing?.example||'Enter a value...'}
                  style={{flex:1,padding:'7px 10px',borderRadius:6,border:`1px solid ${L.bd}`,fontSize:12}}/>
                <Btn label="Resolve" icon={Zap} primary onClick={resolve}/>
              </div>
            </div>
            {simResult&&(
              <div style={{padding:'10px 14px',borderRadius:7,border:`1px solid ${simResult.f?L.grn:L.cor}55`,background:simResult.f?L.grnBg:L.corBg}}>
                <div style={{fontSize:10,fontWeight:700,color:simResult.f?L.grn:L.cor,marginBottom:4}}>{simResult.f?'✓ Resolved':'✗ No match'}</div>
                {simResult.f&&<div style={{fontFamily:L.mono,fontSize:12,color:L.t1}}>"{simResult.d}" → <strong>{simResult.f}</strong></div>}
              </div>
            )}
          </Card>
          {simPairing&&(
            <Card title="Pairing definition">
              {[{label:'Strategy',val:simPairing.strategy},{label:'Source',val:simPairing.srcObj},
                {label:'Display',val:simPairing.dispAttr},{label:'Filter',val:simPairing.filtAttr},
                {label:'Bidir',val:simPairing.bidir?'Yes':'No'},{label:'Cardinality',val:simPairing.cardinality},
              ].map(({label,val})=>(
                <div key={label} style={{display:'flex',gap:8,padding:'6px 0',borderBottom:`1px solid ${L.bd2}`}}>
                  <span style={{fontSize:11,color:L.t4,minWidth:90}}>{label}</span>
                  <span style={{fontSize:12,color:L.t1,fontFamily:L.mono}}>{val}</span>
                </div>
              ))}
            </Card>
          )}
        </div>
      )}

      {drafts.map(d=>(
        <div key={d.id} style={{display:activeId===d.id?'block':'none'}}>
          <PairingCreateForm id={d.id} onClose={()=>closeDraft(d.id)}/>
        </div>
      ))}

      <Drawer open={!!histPair} onClose={()=>setHistPair(null)} eyebrow="Pairing · History"
        title={histPair?histPair.cd:''} sub={histPair?`${histPair.dispAttr} → ${histPair.filtAttr}`:''}
        footer="Append-only governance log — who · what · when. Illustrative in this prototype.">
        {histPair && <HistoryTimeline events={govEvents({name:histPair.cd, kind:'Pairing', status:histPair.st, seed:histPair.cd.length})}/>}
      </Drawer>
    </div>
  )
}



function RelAddForm({id, onClose, localRels, setLocalRels}) {
  const [fromObj,  setFromObj]  = useState('')
  const [fromCol,  setFromCol]  = useState('')
  const [toObj,    setToObj]    = useState('')
  const [toCol,    setToCol]    = useState('')
  const [relType,  setRelType]  = useState('MANY_TO_ONE')
  const [relCd,    setRelCd]    = useState('')
  const [relDesc,  setRelDesc]  = useState('')
  const [submitted,setSubmitted]= useState(false)

  const fromAttrs = fromObj ? (CATALOG[fromObj]?.attrs.filter(a=>a.indexed||a.pk)||[]) : []
  const toAttrs   = toObj   ? (CATALOG[toObj]?.attrs.filter(a=>a.pk)||[])              : []
  const canSubmit = fromObj && fromCol && toObj && toCol && relCd
  // OPA: block cross-engine relationship
  const relOpaPolicy = opaEvaluate('POL-CE-001',{
    fromConn: CATALOG[fromObj]?.connectionId||'lextr-pg',
    toConn:   CATALOG[toObj]?.connectionId  ||'lextr-pg',
  })
  const relBlocked = !!relOpaPolicy

  const submitRel = () => {
    if (!canSubmit) return
    const newRel = {
      cd: relCd.toUpperCase().replace(/\s+/g,'_'),
      from: fromObj, from_col: fromCol,
      to: toObj,     to_col:   toCol,
      type: relType, st: 'PENDING',
    }
    setLocalRels(p=>[...p, newRel])
    setSubmitted(true)
    setTimeout(()=>{onClose()}, 1500)
  }

  const typeClr = t =>
    t==='MANY_TO_ONE' ? {c:L.teal,bg:L.tealBg} :
    t==='ONE_TO_MANY' ? {c:L.blue,bg:L.blueBg} :
                        {c:L.pur, bg:L.purBg}

  const fromTable = fromObj ? fromObj.split('.')[1] : ''
  const toTable   = toObj   ? toObj.split('.')[1]   : ''
  const yamlLines = canSubmit ? [
    'joins:',
    '  '+relCd.toUpperCase().replace(/\s+/g,'_')+':',
    '    relationship: '+relType.toLowerCase(),
    '    sql: "${'+fromTable+'}.'+fromCol+' = ${'+toTable+'}.'+toCol+'"',
  ] : []

  return (
    <div>
      <DraftActionBar id={id} accentColor={L.blue}
        onDiscard={onClose}
        onSaveDraft={()=>api.saveRelationshipDraft({draftId:id,fromObj,fromCol,toObj,toCol,relType,relCd})}
        onSubmit={relBlocked ? null : submitRel} blocked={relBlocked}/>
      {submitted&&(
        <div style={{padding:'10px 16px',marginBottom:16,background:L.grnBg,border:`1px solid ${L.grn}44`,borderRadius:8,
          fontSize:12,color:L.grn,fontWeight:600,display:'flex',alignItems:'center',gap:8}}>
          <Check size={14}/> Relationship registered and submitted for governance approval.
        </div>
      )}
      {relOpaPolicy&&fromObj&&toObj&&(
        <PolicyBlock policy={relOpaPolicy}
          context={{fromConn:CATALOG[fromObj]?.connectionId||'lextr-pg',toConn:CATALOG[toObj]?.connectionId||'lextr-pg'}}/>
      )}
      <div style={{display:'grid',gridTemplateColumns:'1.4fr 1fr',gap:16,marginBottom:20}}>
        <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:20}}>
          <h4 style={{margin:'0 0 14px',fontSize:13,fontWeight:700,color:L.t1}}>Relationship definition</h4>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:14}}>
            <SelectInput label="From object *" value={fromObj} onChange={v=>{setFromObj(v);setFromCol('')}}
              options={Object.keys(CATALOG).map(k=>({value:k,label:k}))}/>
            <SelectInput label="FK column *" value={fromCol} onChange={setFromCol}
              options={fromAttrs.map(a=>({value:a.cd,label:`${a.cd} (${a.type})`}))}
              disabled={!fromObj}/>
            <SelectInput label="To object *" value={toObj} onChange={v=>{setToObj(v);setToCol('')}}
              options={Object.keys(CATALOG).map(k=>({value:k,label:k}))}/>
            <SelectInput label="PK column *" value={toCol} onChange={setToCol}
              options={toAttrs.map(a=>({value:a.cd,label:`${a.cd} (${a.type})`}))}
              disabled={!toObj}/>
          </div>
          <SelectInput label="Relationship type" value={relType} onChange={setRelType}
            options={['MANY_TO_ONE','ONE_TO_MANY','ONE_TO_ONE'].map(t=>({value:t,label:t}))}/>
          <div style={{marginTop:10}}>
            <TextInput label="Relationship code *" value={relCd} onChange={setRelCd}
              placeholder="e.g. GL_TO_ACCOUNT"/>
          </div>
          <div style={{marginTop:10}}>
            <TextArea label="Description" value={relDesc} onChange={setRelDesc}
              placeholder="Describe why this join exists..."/>
          </div>
          <InfoBanner text="Approved relationships auto-generate semantic-service YAML joins section." color={L.blue} bg={L.blueBg}/>
        </div>
        <div>
          {canSubmit&&(
            <div style={{background:L.nv,borderRadius:10,overflow:'hidden'}}>
              <div style={{padding:'8px 14px',borderBottom:'1px solid rgba(255,255,255,0.08)',display:'flex',alignItems:'center',gap:8,flexWrap:'wrap'}}>
                <span style={{fontSize:10,color:'#8aa8c0',fontWeight:700,fontFamily:L.mono}}>CUBE.DEV YAML PREVIEW</span>
                <Chip text={relType} c={typeClr(relType).c} bg={typeClr(relType).bg} sz={9}/>
                {fromObj&&toObj&&(CATALOG[fromObj]?.connectionId||'lextr-pg')!==(CATALOG[toObj]?.connectionId||'lextr-pg')&&(
                  <span style={{fontSize:9,fontWeight:700,color:'#BA7517',background:'#FAEEDA',padding:'2px 6px',borderRadius:3,border:'1px solid #BA751744'}}>⚡ cross-engine — semantic-service routes each cube to its engine dialect</span>
                )}
              </div>
              <pre style={{margin:0,padding:'14px 16px',fontSize:11,color:'#a8d8b0',fontFamily:L.mono,lineHeight:1.7}}>
                {yamlLines.join('\n')}
              </pre>
            </div>
          )}
          {!canSubmit&&(
            <div style={{padding:20,background:L.s3,borderRadius:10,border:`1px solid ${L.bd}`,color:L.t3,fontSize:12,lineHeight:1.6}}>
              Complete the relationship definition to preview the auto-generated semantic-service YAML.
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function RelationshipsScreen({onNav}) {
  const [tab,       setTab]      = useState('inventory')
  const [drafts,    setDrafts]   = useState([])
  const [activeId,  setActiveId] = useState(null)
  const [localRels, setLocalRels]  = useState(INITIAL_RELS)
  const [showAll,   setShowAll]    = useState(false)
  const [selNode,   setSelNode]    = useState(null)
  const [filterSt,  setFilterSt]  = useState('ALL')
  const [relExpanded, setRelExpanded] = useState({})
  const [histRel,   setHistRel]   = useState(null)

  const openDraft  = () => { const id=randId('REL'); setDrafts(p=>[...p,{id}]); setActiveId(id) }
  const closeDraft = (id) => {
    setDrafts(p=>{ const rem=p.filter(d=>d.id!==id); if(activeId===id) setTimeout(()=>setActiveId(rem.length>0?rem[rem.length-1].id:null),0); return rem })
  }
  const filteredRels = filterSt==='ALL' ? localRels : localRels.filter(r=>r.st===filterSt)
  const stClrRel = s => s==='ACTIVE'?{c:L.grn,bg:L.grnBg}:s==='PENDING'?{c:L.amb,bg:L.ambBg}:s==='DRAFT'?{c:L.t3,bg:L.s4}:{c:L.t4,bg:L.s4}
  const typeClr  = t => t==='MANY_TO_ONE'?{c:L.teal,bg:L.tealBg}:t==='ONE_TO_MANY'?{c:L.blue,bg:L.blueBg}:{c:L.pur,bg:L.purBg}

  const currentBase = activeId!==null ? activeId : tab
  return (
    <div>
      <PageHdr title="Relationship Mgmt" icon={Network}
        sub="Join relationships between registered objects → semantic-service joins: YAML. ER Diagram evolves progressively with every registered relationship."/>
      <InfoBanner text="Relationships are registered here (meta.semantic_relationship_catalog), not in PostgreSQL DDL. Both objects must be registered before a relationship can be created. Approved relationships auto-generate semantic-service YAML." color={L.blue} bg={L.blueBg}/>
      <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:'20px 24px',marginTop:12}}>
        <GovTabStrip
          base={[
            {id:'inventory',label:`Relationship Inventory (${localRels.length})`},
            {id:'er',label:'ER Diagram'},
          ]}
          drafts={drafts}
          activeId={currentBase}
          onSelect={id=>{if(id==='inventory'||id==='er'){setActiveId(null);setTab(id)}else setActiveId(id)}}
          onClose={closeDraft}
          addLabel=" Add Relationship"
          onAdd={openDraft}/>

        {/* ════════════ TAB 1: INVENTORY ════════════ */}
        {activeId===null&&tab==='inventory'&&(
          <div>
            <div style={{display:'flex',gap:10,marginBottom:14,alignItems:'center',flexWrap:'wrap'}}>
              {['ALL','ACTIVE','PENDING','DRAFT'].map(s=>{
                const cnt = s==='ALL'?localRels.length:localRels.filter(r=>r.st===s).length
                const {c,bg} = stClrRel(s)
                return (
                  <button key={s} onClick={()=>setFilterSt(s)} style={{
                    padding:'4px 12px',borderRadius:12,fontSize:11,fontWeight:700,cursor:'pointer',
                    border:`1px solid ${filterSt===s?c:L.bd}`,
                    background:filterSt===s?bg:L.s1,color:filterSt===s?c:L.t3}}>
                    {s} ({cnt})
                  </button>
                )
              })}
              <div style={{flex:1}}/>
              <Btn label="View in ER Diagram" icon={Network} small onClick={()=>setTab('er')}/>
            </div>
            <div style={{border:`1px solid ${L.bd}`,borderRadius:8,overflow:'hidden'}}>
              <div style={{display:'grid',gridTemplateColumns:'1.4fr 1.8fr 1fr 1.8fr 1fr 1fr 80px 44px',
                padding:'8px 14px',background:L.s3,borderBottom:`1px solid ${L.bd}`,
                fontSize:10,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.06em',gap:8}}>
                {['Relationship','From Object','FK Column','To Object','PK Column','Type','Status'].map(h=><span key={h}>{h}</span>)}<span/>
              </div>
              {filteredRels.map(r=>{
                const tc=typeClr(r.type), sc=stClrRel(r.st)
                return (
                  <div key={r.cd} style={{display:'grid',gridTemplateColumns:'1.4fr 1.8fr 1fr 1.8fr 1fr 1fr 80px 44px',
                    padding:'9px 14px',borderBottom:`1px solid ${L.bd2}`,fontSize:12,alignItems:'center',gap:8,background:L.s1}}>
                    <div style={{display:'flex',alignItems:'center',gap:4}}>
                      <span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:L.blueDk}}>{r.cd}</span>
                      {isCrossEngineRel(r)&&<span title="Cross-engine join" style={{fontSize:8,fontWeight:700,color:'#BA7517',background:'#FAEEDA',padding:'1px 4px',borderRadius:3,border:'1px solid #BA751744'}}>×eng</span>}
                    </div>
                    <div style={{display:'flex',alignItems:'center',gap:3}}>
                      <EngineBadge connectionId={CATALOG[r.from]?.connectionId||'lextr-pg'} tiny/>
                      <Chip text={r.from.split('.')[1]} c={L.teal} bg={L.tealBg} sz={9}/>
                    </div>
                    <span style={{fontFamily:L.mono,fontSize:10,color:L.t3}}>{r.from_col}</span>
                    <Chip text={r.to}   c={L.blue} bg={L.blueBg} sz={9}/>
                    <span style={{fontFamily:L.mono,fontSize:10,color:L.t3}}>{r.to_col}</span>
                    <Chip text={r.type} c={tc.c} bg={tc.bg} sz={9}/>
                    <span style={{padding:'2px 8px',borderRadius:4,fontSize:10,fontWeight:700,background:sc.bg,color:sc.c}}>{r.st}</span>
                    <div style={{display:'flex',justifyContent:'center'}}><HistBtn onClick={()=>setHistRel(r)}/></div>
                  </div>
                )
              })}
            </div>
          </div>
        )}



        {/* ════════════ TAB 2: ER DIAGRAM ════════════ */}
        {activeId===null&&tab==='er'&&(
          <div>
            {/* Controls */}
            <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:12,flexWrap:'wrap'}}>
              <label style={{display:'flex',alignItems:'center',gap:6,fontSize:12,color:L.t3,cursor:'pointer'}}>
                <input type="checkbox" checked={showAll} onChange={e=>setShowAll(e.target.checked)}
                  style={{accentColor:L.teal}}/>
                Show all registered objects (even without relationships)
              </label>
              <div style={{flex:1}}/>
              <span style={{fontSize:11,color:L.t4}}>
                {localRels.length} relationship{localRels.length!==1?'s':''} · Click a node to inspect · click + to expand
              </span>
            </div>
            {(()=>{
              // Objects to display
              const objSet = new Set()
              localRels.forEach(r=>{objSet.add(r.from);objSet.add(r.to)})
              if(showAll) Object.keys(CATALOG).forEach(k=>objSet.add(k))
              const objs = [...objSet]
              // Layout: 3 cols max
              const COLS_N = Math.min(objs.length, 3)
              const GAP_X = 80, GAP_Y = 60, PAD_X = 32, PAD_Y = 48
              const nodeH = obj => erNodeH(obj, !!relExpanded[obj])
              const nodePos = {}
              objs.forEach((obj,i)=>{
                nodePos[obj] = {
                  x: PAD_X + (i%COLS_N)*(ER_NODE_W+GAP_X),
                  y: PAD_Y + Math.floor(i/COLS_N)*140,
                }
              })
              const maxRow = objs.length>0 ? Math.floor((objs.length-1)/COLS_N) : 0
              const svgW = PAD_X*2 + COLS_N*(ER_NODE_W+GAP_X) - GAP_X + 20
              const svgH = PAD_Y + (maxRow+1)*140 + 50
              const relEdgeCol = r => r.st==='ACTIVE'?'#36c97e':r.st==='PENDING'?'#e6a832':'#4a7fb5'
              const getEdgePts = (fromObj, toObj) => {
                const f = nodePos[fromObj], t = nodePos[toObj]
                if (!f||!t) return null
                const fH = nodeH(fromObj), tH = nodeH(toObj)
                const fCx = f.x+ER_NODE_W/2, fCy = f.y+fH/2
                const tCx = t.x+ER_NODE_W/2, tCy = t.y+tH/2
                const dx = tCx-fCx, dy = tCy-fCy
                const len = Math.sqrt(dx*dx+dy*dy)||1
                const ux=dx/len, uy=dy/len
                return {
                  fEx:fCx+ux*(ER_NODE_W/2+2), fEy:fCy+uy*(fH/2+2),
                  tEx:tCx-ux*(ER_NODE_W/2+2), tEy:tCy-uy*(tH/2+2),
                  ux, uy,
                }
              }
              return (
                <div>
                  {/* Legend */}
                  <div style={{display:'flex',gap:14,marginBottom:10,fontSize:11,color:L.t3,flexWrap:'wrap'}}>
                    {[['#36c97e','ACTIVE — solid'],['#e6a832','PENDING — dashed'],['#4a7fb5','DRAFT — dashed']].map(([col,lbl])=>(
                      <div key={lbl} style={{display:'flex',alignItems:'center',gap:6}}>
                        <svg width={28} height={10}>
                          <line x1={0} y1={5} x2={28} y2={5} stroke={col} strokeWidth={2}
                            strokeDasharray={lbl.includes('dashed')?'4,3':'none'}/>
                        </svg>
                        <span>{lbl}</span>
                      </div>
                    ))}
                  </div>
                  <div style={{background:L.nv,borderRadius:12,overflow:'auto',border:`1px solid #1a3a5f`}}>
                    <svg width={svgW} height={svgH} style={{display:'block',fontFamily:L.font}}>
                      <defs>
                        <filter id="rel-nd-glow">
                          <feGaussianBlur stdDeviation="2.5" result="b"/>
                          <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
                        </filter>
                      </defs>
                      {/* Dot grid */}
                      {Array.from({length:Math.ceil(svgW/22)},(_,xi)=>
                        Array.from({length:Math.ceil(svgH/22)},(_,yi)=>(
                          <circle key={`${xi}-${yi}`} cx={xi*22+11} cy={yi*22+11} r={0.8}
                            fill="rgba(255,255,255,0.03)"/>
                        ))
                      )}
                      {/* Edges with crow-foot notation */}
                      {localRels.map(r=>{
                        const pts = getEdgePts(r.from, r.to)
                        if (!pts) return null
                        const {fEx,fEy,tEx,tEy,ux,uy} = pts
                        const col = isCrossEngineRel(r) ? '#8b5cf6' : relEdgeCol(r)
              const crossEng = isCrossEngineRel(r)
                        const mx=(fEx+tEx)/2, my=(fEy+tEy)/2
                        return (
                          <g key={r.cd}>
                            <line x1={fEx} y1={fEy} x2={tEx} y2={tEy}
                              stroke={col} strokeWidth={r.st==='ACTIVE'?2:1.5}
                              strokeDasharray={crossEng?'3,2,8,2':r.st==='ACTIVE'?'none':'5,3'} opacity={0.9}/>
                            {/* Crow-foot notation */}
                            {r.type==='MANY_TO_ONE'&&<CrowFoot x={fEx} y={fEy} dx={tEx-fEx} dy={tEy-fEy} side="many" col={col}/>}
                            {r.type==='MANY_TO_ONE'&&<CrowFoot x={tEx} y={tEy} dx={fEx-tEx} dy={fEy-tEy} side="one"  col={col}/>}
                            {r.type==='ONE_TO_MANY'&&<CrowFoot x={fEx} y={fEy} dx={tEx-fEx} dy={tEy-fEy} side="one"  col={col}/>}
                            {r.type==='ONE_TO_MANY'&&<CrowFoot x={tEx} y={tEy} dx={fEx-tEx} dy={fEy-tEy} side="many" col={col}/>}
                            {r.type==='ONE_TO_ONE'&&<CrowFoot x={fEx} y={fEy} dx={tEx-fEx} dy={tEy-fEy} side="one"  col={col}/>}
                            {r.type==='ONE_TO_ONE'&&<CrowFoot x={tEx} y={tEy} dx={fEx-tEx} dy={fEy-tEy} side="one"  col={col}/>}
                            {/* Cardinality + join key badge */}
                            <rect x={mx-22} y={my-9} width={44} height={18} rx={4}
                              fill="#0a1828" stroke={col} strokeWidth={0.8}/>
                            <text x={mx} y={my+3} textAnchor="middle"
                              fontSize={8} fontFamily={L.mono} fill={col} fontWeight={700}>
                              {r.type==='MANY_TO_ONE'?'N : 1':r.type==='ONE_TO_MANY'?'1 : N':'1 : 1'}
                            </text>
                            <text x={mx} y={my+14} textAnchor="middle"
                              fontSize={7} fontFamily={L.mono} fill="#2a4a6e">
                              {r.from_col} = {r.to_col}
                            </text>
                          </g>
                        )
                      })}
                      {/* ER Nodes */}
                      {objs.map(obj=>{
                        const hasRels = localRels.some(r=>r.from===obj||r.to===obj)
                        const isSelected = selNode===obj
                        return (
                          <g key={obj} filter={hasRels?'url(#rel-nd-glow)':undefined}>
                            <ERNode
                              obj={obj}
                              x={nodePos[obj].x}
                              y={nodePos[obj].y}
                              expanded={!!relExpanded[obj]}
                              onToggle={obj=>setRelExpanded(p=>({...p,[obj]:!p[obj]}))}
                              highlight={isSelected?'selected':hasRels?'active':undefined}
                              dimmed={!hasRels&&!showAll}
                              selectable={true}
                              onSelect={obj=>setSelNode(isSelected?null:obj)}
                              selected={isSelected}
                            />
                          </g>
                        )
                      })}
                      {/* Legend strip */}
                      <rect x={0} y={svgH-26} width={svgW} height={26} fill="rgba(0,0,0,0.4)"/>
                      <text x={PAD_X} y={svgH-10} fontSize={9} fontFamily={L.font} fill="#2a4a6e">
                        Crow-foot notation  ·  Click a node to inspect  ·  Click + to expand all attributes
                      </text>
                    </svg>
                  </div>
                  {/* Selected node panel */}
                  {selNode&&CATALOG[selNode]&&(
                    <div style={{marginTop:12,padding:'14px 18px',background:L.s1,
                      border:`1px solid ${L.bd}`,borderRadius:10}}>
                      <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:10}}>
                        <span style={{fontFamily:L.mono,fontSize:13,fontWeight:700,color:L.t1}}>{selNode}</span>
                        <Chip text={`${CATALOG[selNode].attrs.length} attrs`} c={L.teal} bg={L.tealBg} sz={10}/>
                        <Chip text={`${localRels.filter(r=>r.from===selNode||r.to===selNode).length} rels`} c={L.blue} bg={L.blueBg} sz={10}/>
                        <button onClick={()=>setSelNode(null)}
                          style={{marginLeft:'auto',padding:'3px 8px',borderRadius:5,
                          border:`1px solid ${L.bd}`,background:L.s3,cursor:'pointer',fontSize:11,color:L.t3}}>✕</button>
                      </div>
                      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(160px,1fr))',gap:6}}>
                        {CATALOG[selNode].attrs.map(a=>(
                          <div key={a.cd} style={{padding:'6px 9px',background:L.s3,borderRadius:6,border:`1px solid ${L.bd2}`}}>
                            <div style={{display:'flex',alignItems:'center',gap:4,marginBottom:2}}>
                              {a.pk&&<span style={{fontSize:7,fontWeight:800,color:'#c097e8',background:'#c097e822',padding:'1px 4px',borderRadius:2}}>PK</span>}
                              {a.indexed&&!a.pk&&<span style={{fontSize:7,fontWeight:800,color:'#7ab8e8',background:'#7ab8e822',padding:'1px 4px',borderRadius:2}}>FK</span>}
                              <span style={{fontSize:11,fontFamily:L.mono,fontWeight:600,color:L.t1}}>{a.cd}</span>
                            </div>
                            <div style={{fontSize:9,color:L.t3}}>{a.type} · {a.semantic||'—'}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )
            })()}
          </div>
        )}
        {drafts.map(d=>(
          <div key={d.id} style={{display:activeId===d.id?'block':'none'}}>
            <RelAddForm id={d.id} onClose={()=>closeDraft(d.id)} localRels={localRels} setLocalRels={setLocalRels}/>
          </div>
        ))}
      </div>

      <Drawer open={!!histRel} onClose={()=>setHistRel(null)} eyebrow="Relationship · History"
        title={histRel?histRel.cd:''} sub={histRel?`${(histRel.from||'').split('.')[1]||histRel.from} → ${histRel.to}`:''}
        footer="Append-only governance log — who · what · when. Illustrative in this prototype.">
        {histRel && <HistoryTimeline events={govEvents({name:histRel.cd, kind:'Relationship', status:histRel.st, seed:(histRel.cd||'').length})}/>}
      </Drawer>
    </div>
  )
}



function HierarchyScreen() {
  const [hTab, setHTab] = useState('workspaces')
  const [selWs, setSelWs] = useState(TENANT_WORKSPACES[0].id)
  const [newWs, setNewWs] = useState({id:'',tenant:'',desc:''})
  const [addingObj, setAddingObj] = useState(false)
  const [objToAdd, setObjToAdd] = useState('')

  const ws = TENANT_WORKSPACES.find(w=>w.id===selWs)

  const wsTabItems = [
    {id:'workspaces',label:'Workspaces',   icon:Globe,   badge:TENANT_WORKSPACES.length},
    {id:'create',    label:'New Workspace', icon:Plus},
  ]

  return (
    <div>
      <PageHdr title="Semantic Layer Workspaces" icon={Globe}
        sub="Organize the semantic layer by tenant. Each workspace defines which objects and cubes a tenant can see. Global workspace applies to all tenants."/>

      <InfoBanner text="Prototype only — not part of the Development Manifest. A workspace is the tenant's view into the semantic layer — it controls which registered objects, cubes, and pairings are accessible to each tenant. Objects are registered once and assigned to one or more workspaces. This is folder-level organization, not data access control (that is handled by IAM)." color={L.teal} bg={L.tealBg}/>

      <div style={{marginTop:12}}>
        <HorizTabs tabs={wsTabItems} active={hTab} onChange={setHTab}/>

        {hTab==='workspaces'&&(
          <div style={{display:'grid',gridTemplateColumns:'240px 1fr',gap:12}}>
            {/* Workspace list */}
            <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,overflow:'hidden'}}>
              <div style={{padding:'9px 12px',background:L.s3,borderBottom:`1px solid ${L.bd}`,fontSize:10,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.07em'}}>
                Tenant Workspaces ({TENANT_WORKSPACES.length})
              </div>
              {TENANT_WORKSPACES.map(w=>{
                const on=selWs===w.id
                return (
                  <div key={w.id} onClick={()=>setSelWs(w.id)} style={{
                    padding:'10px 12px',cursor:'pointer',borderBottom:`1px solid ${L.bd2}`,
                    background:on?L.tealBg:L.s1,borderLeft:on?`3px solid ${L.teal}`:'3px solid transparent',
                  }}>
                    <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:3}}>
                      <Globe size={11} color={on?L.teal:L.t4}/>
                      <span style={{fontSize:10,fontWeight:700,color:on?L.tealDk:L.t1}}>{w.id}</span>
                    </div>
                    <div style={{fontSize:11,color:L.t2,marginBottom:3}}>{w.tenant}</div>
                    <div style={{display:'flex',gap:4}}>
                      <SBadge st={w.st}/>
                      <Chip text={`${w.objects.length} objects`} c={L.t3} bg={L.s4} sz={9}/>
                    </div>
                  </div>
                )
              })}
            </div>

            {/* Workspace detail */}
            {ws&&(
              <div>
                <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:'16px 20px',marginBottom:12}}>
                  <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',marginBottom:10}}>
                    <div>
                      <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}>
                        <Globe size={16} color={L.teal}/>
                        <span style={{fontSize:15,fontWeight:700,color:L.t1}}>{ws.id}</span>
                        <SBadge st={ws.st}/>
                        {ws.tenant.startsWith('ALL')&&<Chip text="Global" c={L.grn} bg={L.grnBg}/>}
                      </div>
                      <div style={{fontSize:13,fontWeight:600,color:L.t2,marginBottom:4}}>{ws.tenant}</div>
                      <p style={{margin:0,fontSize:12,color:L.t3,lineHeight:1.6}}>{ws.desc}</p>
                    </div>
                    <div style={{display:'flex',gap:6}}>
                      <Btn label="Edit workspace" icon={Edit2} small/>
                    </div>
                  </div>
                  <div style={{display:'flex',gap:16,fontSize:11,color:L.t3}}>
                    <span><User size={11} style={{verticalAlign:'middle',marginRight:3}}/>Created by: <strong style={{color:L.t2}}>{ws.createdBy}</strong></span>
                    <span><Calendar size={11} style={{verticalAlign:'middle',marginRight:3}}/>Updated: <strong style={{color:L.t2}}>{ws.updatedAt}</strong></span>
                    <span><Table2 size={11} style={{verticalAlign:'middle',marginRight:3}}/>Objects: <strong style={{color:L.t2}}>{ws.objects.length}</strong></span>
                    <span><Layers size={11} style={{verticalAlign:'middle',marginRight:3}}/>Cubes: <strong style={{color:L.t2}}>{ws.cubes.length}</strong></span>
                  </div>
                </div>

                {/* Objects in workspace */}
                <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:'16px 20px',marginBottom:12}}>
                  <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:12}}>
                    <div style={{fontSize:13,fontWeight:600,color:L.t1}}>Objects in this workspace</div>
                    <Btn label="Add object" icon={Plus} small onClick={()=>setAddingObj(!addingObj)}/>
                  </div>

                  {addingObj&&(
                    <div style={{display:'flex',gap:8,marginBottom:12,padding:'10px',background:L.s3,borderRadius:7,border:`1px solid ${L.bd}`}}>
                      <select value={objToAdd} onChange={e=>setObjToAdd(e.target.value)}
                        style={{flex:1,padding:'6px 10px',border:`1px solid ${L.bd}`,borderRadius:5,fontSize:12,color:L.t1,background:L.s1,outline:'none'}}>
                        <option value="">Select object to add…</option>
                        {OBJECTS.filter(k=>!ws.objects.includes(k)).map(k=><option key={k} value={k}>{k}</option>)}
                      </select>
                      <Btn label="Add" primary small onClick={()=>{if(objToAdd){api.addObjectToWorkspace({workspaceId:ws.id,objectKey:objToAdd});setAddingObj(false);setObjToAdd('')}}}/>
                      <Btn label="Cancel" small onClick={()=>{setAddingObj(false);setObjToAdd('')}}/>
                    </div>
                  )}

                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
                    {(ws.objects||[]).map(k=>{
                      const o=CATALOG[k]
                      if(!o) return null
                      return (
                        <div key={k} style={{padding:'10px 14px',background:L.s3,borderRadius:8,border:`1px solid ${L.bd}`,display:'flex',alignItems:'center',justifyContent:'space-between'}}>
                          <div>
                            <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:3}}>
                              <Table2 size={11} color={L.blue}/>
                              <span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:L.t1}}>{k}</span>
                            </div>
                            <div style={{display:'flex',gap:4}}>
                              <Chip text={o.schema} c={L.t3} bg={L.s4} sz={9}/>
                              <SBadge st={o.st}/>
                              <Chip text={`${o.attrs?.length||0}a`} c={L.t4} bg={L.s4} sz={9}/>
                            </div>
                          </div>
                          <button style={{padding:'3px 8px',borderRadius:4,border:`1px solid ${L.cor}44`,background:L.corBg,cursor:'pointer',fontSize:10,color:L.cor,fontWeight:700}}
                            onClick={()=>api.removeObjectFromWorkspace({workspaceId:ws.id,objectKey:k})}>Remove</button>
                        </div>
                      )
                    })}
                  </div>
                </div>

                {/* Cubes exposed */}
                <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:'16px 20px'}}>
                  <div style={{fontSize:13,fontWeight:600,color:L.t1,marginBottom:10}}>semantic-service cubes exposed to this tenant</div>
                  <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
                    {(ws.cubes||[]).map(c=>(
                      <div key={c} style={{padding:'6px 12px',borderRadius:6,background:L.purBg,border:`1px solid ${L.pur}44`}}>
                        <span style={{fontFamily:L.mono,fontSize:11,color:L.purDk,fontWeight:600}}>{c}</span>
                      </div>
                    ))}
                  </div>
                  <div style={{marginTop:10,fontSize:11,color:L.t3}}>
                    Cubes inherit from assigned objects. A cube is exposed to a tenant when its source object is in the workspace.
                    semantic-service pairing resolution enforces tenant isolation on every query via securityContext.tenantCd.
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {hTab==='create'&&(
          <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:24}}>
            <h3 style={{margin:'0 0 16px',fontSize:14,fontWeight:700,color:L.t1}}>Create tenant workspace</h3>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14,marginBottom:14}}>
              <TextInput label="Workspace ID" req value={newWs.id} onChange={v=>setNewWs(p=>({...p,id:v}))} placeholder="e.g. WS-BHC-C" mono/>
              <TextInput label="Tenant identifier" req value={newWs.tenant} onChange={v=>setNewWs(p=>({...p,tenant:v}))} placeholder="e.g. BHC_C003 — Bank Holding Co C"/>
              <div style={{gridColumn:'span 2'}}>
                <TextArea label="Description" value={newWs.desc} onChange={v=>setNewWs(p=>({...p,desc:v}))} placeholder="Describe which objects and capabilities this tenant needs access to…" rows={3}/>
              </div>
            </div>
            <InfoBanner text="After creating the workspace, add objects from the workspace detail view. Each object addition requires governance approval. semantic-service cubes are exposed automatically based on assigned objects." color={L.teal} bg={L.tealBg}/>
            <div style={{marginTop:14,display:'flex',gap:8}}>
              <Btn label="Create workspace" icon={Check} primary onClick={()=>{api.createWorkspace({tenantCd:newWsTenant,desc:newWsDesc}).then(()=>setHTab('workspaces'))}}/>
              <Btn label="Cancel" onClick={()=>setHTab('workspaces')}/>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}


// ══════════════════════════════════════════════════════════════════════
// SCREEN 7: QUERY STUDIO (unchanged, compact)
// ══════════════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════════════
// SCREEN 7: QUERY STUDIO — Enhanced
// Left panel : Attribute browser (same LHP as Data Catalog)
//              Technical (Schema→Table→Attribute) | Asset view
// Right panel: Workspace — selected attributes, query generation,
//              relationship validation, performance indicators
// ══════════════════════════════════════════════════════════════════════

// ── ER Diagram shared helpers ──────────────────────────────────────────────
// Draws a real-ER-style node: table header + key attribute rows + expand toggle
// expandedNodes: Set of obj keys that are fully expanded
// onToggle(obj): callback to expand/contract
const ER_NODE_W  = 188  // fixed column width
const ER_HDR_H   = 28   // table name header height
const ER_ROW_H   = 20   // per-attribute row height
const ER_PREVIEW = 3    // key attrs shown collapsed

// Given a CATALOG object, return its key attrs (PK first, then FK, then indexed)
const erKeyAttrs = (obj) => {
  const attrs = CATALOG[obj]?.attrs || []
  const pk  = attrs.filter(a=>a.pk)
  const fk  = attrs.filter(a=>!a.pk && a.indexed && !a.pk)
  const rest = attrs.filter(a=>!a.pk && !a.indexed)
  return [...pk, ...fk, ...rest]
}

// How tall is a node given expanded state
const erNodeH = (obj, expanded) => {
  const keys = erKeyAttrs(obj)
  const shown = expanded ? keys.length : Math.min(ER_PREVIEW, keys.length)
  const hasMore = !expanded && keys.length > ER_PREVIEW
  return ER_HDR_H + shown * ER_ROW_H + (hasMore ? ER_ROW_H : 0) + 2
}

// Crow-foot line end: draws one-side notation at (x,y) in direction (dx,dy)
// side: 'one' | 'many' | 'one_only' | 'zero_or_many'
const CrowFoot = ({x, y, dx, dy, side, col}) => {
  // Normalise direction
  const len = Math.sqrt(dx*dx + dy*dy) || 1
  const ux = dx/len, uy = dy/len
  // Perpendicular
  const px = -uy, py = ux
  const TICK = 8, SPREAD = 5
  if (side === 'one') return (
    <g>
      <line x1={x+ux*TICK} y1={y+uy*TICK} x2={x+ux*TICK+px*SPREAD} y2={y+uy*TICK+py*SPREAD} stroke={col} strokeWidth={1.5}/>
      <line x1={x+ux*TICK} y1={y+uy*TICK} x2={x+ux*TICK-px*SPREAD} y2={y+uy*TICK-py*SPREAD} stroke={col} strokeWidth={1.5}/>
      <line x1={x+ux*(TICK+5)} y1={y+uy*(TICK+5)} x2={x+ux*(TICK+5)+px*SPREAD} y2={y+uy*(TICK+5)+py*SPREAD} stroke={col} strokeWidth={1.5}/>
      <line x1={x+ux*(TICK+5)} y1={y+uy*(TICK+5)} x2={x+ux*(TICK+5)-px*SPREAD} y2={y+uy*(TICK+5)-py*SPREAD} stroke={col} strokeWidth={1.5}/>
    </g>
  )
  if (side === 'many') return (
    <g>
      <line x1={x} y1={y} x2={x+ux*TICK+px*SPREAD} y2={y+uy*TICK+py*SPREAD} stroke={col} strokeWidth={1.5}/>
      <line x1={x} y1={y} x2={x+ux*TICK-px*SPREAD} y2={y+uy*TICK-py*SPREAD} stroke={col} strokeWidth={1.5}/>
      <line x1={x+ux*TICK} y1={y+uy*TICK} x2={x+ux*TICK+px*SPREAD} y2={y+uy*TICK+py*SPREAD} stroke={col} strokeWidth={1.5}/>
      <line x1={x+ux*TICK} y1={y+uy*TICK} x2={x+ux*TICK-px*SPREAD} y2={y+uy*TICK-py*SPREAD} stroke={col} strokeWidth={1.5}/>
    </g>
  )
  return null
}

// Full ER node SVG group
const ERNode = ({obj, x, y, expanded, onToggle, highlight, dimmed, selectable, onSelect, selected}) => {
  const catalog   = CATALOG[obj]
  const schema    = obj.split('.')[0]
  const name      = obj.split('.')[1] || obj
  const keyAttrs  = erKeyAttrs(obj)
  const nodeH     = erNodeH(obj, expanded)
  const shown     = expanded ? keyAttrs : keyAttrs.slice(0, ER_PREVIEW)
  const hasMore   = !expanded && keyAttrs.length > ER_PREVIEW
  const schCol    = schema==='core'?'#36c97e':schema==='ref'?'#5b9bd5':schema==='meta'?'#c97836':schema==='analytics'?'#BA7517':'#9b8fff'
  const connCfgNode = connCfg(catalog?.connectionId||'lextr-pg')
  const borderCol = highlight==='warn'?'#e6a832':highlight==='active'?L.teal:highlight==='selected'?'#5b9bd5':'#1e3a5f'
  const fillHdr   = highlight==='warn'?'#1c0e00':highlight==='active'||highlight==='selected'?'#061c10':'#0d2140'
  const fillBody  = highlight==='warn'?'#120a00':highlight==='active'||highlight==='selected'?'#031208':'#0a1828'
  const opacity   = dimmed ? 0.35 : 1

  return (
    <g opacity={opacity} onClick={selectable ? ()=>onSelect(obj) : undefined}
      style={{cursor:selectable?'pointer':'default'}}>
      {/* Node shadow */}
      <rect x={x+2} y={y+2} width={ER_NODE_W} height={nodeH} rx={7} fill="rgba(0,0,0,0.4)"/>
      {/* Header */}
      <rect x={x} y={y} width={ER_NODE_W} height={ER_HDR_H} rx={7}
        fill={fillHdr} stroke={borderCol} strokeWidth={highlight?2:1}/>
      <rect x={x} y={y+ER_HDR_H-4} width={ER_NODE_W} height={4} fill={fillHdr}/>
      {/* Schema pill */}
      <rect x={x+6} y={y+5} width={schema.length*5+8} height={11} rx={3} fill={schCol+'28'}/>
      <text x={x+10} y={y+14} fontSize={7} fontFamily={L.mono} fill={schCol} fontWeight={700}>{schema}</text>
      {/* Table name */}
      <text x={x+ER_NODE_W/2} y={y+20} textAnchor="middle" fontSize={11} fontFamily={L.font}
        fill={highlight?'#e8f8f0':'#9ab8d4'} fontWeight={700}>
        {name.length>18?name.slice(0,16)+'…':name}
      </text>
      {/* Expand/collapse button */}
      <g onClick={e=>{e.stopPropagation();onToggle(obj)}} style={{cursor:'pointer'}}>
        <circle cx={x+ER_NODE_W-10} cy={y+14} r={7} fill="#0a1828" stroke={borderCol} strokeWidth={0.8}/>
        <text x={x+ER_NODE_W-10} y={y+18} textAnchor="middle" fontSize={9} fill={borderCol} fontWeight={700}>
          {expanded?'−':'+'}
        </text>
      </g>
      {/* Engine label — CH shown in amber, PG implicit */}
      {(catalog?.connectionId==='lextr-ch')&&(
        <g>
          <rect x={x+schema.length*5+18} y={y+5} width={18} height={11} rx={3} fill="#FAEEDA"/>
          <text x={x+schema.length*5+19} y={y+14} fontSize={7} fontFamily={L.mono} fill="#BA7517" fontWeight={700}>CH</text>
        </g>
      )}
      {/* Body */}
      <rect x={x} y={y+ER_HDR_H} width={ER_NODE_W} height={nodeH-ER_HDR_H} rx={0}
        fill={fillBody} stroke={borderCol} strokeWidth={highlight?2:1}/>
      <rect x={x} y={y+nodeH-4} width={ER_NODE_W} height={4} rx={7} fill={fillBody} stroke={borderCol} strokeWidth={highlight?2:1}/>
      {/* Divider under header */}
      <line x1={x} y1={y+ER_HDR_H} x2={x+ER_NODE_W} y2={y+ER_HDR_H} stroke={borderCol} strokeWidth={0.5} opacity={0.5}/>
      {/* Attribute rows */}
      {shown.map((a, ai)=>{
        const rowY = y + ER_HDR_H + ai*ER_ROW_H + 1
        const isKey = a.pk || a.indexed
        const keyTag = a.pk ? 'PK' : a.indexed ? 'FK' : ''
        const tagCol = a.pk ? '#c97bf0' : '#5b9bd5'
        return (
          <g key={a.cd}>
            {ai > 0 && <line x1={x+1} y1={rowY} x2={x+ER_NODE_W-1} y2={rowY} stroke="#ffffff0a" strokeWidth={0.5}/>}
            {keyTag&&(
              <rect x={x+5} y={rowY+3} width={keyTag.length*5+4} height={12} rx={2} fill={tagCol+'22'}/>
            )}
            {keyTag&&(
              <text x={x+7} y={rowY+13} fontSize={7} fontFamily={L.mono} fill={tagCol} fontWeight={700}>{keyTag}</text>
            )}
            <text x={x+(keyTag?keyTag.length*5+14:8)} y={rowY+13}
              fontSize={9} fontFamily={L.mono}
              fill={a.pk?'#c097e8':a.indexed?'#7ab8e8':'#6a8fab'}>
              {a.cd.length>20?a.cd.slice(0,18)+'…':a.cd}
            </text>
            <text x={x+ER_NODE_W-6} y={rowY+13} textAnchor="end"
              fontSize={7} fontFamily={L.mono} fill="#2a4a6e">
              {(a.type||'').split('(')[0].slice(0,8)}
            </text>
          </g>
        )
      })}
      {/* "… N more" row */}
      {hasMore&&(
        <g onClick={e=>{e.stopPropagation();onToggle(obj)}} style={{cursor:'pointer'}}>
          <text x={x+ER_NODE_W/2} y={y+ER_HDR_H+shown.length*ER_ROW_H+13}
            textAnchor="middle" fontSize={9} fontFamily={L.font} fill="#2a5a8a">
            + {keyAttrs.length - ER_PREVIEW} more attrs — click + to expand
          </text>
        </g>
      )}
    </g>
  )
}

function QueryStudioScreen() {
  // LHP state
  const [lhpView, setLhpView]   = useState('technical')
  const [expSchemas, setExpSchemas] = useState({core:true,ref:true})
  const [expObjs,    setExpObjs]    = useState({})
  const [expAssets,  setExpAssets]  = useState({[DATA_ASSETS[0].id]:true})

  // Workspace: list of {objKey, attrCd, attrId, ln, cd, type, semantic}
  const [workspace,   setWorkspace]  = useState([])
  const [ran,         setRan]        = useState(false)
  const [activeQTab,  setActiveQTab] = useState('workspace')
  const [qsExpanded,  setQsExpanded] = useState({})  // obj keys expanded in QS ER // workspace | sql | trace | perf

  // OPA policy state for QS
  const [qsOpaBlock, setQsOpaBlock] = useState(null) // {policy, attrName, objKey}
  const [qsSearch,   setQsSearch]   = useState('')
  const [wsTags,     setWsTags]     = useState({})   // { attrKey: lookupCd }
  const [lookupSel,  setLookupSel]  = useState(null) // attrKey with selector open

  // Add attribute to workspace — checks OPA before adding
  const addToWorkspace = (objKey, a) => {
    const key = `${objKey}.${a.cd}`
    if (workspace.find(w=>w.key===key)) return // already in
    // Check OPA: is there an existing engine in the workspace that differs?
    const incomingEngine = CATALOG[objKey]?.connectionId || 'lextr-pg'
    const existingEngines = [...new Set(wsTables.map(t=>CATALOG[t]?.connectionId||'lextr-pg'))]
    if (existingEngines.length > 0 && !existingEngines.includes(incomingEngine)) {
      const pol = opaEvaluate('POL-CE-003',{wsEngines:[incomingEngine,...existingEngines]})
      if (pol) {
        setQsOpaBlock({policy:pol, attrName:`${objKey}.${a.cd}`,
          incomingConn:incomingEngine, existingConn:existingEngines[0]})
        return // block the add
      }
    }
    setQsOpaBlock(null)
    setWorkspace(p=>[...p, {
      key, objKey, attrCd:a.cd, attrId:a.attrId||'—',
      ln:a.ln||a.cd, cd:a.cd, type:a.type||a.dbType||'',
      semantic:a.semantic, domain:a.domain||null,
    }])
    setRan(false)
  }
  const removeFromWorkspace = (key) => setWorkspace(p=>p.filter(w=>w.key!==key))
  const clearWorkspace = () => { setWorkspace([]); setRan(false) }

  // Unique tables in workspace
  const wsTables = [...new Set(workspace.map(w=>w.objKey))]

  // Relationship validation
  const relPairs = useMemo(()=>{
    const pairs = []
    for (let i=0; i<wsTables.length; i++) {
      for (let j=i+1; j<wsTables.length; j++) {
        const a = wsTables[i], b = wsTables[j]
        const hasRel = INITIAL_RELS.some(r=>(r.from===a&&r.to===b)||(r.from===b&&r.to===a))
        pairs.push({a, b, hasRel})
      }
    }
    return pairs
  },[wsTables])

  const missingRels = relPairs.filter(p=>!p.hasRel)
  const hasCrossEngineWorkspace = useMemo(()=>{
    const engines = [...new Set(wsTables.map(t=>CATALOG[t]?.connectionId||'lextr-pg'))]
    return engines.length > 1
  },[wsTables])
  const hasRelWarning = missingRels.length > 0

  // Applicable pairings from PAIRINGS (any attr in workspace is display/filter attr)
  const applicablePairings = useMemo(()=>
    PAIRINGS.filter(p=>workspace.some(w=>w.cd===p.dispAttr||w.cd===p.filtAttr))
  ,[workspace])

  // Routing hint
  const routingHint = useMemo(()=>{
    const hasComplex = wsTables.some(t=>['logic','intelligence'].includes(t.split('.')[0]))
    if (hasComplex) return {mode:'DAG_THEN_CUBE',color:L.amb,bg:L.ambBg}
    return {mode:'CUBE_DIRECT',color:L.pur,bg:L.purBg}
  },[wsTables])

  // Generated SQL (simplified semantic layer SQL for preview)

  // Return filter lookups applicable to an attribute in the workspace
  const applicableLookups = (w) => {
    const attr = CATALOG[w.objKey]?.attrs?.find(a=>a.cd===w.cd)
    const isBinary = ['BOOLEAN'].includes(attr?.domain)||w.type?.toLowerCase().includes('bool')  // v2.10.0: YN_FLAG mode removed; booleans are two-value ENUM_LIST
    return FILTER_LOOKUPS.filter(lk=>{
      if(lk.st!=='ACTIVE') return false
      if(lk.filterAttr===w.cd) return true                    // direct attribute match
      if(attr?.domain && lk.filterAttr===attr.domain) return true  // domain match
      if(isBinary && (lk.values||[]).every(v=>['Y','N','YES','NO','TRUE','FALSE','1','0'].includes(v.cd?.toUpperCase()))) return true
      return false
    })
  }

  // Mock Phase 1 resolution — returns a preview of the IN-list
  const previewLookup = (lk) => {
    if (!lk) return null
    if (lk.constructionType==='MANUAL_LIST' && lk.values) {
      const active = lk.values.filter(v=>v.st==='ACTIVE'||v.st==='ANTICIPATED')
      return {values: active.map(v=>v.cd), source:'MANUAL_LIST', count:active.length}
    }
    // SQL_QUERY — simulated Phase 1 resolution for preview
    // count uses values.length (actual preview set), not avgPhase1Rows (historical average)
    const MOCK_RESOLVED = {
      'OFAC_BLOCKED_COUNTRIES':     {values:['SY','IR','KP','CU','VE','SD','BY','MM','NI','LR','ZW','SS','CF','ML','SO'], note:'OFAC SDN list'},
      'AAA_RATED_COUNTRIES':        {values:['AU','AT','CA','DK','FI','DE','LU','NL','NO','SG','SE','CH'], note:'S&P/Moodys/Fitch AAA'},
      'ACTIVE_REGULATORY_ENTITIES': {values:['BHC_A001','BHC_A001_SUB1','BHC_A001_SUB2','BHC_B002'], note:'Y-9C / Y-14Q-H scope'},
      'OPEN_FISCAL_PERIODS':        {values:['2026-Q1','2026-Q2'], note:'currently open'},
      'NPL_LOAN_IDS':               {values:[], bloomFilter:true, note:'~12,400 loan IDs — BLOOM_FILTER'},
      'HIGH_RISK_GL_ACCOUNTS':      {values:['4100','4210','4850'], note:'high-volatility accounts'},
    }
    const m = MOCK_RESOLVED[lk.cd]
    if (!m) return null
    if (m.bloomFilter) return {values:[], source:'BLOOM_FILTER', count:lk.stats.avgPhase1Rows||12400, note:m.note}
    return {values:m.values, source:'SQL_QUERY', count:m.values.length, note:m.note}
  }

  const generatedSQL = useMemo(()=>{
    if (workspace.length===0) return '-- Select attributes from the left panel to build a query'
    const dims    = workspace.filter(w=>w.semantic!=='MEASURE')
    const measures= workspace.filter(w=>w.semantic==='MEASURE')
    const selects = [
      ...dims.map(w=>`  ${w.objKey.split('.')[1]}.${w.cd}  AS "${w.ln}"`),
      ...measures.map(w=>`  SUM(${w.objKey.split('.')[1]}.${w.cd})  AS "${w.ln}"`),
    ]
    const fromObj = wsTables[0]?.split('.')[1] || 'object'
    const joins = INITIAL_RELS
      .filter(r=>wsTables.includes(r.from) && wsTables.includes(r.to))
      .map(r=>`  JOIN ${r.to.split('.')[1]} ON ${r.from.split('.')[1]}.${r.from_col} = ${r.to.split('.')[1]}.${r.to_col}`)
    const groupBy = dims.map((w,i)=>`${i+1}`).join(', ')
    const pairing = applicablePairings[0]
    const pairingWhere = pairing
      ? `  ${pairing.filtAttr} = :resolved_id  -- pairing: ${pairing.cd}`
      : null

    // Build WHERE conditions from tagged filter lookups
    const lookupWheres = Object.entries(wsTags)
      .map(([attrKey, lkCd])=>{
        const lk = FILTER_LOOKUPS.find(l=>l.cd===lkCd)
        if(!lk) return null
        const w = workspace.find(x=>x.key===attrKey)
        if(!w) return null
        const preview = previewLookup(lk)
        const alias = w.objKey.split('.')[1]
        if(!preview) return `  ${alias}.${w.cd} IN (/* ${lkCd} */)  -- filter lookup (unresolved)`
        if(preview.source==='BLOOM_FILTER' || lk.executionStrategy==='BLOOM_FILTER')
          return `  ${alias}.${w.cd} IN (/* ${lkCd}: ~${preview.count.toLocaleString()} values — BLOOM_FILTER (Phase 1 resolved) */)`
        if(preview.values.length > 20)
          return `  ${alias}.${w.cd} IN (/* ${lkCd}: ${preview.values.length} values resolved by Phase 1 — ${preview.note||preview.source} */)`
        const inList = preview.values.map(v=>`'${v}'`).join(', ')
        return `  ${alias}.${w.cd} IN (${inList})  -- ${lkCd}: ${preview.note||preview.source}`
      }).filter(Boolean)

    const allWheres = [...(pairingWhere?[pairingWhere]:[]), ...lookupWheres]
    const whereBlock = allWheres.length>0
      ? (allWheres.length===1 ? `WHERE ${allWheres[0].trim()}` : `WHERE\n${allWheres.join('\n  AND ')}`)
      : ''

    // SQL uses PHYSICAL column names (w.cd) — logical names appear only as AS aliases
    // The LHP shows logical names; SQL is the technical layer showing physical names
    return [
      `-- Lextr Semantic Layer · generated SQL`,
      `-- Logical names shown in Query Studio; physical names used in SQL`,
      'SELECT',
      selects.join(',\n'),
      `FROM ${fromObj}`,
      ...joins,
      whereBlock,
      groupBy ? `GROUP BY ${groupBy}` : '',
    ].filter(Boolean).join('\n')
  },[workspace, wsTables, applicablePairings, wsTags])

  const bySchema = useMemo(()=>{
    const m={}
    OBJECTS.forEach(k=>{ const s=CATALOG[k].schema; if(!m[s])m[s]=[]; m[s].push(k) })
    return m
  },[])

  const qTabs = [
    {id:'workspace',label:'Workspace',    icon:Columns,   badge:workspace.length||undefined},
    {id:'er',       label:'ER Diagram',   icon:Network,   badge:hasRelWarning&&workspace.length>0?'!':undefined},
    {id:'sql',      label:'Generated SQL',icon:AlignLeft},
    {id:'trace',    label:'Exec Trace',   icon:Activity},
    {id:'perf',     label:'Performance',  icon:Zap},
  ]

  return (
    <div>
      <PageHdr title="Query Studio" icon={Play}
        sub="Browse attributes, build a workspace, generate and validate semantic layer SQL. Relationship warnings prevent invalid cross-table queries."
        action={<Btn label="Run Query" icon={Play} primary onClick={()=>setRan(true)} disabled={workspace.length===0}/>}/>

      {/* OPA Policy Block — shown when a cross-engine add was attempted */}
      {qsOpaBlock&&(
        <div style={{marginBottom:12}}>
          <PolicyBlock
            policy={qsOpaBlock.policy}
            context={{fromConn:qsOpaBlock.incomingConn, toConn:qsOpaBlock.existingConn}}/>
          <div style={{display:'flex',alignItems:'center',gap:8,marginTop:6,
            padding:'8px 12px',background:'#FCEBEB',border:'1px solid #F09595',
            borderRadius:6,fontSize:11}}>
            <Shield size={12} color="#A32D2D"/>
            <span style={{fontWeight:700,color:'#791F1F'}}>Attribute not added:</span>
            <code style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:'#A32D2D',
              background:'#F7C1C1',padding:'1px 6px',borderRadius:3}}>{qsOpaBlock.attrName}</code>
            <span style={{color:'#A32D2D'}}>Engine conflict blocked by {qsOpaBlock.policy.id}.</span>
            <button onClick={()=>setQsOpaBlock(null)} style={{marginLeft:'auto',
              padding:'3px 8px',borderRadius:5,border:'1px solid #E24B4A',
              background:'transparent',cursor:'pointer',fontSize:10,color:'#A32D2D'}}>Dismiss ✕</button>
          </div>
        </div>
      )}

      {/* Relationship warning banner */}
      {hasRelWarning && workspace.length>0 && !qsOpaBlock && (
        <div style={{padding:'9px 14px',marginBottom:12,background:L.ambBg,border:`1px solid ${L.amb}55`,
          borderRadius:8,display:'flex',alignItems:'flex-start',gap:8}}>
          <AlertTriangle size={14} color={L.amb} style={{flexShrink:0,marginTop:1}}/>
          <div>
            <div style={{fontSize:12,fontWeight:700,color:L.ambDk,marginBottom:3}}>No registered relationship between selected tables</div>
            <div style={{fontSize:11,color:L.t2,lineHeight:1.5}}>
              {missingRels.map(p=>(
                <span key={`${p.a}${p.b}`} style={{marginRight:10}}>
                  <code style={{fontSize:10,fontFamily:L.mono}}>{p.a.split('.')[1]}</code>
                  <span style={{margin:'0 4px',color:L.amb}}>↔</span>
                  <code style={{fontSize:10,fontFamily:L.mono}}>{p.b.split('.')[1]}</code>
                </span>
              ))}
              — <button onClick={()=>setActiveQTab('er')} style={{fontWeight:700,color:L.ambDk,background:'none',border:'none',cursor:'pointer',padding:0,fontSize:11,textDecoration:'underline'}}>View in ER Diagram</button> · Register a JOIN relationship first, or remove attributes from one of the tables.
            </div>
          </div>
        </div>
      )}

      <div style={{display:'grid',gridTemplateColumns:'240px 1fr',gap:12}}>

        {/* ── Attribute Browser LHP (dark, same as Data Catalog) ── */}
        <div style={{background:SL.bg,border:`1px solid ${SL.border}`,borderRadius:10,
          overflow:'hidden',display:'flex',flexDirection:'column',maxHeight:'calc(100vh - 200px)'}}>

          {/* View toggle */}
          <div style={{display:'flex',background:SL.sectionBg,borderBottom:`1px solid ${SL.div}`,flexShrink:0}}>
            {[{id:'technical',label:'Technical'},{id:'asset',label:'Data Asset'}].map(v=>{
              const on=lhpView===v.id
              return <button key={v.id} onClick={()=>setLhpView(v.id)} style={{
                flex:1,padding:'8px 4px',border:'none',cursor:'pointer',fontSize:11,fontWeight:700,
                background:on?SL.selObj:'transparent',color:on?SL.accentObj:SL.dim,
                borderBottom:on?`2px solid ${SL.accentObj}`:'2px solid transparent'}}>{v.label}</button>
            })}
          </div>
          <div style={{padding:'5px 10px',background:SL.bg,borderBottom:`1px solid ${SL.div}`,flexShrink:0}}>
            <div style={{position:'relative'}}>
              <Search size={11} style={{position:'absolute',left:7,top:'50%',transform:'translateY(-50%)',color:SL.dim,pointerEvents:'none'}}/>
              <input value={qsSearch} onChange={e=>setQsSearch(e.target.value)}
                placeholder="Search attributes…"
                style={{width:'100%',padding:'5px 24px 5px 24px',borderRadius:6,
                  border:`1px solid ${qsSearch?SL.accentAttr:SL.div}`,
                  background:SL.sectionBg,fontSize:11,color:SL.attrNm,
                  outline:'none',boxSizing:'border-box',fontFamily:'inherit'}}/>
              {qsSearch&&<button onClick={()=>setQsSearch('')}
                style={{position:'absolute',right:6,top:'50%',transform:'translateY(-50%)',
                  background:'none',border:'none',cursor:'pointer',color:SL.dim,fontSize:12,padding:0}}>✕</button>}
            </div>
          </div>
          <div style={{padding:'4px 10px',background:SL.sectionBg,borderBottom:`1px solid ${SL.div}`,
            flexShrink:0,fontSize:9,color:SL.dim}}>
            {qsSearch ? `Showing matches for "${qsSearch}"` : 'Click an attribute to add it to the workspace'}
          </div>

          <div style={{flex:1,overflow:'auto'}}>

            {/* Technical tree */}
            {lhpView==='technical' && (()=>{
              const qs=qsSearch.toLowerCase()
              const filtSchemas=Object.entries(bySchema).reduce((acc,[schema,objs])=>{
                const matched=objs.filter(k=>{
                  if(!qs) return true
                  const o=CATALOG[k]
                  return k.toLowerCase().includes(qs)||o?.logicalShortNm?.toLowerCase().includes(qs)
                    ||(o?.attrs||[]).some(a=>a.cd.toLowerCase().includes(qs)||a.ln?.toLowerCase().includes(qs))
                })
                if(matched.length) acc[schema]=matched; return acc
              },{})
              const schemaEntries=qs?Object.entries(filtSchemas):Object.entries(bySchema)
              if(qs&&schemaEntries.length===0) return(
                <div style={{padding:'24px 16px',textAlign:'center',color:SL.dim,fontSize:11}}>
                  No attributes match <strong style={{color:SL.attrNm}}>"{qsSearch}"</strong>
                </div>
              )
              return schemaEntries.map(([schema,keys])=>{
              const schOpen=expSchemas[schema]
              return (
                <div key={schema}>
                  <div onClick={()=>setExpSchemas(p=>({...p,[schema]:!p[schema]}))}
                    style={{padding:'5px 12px',background:SL.sectionBg,
                      borderBottom:`1px solid ${SL.div}`,borderTop:`1px solid ${SL.div}`,
                      cursor:'pointer',display:'flex',alignItems:'center',gap:5,userSelect:'none'}}>
                    <span style={{fontSize:9,color:SL.dim}}>{schOpen?'▾':'▸'}</span>
                    <Database size={9} color={SL.dim}/>
                    <span style={{fontSize:9,fontWeight:700,color:SL.schema,textTransform:'uppercase',letterSpacing:'.07em',flex:1}}>{schema}</span>
                  </div>
                  {schOpen && (keys||[]).map(k=>{
                    const o=CATALOG[k]; const objOpen=expObjs[k]
                    const inWs=workspace.some(w=>w.objKey===k)
                    return (
                      <div key={k}>
                        <div onClick={()=>setExpObjs(p=>({...p,[k]:!p[k]}))}
                          style={{display:'flex',alignItems:'center',gap:5,
                            padding:'7px 12px 7px 20px',cursor:'pointer',
                            borderBottom:`1px solid ${SL.div}`,
                            background:inWs?SL.selTeal:'transparent',
                            borderLeft:inWs?`3px solid ${SL.accentAsset}`:'3px solid transparent'}}>
                          <span style={{fontSize:9,color:SL.dim,flexShrink:0}}>{objOpen?'▾':'▸'}</span>
                          <Table2 size={10} color={inWs?SL.accentAsset:SL.dim}/>
                          <div style={{flex:1,minWidth:0,overflow:'hidden'}}>
                            {o.logicalShortNm&&<div style={{fontSize:9,fontWeight:700,
                              color:inWs?SL.accentAsset:'#36c97e',lineHeight:1.2,marginBottom:1,
                              overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{o.logicalShortNm}</div>}
                            <div style={{fontFamily:L.mono,fontSize:10,
                              color:inWs?SL.accentAsset:SL.objNm,
                              overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{o.obj}</div>
                          </div>
                          {inWs&&<span style={{fontSize:8,fontWeight:700,color:SL.accentAsset}}>
                            {workspace.filter(w=>w.objKey===k).length}
                          </span>}
                        </div>
                        {objOpen && (o.attrs||[]).map(a=>{
                          const wKey=`${k}.${a.cd}`
                          const inWksp = workspace.some(w=>w.key===wKey)
                          return (
                            <div key={a.cd} onClick={()=>addToWorkspace(k,a)}
                              style={{display:'flex',alignItems:'center',gap:4,
                                padding:'5px 12px 5px 34px',cursor:'pointer',
                                borderBottom:`1px solid ${SL.div}`,
                                background:inWksp?'#eeedfe':'transparent',
                                borderLeft:inWksp?`3px solid ${SL.accentAttr}`:'3px solid transparent'}}
                              onMouseEnter={e=>{if(!inWksp)e.currentTarget.style.background=SL.hov}}
                              onMouseLeave={e=>{if(!inWksp)e.currentTarget.style.background='transparent'}}>
                              <div style={{flex:1,minWidth:0,overflow:'hidden'}}>
                                <div style={{fontSize:10,fontWeight:600,
                                  color:inWksp?SL.accentAttr:SL.attrNm,
                                  overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                                  {a.ln||a.cd}
                                </div>
                                <div style={{fontFamily:L.mono,fontSize:8,
                                  color:inWksp?`${SL.accentAttr}99`:SL.dim,
                                  overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                                  {a.cd}
                                </div>
                              </div>
                              {a.semantic==='MEASURE'&&<span style={{fontSize:7,fontWeight:800,color:L.teal,flexShrink:0}}>∑</span>}
                              {a.pk&&<span style={{fontSize:7,fontWeight:800,color:SL.accentAttr,flexShrink:0}}>PK</span>}
                              {inWksp&&<span style={{fontSize:10,color:SL.accentAttr,flexShrink:0}}>✓</span>}
                            </div>
                          )
                        })}
                      </div>
                    )
                  })}
                </div>
              )
            })

            })()}

            {/* Asset tree */}
            {lhpView==='asset' && (()=>{
              const qs=qsSearch.toLowerCase()
              const filtAssets=DATA_ASSETS.map(asset=>({
                ...asset,
                attrs:asset.objects.flatMap(k=>{
                  const o=CATALOG[k]; if(!o) return []
                  return (o.attrs||[]).filter(a=>!qs||a.cd.toLowerCase().includes(qs)||a.ln?.toLowerCase().includes(qs)).map(a=>({...a,objKey:k}))
                })
              })).filter(asset=>!qs||asset.attrs.length>0||asset.label.toLowerCase().includes(qs))
              if(qs&&filtAssets.every(a=>a.attrs.length===0)) return(
                <div style={{padding:'24px 16px',textAlign:'center',color:SL.dim,fontSize:11}}>
                  No attributes match <strong style={{color:SL.attrNm}}>"{qsSearch}"</strong>
                </div>
              )
              return filtAssets.map(asset=>{
              const open=expAssets[asset.id]
              const allAttrs=asset.objects.flatMap(k=>{
                const o=CATALOG[k]; if(!o) return []
                return (o.attrs||[]).map(a=>({...a,objKey:k}))
              })
              return (
                <div key={asset.id}>
                  <div onClick={()=>setExpAssets(p=>({...p,[asset.id]:!p[asset.id]}))}
                    style={{padding:'8px 12px',cursor:'pointer',userSelect:'none',
                      display:'flex',alignItems:'center',gap:7,
                      background:open?SL.selTeal:SL.sectionBg,
                      borderBottom:`1px solid ${SL.div}`,borderTop:`1px solid ${SL.div}`,
                      borderLeft:open?`3px solid ${SL.accentAsset}`:'3px solid transparent'}}>
                    <span style={{fontSize:13}}>{asset.icon}</span>
                    <div style={{flex:1}}>
                      <div style={{fontSize:11,fontWeight:700,color:open?SL.accentAsset:SL.objNm}}>{asset.label}</div>
                      <div style={{fontSize:9,color:SL.dim}}>{allAttrs.length} attributes</div>
                    </div>
                    <span style={{fontSize:10,color:SL.dim}}>{open?'▾':'▸'}</span>
                  </div>
                  {open && allAttrs.map((a,i)=>{
                    const wKey=`${a.objKey}.${a.cd}`; const inWksp=workspace.some(w=>w.key===wKey)
                    return (
                      <div key={wKey} onClick={()=>addToWorkspace(a.objKey,a)}
                        style={{display:'flex',alignItems:'center',gap:5,
                          padding:'5px 12px 5px 26px',cursor:'pointer',
                          borderBottom:`1px solid ${SL.div}`,
                          background:inWksp?'#eeedfe':'transparent',
                          borderLeft:inWksp?`3px solid ${SL.accentAttr}`:'3px solid transparent'}}
                        onMouseEnter={e=>{if(!inWksp)e.currentTarget.style.background=SL.hov}}
                        onMouseLeave={e=>{if(!inWksp)e.currentTarget.style.background='transparent'}}>
                        <div style={{flex:1,minWidth:0,overflow:'hidden'}}>
                          <div style={{fontSize:10,fontWeight:600,
                            color:inWksp?SL.accentAttr:SL.attrNm,
                            overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                            {a.ln||a.cd}
                          </div>
                          <div style={{fontFamily:L.mono,fontSize:8,
                            color:inWksp?`${SL.accentAttr}99`:SL.dim,
                            overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                            {a.objKey.split('.')[1]}.{a.cd}
                          </div>
                        </div>
                        {a.semantic==='MEASURE'&&<span style={{fontSize:7,fontWeight:800,color:L.teal,flexShrink:0}}>∑</span>}
                        {inWksp&&<span style={{fontSize:10,color:SL.accentAttr,flexShrink:0}}>✓</span>}
                      </div>
                    )
                  })}
                </div>
              )
            })
            })()}
          </div>

          <div style={{padding:'6px 12px',background:SL.sectionBg,borderTop:`1px solid ${SL.div}`,
            fontSize:9,color:SL.dim,flexShrink:0,display:'flex',justifyContent:'space-between'}}>
            <span>{OBJECTS.length} tables · {OBJECTS.reduce((s,k)=>s+(CATALOG[k]?.attrs?.length||0),0)} attrs</span>
            <span>Logical name shown · physical name below · ∑ = measure · PK = primary key</span>
          </div>
        </div>

        {/* ── Right panel: workspace + query ── */}
        <div style={{display:'flex',flexDirection:'column',gap:12}}>

          {/* Empty state */}
          {workspace.length===0&&(
            <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:'48px',textAlign:'center'}}>
              <Play size={32} color={L.t4} style={{marginBottom:12}}/>
              <div style={{fontSize:14,fontWeight:600,color:L.t2,marginBottom:6}}>Select attributes to build a query</div>
              <div style={{fontSize:12,color:L.t3,maxWidth:400,margin:'0 auto',lineHeight:1.6}}>
                Click any attribute in the left panel. Query Studio will validate relationships,
                apply attribute pairings, and generate the semantic-service semantic query automatically.
              </div>
            </div>
          )}

          {workspace.length>0&&(
            <Fragment>
              {/* Workspace status bar */}
              <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:'12px 16px',
                display:'flex',alignItems:'center',gap:12,flexWrap:'wrap'}}>
                <div style={{display:'flex',gap:6,flexWrap:'wrap',flex:1}}>
                  {(wsTables||[]).map(t=>{
                    const cnt=workspace.filter(w=>w.objKey===t).length
                    const hasRel=wsTables.length===1||relPairs.filter(p=>p.a===t||p.b===t).every(p=>p.hasRel)
                    return (
                      <div key={t} style={{display:'flex',alignItems:'center',gap:5,padding:'4px 10px',
                        borderRadius:6,background:hasRel?L.tealBg:L.ambBg,
                        border:`1px solid ${hasRel?L.teal:L.amb}44`}}>
                        <Table2 size={10} color={hasRel?L.teal:L.amb}/>
                        <span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:hasRel?L.tealDk:L.ambDk}}>{t.split('.')[1]}</span>
                        <span style={{fontSize:10,color:hasRel?L.teal:L.amb}}>{cnt}a</span>
                      </div>
                    )
                  })}
                </div>
                <div style={{display:'flex',gap:8,alignItems:'center'}}>
                  {applicablePairings.length>0&&(
                    <Chip text={`${applicablePairings.length} pairing${applicablePairings.length>1?'s':''}`} c={L.pur} bg={L.purBg}/>
                  )}
                  {hasRelWarning&&<button onClick={()=>setActiveQTab('er')} style={{padding:0,border:'none',background:'none',cursor:'pointer'}}><Chip text="⚠ Missing relationship — view ER" c={L.amb} bg={L.ambBg}/></button>}
                  <Btn label="Clear" small onClick={clearWorkspace}/>
                  <Btn label="Run Query" icon={Play} primary small onClick={()=>{setRan(true);setActiveQTab('sql')}} disabled={hasRelWarning}/>
                </div>
              </div>

              {/* Query panel tabs */}
              <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:'14px 20px'}}>
                <HorizTabs tabs={qTabs} active={activeQTab} onChange={setActiveQTab}/>

                {/* ── Workspace tab ── */}
                {activeQTab==='workspace'&&(
                  <div>
                    <div style={{border:`1px solid ${L.bd}`,borderRadius:8,overflow:'hidden'}}>
                      <div style={{display:'grid',gridTemplateColumns:'64px 1fr 1fr 1fr 0.8fr 1fr 32px',
                        padding:'7px 12px',background:L.s3,borderBottom:`1px solid ${L.bd}`,
                        fontSize:9,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.05em',gap:6}}>
                        {['ID','Logical name','Physical (SQL)','Object','Role','Filter lookup',''].map(h=><span key={h}>{h}</span>)}
                      </div>
                      {workspace.map((w,i)=>{
                        const pairing   = PAIRINGS.find(p=>p.dispAttr===w.cd||p.filtAttr===w.cd)
                        const hasMissingRel = wsTables.length > 1 &&
                          missingRels.some(p=>p.a===w.objKey||p.b===w.objKey)
                        const rowBg     = hasMissingRel ? '#fff8f0' : i%2 ? L.s2 : L.s1
                        const rowBdr    = hasMissingRel ? `3px solid ${L.amb}` : '3px solid transparent'
                        const taggedLk  = wsTags[w.key] ? FILTER_LOOKUPS.find(l=>l.cd===wsTags[w.key]) : null
                        const applicable= applicableLookups(w)
                        const selOpen   = lookupSel===w.key
                        return (
                          <div key={w.key} style={{borderBottom:`1px solid ${L.bd2}`,background:rowBg,borderLeft:rowBdr}}>
                            <div style={{display:'grid',
                              gridTemplateColumns:'56px 1fr 1fr 1fr 0.7fr 1.4fr 32px',
                              padding:'8px 12px',fontSize:12,alignItems:'center',gap:6}}>
                              <span style={{fontFamily:L.mono,fontSize:9,color:L.purDk,fontWeight:700}}>{w.attrId}</span>
                              <div>
                                {/* Logical name — user-facing primary */}
                                <div style={{fontSize:11,fontWeight:600,color:hasMissingRel?L.ambDk:L.t1,
                                  overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                                  {w.ln||w.cd}
                                </div>
                                {/* Physical name — SQL reference */}
                                <div style={{fontFamily:L.mono,fontSize:9,color:hasMissingRel?L.ambDk:L.t3,marginTop:1,
                                  overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                                  {w.objKey.split('.')[1]}.{w.cd}
                                </div>
                                {pairing&&<div style={{fontSize:9,color:L.pur,marginTop:1}}>⟳ {pairing.cd}</div>}
                                {hasMissingRel&&(
                                  <div style={{fontSize:9,color:L.amb,fontWeight:700,marginTop:1,display:'flex',alignItems:'center',gap:4}}>
                                    <AlertTriangle size={9}/> no relationship
                                  </div>
                                )}
                              </div>
                              <span style={{fontSize:11,color:L.t4,fontStyle:'italic'}}>{w.ln}</span>
                              <Chip text={w.objKey.split('.')[1]} c={hasMissingRel?L.amb:L.teal}
                                bg={hasMissingRel?L.ambBg:L.tealBg} sz={9}/>
                              <SemBadge s={w.semantic}/>

                              {/* Filter Lookup tag cell */}
                              <div style={{position:'relative'}}>
                                {taggedLk ? (
                                  <div style={{display:'flex',alignItems:'center',gap:4}}>
                                    <span style={{fontSize:9,fontWeight:700,color:L.tealDk,background:L.tealBg,
                                      padding:'2px 6px',borderRadius:4,border:`1px solid ${L.teal}44`,
                                      maxWidth:120,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                                      ⊆ {taggedLk.cd}
                                    </span>
                                    <button onClick={()=>{setWsTags(p=>{const n={...p};delete n[w.key];return n});setLookupSel(null)}}
                                      style={{fontSize:9,color:L.cor,background:'none',border:'none',cursor:'pointer',padding:'0 2px'}}>✕</button>
                                  </div>
                                ) : applicable.length>0 ? (
                                  <button onClick={()=>setLookupSel(selOpen?null:w.key)}
                                    style={{fontSize:9,fontWeight:700,color:'#534AB7',background:'#EEEDFE',
                                      padding:'2px 8px',borderRadius:4,border:'1px solid #AFA9EC',
                                      cursor:'pointer',whiteSpace:'nowrap'}}>
                                    ⊆ Tag lookup ({applicable.length})
                                  </button>
                                ) : (
                                  <span style={{fontSize:9,color:L.t4}}>—</span>
                                )}
                              </div>

                              <button onClick={()=>removeFromWorkspace(w.key)}
                                style={{width:20,height:20,borderRadius:4,border:`1px solid ${L.bd}`,
                                  background:L.s1,cursor:'pointer',fontSize:11,color:L.cor,
                                  display:'flex',alignItems:'center',justifyContent:'center'}}>×</button>
                            </div>

                            {/* Lookup selector dropdown */}
                            {selOpen&&(
                              <div style={{margin:'0 12px 10px 56px',border:`1px solid ${L.bd}`,
                                borderRadius:8,overflow:'hidden',background:L.s1}}>
                                <div style={{padding:'7px 12px',background:L.s3,borderBottom:`1px solid ${L.bd}`,
                                  fontSize:10,fontWeight:700,color:L.t2}}>
                                  Select filter lookup for <code style={{fontFamily:L.mono,color:L.purDk}}>{w.cd}</code>
                                  <span style={{marginLeft:6,fontSize:9,color:L.t4,fontWeight:400}}>IN-list will be resolved at query execution time</span>
                                </div>
                                {applicable.map(lk=>{
                                  const preview = previewLookup(lk)
                                  const stratClr = lk.executionStrategy==='IN_LIST'?{c:L.tealDk,bg:L.tealBg}:
                                                   lk.executionStrategy==='BLOOM_FILTER'?{c:'#185FA5',bg:'#E6F1FB'}:
                                                   {c:'#534AB7',bg:'#EEEDFE'}
                                  return (
                                    <div key={lk.cd} onClick={()=>{setWsTags(p=>({...p,[w.key]:lk.cd}));setLookupSel(null)}}
                                      style={{display:'flex',alignItems:'flex-start',gap:10,padding:'10px 12px',
                                        borderBottom:`1px solid ${L.bd2}`,cursor:'pointer',
                                        background:L.s1}}
                                      onMouseEnter={e=>e.currentTarget.style.background=L.s3}
                                      onMouseLeave={e=>e.currentTarget.style.background=L.s1}>
                                      <div style={{flex:1}}>
                                        <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:3}}>
                                          <span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:L.tealDk}}>{lk.cd}</span>
                                          <span style={{fontSize:9,fontWeight:700,color:stratClr.c,background:stratClr.bg,
                                            padding:'1px 5px',borderRadius:3}}>{lk.executionStrategy}</span>
                                          {!lk.tenantCd&&<span style={{fontSize:9,fontWeight:700,color:L.grn,background:L.grnBg,padding:'1px 5px',borderRadius:3}}>GLOBAL</span>}
                                        </div>
                                        <div style={{fontSize:10,color:L.t3,lineHeight:1.4}}>{lk.desc.slice(0,80)}…</div>
                                      </div>
                                        {preview&&(
                                        <div style={{textAlign:'right',flexShrink:0}}>
                                          {preview.source==='BLOOM_FILTER'
                                            ?<div style={{fontSize:9,fontWeight:700,color:'#185FA5',background:'#E6F1FB',padding:'3px 7px',borderRadius:4}}>
                                                BLOOM_FILTER · ~{preview.count.toLocaleString()} values
                                              </div>
                                            :preview.values.length<=20
                                            ?<div style={{fontFamily:L.mono,fontSize:9,color:L.tealDk,
                                                background:L.tealBg,padding:'3px 7px',borderRadius:4,
                                                maxWidth:200,wordBreak:'break-all'}}>
                                                {preview.values.map(v=>`'${v}'`).join(', ')}
                                              </div>
                                            :<div style={{fontSize:9,fontWeight:700,color:L.t2}}>
                                                {preview.values.length} values
                                              </div>
                                          }
                                          {preview.note&&<div style={{fontSize:8,color:L.t4,marginTop:2}}>{preview.note}</div>}
                                          <div style={{fontSize:8,color:L.t4,marginTop:1}}>{preview.source}</div>
                                        </div>
                                      )}
                                    </div>
                                  )
                                })}
                              </div>
                            )}
                          </div>
                        )
                      })}
                    </div>
                    {!ran&&(
                      <div style={{marginTop:10,padding:'8px 12px',background:L.s3,borderRadius:6,
                        fontSize:11,color:L.t3,display:'flex',alignItems:'center',gap:6}}>
                        <Info size={12} color={L.t4}/>
                        {workspace.length} attribute{workspace.length>1?'s':''} selected across {wsTables.length} table{wsTables.length>1?'s':''}.
                        {!hasRelWarning?' Click Run Query to generate and execute.':' Fix relationship warnings before running.'}
                      </div>
                    )}
                  </div>
                )}

                {/* ── Generated ER Diagram tab ── */}
                {activeQTab==='er'&&(
                  <div>
                    {/* QS ER: only workspace tables; grows as attributes are added */}
                    {wsTables.length===0&&(
                      <div style={{padding:'40px',textAlign:'center',color:L.t4}}>
                        <Network size={28} color={L.t4} style={{display:'block',margin:'0 auto 10px'}}/>
                        <div style={{fontWeight:600,marginBottom:4,fontSize:13}}>No tables in workspace</div>
                        <div style={{fontSize:12}}>Add attributes from the left panel — the ER diagram grows with each table you add.</div>
                      </div>
                    )}
                    {wsTables.length>0&&(()=>{
                      // ── Only workspace tables in this diagram ──────────────────
                      const objs = wsTables
                      // Layout: up to 3 cols, auto-flow, taller nodes (real ER style)
                      const COLS_N = Math.min(objs.length, 3)
                      const GAP_X = 80, GAP_Y = 60, PAD_X = 32, PAD_Y = 48
                      // Compute node heights based on expand state
                      const nodeH = obj => erNodeH(obj, !!qsExpanded[obj])
                      const nodeW = ER_NODE_W
                      // Position grid — stagger rows for visual breathing room
                      const nodePos = {}
                      objs.forEach((obj,i)=>{
                        const col = i % COLS_N, row = Math.floor(i / COLS_N)
                        nodePos[obj] = {
                          x: PAD_X + col*(nodeW+GAP_X),
                          y: PAD_Y + row*(120+GAP_Y),
                        }
                      })
                      // Canvas size
                      const svgW = PAD_X*2 + COLS_N*(nodeW+GAP_X) - GAP_X
                      const maxRow = Math.max(...objs.map((o,i)=>Math.floor(i/COLS_N)))
                      const svgH = PAD_Y + (maxRow+1)*120 + maxRow*GAP_Y + 60
                      // Crow-foot notation helpers
                      const getEdgePts = (fromObj, toObj) => {
                        const f = nodePos[fromObj], t = nodePos[toObj]
                        if (!f||!t) return null
                        const fH = nodeH(fromObj), tH = nodeH(toObj)
                        const fCx = f.x+nodeW/2, fCy = f.y+fH/2
                        const tCx = t.x+nodeW/2, tCy = t.y+tH/2
                        const dx = tCx-fCx, dy = tCy-fCy
                        const len = Math.sqrt(dx*dx+dy*dy)||1
                        const ux = dx/len, uy = dy/len
                        // Entry/exit on the side of the node (left or right edge, or top/bottom)
                        const fEx = fCx+ux*(nodeW/2+2), fEy = fCy+uy*(fH/2+2)
                        const tEx = tCx-ux*(nodeW/2+2), tEy = tCy-uy*(tH/2+2)
                        return {fEx,fEy,tEx,tEy,ux,uy,dx,dy}
                      }
                      // Edge style by rel status
                      const relEdgeCol = r => r.isMissing?'#e6a832':r.st==='ACTIVE'?L.teal:r.st==='PENDING'?'#e6a832':'#4a7fb5'
                      return (
                        <div>
                          {/* Legend */}
                          <div style={{display:'flex',gap:14,marginBottom:10,fontSize:11,color:L.t3,flexWrap:'wrap',alignItems:'center'}}>
                            <div style={{display:'flex',alignItems:'center',gap:6}}>
                              <svg width={28} height={10}><line x1={0} y1={5} x2={28} y2={5} stroke={L.teal} strokeWidth={2}/></svg>
                              Registered join (ACTIVE)
                            </div>
                            <div style={{display:'flex',alignItems:'center',gap:6}}>
                              <svg width={28} height={10}><line x1={0} y1={5} x2={28} y2={5} stroke={'#e6a832'} strokeWidth={2} strokeDasharray="5,3"/></svg>
                              Missing or PENDING
                            </div>
                            <div style={{flex:1}}/>
                            <span style={{fontSize:10,color:L.t4}}>Click + on a node to see all attributes</span>
                            {hasRelWarning&&(
                              <span style={{padding:'3px 9px',borderRadius:5,background:L.ambBg,
                                border:`1px solid ${L.amb}55`,fontSize:11,fontWeight:700,color:L.ambDk}}>
                                <AlertTriangle size={11} style={{verticalAlign:'middle',marginRight:3}}/>
                                {missingRels.length} missing join{missingRels.length!==1?'s':''}
                              </span>
                            )}
                          </div>
                          <div style={{background:L.nv,borderRadius:12,overflow:'auto',border:`1px solid #1a3a5f`}}>
                            <svg width={svgW} height={svgH} style={{display:'block',fontFamily:L.font}}>
                              <defs>
                                <marker id="qs-cf-teal" viewBox="0 0 10 10" refX="9" refY="5"
                                  markerWidth="6" markerHeight="6" orient="auto">
                                  <circle cx={5} cy={5} r={3} fill="none" stroke={L.teal} strokeWidth={1.5}/>
                                </marker>
                                <marker id="qs-cf-amb" viewBox="0 0 10 10" refX="9" refY="5"
                                  markerWidth="6" markerHeight="6" orient="auto">
                                  <circle cx={5} cy={5} r={3} fill="none" stroke="#e6a832" strokeWidth={1.5}/>
                                </marker>
                                <filter id="qs-nd-glow">
                                  <feGaussianBlur stdDeviation="3" result="b"/>
                                  <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
                                </filter>
                              </defs>
                              {/* Dot grid */}
                              {Array.from({length:Math.ceil(svgW/22)},(_,xi)=>
                                Array.from({length:Math.ceil(svgH/22)},(_,yi)=>(
                                  <circle key={`${xi}-${yi}`} cx={xi*22+11} cy={yi*22+11} r={0.8}
                                    fill="rgba(255,255,255,0.03)"/>
                                ))
                              )}
                              {/* Registered relationship edges */}
                              {INITIAL_RELS.filter(r=>wsTables.includes(r.from)&&wsTables.includes(r.to)).map(r=>{
                                const pts = getEdgePts(r.from, r.to)
                                if (!pts) return null
                                const {fEx,fEy,tEx,tEy,ux,uy} = pts
                                const col = relEdgeCol(r)
                                const mx=(fEx+tEx)/2, my=(fEy+tEy)/2
                                const isMany = r.type==='MANY_TO_ONE'||r.type==='ONE_TO_MANY'
                                return (
                                  <g key={r.cd}>
                                    <line x1={fEx} y1={fEy} x2={tEx} y2={tEy}
                                      stroke={col} strokeWidth={1.5}
                                      strokeDasharray={r.st==='ACTIVE'?'none':'5,3'}/>
                                    {/* Crow-foot: many side (from) */}
                                    {(r.type==='MANY_TO_ONE')&&<CrowFoot x={fEx} y={fEy} dx={tEx-fEx} dy={tEy-fEy} side="many" col={col}/>}
                                    {/* Crow-foot: one side (to) */}
                                    {(r.type==='MANY_TO_ONE')&&<CrowFoot x={tEx} y={tEy} dx={fEx-tEx} dy={fEy-tEy} side="one" col={col}/>}
                                    {(r.type==='ONE_TO_MANY')&&<CrowFoot x={fEx} y={fEy} dx={tEx-fEx} dy={tEy-fEy} side="one" col={col}/>}
                                    {(r.type==='ONE_TO_MANY')&&<CrowFoot x={tEx} y={tEy} dx={fEx-tEx} dy={fEy-tEy} side="many" col={col}/>}
                                    {/* Cardinality badge */}
                                    <rect x={mx-18} y={my-8} width={36} height={16} rx={4}
                                      fill="#0a1828" stroke={col} strokeWidth={0.8}/>
                                    <text x={mx} y={my+4} textAnchor="middle"
                                      fontSize={8} fontFamily={L.mono} fill={col} fontWeight={700}>
                                      {r.type==='MANY_TO_ONE'?'N : 1':r.type==='ONE_TO_MANY'?'1 : N':'1 : 1'}
                                    </text>
                                    {/* Join column tooltip */}
                                    <text x={mx} y={my+18} textAnchor="middle"
                                      fontSize={7} fontFamily={L.mono} fill="#2a4a6e">
                                      {r.from_col} = {r.to_col}
                                    </text>
                                  </g>
                                )
                              })}
                              {/* Missing join dashed amber lines */}
                              {missingRels.map(p=>{
                                const pts = getEdgePts(p.a, p.b)
                                if (!pts) return null
                                const {fEx,fEy,tEx,tEy} = pts
                                const mx=(fEx+tEx)/2, my=(fEy+tEy)/2
                                return (
                                  <g key={`miss-${p.a}-${p.b}`}>
                                    <line x1={fEx} y1={fEy} x2={tEx} y2={tEy}
                                      stroke="#e6a832" strokeWidth={2} strokeDasharray="6,4"/>
                                    <rect x={mx-28} y={my-9} width={56} height={18} rx={4}
                                      fill="#1c0e00" stroke="#e6a832" strokeWidth={0.8}/>
                                    <text x={mx} y={my+4} textAnchor="middle"
                                      fontSize={8} fontFamily={L.font} fill="#e6a832" fontWeight={700}>⚠ NO JOIN</text>
                                  </g>
                                )
                              })}
                              {/* ER Nodes — workspace tables only */}
                              {objs.map(obj=>{
                                const isMiss = wsTables.length>1&&missingRels.some(p=>p.a===obj||p.b===obj)
                                return (
                                  <g key={obj} filter="url(#qs-nd-glow)">
                                    <ERNode
                                      obj={obj}
                                      x={nodePos[obj].x}
                                      y={nodePos[obj].y}
                                      expanded={!!qsExpanded[obj]}
                                      onToggle={obj=>setQsExpanded(p=>({...p,[obj]:!p[obj]}))}
                                      highlight={isMiss?'warn':'active'}
                                      dimmed={false}
                                      selectable={false}
                                    />
                                  </g>
                                )
                              })}
                            </svg>
                          </div>
                          {/* Missing joins action list */}
                          {missingRels.length>0&&(
                            <div style={{marginTop:12,padding:'12px 14px',background:L.ambBg,
                              border:`1px solid ${L.amb}44`,borderRadius:8}}>
                              <div style={{fontSize:12,fontWeight:700,color:L.ambDk,marginBottom:8,
                                display:'flex',alignItems:'center',gap:6}}>
                                <AlertTriangle size={13}/> These table pairs need a registered relationship
                              </div>
                              {missingRels.map(p=>(
                                <div key={`${p.a}${p.b}`} style={{display:'flex',alignItems:'center',
                                  gap:8,padding:'7px 10px',marginBottom:5,
                                  background:L.s1,border:`1px solid ${L.bd}`,borderRadius:7}}>
                                  <span style={{fontFamily:L.mono,fontSize:11,fontWeight:700,color:L.ambDk,
                                    background:L.ambBg,padding:'2px 8px',borderRadius:4}}>{p.a.split('.')[1]}</span>
                                  <span style={{color:L.amb,fontWeight:700,fontSize:14}}>↔</span>
                                  <span style={{fontFamily:L.mono,fontSize:11,fontWeight:700,color:L.ambDk,
                                    background:L.ambBg,padding:'2px 8px',borderRadius:4}}>{p.b.split('.')[1]}</span>
                                  <div style={{flex:1}}/>
                                  <span style={{fontSize:11,color:L.t3}}>
                                    Go to <strong style={{color:L.blue}}>Relationship Mgmt</strong> → register a JOIN.
                                  </span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )
                    })()}
                  </div>
                )}
                {/* ── SQL tab ── */}
                {activeQTab==='sql'&&(
                  <div>
                    <div style={{background:L.nv,borderRadius:8,overflow:'hidden',marginBottom:10}}>
                      <div style={{padding:'8px 14px',borderBottom:'1px solid rgba(255,255,255,0.08)',
                        display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                        <span style={{fontSize:10,color:'#8aa8c0',fontWeight:600,fontFamily:L.mono}}>
                          semantic-service /v1/sql
                        </span>
                        <div style={{display:'flex',gap:6}}>
                          <Chip text={routingHint.mode} c={routingHint.color} bg={routingHint.color+'33'}/>
                          {applicablePairings.length>0&&<Chip text="pairing resolution active" c={L.pur} bg={L.pur+'33'}/>}
                        </div>
                      </div>
                      <pre style={{margin:0,padding:'14px',fontSize:12,fontFamily:L.mono,
                        color:'#b8d4ee',lineHeight:1.8,whiteSpace:'pre-wrap',overflow:'auto'}}>
                        {generatedSQL}
                      </pre>
                    </div>
                    {/* Filter Lookup resolution summary */}
                    {Object.keys(wsTags).length>0&&(
                      <div style={{padding:'10px 14px',background:L.tealBg,borderRadius:8,
                        border:`1px solid ${L.teal}44`,marginBottom:10}}>
                        <div style={{fontSize:11,fontWeight:700,color:L.tealDk,marginBottom:8,display:'flex',alignItems:'center',gap:8}}>
                          <Filter size={13} color={L.teal}/> Filter lookup resolution  (Phase 1 — runs before main query)
                        </div>
                        {Object.entries(wsTags).map(([attrKey,lkCd])=>{
                          const lk = FILTER_LOOKUPS.find(l=>l.cd===lkCd)
                          const w  = workspace.find(x=>x.key===attrKey)
                          const preview = lk ? previewLookup(lk) : null
                          if(!lk||!w) return null
                          return (
                            <div key={attrKey} style={{padding:'8px 10px',background:L.s1,borderRadius:6,
                              marginBottom:6,border:`1px solid ${L.teal}33`}}>
                              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:preview?.values?.length>0?5:0}}>
                                <code style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:L.tealDk}}>{w.objKey.split('.')[1]}.{w.cd}</code>
                                <span style={{fontSize:11,color:L.t3}}>IN</span>
                                <code style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:'#534AB7'}}>{lk.cd}</code>
                                <span style={{fontSize:9,fontWeight:700,color:L.t4}}>
                                  {lk.executionStrategy} · {lk.constructionType==='MANUAL_LIST'?`${(lk.values||[]).filter(v=>v.st==='ACTIVE').length} values (manual)`:`~${lk.stats.avgPhase1Rows} avg rows`}
                                </span>
                                <span style={{fontSize:9,color:L.t4,marginLeft:'auto'}}>Phase 1 on {CATALOG[lk.filterObj]?.connectionId||'lextr-pg'} → injected into Phase 2</span>
                              </div>
                              {preview?.source==='BLOOM_FILTER'&&(
                                <div style={{fontSize:9,fontWeight:700,color:'#185FA5',background:'#E6F1FB',padding:'4px 8px',borderRadius:4}}>
                                  BLOOM_FILTER — ~{preview.count.toLocaleString()} values · no IN-list generated
                                </div>
                              )}
                              {preview?.values&&preview.values.length>0&&preview.values.length<=20&&(
                                <div style={{fontFamily:L.mono,fontSize:9,color:L.tealDk,
                                  background:L.tealBg,padding:'4px 8px',borderRadius:4,wordBreak:'break-all'}}>
                                  {preview.values.map(v=>`'${v}'`).join(', ')}
                                  {preview.note&&<span style={{fontFamily:'inherit',color:L.t4,marginLeft:8}}>/* {preview.note} */</span>}
                                </div>
                              )}
                              {preview?.values&&preview.values.length>20&&(
                                <div style={{fontSize:9,color:L.t3}}>
                                  {preview.values.length} values resolved — full IN-list injected into Phase 2 query
                                </div>
                              )}
                            </div>
                          )
                        })}
                        <div style={{fontSize:10,color:L.t3,marginTop:4}}>
                          Phase 1 results are cached for {wsTags&&Object.values(wsTags).map(cd=>FILTER_LOOKUPS.find(l=>l.cd===cd)?.cacheTtlMin).filter(Boolean)[0]||60} min · same lookup reused across repeated queries in this session
                        </div>
                      </div>
                    )}
                    {applicablePairings.length>0&&(
                      <div style={{padding:'9px 12px',background:L.purBg,borderRadius:6,
                        border:`1px solid ${L.pur}33`,fontSize:11}}>
                        <div style={{fontWeight:700,color:L.purDk,marginBottom:6}}>pairing resolution substitutions</div>
                        {(applicablePairings||[]).map(p=>(
                          <div key={p.cd} style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}>
                            <code style={{fontSize:10,color:L.t2,fontFamily:L.mono}}>{p.dispAttr}</code>
                            <ArrowRight size={10} color={L.pur}/>
                            <code style={{fontSize:10,color:L.purDk,fontFamily:L.mono,fontWeight:700}}>{p.filtAttr}</code>
                            <Chip text={p.strategy} c={L.t3} bg={L.s4} sz={9}/>
                            <span style={{fontSize:10,color:L.grn,fontWeight:700}}>↑{p.perf}%</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* ── Execution trace tab ── */}
                {activeQTab==='trace'&&(
                  <div>
                    {!ran&&(
                      <div style={{padding:'24px',textAlign:'center',color:L.t4,fontSize:12}}>
                        Run the query first to see the execution trace
                      </div>
                    )}
                    {ran&&(
                      <Fragment>
                        <div style={{display:'flex',alignItems:'center',flexWrap:'wrap',gap:5,marginBottom:12}}>
                          {[
                            {label:'Consumer',    color:L.t3},
                            {label:'FastAPI',     color:L.blue},
                            {label:'Pairing lookup',color:L.pur},
                            {label:'pairing resolution',color:L.pur},
                            {label:routingHint.mode,color:routingHint.color},
                            {label:'semantic-service',   color:L.teal},
                            {label:'PostgreSQL', color:L.grn},
                            {label:'Response',   color:L.t3},
                          ].map(({label,color},i,arr)=>(
                            <div key={label} style={{display:'flex',alignItems:'center',gap:5}}>
                              <span style={{padding:'4px 9px',borderRadius:5,background:color+'18',
                                fontSize:11,fontWeight:600,color}}>{label}</span>
                              {i<arr.length-1&&<ArrowRight size={10} color={L.t4}/>}
                            </div>
                          ))}
                        </div>
                        <div style={{display:'flex',flexDirection:'column',gap:6}}>
                          {(applicablePairings||[]).map(p=>(
                            <div key={p.cd} style={{padding:'7px 10px',background:L.purBg,
                              border:`1px solid ${L.pur}33`,borderRadius:5,fontSize:11,color:L.purDk}}>
                              Pairing <strong>{p.cd}</strong>: <code style={{fontSize:10}}>{p.dispAttr}</code>
                              → resolved → <code style={{fontSize:10,fontWeight:700}}>{p.filtAttr}</code>
                              &nbsp;· cache {p.strategy} · est. {p.perf}% faster
                            </div>
                          ))}
                          <div style={{padding:'7px 10px',background:L.tealBg,border:`1px solid ${L.teal}33`,borderRadius:5,fontSize:11,color:L.tealDk}}>
                            {Object.keys(wsTags).length>0&&Object.entries(wsTags).map(([k,lcd])=>(
                              <div key={k} style={{padding:'7px 10px',background:L.tealBg,border:`1px solid ${L.teal}33`,borderRadius:5,fontSize:11,color:L.tealDk}}>
                                Phase 1 — <strong>{lcd}</strong>: {previewLookup(FILTER_LOOKUPS.find(l=>l.cd===lcd))?.count||'?'} values resolved · cache miss (first call) · injected as IN-list into Phase 2
                              </div>
                            ))}
                            semantic-service → PostgreSQL: B-tree index seek · estimated ~18ms · {wsTables.length} table join{wsTables.length>1?'s':''}
                          </div>
                          <div style={{padding:'7px 10px',background:L.grnBg,border:`1px solid ${L.grn}33`,borderRadius:5,fontSize:11,color:L.grn,fontWeight:700}}>
                            ✓ Query completed · {workspace.length} attribute{workspace.length>1?'s':''} returned
                          </div>
                        </div>
                      </Fragment>
                    )}
                  </div>
                )}

                {/* ── Performance tab ── */}
                {activeQTab==='perf'&&(
                  <div>
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:12,marginBottom:16}}>
                      {[
                        {label:'Routing mode',     val:routingHint.mode,                          c:routingHint.color, bg:routingHint.bg},
                        {label:'Pairings active',  val:`${applicablePairings.length} pairing${applicablePairings.length!==1?'s':''}`, c:L.pur, bg:L.purBg},
                        {label:'Tables in join',   val:`${wsTables.length} table${wsTables.length!==1?'s':''}`, c:L.teal, bg:L.tealBg},
                        {label:'Relationship status', val:hasRelWarning?'⚠ Missing':'✓ All registered', c:hasRelWarning?L.amb:L.grn, bg:hasRelWarning?L.ambBg:L.grnBg},
                        {label:'Est. index seeks',  val:wsTables.length>0?`${wsTables.length} B-tree seek${wsTables.length>1?'s':''}`:'—', c:L.blue, bg:L.blueBg},
                        {label:'Pairing speedup',  val:applicablePairings.length>0?`↑${Math.max(...applicablePairings.map(p=>p.perf))}% on best pairing`:'—', c:L.grn, bg:L.grnBg},
                      ].map(({label,val,c,bg})=>(
                        <div key={label} style={{padding:'12px',background:bg,borderRadius:8,border:`1px solid ${c}44`}}>
                          <div style={{fontSize:9,fontWeight:700,color:c,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:4}}>{label}</div>
                          <div style={{fontSize:13,fontWeight:700,color:c}}>{val}</div>
                        </div>
                      ))}
                    </div>

                    {/* Pairing detail */}
                    {applicablePairings.length>0&&(
                      <div style={{marginBottom:12}}>
                        <div style={{fontSize:12,fontWeight:700,color:L.t1,marginBottom:8}}>Applied attribute pairings</div>
                        {(applicablePairings||[]).map(p=>(
                          <div key={p.cd} style={{padding:'10px 14px',marginBottom:6,background:L.s3,borderRadius:8,border:`1px solid ${L.bd}`}}>
                            <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:6,flexWrap:'wrap'}}>
                              <span style={{fontFamily:L.mono,fontSize:11,fontWeight:700,color:L.t1}}>{p.cd}</span>
                              <Chip text={p.strategy} c={L.teal} bg={L.tealBg}/>
                              <Chip text={`↑${p.perf}% faster`} c={L.grn} bg={L.grnBg}/>
                              {p.bidir&&<Chip text="bidirectional" c={L.blue} bg={L.blueBg}/>}
                            </div>
                            <div style={{display:'flex',alignItems:'center',gap:8}}>
                              <div style={{padding:'4px 9px',background:L.s4,borderRadius:4,fontFamily:L.mono,fontSize:10,color:L.t2}}>
                                display: <strong>{p.dispAttr}</strong>
                              </div>
                              <ArrowRight size={12} color={L.pur}/>
                              <div style={{padding:'4px 9px',background:L.purBg,borderRadius:4,fontFamily:L.mono,fontSize:10,color:L.purDk}}>
                                filter: <strong>{p.filtAttr}</strong> [IDX]
                              </div>
                              <span style={{fontSize:10,color:L.t3}}>via {p.strategy}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Relationship map */}
                    {wsTables.length>1&&(
                      <div>
                        <div style={{fontSize:12,fontWeight:700,color:L.t1,marginBottom:8}}>Join relationship map</div>
                        {(relPairs||[]).map(p=>(
                          <div key={`${p.a}${p.b}`} style={{display:'flex',alignItems:'center',gap:10,
                            padding:'8px 12px',marginBottom:4,borderRadius:7,
                            background:p.hasRel?L.tealBg:L.ambBg,border:`1px solid ${p.hasRel?L.teal:L.amb}44`}}>
                            <Chip text={p.a.split('.')[1]} c={L.teal} bg='rgba(29,158,117,0.1)'/>
                            <span style={{color:p.hasRel?L.teal:L.amb,fontWeight:700}}>{p.hasRel?'↔':'⚠'}</span>
                            <Chip text={p.b.split('.')[1]} c={L.blue} bg='rgba(34,101,184,0.1)'/>
                            {p.hasRel
                              ? <span style={{fontSize:11,color:L.teal}}>✓ Relationship registered</span>
                              : <span style={{fontSize:11,color:L.amb}}>No registered relationship — register in Relationship Mgmt first</span>
                            }
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </Fragment>
          )}
        </div>
      </div>
    </div>
  )
}


// ── Semantic Filter Lookups ────────────────────────────────────────────────
const FILTER_LOOKUPS = [
  {
    cd:'OFAC_BLOCKED_COUNTRIES', tenantCd:null,
    constructionType:'SQL_QUERY',
    desc:'Countries on the OFAC Specially Designated Nationals and Blocked Persons list. Used to flag loans, balances, and customer exposure in sanctioned jurisdictions. Updated monthly from OFAC feed.',
    filterObj:'ref.country_master', filterCondition:"sanction_status = 'OFAC_BLOCKED'",
    filterAttr:'country_cd', suggestedTargetAttr:'country_cd',
    maxInputSetSize:10000, maxOutputRows:500000, reviewPeriodDays:30,
    executionStrategy:'IN_LIST', cacheTtlMin:60,
    rulesEligible:true, qsEligible:true, aiEligible:true,
    replicateToCh:true, st:'ACTIVE', createdBy:'system', createdAt:'May 01 2026',
    governance:{lastCertified:'May 01 2026',nextReview:'Jun 01 2026',certifiedBy:'system',changeWorkflow:true},
    health:{staleValues:0, inactiveInSource:0, newSinceLastCert:0, removedSinceLastCert:0, overallStatus:'HEALTHY'},
    stats:{execLast30d:847, avgPhase1Rows:42, avgPhase2Rows:18500, cacheHitRate:94, lastExec:'May 25 2026'},
    usedBy:[{type:'rule',id:'flag_ofac_exposure'},{type:'rule',id:'ofac_client_check'},{type:'query',id:'Q-Studio'}],
  },
  {
    cd:'AAA_RATED_COUNTRIES', tenantCd:null,
    constructionType:'SQL_QUERY',
    desc:'Countries with AAA sovereign credit rating across S&P, Moodys, and Fitch. Used to segment low-risk international exposure and apply preferential capital treatment in credit analysis.',
    filterObj:'ref.country_master', filterCondition:"sp_rating = 'AAA' AND moodys_rating = 'Aaa'",
    filterAttr:'country_cd', suggestedTargetAttr:'country_cd',
    maxInputSetSize:10000, maxOutputRows:200000, reviewPeriodDays:90,
    executionStrategy:'IN_LIST', cacheTtlMin:1440,
    rulesEligible:true, qsEligible:true, aiEligible:true,
    replicateToCh:true, st:'ACTIVE', createdBy:'system', createdAt:'May 05 2026',
    governance:{lastCertified:'Mar 01 2026',nextReview:'Jun 01 2026',certifiedBy:'m.johnson',changeWorkflow:true},
    health:{staleValues:0, inactiveInSource:0, newSinceLastCert:1, removedSinceLastCert:0, overallStatus:'REVIEW_DUE'},
    stats:{execLast30d:312, avgPhase1Rows:18, avgPhase2Rows:42000, cacheHitRate:98, lastExec:'May 25 2026'},
    usedBy:[{type:'rule',id:'preferential_capital_rule'},{type:'query',id:'Variance Analysis'}],
  },
  {
    cd:'ACTIVE_REGULATORY_ENTITIES', tenantCd:null,
    constructionType:'SQL_QUERY',
    desc:'Legal entities currently in regulatory reporting scope. Includes all BHC subsidiaries required to file Y-9C or Y-14Q-H. Excludes dormant, liquidated, or non-regulated shells.',
    filterObj:'ref.organization_hierarchy', filterCondition:"is_regulatory_flg = true AND lifecycle_status_cd = 'ACTIVE'",
    filterAttr:'org_node_cd', suggestedTargetAttr:'legal_entity_cd',
    maxInputSetSize:10000, maxOutputRows:1000000, reviewPeriodDays:30,
    executionStrategy:'IN_LIST', cacheTtlMin:120,
    rulesEligible:true, qsEligible:true, aiEligible:true,
    replicateToCh:true, st:'ACTIVE', createdBy:'system', createdAt:'May 05 2026',
    governance:{lastCertified:'May 10 2026',nextReview:'Jun 10 2026',certifiedBy:'s.patel',changeWorkflow:true},
    health:{staleValues:0, inactiveInSource:0, newSinceLastCert:0, removedSinceLastCert:0, overallStatus:'HEALTHY'},
    stats:{execLast30d:1204, avgPhase1Rows:247, avgPhase2Rows:185000, cacheHitRate:89, lastExec:'May 25 2026'},
    usedBy:[{type:'rule',id:'regulatory_scope_filter'},{type:'query',id:'Y-9C Pipeline'},{type:'query',id:'Q-Studio'},{type:'ai',id:'Lexie Variance'}],
  },
  {
    cd:'OPEN_FISCAL_PERIODS', tenantCd:null,
    constructionType:'SQL_QUERY',
    desc:'Fiscal periods currently open for data submission. Used to restrict variance analysis and GL queries to the active reporting window. Typically 1-2 periods open at any time.',
    filterObj:'ref.fiscal_period', filterCondition:"period_status_cd = 'OPEN'",
    filterAttr:'period_cd', suggestedTargetAttr:'period_cd',
    maxInputSetSize:100, maxOutputRows:100000, reviewPeriodDays:7,
    executionStrategy:'IN_LIST', cacheTtlMin:15,
    rulesEligible:false, qsEligible:true, aiEligible:true,
    replicateToCh:true, st:'ACTIVE', createdBy:'system', createdAt:'May 01 2026',
    governance:{lastCertified:'May 20 2026',nextReview:'May 27 2026',certifiedBy:'system',changeWorkflow:false},
    health:{staleValues:0, inactiveInSource:0, newSinceLastCert:0, removedSinceLastCert:0, overallStatus:'HEALTHY'},
    stats:{execLast30d:3891, avgPhase1Rows:2, avgPhase2Rows:95000, cacheHitRate:99, lastExec:'May 25 2026'},
    usedBy:[{type:'query',id:'Q-Studio'},{type:'query',id:'Variance Analysis'},{type:'ai',id:'Lexie Variance'}],
  },
  {
    cd:'NPL_LOAN_IDS', tenantCd:'BHC_A001',
    constructionType:'SQL_QUERY',
    desc:'Non-performing loan IDs for BHC_A001 — loans past due more than 90 days or in DOUBTFUL/LOSS classification. Updated daily from ClickHouse loan performance snapshot. Used in capital adequacy and stress-test rules.',
    filterObj:'analytics.loan_performance_daily', filterCondition:"past_due_days_nbr > 90 AND snapshot_dt = today()",
    filterAttr:'loan_id', suggestedTargetAttr:'loan_id',
    maxInputSetSize:50000, maxOutputRows:100000, reviewPeriodDays:14,
    executionStrategy:'BLOOM_FILTER', cacheTtlMin:60,
    rulesEligible:true, qsEligible:true, aiEligible:false,
    replicateToCh:false, st:'ACTIVE', createdBy:'j.chen', createdAt:'May 15 2026',
    governance:{lastCertified:'May 15 2026',nextReview:'May 29 2026',certifiedBy:'j.chen',changeWorkflow:true},
    health:{staleValues:0, inactiveInSource:0, newSinceLastCert:847, removedSinceLastCert:112, overallStatus:'HEALTHY'},
    stats:{execLast30d:448, avgPhase1Rows:12400, avgPhase2Rows:12400, cacheHitRate:71, lastExec:'May 25 2026'},
    usedBy:[{type:'rule',id:'npl_capital_charge'},{type:'rule',id:'stress_test_base_case'}],
  },
  {
    // ─── Multi-point failure scenario example ───
    // This is the pattern from the audit finding: a MANUAL_LIST where
    // INACTIVE values were retained after the booking system stopped using them.
    // The reporting system continued including them in scope.
    // Audit: "you didn't know this was happening."
    cd:'EXEMPT_CAPITAL_INSTRUMENTS', tenantCd:null,
    constructionType:'MANUAL_LIST',
    manualSubtype:'ATTRIBUTE_VALIDATED',
    validationSource:{obj:'core.loan_contract', attr:'product_type_cd',
      note:'Values must exist in product_type_cd domain on core.loan_contract. Anticipated values require governance approval before booking system activation.'},
    desc:'Product codes explicitly exempt from certain capital adequacy calculations per internal policy. Maintained manually by the Regulatory Reporting team. Each value must be reviewed quarterly — inactive values not removed caused a multi-point failure in Mar 2025 (booking stopped, reporting continued). Change requires governance workflow approval.',
    filterObj:null, filterCondition:null,
    filterAttr:'product_type_cd', suggestedTargetAttr:'product_type_cd',
    maxInputSetSize:500, maxOutputRows:10000000, reviewPeriodDays:90,
    executionStrategy:'IN_LIST', cacheTtlMin:1440,
    rulesEligible:true, qsEligible:true, aiEligible:true,
    replicateToCh:false, st:'ACTIVE', createdBy:'s.patel', createdAt:'Feb 01 2025',
    governance:{lastCertified:'Feb 20 2026',nextReview:'May 20 2026',certifiedBy:'s.patel',changeWorkflow:true,
      reviewNote:'OVERDUE — Next review was May 20. 2 values show INACTIVE_IN_SOURCE. These must be formally retired or re-certified before next regulatory submission.'},
    health:{staleValues:2, inactiveInSource:2, newSinceLastCert:0, removedSinceLastCert:0, overallStatus:'AT_RISK'},
    stats:{execLast30d:224, avgPhase1Rows:12, avgPhase2Rows:1840000, cacheHitRate:85, lastExec:'May 25 2026'},
    usedBy:[{type:'rule',id:'capital_exemption_rule'},{type:'query',id:'Y-9C Pipeline'},{type:'rule',id:'rwa_calculation'}],
    values:[
      {cd:'DERIV_OTC',     desc:'OTC Derivatives (listed)',      st:'ACTIVE',            addedBy:'s.patel',   addedAt:'Feb 2025', lastSeenInSource:'May 24 2026', reviewDue:'Aug 2026', autoExpireAfterDays:180},
      {cd:'REPO_BILATERAL', desc:'Bilateral Repo Agreements',   st:'ACTIVE',            addedBy:'s.patel',   addedAt:'Feb 2025', lastSeenInSource:'May 25 2026', reviewDue:'Aug 2026', autoExpireAfterDays:180},
      {cd:'SFT_TRIPARTY',   desc:'Triparty Securities Finance', st:'ACTIVE',            addedBy:'m.johnson', addedAt:'Apr 2025', lastSeenInSource:'May 22 2026', reviewDue:'Aug 2026', autoExpireAfterDays:180},
      {cd:'EQ_REPO_INTL',   desc:'International Equity Repo',   st:'ACTIVE',            addedBy:'m.johnson', addedAt:'Jun 2025', lastSeenInSource:'May 18 2026', reviewDue:'Aug 2026', autoExpireAfterDays:180},
      {cd:'BOND_AGENCY_EX',  desc:'Agency Bond (exempt class)',   st:'INACTIVE_IN_SOURCE',validated:true,  addedBy:'s.patel',   addedAt:'Feb 2025', lastSeenInSource:'Nov 14 2025', reviewDue:'OVERDUE',  autoExpireAfterDays:180,
        alert:'Booking system has not used this code since Nov 2025. Reporting continued including it in the exempt set until flagged in the Mar 2025 audit. Requires formal retirement or re-certification.'},
      {cd:'STRUC_NOTE_HY',   desc:'HY Structured Note (legacy)', st:'INACTIVE_IN_SOURCE',validated:true,  addedBy:'s.patel',   addedAt:'Feb 2025', lastSeenInSource:'Oct 28 2025', reviewDue:'OVERDUE',  autoExpireAfterDays:180,
        alert:'Legacy product retired in Oct 2025. Still present in lookup. Not booked since retirement but lookup has not been updated. Creates silent reporting scope error.'},
      {cd:'CLO_TRANCHE_AAA', desc:'CLO Tranche AAA (new Q3 2026)',st:'ANTICIPATED',      validated:false, addedBy:'m.johnson', addedAt:'May 2026', lastSeenInSource:'Not yet in source', reviewDue:'Aug 2026', autoExpireAfterDays:365,
        anticipatedDate:'Sep 01 2026', workflowRef:'WF-2026-0112',
        alert:'Anticipated value — new product code expected from booking system in Q3 2026. Pre-approved via WF-2026-0112 so lookup will cover it immediately on first booking. Requires re-validation if booking system does not activate by Sep 2026.'},
      {cd:'FUND_LOAN_PART',  desc:'Funded Loan Participation',  st:'FUTURE_PENDING',   validated:false, addedBy:'j.chen',    addedAt:'May 26 2026', lastSeenInSource:'Not yet in source', reviewDue:'Pending approval', autoExpireAfterDays:365,
        anticipatedDate:'Aug 01 2026', workflowRef:null,
        alert:'Proposed anticipated value — awaiting governance approval. Cannot be used in lookups until WF task is approved. Submitted by j.chen May 26 2026.'},
    ],
  },
  {
    cd:'HIGH_RISK_GL_ACCOUNTS', tenantCd:null,
    constructionType:'MANUAL_LIST',
    manualSubtype:'HAND_TYPED',
    validationSource:null,
    desc:'Chart of accounts codes classified as high-risk for variance analysis — accounts with high historical volatility or regulatory scrutiny. Curated quarterly by the governance team. Triggers enhanced variance commentary from Lexie AI.',
    filterObj:null, filterCondition:null,
    filterAttr:'account_cd', suggestedTargetAttr:'account_cd',
    maxInputSetSize:10000, maxOutputRows:5000000, reviewPeriodDays:90,
    executionStrategy:'IN_LIST', cacheTtlMin:720,
    rulesEligible:true, qsEligible:true, aiEligible:true,
    replicateToCh:true, st:'DRAFT', createdBy:'m.johnson', createdAt:'May 22 2026',
    governance:{lastCertified:null,nextReview:'Aug 22 2026',certifiedBy:null,changeWorkflow:true,
      reviewNote:'Draft — pending initial governance approval before first use.'},
    health:{staleValues:0, inactiveInSource:0, newSinceLastCert:0, removedSinceLastCert:0, overallStatus:'PENDING'},
    stats:{execLast30d:0, avgPhase1Rows:0, avgPhase2Rows:0, cacheHitRate:0, lastExec:'—'},
    usedBy:[],
    values:[
      {cd:'4100', desc:'Net Interest Income — Wholesale', st:'ACTIVE', validated:false, addedBy:'m.johnson', addedAt:'May 2026', lastSeenInSource:'May 25 2026', reviewDue:'Aug 2026', autoExpireAfterDays:365},
      {cd:'4210', desc:'Non-Interest Income — Trading',  st:'ACTIVE', validated:false, addedBy:'m.johnson', addedAt:'May 2026', lastSeenInSource:'May 25 2026', reviewDue:'Aug 2026', autoExpireAfterDays:365},
      {cd:'4850', desc:'Provision for Credit Losses',    st:'ACTIVE', validated:false, addedBy:'m.johnson', addedAt:'May 2026', lastSeenInSource:'May 25 2026', reviewDue:'Aug 2026', autoExpireAfterDays:365},
    ],
  },
]


// ── Governance Policy Defaults (externalized — sourced from Lextr Governance) ──
// In production these are fetched from governance.policy_preset where
// policy_scope_cd = 'FILTER_LOOKUP'. Shown here as seed constants.
// Business submits policy change requests via Workflow Queue → Governance Approval.
const GOVERNANCE_DEFAULTS = {
  FILTER_LOOKUP: {
    reviewPeriodDays:           90,   // GOV-FL-001: all lookups reviewed every 90 days min
    autoExpireDays:            180,   // GOV-FL-002: inactive values auto-retired after 180 days
    inactiveGracePeriodDays:    14,   // GOV-FL-003: 14-day grace before stale policy blocks
    anticipatedApprovalRequired:true, // GOV-FL-004: anticipated values need workflow approval
    maxManualValues:           500,   // GOV-FL-005: manual lists capped at 500 values
    handTypedRequiresExtraReview:true,// GOV-FL-006: HAND_TYPED lookups have shorter review (50%)
    source: 'GOV_PRESET',
    policyRef: 'Lextr Governance · Filter Lookup Policy v1.0 · Approved May 2026',
  },
}

// Effective review period: min of governance default and lookup override
const effectiveReviewPeriod = (lk) => {
  const govMin = GOVERNANCE_DEFAULTS.FILTER_LOOKUP.reviewPeriodDays
  const lkDays = lk.reviewPeriodDays
  const handTypedFactor = lk.manualSubtype==='HAND_TYPED' ? 0.5 : 1
  const handTypedAdjusted = Math.ceil(govMin * handTypedFactor)
  // Lookup cannot set a period looser than governance floor
  const floor = Math.min(govMin, handTypedAdjusted)  // strictest default
  if (!lkDays) return {days:floor, source:'GOV_DEFAULT'}
  if (lkDays < floor) return {days:lkDays, source:'LOOKUP_OVERRIDE_STRICTER'}
  if (lkDays > govMin) return {days:govMin, source:'GOV_ENFORCED', note:`Lookup requested ${lkDays}d but governance floor is ${govMin}d`}
  return {days:lkDays, source:'LOOKUP_OVERRIDE'}
}


// ══════════════════════════════════════════════════════════════════════
// SCREEN: FILTER LOOKUPS
// ══════════════════════════════════════════════════════════════════════
function RegisterLookupForm({id, onClose, onRegister}) {
  const [lcd,       setLcd]       = useState('')
  const [desc,      setDesc]      = useState('')
  const [tenantCd,  setTenantCd]  = useState('')          // '' = global
  const [fObj,      setFObj]      = useState('')
  const [fCond,     setFCond]     = useState('')
  const [fAttr,     setFAttr]     = useState('')
  const [maxIn,     setMaxIn]     = useState(10000)
  const [maxOut,    setMaxOut]    = useState(100000)
  const [strategy,  setStrategy]  = useState('IN_LIST')
  const [ttl,       setTtl]       = useState(60)
  const [rulesOk,       setRulesOk]       = useState(true)
  const [qsOk,          setQsOk]          = useState(true)
  const [aiOk,          setAiOk]          = useState(true)
  const [repCh,         setRepCh]         = useState(false)
  const [constrType,    setConstrType]     = useState('SQL_QUERY')
  const [reviewDays,    setReviewDays]     = useState(90)
  const [manualValues,  setManualValues]   = useState([])
  const [manualSubtype, setManualSubtype]  = useState('ATTRIBUTE_VALIDATED')
  const [valObj,        setValObj]         = useState('')
  const [valAttr,       setValAttr]        = useState('')
  const [newValCd,      setNewValCd]       = useState('')
  const [newValDesc,    setNewValDesc]     = useState('')
  const [newValStatus,  setNewValStatus]   = useState('ACTIVE')
  const [newValDate,    setNewValDate]     = useState('')
  const [showExcReq,    setShowExcReq]    = useState(false)
  const [excReason,     setExcReason]     = useState('')
  const [excDays,       setExcDays]       = useState('')
  const [excSubmitted,  setExcSubmitted]  = useState(false)

  const fObjAttrs = fObj ? (CATALOG[fObj]?.attrs || []) : []
  const fObjConn  = CATALOG[fObj]?.connectionId || 'lextr-pg'
  const isCrossEng = fObj && fObjConn === 'lextr-ch'
  const canSave   = lcd && fObj && fCond && fAttr

  const strategyHint = maxIn <= 10000 ? 'IN_LIST' : maxIn <= 500000 ? 'BLOOM_FILTER' : 'BRIDGE_TABLE'

  const submit = () => {
    if (!canSave) return
    onRegister({
      cd: lcd.toUpperCase().replace(/\s+/g,'_'),
      desc, tenantCd: tenantCd||null,
      filterObj:fObj, filterCondition:fCond, filterAttr:fAttr,
      maxInputSetSize:maxIn, maxOutputRows:maxOut,
      executionStrategy:strategy, cacheTtlMin:ttl,
      rulesEligible:rulesOk, qsEligible:qsOk, aiEligible:aiOk,
      replicateToCh:repCh, st:'DRAFT',
      createdBy:'current_user', createdAt:'May 26 2026',
      stats:{execLast30d:0,avgPhase1Rows:0,avgPhase2Rows:0,cacheHitRate:0,lastExec:'—'},
      usedBy:[],
    })
    onClose()
  }

  const Row = ({label, children}) => (
    <div style={{marginBottom:14}}>
      <label style={{display:'block',fontSize:11,fontWeight:700,color:L.t2,marginBottom:4}}>{label}</label>
      {children}
    </div>
  )
  const inp = {width:'100%',padding:'7px 10px',borderRadius:6,border:`1px solid ${L.bd}`,
    fontSize:12,color:L.t1,fontFamily:L.font,outline:'none',background:L.s1,boxSizing:'border-box'}

  return (
    <div>
      <DraftActionBar id={id} accentColor={L.teal}
        onDiscard={onClose} onSaveDraft={()=>{}} onSubmit={submit}
        incomplete={!canSave}
        incompleteMsg={!lcd?'Lookup code required':constrType==='SQL_QUERY'&&!fObj?'Filter object required':constrType==='SQL_QUERY'&&!fCond?'Filter condition required':constrType==='SQL_QUERY'&&!fAttr?'Filter attribute required':constrType==='MANUAL_LIST'&&manualValues.length===0?'Add at least one value':'Complete required fields'}/>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16,marginBottom:16}}>
        <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:18}}>
          <div style={{fontSize:12,fontWeight:700,color:L.t1,marginBottom:12}}>Identity</div>
          {/* Construction type toggle */}
          <div style={{marginBottom:14}}>
            <label style={{display:'block',fontSize:11,fontWeight:700,color:L.t2,marginBottom:6}}>Construction type *</label>
            <div style={{display:'flex',gap:0,border:`1px solid ${L.bd}`,borderRadius:7,overflow:'hidden',width:'fit-content'}}>
              {[['SQL_QUERY','SQL Query','Dynamic — evaluated at runtime against filter_object'],
                ['MANUAL_LIST','Manual List','Static — explicitly maintained set of values']].map(([v,label,hint])=>(
                <button key={v} onClick={()=>setConstrType(v)} style={{
                  padding:'7px 16px',border:'none',cursor:'pointer',fontSize:12,fontWeight:600,
                  background:constrType===v?L.teal:L.s3,color:constrType===v?'#fff':L.t3,
                  borderRight:`1px solid ${L.bd}`}}>
                  {label}
                </button>
              ))}
            </div>
            <div style={{fontSize:10,color:L.t4,marginTop:4}}>
              {constrType==='SQL_QUERY'
                ?'SQL query is evaluated against filter_object at runtime. Result set is the IN-list. Changes to the SQL require governance workflow approval.'
                :'Values are maintained manually. Each value has its own lifecycle. Inactive values not retired cause silent reporting scope errors — mitigates the multi-point failure pattern.'}
            </div>
          </div>
          <Row label="Lookup code *  (UPPER_SNAKE_CASE)">
            <input style={inp} value={lcd} onChange={e=>setLcd(e.target.value.toUpperCase())}
              placeholder="e.g. OFAC_BLOCKED_COUNTRIES"/>
          </Row>
          <Row label="Description *">
            <textarea style={{...inp,resize:'vertical'}} rows={3} value={desc}
              onChange={e=>setDesc(e.target.value)}
              placeholder="What does this filter set represent? What business rule does it enforce?"/>
          </Row>
          <Row label="Tenant scope">
            <select style={inp} value={tenantCd} onChange={e=>setTenantCd(e.target.value)}>
              <option value="">Global — all tenants</option>
              <option value="BHC_A001">BHC_A001</option>
              <option value="BHC_B002">BHC_B002</option>
            </select>
            <div style={{fontSize:10,color:L.t4,marginTop:3}}>Global lookups are shared across all tenants. Tenant-scoped lookups are isolated.</div>
          </Row>
        </div>
        <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:18}}>
          <div style={{fontSize:12,fontWeight:700,color:L.t1,marginBottom:12}}>
            {constrType==='SQL_QUERY'?'Filter definition  (Phase 1 — the set-defining query)':'Manual value list  (governed, lifecycle-tracked)'}
          </div>
          {constrType==='SQL_QUERY'&&(
            <div>
              <Row label="Filter object *">
                <select style={inp} value={fObj} onChange={e=>{setFObj(e.target.value);setFAttr('')}}>
                  <option value="">Select registered object…</option>
                  {Object.keys(CATALOG).map(k=>(
                    <option key={k} value={k}>
                      {CATALOG[k]?.logicalShortNm?`${CATALOG[k].logicalShortNm} · `:''}{k}{CATALOG[k]?.connectionId==='lextr-ch'?' [CH]':''}
                    </option>
                  ))}
                </select>
                {fObj&&<div style={{display:'flex',alignItems:'center',gap:6,marginTop:4}}>
                  <EngineBadge connectionId={fObjConn}/>
                  <span style={{fontSize:10,color:L.t4}}>queries this engine in Phase 1</span>
                  {isCrossEng&&<span style={{fontSize:10,color:'#BA7517',fontWeight:700}}>⚡ CH-native lookup</span>}
                </div>}
              </Row>
              <Row label="Filter condition *  (SQL WHERE clause)">
                <input style={{...inp,fontFamily:L.mono,fontSize:11}} value={fCond}
                  onChange={e=>setFCond(e.target.value)}
                  placeholder="e.g. sanction_status = 'OFAC_BLOCKED'"/>
                <div style={{fontSize:10,color:L.t4,marginTop:3}}>Written in the filter object native SQL dialect.</div>
              </Row>
              <Row label="Filter attribute *  (becomes the IN-list)">
                <select style={inp} value={fAttr} onChange={e=>setFAttr(e.target.value)}>
                  <option value="">Select attribute…</option>
                  {fObjAttrs.map(a=><option key={a.cd} value={a.cd}>{a.cd}  ({a.type})</option>)}
                </select>
              </Row>
            </div>
          )}
          {constrType==='MANUAL_LIST'&&(
            <div>
              {/* Manual subtype toggle */}
              <div style={{marginBottom:14}}>
                <label style={{display:'block',fontSize:11,fontWeight:700,color:L.t2,marginBottom:6}}>Validation mode *</label>
                <div style={{display:'flex',gap:0,border:`1px solid ${L.bd}`,borderRadius:7,overflow:'hidden',width:'fit-content',marginBottom:8}}>
                  {[['ATTRIBUTE_VALIDATED','Attribute-validated','Values must exist in a registered attribute domain'],
                    ['HAND_TYPED','Hand-typed (unvalidated)','No validation — higher governance risk']].map(([v,label])=>(
                    <button key={v} onClick={()=>setManualSubtype(v)} style={{
                      padding:'7px 16px',border:'none',cursor:'pointer',fontSize:12,fontWeight:600,
                      background:manualSubtype===v?L.teal:L.s3,color:manualSubtype===v?'#fff':L.t3,
                      borderRight:`1px solid ${L.bd}`}}>
                      {label}
                    </button>
                  ))}
                </div>
                {manualSubtype==='HAND_TYPED'&&(
                  <div style={{padding:'8px 12px',background:'#FAEEDA',border:'1px solid #FAC775',borderRadius:6,fontSize:11,color:'#633806'}}>
                    <strong>Governance note:</strong> Hand-typed values are not validated against any source attribute.
                    Every value must be manually certified at each review cycle. Values that become inactive in the source will not be detected automatically — the reporting team must compare manually.
                  </div>
                )}
              </div>

              {/* ATTRIBUTE_VALIDATED: pick object + attr, select from domain */}
              {manualSubtype==='ATTRIBUTE_VALIDATED'&&(
                <div style={{marginBottom:14}}>
                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:12}}>
                    <div>
                      <label style={{display:'block',fontSize:11,fontWeight:700,color:L.t2,marginBottom:4}}>Validation object</label>
                      <select style={inp} value={valObj} onChange={e=>{setValObj(e.target.value);setValAttr('');setManualValues([])}}>
                        <option value="">Select object…</option>
                        {Object.keys(CATALOG).map(k=><option key={k} value={k}>{CATALOG[k]?.logicalShortNm?`${CATALOG[k].logicalShortNm} · `:''}{k}</option>)}
                      </select>
                    </div>
                    <div>
                      <label style={{display:'block',fontSize:11,fontWeight:700,color:L.t2,marginBottom:4}}>Validation attribute</label>
                      <select style={inp} value={valAttr} onChange={e=>setValAttr(e.target.value)}>
                        <option value="">Select attribute…</option>
                        {(CATALOG[valObj]?.attrs||[]).map(a=><option key={a.cd} value={a.cd}>{a.cd}  ({a.domain||a.type})</option>)}
                      </select>
                    </div>
                  </div>
                  {valObj&&valAttr&&(
                    <div style={{padding:'8px 12px',background:L.tealBg,border:`1px solid ${L.teal}44`,borderRadius:6,fontSize:11,color:L.tealDk,marginBottom:10}}>
                      Values added to this lookup will be validated against the domain of <strong>{valAttr}</strong> on <strong>{valObj}</strong>.
                      Source system activity on this attribute is monitored — inactive codes are flagged automatically.
                    </div>
                  )}
                </div>
              )}

              {/* Value table */}
              <div style={{fontSize:11,fontWeight:700,color:L.t2,marginBottom:6}}>Values
                <span style={{fontWeight:400,color:L.t4,marginLeft:8}}>{manualValues.length} registered</span>
                {manualValues.some(v=>v.st==='FUTURE_PENDING')&&(
                  <span style={{marginLeft:8,fontSize:10,fontWeight:700,color:'#534AB7',background:'#EEEDFE',padding:'1px 6px',borderRadius:3}}>
                    {manualValues.filter(v=>v.st==='FUTURE_PENDING').length} pending approval
                  </span>
                )}
              </div>
              <div style={{border:`1px solid ${L.bd}`,borderRadius:6,overflow:'hidden',marginBottom:10}}>
                {manualValues.length===0&&<div style={{padding:'12px',fontSize:11,color:L.t4,fontStyle:'italic'}}>No values yet. Add below.</div>}
                {manualValues.map((v,i)=>{
                  const stClr = v.st==='ANTICIPATED'?{c:'#185FA5',bg:'#E6F1FB'}:
                                v.st==='FUTURE_PENDING'?{c:'#534AB7',bg:'#EEEDFE'}:
                                {c:L.grn,bg:L.grnBg}
                  return (
                    <div key={v.cd} style={{display:'flex',alignItems:'center',gap:8,padding:'8px 10px',
                      borderBottom:`1px solid ${L.bd2}`,background:i%2?L.s2:L.s1,fontSize:11}}>
                      <span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:L.tealDk,
                        background:L.tealBg,padding:'1px 6px',borderRadius:3,minWidth:90}}>{v.cd}</span>
                      <span style={{color:L.t2,flex:1}}>{v.desc}</span>
                      {v.anticipatedDate&&<span style={{fontSize:9,color:L.t4}}>expected: {v.anticipatedDate}</span>}
                      <span style={{fontSize:9,fontWeight:700,color:stClr.c,background:stClr.bg,
                        padding:'2px 6px',borderRadius:3,whiteSpace:'nowrap'}}>
                        {v.st==='ANTICIPATED'?'ANTICIPATED':v.st==='FUTURE_PENDING'?'PENDING APPROVAL':'ACTIVE'}
                      </span>
                      {manualSubtype==='ATTRIBUTE_VALIDATED'&&(
                        <span style={{fontSize:9,color:v.validated!==false?L.grn:L.t4}}>
                          {v.validated!==false?'✓ validated':'○ unvalidated'}
                        </span>
                      )}
                      <button onClick={()=>setManualValues(p=>p.filter((_,j)=>j!==i))}
                        style={{padding:'2px 7px',borderRadius:4,border:`1px solid ${L.cor}`,background:L.corBg,cursor:'pointer',fontSize:10,color:L.cor}}>✕</button>
                    </div>
                  )
                })}
              </div>

              {/* Add value row */}
              <div style={{display:'flex',gap:8,alignItems:'flex-start',flexWrap:'wrap'}}>
                <input value={newValCd} onChange={e=>setNewValCd(e.target.value.toUpperCase())}
                  placeholder="VALUE_CODE" style={{...inp,width:140,fontFamily:L.mono,fontSize:11}}/>
                <input value={newValDesc} onChange={e=>setNewValDesc(e.target.value)}
                  placeholder="Description" style={{...inp,flex:1,minWidth:160}}/>
                <select value={newValStatus} onChange={e=>setNewValStatus(e.target.value)}
                  style={{...inp,width:170}}>
                  <option value="ACTIVE">Active (in source now)</option>
                  <option value="ANTICIPATED">Anticipated (expected future)</option>
                </select>
                {newValStatus==='ANTICIPATED'&&(
                  <input value={newValDate} onChange={e=>setNewValDate(e.target.value)}
                    placeholder="Expected date e.g. Sep 2026" style={{...inp,width:180}}/>
                )}
                <button onClick={()=>{
                  if(!newValCd) return
                  setManualValues(p=>[...p,{
                    cd:newValCd, desc:newValDesc,
                    st: newValStatus==='ANTICIPATED'?'FUTURE_PENDING':'ACTIVE',
                    validated: manualSubtype==='ATTRIBUTE_VALIDATED'&&!!valAttr,
                    addedBy:'current_user', addedAt:'May 2026',
                    lastSeenInSource: newValStatus==='ANTICIPATED'?'Not yet in source':'—',
                    anticipatedDate: newValStatus==='ANTICIPATED'?newValDate:null,
                    reviewDue:'Per lookup review period', autoExpireAfterDays:180,
                    workflowRef: newValStatus==='ANTICIPATED'?'PENDING':null,
                    alert: newValStatus==='ANTICIPATED'
                      ?'Proposed anticipated value — requires governance approval before use in lookup execution.'
                      :null,
                  }])
                  setNewValCd('');setNewValDesc('');setNewValStatus('ACTIVE');setNewValDate('')
                }} style={{padding:'7px 14px',borderRadius:6,border:'none',background:L.teal,color:'#fff',cursor:'pointer',fontSize:12,fontWeight:700,whiteSpace:'nowrap'}}>
                  {newValStatus==='ANTICIPATED'?'+ Add (pending approval)':'+ Add'}
                </button>
              </div>
              <div style={{fontSize:10,color:L.t4,marginTop:6,lineHeight:1.5}}>
                {manualSubtype==='ATTRIBUTE_VALIDATED'
                  ?'Validated values are matched against the attribute domain. Anticipated values require governance workflow approval before activation. Inactive-in-source detection is automatic.'
                  :'Unvalidated values carry higher governance risk. Manual comparison against source required at each review cycle. Consider switching to Attribute-validated if a domain attribute exists.'}
              </div>
            </div>
          )}
        </div>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16,marginBottom:16}}>
        <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:18}}>
          <div style={{fontSize:12,fontWeight:700,color:L.t1,marginBottom:12}}>Execution policy</div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:12}}>
            <Row label={`max_input_set_size  (IN-list cap)`}>
              <input style={{...inp,fontFamily:L.mono}} type="number" value={maxIn} onChange={e=>setMaxIn(+e.target.value)}/>
              <div style={{fontSize:10,color:L.t4,marginTop:2}}>Suggested strategy: <strong>{strategyHint}</strong></div>
            </Row>
            <Row label="max_output_rows  (result cap)">
              <input style={{...inp,fontFamily:L.mono}} type="number" value={maxOut} onChange={e=>setMaxOut(+e.target.value)}/>
              <div style={{fontSize:10,color:L.t4,marginTop:2}}>AI context + rule engine safety limit.</div>
            </Row>
          </div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
            <Row label="Execution strategy">
              <select style={inp} value={strategy} onChange={e=>setStrategy(e.target.value)}>
                {['IN_LIST','BLOOM_FILTER','BRIDGE_TABLE','REJECT'].map(s=><option key={s}>{s}</option>)}
              </select>
            </Row>
            <Row label="Cache TTL (minutes)">
              <input style={{...inp,fontFamily:L.mono}} type="number" value={ttl} onChange={e=>setTtl(+e.target.value)}/>
            </Row>
            <Row label="Review period (days)">
              {/* READ-ONLY — governed by GOV-FL-001. Override requires exception approval. */}
              <div style={{display:'flex',alignItems:'center',gap:8,padding:'8px 10px',
                background:L.s3,borderRadius:6,border:`1px solid ${L.bd}`}}>
                <span style={{fontFamily:L.mono,fontSize:14,fontWeight:700,color:L.t1}}>
                  {constrType==='MANUAL_LIST'&&manualSubtype==='HAND_TYPED'
                    ? Math.ceil(GOVERNANCE_DEFAULTS.FILTER_LOOKUP.reviewPeriodDays * 0.5)
                    : GOVERNANCE_DEFAULTS.FILTER_LOOKUP.reviewPeriodDays}
                </span>
                <span style={{fontSize:11,color:L.t3}}>days</span>
                <span style={{fontSize:9,fontWeight:700,color:'#534AB7',background:'#EEEDFE',
                  padding:'2px 7px',borderRadius:4,border:'1px solid #AFA9EC'}}>
                  GOV-FL-001{constrType==='MANUAL_LIST'&&manualSubtype==='HAND_TYPED'?' · GOV-FL-006 (0.5×)':''}
                </span>
                <span style={{flex:1}}/>
                <span style={{fontSize:10,color:L.t4}}>Policy-resolved · read-only</span>
                {!excSubmitted&&(
                  <button onClick={()=>setShowExcReq(p=>!p)} style={{padding:'3px 10px',borderRadius:5,
                    border:`1px solid ${L.pur}`,background:'#EEEDFE',cursor:'pointer',
                    fontSize:10,fontWeight:700,color:'#534AB7'}}>
                    {showExcReq?'Cancel':'Request override'}
                  </button>
                )}
                {excSubmitted&&(
                  <span style={{fontSize:10,fontWeight:700,color:L.grn}}>✓ Override request submitted</span>
                )}
              </div>
              {showExcReq&&!excSubmitted&&(
                <div style={{marginTop:8,padding:'12px 14px',background:'#EEEDFE',
                  border:'1px solid #AFA9EC',borderRadius:7}}>
                  <div style={{fontSize:11,fontWeight:700,color:'#3C3489',marginBottom:8}}>
                    Exception request — GOV-FL-001 override
                  </div>
                  <div style={{display:'flex',gap:8,alignItems:'flex-start',marginBottom:8}}>
                    <div style={{flex:1}}>
                      <label style={{fontSize:10,fontWeight:700,color:'#534AB7',display:'block',marginBottom:3}}>Requested period (days)</label>
                      <input value={excDays} onChange={e=>setExcDays(e.target.value)}
                        placeholder={`e.g. ${GOVERNANCE_DEFAULTS.FILTER_LOOKUP.reviewPeriodDays * 2}`}
                        style={{...inp,fontFamily:L.mono,width:'100%'}} type="number"/>
                    </div>
                    <div style={{flex:3}}>
                      <label style={{fontSize:10,fontWeight:700,color:'#534AB7',display:'block',marginBottom:3}}>Business justification *</label>
                      <textarea value={excReason} onChange={e=>setExcReason(e.target.value)}
                        placeholder="Explain why the governance default is not appropriate for this lookup. Governance team will review."
                        style={{...inp,resize:'vertical',width:'100%'}} rows={2}/>
                    </div>
                  </div>
                  <div style={{display:'flex',justifyContent:'flex-end',gap:8}}>
                    <button onClick={()=>setShowExcReq(false)}
                      style={{padding:'5px 12px',borderRadius:5,border:`1px solid ${L.bd}`,background:L.s1,cursor:'pointer',fontSize:11,color:L.t3}}>Cancel</button>
                    <button onClick={()=>{if(excReason&&excDays){setExcSubmitted(true);setShowExcReq(false)}}}
                      style={{padding:'5px 14px',borderRadius:5,border:'none',background:'#534AB7',cursor:'pointer',fontSize:11,fontWeight:700,color:'#fff'}}>
                      Submit exception request →
                    </button>
                  </div>
                  <div style={{fontSize:10,color:'#534AB7',marginTop:6}}>
                    Approved exceptions generate a workflow task and update the lookup after governance sign-off. The governance floor remains in effect until approval.
                  </div>
                </div>
              )}
              <div style={{fontSize:10,color:L.t4,marginTop:4}}>
                Set by governance policy GOV-FL-001 · {GOVERNANCE_DEFAULTS.FILTER_LOOKUP.policyRef}
              </div>
            </Row>
          </div>
        </div>
        <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,padding:18}}>
          <div style={{fontSize:12,fontWeight:700,color:L.t1,marginBottom:12}}>Eligibility  (who can reference this lookup)</div>
          {[
            ['rules_eligible_flg',    rulesOk, setRulesOk,  'Rule catalog — rule authors can use this as a filter primitive'],
            ['query_studio_eligible',  qsOk,    setQsOk,     'Query Studio — analysts can apply this as a filter in ad-hoc queries'],
            ['ai_eligible_flg',        aiOk,    setAiOk,     'Lexie AI — AI narrative generation can reference this filter'],
            ['replicate_to_ch_flg',    repCh,   setRepCh,    'Replicate filter_object to ClickHouse — eliminates Phase 1 cross-engine round-trip'],
          ].map(([field,val,setter,hint])=>(
            <label key={field} style={{display:'flex',alignItems:'flex-start',gap:10,marginBottom:10,cursor:'pointer'}}>
              <input type="checkbox" checked={val} onChange={e=>setter(e.target.checked)} style={{marginTop:2,accentColor:L.teal}}/>
              <div>
                <div style={{fontSize:11,fontWeight:700,color:L.t1,fontFamily:L.mono}}>{field}</div>
                <div style={{fontSize:11,color:L.t3,lineHeight:1.4}}>{hint}</div>
              </div>
            </label>
          ))}
        </div>
      </div>
    </div>
  )
}

function FilterLookupScreen() {
  const [drafts,    setDrafts]    = useState([])
  const [activeId,  setActiveId]  = useState(null)
  const [tab,       setTab]       = useState('registry')  // registry | usage
  const [lookups,   setLookups]   = useState(FILTER_LOOKUPS)
  const [selLookup, setSelLookup] = useState(null)
  const [filterTen, setFilterTen] = useState('ALL')
  const [filterSt,  setFilterSt]  = useState('ALL')
  const [histLk,    setHistLk]    = useState(null)

  const addDraft = () => {
    const id = 'LOOK-'+Math.random().toString(36).slice(2,8).toUpperCase()
    setDrafts(p=>[...p,{id,initData:{}}])
    setActiveId(id)
  }
  const closeDraft = (id) => { setDrafts(p=>p.filter(d=>d.id!==id)); if(activeId===id)setActiveId(null) }
  const registerLookup = (data) => { setLookups(p=>[...p,data]) }

  const visible = lookups.filter(l=>
    (filterTen==='ALL'||l.tenantCd===filterTen||(filterTen==='GLOBAL'&&!l.tenantCd)) &&
    (filterSt==='ALL'||l.st===filterSt)
  )

  const stClr = s => s==='ACTIVE'?{c:L.grn,bg:L.grnBg}:s==='DRAFT'?{c:L.amb,bg:L.ambBg}:{c:L.cor,bg:L.corBg}
  const stratClr = s =>
    s==='IN_LIST'?{c:L.teal,bg:L.tealBg}:
    s==='BLOOM_FILTER'?{c:L.blue,bg:L.blueBg}:
    s==='BRIDGE_TABLE'?{c:'#534AB7',bg:'#EEEDFE'}:
    {c:L.cor,bg:L.corBg}

  return (
    <div>
      <PageHdr title="Semantic Filter Lookups" icon={Filter}
        sub="Registered filter sets used by Query Studio, Lexie AI, and the Rule catalog. Each lookup resolves a filter condition on one engine and injects the result into queries on another."
        action={<div style={{display:'flex',gap:8,alignItems:'center'}}>
          <span style={{fontSize:12,color:L.t3}}>{lookups.filter(l=>l.st==='ACTIVE').length} active</span>
          <Btn label="Export registry" icon={Download}/>
        </div>}/>

      {/* GovTabStrip */}
      <GovTabStrip
        base={[{id:'registry',label:'Lookup Registry'},{id:'usage',label:'Usage & Stats'}]}
        drafts={drafts.map(d=>({id:d.id,label:`LOOK-${d.id.split('-')[1]}`}))}
        activeId={activeId||tab}
        onSelect={id=>{if(drafts.find(d=>d.id===id))setActiveId(id);else{setTab(id);setActiveId(null)}}}
        onClose={closeDraft}
        addLabel="Register Lookup"
        onAdd={addDraft}/>

      {/* Draft panels */}
      {drafts.map(d=>(
        <div key={d.id} style={{display:activeId===d.id?'block':'none'}}>
          <RegisterLookupForm id={d.id} onClose={()=>closeDraft(d.id)} onRegister={registerLookup}/>
        </div>
      ))}

      {/* ── Registry tab ── */}
      {activeId===null&&tab==='registry'&&(
        <div>
          {/* Filters */}
          <div style={{display:'flex',gap:10,marginBottom:14,alignItems:'center',flexWrap:'wrap'}}>
            <div style={{display:'flex',gap:4,background:L.s3,padding:3,borderRadius:7,border:`1px solid ${L.bd}`}}>
              {['ALL','GLOBAL','BHC_A001','BHC_B002'].map(t=>(
                <button key={t} onClick={()=>setFilterTen(t)}
                  style={{padding:'4px 12px',borderRadius:5,border:'none',cursor:'pointer',fontSize:11,fontWeight:600,
                    background:filterTen===t?L.s1:L.s3,color:filterTen===t?L.t1:L.t3,
                    boxShadow:filterTen===t?`0 1px 3px ${L.bd}`:'none'}}>
                  {t}
                </button>
              ))}
            </div>
            {['ALL','ACTIVE','DRAFT'].map(s=>(
              <button key={s} onClick={()=>setFilterSt(s)}
                style={{padding:'4px 12px',borderRadius:5,border:`1px solid ${filterSt===s?L.teal:L.bd}`,
                  cursor:'pointer',fontSize:11,fontWeight:600,background:filterSt===s?L.tealBg:L.s1,
                  color:filterSt===s?L.tealDk:L.t3}}>
                {s}
              </button>
            ))}
            <div style={{flex:1}}/>
            <span style={{fontSize:12,color:L.t3}}>{visible.length} lookup{visible.length!==1?'s':''}</span>
          </div>
          {/* Table */}
          <div style={{border:`1px solid ${L.bd}`,borderRadius:10,overflow:'hidden'}}>
            <div style={{display:'grid',
              gridTemplateColumns:'1.6fr 90px 1.4fr 1fr 80px 80px 80px 80px 80px 44px',
              padding:'8px 14px',background:L.s3,borderBottom:`1px solid ${L.bd}`,
              fontSize:9,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.06em',gap:8}}>
              {['Lookup code','Tenant','Filter object · condition','Filter attr','Max input','Max output','Strategy','Status','Last exec'].map(h=><span key={h}>{h}</span>)}<span/>
            </div>
            {visible.map((lk,i)=>{
              const isSel = selLookup?.cd===lk.cd
              const sc = stClr(lk.st), stc = stratClr(lk.executionStrategy)
              return (
                <div key={lk.cd} style={{borderBottom:`1px solid ${L.bd2}`}}>
                  <div onClick={()=>setSelLookup(isSel?null:lk)}
                    style={{display:'grid',
                      gridTemplateColumns:'1.6fr 90px 1.4fr 1fr 80px 80px 80px 80px 80px 44px',
                      padding:'10px 14px',gap:8,fontSize:12,alignItems:'center',
                      cursor:'pointer',background:isSel?L.s3:i%2?L.s2:L.s1}}>
                    <div>
                      <div style={{display:'flex',alignItems:'center',gap:6}}>
                        <span style={{fontFamily:L.mono,fontSize:11,fontWeight:700,color:L.tealDk}}>{lk.cd}</span>
                        <span style={{fontSize:8,fontWeight:700,padding:'1px 5px',borderRadius:3,
                          color: lk.health?.overallStatus==='AT_RISK'?'#791F1F':
                                 lk.health?.overallStatus==='REVIEW_DUE'?'#633806':
                                 lk.health?.overallStatus==='PENDING'?'#444441':L.grn,
                          background: lk.health?.overallStatus==='AT_RISK'?'#F7C1C1':
                                      lk.health?.overallStatus==='REVIEW_DUE'?'#FAC775':
                                      lk.health?.overallStatus==='PENDING'?'#D3D1C7':'#C0DD97',
                        }}>
                          {lk.health?.overallStatus==='AT_RISK'?'⚠ AT RISK':
                           lk.health?.overallStatus==='REVIEW_DUE'?'↻ REVIEW DUE':
                           lk.health?.overallStatus==='PENDING'?'◌ PENDING':'✓ HEALTHY'}
                        </span>
                        <span style={{fontSize:8,fontWeight:700,color:lk.constructionType==='MANUAL_LIST'?'#854F0B':'#0F6E56',
                          background:lk.constructionType==='MANUAL_LIST'?'#FAEEDA':'#E1F5EE',
                          padding:'1px 5px',borderRadius:3}}>
                          {lk.constructionType==='MANUAL_LIST'?'MANUAL':'SQL'}
                        </span>
                      </div>
                      <div style={{fontSize:10,color:L.t4,marginTop:2,lineHeight:1.3}}>{lk.desc.slice(0,65)}…</div>
                    </div>
                    <span style={{fontSize:10,fontWeight:700,
                      color:lk.tenantCd?'#534AB7':'#0F6E56',
                      background:lk.tenantCd?'#EEEDFE':L.tealBg,
                      padding:'2px 6px',borderRadius:4,textAlign:'center'}}>
                      {lk.tenantCd||'GLOBAL'}
                    </span>
                    <div>
                      <div style={{display:'flex',alignItems:'center',gap:5}}>
                        <span style={{fontFamily:L.mono,fontSize:10,color:L.t2}}>{lk.filterObj||'manual list'}</span>
                        {lk.filterObj&&<EngineBadge connectionId={CATALOG[lk.filterObj]?.connectionId||'lextr-pg'} tiny/>}
                      </div>
                      <div style={{fontFamily:L.mono,fontSize:10,color:L.t4,marginTop:1}}>{(lk.filterCondition||'manual list').slice(0,40)}{(lk.filterCondition||'').length>40?'…':''}</div>
                    </div>
                    <span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:L.teal}}>{lk.filterAttr}</span>
                    <span style={{fontFamily:L.mono,fontSize:10,color:L.t2}}>{(lk.maxInputSetSize/1000).toFixed(0)}k</span>
                    <span style={{fontFamily:L.mono,fontSize:10,color:L.t2}}>{(lk.maxOutputRows/1000).toFixed(0)}k</span>
                    <span style={{fontSize:9,fontWeight:700,color:stc.c,background:stc.bg,
                      padding:'2px 5px',borderRadius:3,textAlign:'center'}}>{lk.executionStrategy.replace('_',' ')}</span>
                    <span style={{fontSize:10,fontWeight:700,color:sc.c,background:sc.bg,
                      padding:'2px 6px',borderRadius:4,textAlign:'center'}}>{lk.st}</span>
                    <span style={{fontSize:10,color:L.t4}}>{lk.stats.lastExec}</span>
                    <div style={{display:'flex',justifyContent:'center'}}><HistBtn onClick={()=>setHistLk(lk)}/></div>
                  </div>

                  {/* Expanded detail */}
                  {isSel&&(
                    <div style={{padding:'16px 18px',background:L.s3,borderTop:`1px solid ${L.bd2}`}}>
                      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:12,marginBottom:14}}>
                        {/* Stats */}
                        {[
                          ['Executions (30d)',  lk.stats.execLast30d.toLocaleString(), L.teal],
                          ['Avg Phase 1 rows',  lk.stats.avgPhase1Rows.toLocaleString(), L.blue],
                          ['Avg Phase 2 rows',  lk.stats.avgPhase2Rows.toLocaleString(), L.pur],
                          ['Cache hit rate',    lk.stats.cacheHitRate+'%', lk.stats.cacheHitRate>90?L.grn:L.amb],
                          ['max_input_set_size',lk.maxInputSetSize.toLocaleString(), L.t2],
                          ['max_output_rows',   lk.maxOutputRows.toLocaleString(), L.t2],
                        ].map(([k,v,col])=>(
                          <div key={k} style={{padding:'9px 12px',background:L.s1,borderRadius:7,border:`1px solid ${L.bd}`}}>
                            <div style={{fontSize:9,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.06em',marginBottom:3}}>{k}</div>
                            <div style={{fontSize:14,fontWeight:700,color:col,fontFamily:L.mono}}>{v}</div>
                          </div>
                        ))}
                      </div>
                      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12,marginBottom:12}}>
                        <div>
                          <div style={{fontSize:10,fontWeight:700,color:L.t2,marginBottom:5}}>Eligibility flags</div>
                          <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                            {[['Rules',lk.rulesEligible],['Query Studio',lk.qsEligible],['Lexie AI',lk.aiEligible],['CH replica',lk.replicateToCh]].map(([l,v])=>(
                              <span key={l} style={{fontSize:10,fontWeight:700,
                                color:v?L.grn:L.t4,background:v?L.grnBg:L.s4,
                                padding:'2px 8px',borderRadius:4,border:`1px solid ${v?L.grn+'44':L.bd}`}}>
                                {v?'✓':'✗'} {l}
                              </span>
                            ))}
                          </div>
                        </div>
                        <div>
                          <div style={{fontSize:10,fontWeight:700,color:L.t2,marginBottom:5}}>Used by</div>
                          <div style={{display:'flex',gap:5,flexWrap:'wrap'}}>
                            {lk.usedBy.length===0&&<span style={{fontSize:11,color:L.t4,fontStyle:'italic'}}>No consumers registered yet</span>}
                            {lk.usedBy.map(u=>(
                              <span key={u.id} style={{fontSize:10,fontWeight:700,
                                color:u.type==='rule'?L.pur:u.type==='ai'?L.blue:L.teal,
                                background:u.type==='rule'?'#EEEDFE':u.type==='ai'?L.blueBg:L.tealBg,
                                padding:'2px 8px',borderRadius:4}}>
                                [{u.type}] {u.id}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div style={{padding:'10px 12px',background:'#fffbf0',border:`1px solid ${L.amb}33`,borderRadius:7,marginBottom:12}}>
                        <div style={{fontSize:11,color:L.t1,lineHeight:1.6}}>{lk.desc}</div>
                        <div style={{marginTop:6,fontFamily:L.mono,fontSize:10,color:L.t3}}>
                          Type: {lk.constructionType}{lk.manualSubtype?` (${lk.manualSubtype})`:''} · Registered: {lk.createdAt} · {lk.createdBy} · Cache TTL: {lk.cacheTtlMin} min · Strategy: {lk.executionStrategy}
                        </div>
                        <div style={{marginTop:4,display:'flex',gap:6,flexWrap:'wrap',alignItems:'center'}}>
                          {(()=>{
                            const eff = effectiveReviewPeriod(lk)
                            return (
                              <span style={{fontSize:10,fontWeight:700,
                                color:eff.source==='GOV_ENFORCED'?'#A32D2D':eff.source==='LOOKUP_OVERRIDE_STRICTER'?'#0F6E56':'#534AB7',
                                background:eff.source==='GOV_ENFORCED'?'#FCEBEB':eff.source==='LOOKUP_OVERRIDE_STRICTER'?'#E1F5EE':'#EEEDFE',
                                padding:'2px 7px',borderRadius:4,border:'1px solid rgba(0,0,0,0.06)'}}>
                                Review every {eff.days}d
                                {eff.source==='GOV_DEFAULT'?' · from governance (GOV-FL-001)':eff.source==='GOV_ENFORCED'?` · capped by governance (GOV-FL-001)`:eff.source==='LOOKUP_OVERRIDE_STRICTER'?' · stricter than governance default':' · lookup override'}
                              </span>
                            )
                          })()}
                          <span style={{fontSize:10,color:'#534AB7',background:'#EEEDFE',padding:'2px 7px',borderRadius:4}}>
                            Auto-expire inactive: {GOVERNANCE_DEFAULTS.FILTER_LOOKUP.autoExpireDays}d (GOV-FL-002)
                          </span>
                          {lk.manualSubtype==='HAND_TYPED'&&(
                            <span style={{fontSize:10,color:'#633806',background:'#FAEEDA',padding:'2px 7px',borderRadius:4}}>
                              HAND_TYPED 0.5× review (GOV-FL-006)
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Governance review panel */}
                      <div style={{border:`1px solid ${
                        lk.governance?.overallStatus==='AT_RISK'?'#F09595':
                        lk.health?.overallStatus==='REVIEW_DUE'?'#FAC775':L.bd}`,
                        borderRadius:9,overflow:'hidden',marginBottom:12}}>
                        <div style={{padding:'10px 14px',background:
                          lk.health?.overallStatus==='AT_RISK'?'#FCEBEB':
                          lk.health?.overallStatus==='REVIEW_DUE'?'#FAEEDA':L.s3,
                          display:'flex',alignItems:'center',gap:10,flexWrap:'wrap'}}>
                          <span style={{fontSize:12,fontWeight:700,color:L.t1}}>Governance review</span>
                          <span style={{fontSize:11,color:L.t3}}>Last certified: <strong style={{color:L.t1}}>{lk.governance?.lastCertified||'—'}</strong> by {lk.governance?.certifiedBy||'—'}</span>
                          <span style={{fontSize:11,color:L.t3}}>Next review: <strong style={{color:
                            lk.governance?.nextReview==='OVERDUE'?'#A32D2D':
                            lk.health?.overallStatus==='REVIEW_DUE'?'#633806':L.t1}}>{lk.governance?.nextReview||'—'}</strong></span>
                          {lk.governance?.changeWorkflow&&<span style={{fontSize:10,fontWeight:700,color:L.pur,background:'#EEEDFE',padding:'2px 7px',borderRadius:4}}>Change requires workflow</span>}
                          <div style={{marginLeft:'auto',display:'flex',gap:8,alignItems:'center'}}>
                            {lk.health?.inactiveInSource>0&&(
                              <span style={{fontSize:10,fontWeight:700,color:'#A32D2D',background:'#F7C1C1',padding:'3px 8px',borderRadius:4,border:'1px solid #F09595'}}>
                                POL-SV-001 · {lk.health.inactiveInSource} inactive value{lk.health.inactiveInSource>1?'s':''} blocking new bindings
                              </span>
                            )}
                            {lk.health?.overallStatus==='REVIEW_DUE'&&(
                              <span style={{fontSize:10,fontWeight:700,color:'#633806',background:'#FAC775',padding:'3px 8px',borderRadius:4,border:'1px solid #EF9F27'}}>
                                POL-SV-002 · Review overdue — new pipeline bindings blocked
                              </span>
                            )}
                            <button style={{padding:'5px 14px',borderRadius:6,border:`1px solid ${L.teal}`,background:L.tealBg,cursor:'pointer',fontSize:11,fontWeight:700,color:L.tealDk}}>
                              Certify values ✓
                            </button>
                          </div>
                        </div>
                        {lk.governance?.reviewNote&&(
                          <div style={{padding:'10px 14px',background:
                            lk.health?.overallStatus==='AT_RISK'?'#FCEBEB':
                            lk.health?.overallStatus==='REVIEW_DUE'?'#FAEEDA40':L.s1,
                            fontSize:11,color:lk.health?.overallStatus==='AT_RISK'?'#791F1F':L.t2,lineHeight:1.6,
                            borderTop:`1px solid ${lk.health?.overallStatus==='AT_RISK'?'#F09595':L.bd2}`}}>
                            {lk.governance.reviewNote}
                          </div>
                        )}
                        {/* Health summary chips */}
                        <div style={{padding:'8px 14px',background:L.s1,display:'flex',gap:8,flexWrap:'wrap',
                          borderTop:`1px solid ${L.bd2}`}}>
                          {[
                            ['Stale values',       lk.health?.staleValues,         'coral'],
                            ['Inactive in source', lk.health?.inactiveInSource,    'red'],
                            ['Anticipated',        lk.values?.filter(v=>v.st==='ANTICIPATED').length||0, 'blue'],
                            ['Pending approval',   lk.values?.filter(v=>v.st==='FUTURE_PENDING').length||0, 'purple'],
                            ['New since cert',     lk.health?.newSinceLastCert,    'gray'],
                          ].map(([label,val,color])=>{
                            if(color==='purple'){const {c:fc,bg}={c:'#534AB7',bg:'#EEEDFE'};const highlight=val>0;return(<div key={label} style={{padding:'5px 10px',borderRadius:6,background:highlight?bg:L.s3,border:`1px solid ${highlight?fc+'44':L.bd}`}}><div style={{fontSize:9,fontWeight:700,color:highlight?fc:L.t4,textTransform:'uppercase',letterSpacing:'.05em'}}>{label}</div><div style={{fontSize:16,fontWeight:700,color:highlight?fc:L.t2,fontFamily:L.mono}}>{val}</div></div>)}
                            const cfg={coral:{c:'#993C1D',bg:'#FAECE7'},red:{c:'#A32D2D',bg:'#FCEBEB'},blue:{c:'#185FA5',bg:'#E6F1FB'},gray:{c:'#444441',bg:'#F1EFE8'}}
                            const {c:fc,bg}=cfg[color]
                            const highlight = (color==='coral'||color==='red')&&val>0
                            return (
                              <div key={label} style={{padding:'5px 10px',borderRadius:6,
                                background:highlight?bg:L.s3,border:`1px solid ${highlight?fc+'44':L.bd}`}}>
                                <div style={{fontSize:9,fontWeight:700,color:highlight?fc:L.t4,textTransform:'uppercase',letterSpacing:'.05em'}}>{label}</div>
                                <div style={{fontSize:16,fontWeight:700,color:highlight?fc:L.t2,fontFamily:L.mono}}>{val}</div>
                              </div>
                            )
                          })}
                        </div>
                      </div>

                      {/* MANUAL_LIST value table */}
                      {lk.constructionType==='MANUAL_LIST'&&lk.values&&lk.values.length>0&&(
                        <div style={{border:`1px solid ${L.bd}`,borderRadius:9,overflow:'hidden'}}>
                          <div style={{padding:'8px 14px',background:L.s3,display:'flex',alignItems:'center',gap:8,
                            borderBottom:`1px solid ${L.bd}`}}>
                            <span style={{fontSize:12,fontWeight:700,color:L.t1}}>Manual values</span>
                            <span style={{fontSize:11,color:L.t3}}>{lk.values.length} registered · {lk.values.filter(v=>v.st==='INACTIVE_IN_SOURCE').length} inactive in source</span>
                            <button style={{marginLeft:'auto',padding:'4px 10px',borderRadius:5,border:`1px solid ${L.bd}`,background:L.s1,cursor:'pointer',fontSize:10,fontWeight:600,color:L.t2}}>+ Add value</button>
                          </div>
                          <div style={{display:'grid',gridTemplateColumns:'110px 1.4fr 110px 110px 1fr 80px',
                            padding:'6px 14px',background:L.s3,borderBottom:`1px solid ${L.bd}`,
                            fontSize:9,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.06em',gap:8}}>
                            {['Code','Description','Status','Last seen in source','Alert','Action'].map(h=><span key={h}>{h}</span>)}
                          </div>
                          {lk.values.map(v=>{
                            const isInactive   = v.st==='INACTIVE_IN_SOURCE'
                            const isAnticipated= v.st==='ANTICIPATED'
                            const isPending    = v.st==='FUTURE_PENDING'
                            const rowBg = isInactive?'#FFF5F5':isPending?'#EEEDFE20':L.s1
                            const codeCl= isInactive?{c:'#A32D2D',bg:'#F7C1C1'}:
                                          isAnticipated?{c:'#185FA5',bg:'#E6F1FB'}:
                                          isPending?{c:'#534AB7',bg:'#EEEDFE'}:
                                          {c:L.tealDk,bg:L.tealBg}
                            const stLabel= isInactive?'INACTIVE IN SOURCE':
                                           isAnticipated?'ANTICIPATED':
                                           isPending?'PENDING APPROVAL':'ACTIVE'
                            const stCl = isInactive?{c:'#A32D2D',bg:'#F7C1C1'}:
                                         isAnticipated?{c:'#185FA5',bg:'#E6F1FB'}:
                                         isPending?{c:'#534AB7',bg:'#EEEDFE'}:
                                         {c:L.grn,bg:L.grnBg}
                            return (
                              <div key={v.cd} style={{display:'grid',gridTemplateColumns:'110px 1.4fr 110px 110px 1fr 80px',
                                padding:'9px 14px',borderBottom:`1px solid ${L.bd2}`,gap:8,
                                background:rowBg,alignItems:'flex-start',fontSize:12}}>
                                <div>
                                  <span style={{fontFamily:L.mono,fontSize:11,fontWeight:700,
                                    color:codeCl.c,background:codeCl.bg,
                                    padding:'2px 6px',borderRadius:4,display:'inline-block'}}>{v.cd}</span>
                                  {v.validated!==undefined&&(
                                    <div style={{fontSize:8,color:v.validated?L.grn:L.t4,marginTop:2}}>
                                      {v.validated?'✓ attr-validated':'○ unvalidated'}
                                    </div>
                                  )}
                                </div>
                                <div>
                                  <span style={{fontSize:11,color:L.t2}}>{v.desc}</span>
                                  {v.anticipatedDate&&<div style={{fontSize:9,color:'#185FA5',marginTop:2}}>Expected: {v.anticipatedDate}</div>}
                                  {v.workflowRef&&<div style={{fontSize:9,color:'#534AB7',marginTop:1}}>WF: {v.workflowRef}</div>}
                                </div>
                                <span style={{fontSize:10,fontWeight:700,
                                  color:stCl.c,background:stCl.bg,
                                  padding:'2px 6px',borderRadius:4,textAlign:'center'}}>{stLabel}</span>
                                <div>
                                  <div style={{fontSize:11,color:isInactive?'#A32D2D':L.t2,fontWeight:isInactive?700:400}}>{v.lastSeenInSource}</div>
                                  <div style={{fontSize:9,color:L.t4,marginTop:1}}>Review: <span style={{color:v.reviewDue==='OVERDUE'?'#A32D2D':L.t4,fontWeight:v.reviewDue==='OVERDUE'?700:400}}>{v.reviewDue}</span></div>
                                </div>
                                <div style={{fontSize:11,color:isInactive?'#791F1F':L.t4,lineHeight:1.5}}>
                                  {v.alert||'—'}
                                </div>
                                <div style={{display:'flex',flexDirection:'column',gap:4}}>
                                  {isInactive&&<button style={{padding:'3px 7px',borderRadius:4,border:'1px solid #E24B4A',background:'#FCEBEB',cursor:'pointer',fontSize:9,fontWeight:700,color:'#A32D2D'}}>Retire</button>}
                                  {isInactive&&<button style={{padding:'3px 7px',borderRadius:4,border:'1px solid #1D9E75',background:L.tealBg,cursor:'pointer',fontSize:9,fontWeight:700,color:L.tealDk}}>Re-certify</button>}
                                  {isPending&&<button style={{padding:'3px 7px',borderRadius:4,border:'1px solid #534AB7',background:'#EEEDFE',cursor:'pointer',fontSize:9,fontWeight:700,color:'#534AB7'}}>Approve ↗</button>}
                                  {isPending&&<button style={{padding:'3px 7px',borderRadius:4,border:`1px solid ${L.cor}`,background:L.corBg,cursor:'pointer',fontSize:9,fontWeight:700,color:L.cor}}>Reject</button>}
                                  {isAnticipated&&<button style={{padding:'3px 7px',borderRadius:4,border:'1px solid #185FA5',background:'#E6F1FB',cursor:'pointer',fontSize:9,fontWeight:700,color:'#185FA5'}}>Validate</button>}
                                  {!isInactive&&!isPending&&!isAnticipated&&<button style={{padding:'3px 7px',borderRadius:4,border:`1px solid ${L.bd}`,background:L.s1,cursor:'pointer',fontSize:9,color:L.t3}}>Retire</button>}
                                </div>
                              </div>
                            )
                          })}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* ── Usage & Stats tab ── */}
      {activeId===null&&tab==='usage'&&(
        <div>
          {/* Summary cards */}
          <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12,marginBottom:20}}>
            {[
              {label:'Total lookups',     val:lookups.length,                               sub:'registered'},
              {label:'Active',            val:lookups.filter(l=>l.st==='ACTIVE').length,    sub:'in use'},
              {label:'Rules referencing', val:lookups.reduce((s,l)=>s+l.usedBy.filter(u=>u.type==='rule').length,0), sub:'rule bindings'},
              {label:'Total executions',  val:lookups.reduce((s,l)=>s+l.stats.execLast30d,0).toLocaleString(), sub:'last 30 days'},
            ].map(({label,val,sub})=>(
              <div key={label} style={{padding:'12px 14px',background:L.s3,borderRadius:8,border:`1px solid ${L.bd}`}}>
                <div style={{fontSize:10,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.06em',marginBottom:4}}>{label}</div>
                <div style={{fontSize:22,fontWeight:700,color:L.t1,fontFamily:L.mono}}>{val}</div>
                <div style={{fontSize:10,color:L.t4,marginTop:2}}>{sub}</div>
              </div>
            ))}
          </div>

          {/* Per-lookup usage table */}
          <div style={{fontSize:12,fontWeight:700,color:L.t1,marginBottom:10}}>Execution stats by lookup  (last 30 days)</div>
          <div style={{border:`1px solid ${L.bd}`,borderRadius:10,overflow:'hidden'}}>
            <div style={{display:'grid',gridTemplateColumns:'1.6fr 80px 90px 90px 90px 80px 90px',
              padding:'8px 14px',background:L.s3,borderBottom:`1px solid ${L.bd}`,
              fontSize:9,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.06em',gap:8}}>
              {['Lookup','Tenant','Executions','Phase 1 avg','Phase 2 avg','Cache %','Used by'].map(h=><span key={h}>{h}</span>)}
            </div>
            {lookups.map((lk,i)=>{
              const bar = lk.stats.execLast30d>0 ? Math.round((lk.stats.execLast30d / Math.max(...lookups.map(l=>l.stats.execLast30d)))*100) : 0
              return (
                <div key={lk.cd} style={{display:'grid',gridTemplateColumns:'1.6fr 80px 90px 90px 90px 80px 90px',
                  padding:'10px 14px',borderBottom:`1px solid ${L.bd2}`,gap:8,
                  fontSize:12,alignItems:'center',background:i%2?L.s2:L.s1}}>
                  <div>
                    <div style={{fontFamily:L.mono,fontSize:11,fontWeight:700,color:L.tealDk}}>{lk.cd}</div>
                    <div style={{height:4,background:L.s4,borderRadius:2,marginTop:4,maxWidth:200}}>
                      <div style={{height:4,background:lk.stats.execLast30d>0?L.teal:L.bd,borderRadius:2,width:bar+'%'}}/>
                    </div>
                  </div>
                  <span style={{fontSize:10,fontWeight:700,color:lk.tenantCd?'#534AB7':'#0F6E56',
                    background:lk.tenantCd?'#EEEDFE':L.tealBg,padding:'2px 5px',borderRadius:3,textAlign:'center'}}>
                    {lk.tenantCd||'GLOBAL'}
                  </span>
                  <span style={{fontFamily:L.mono,fontSize:11,color:lk.stats.execLast30d>0?L.t1:L.t4}}>
                    {lk.stats.execLast30d.toLocaleString()}
                  </span>
                  <span style={{fontFamily:L.mono,fontSize:11,color:L.t2}}>
                    {lk.stats.avgPhase1Rows>0?lk.stats.avgPhase1Rows.toLocaleString():'-'} rows
                  </span>
                  <span style={{fontFamily:L.mono,fontSize:11,color:L.t2}}>
                    {lk.stats.avgPhase2Rows>0?lk.stats.avgPhase2Rows.toLocaleString():'-'} rows
                  </span>
                  <span style={{fontFamily:L.mono,fontSize:11,
                    color:lk.stats.cacheHitRate>90?L.grn:lk.stats.cacheHitRate>70?L.amb:lk.stats.cacheHitRate>0?L.cor:L.t4}}>
                    {lk.stats.cacheHitRate>0?lk.stats.cacheHitRate+'%':'—'}
                  </span>
                  <div style={{display:'flex',gap:3,flexWrap:'wrap'}}>
                    {lk.usedBy.length===0
                      ?<span style={{fontSize:10,color:L.t4}}>—</span>
                      :lk.usedBy.map(u=>(
                        <span key={u.id} style={{fontSize:9,fontWeight:700,
                          color:u.type==='rule'?L.pur:u.type==='ai'?L.blue:L.teal,
                          background:u.type==='rule'?'#EEEDFE':u.type==='ai'?L.blueBg:L.tealBg,
                          padding:'1px 4px',borderRadius:3}}>
                          {u.type[0].toUpperCase()}
                        </span>
                      ))
                    }
                  </div>
                </div>
              )
            })}
          </div>
          <div style={{display:'flex',gap:10,marginTop:12,fontSize:11,color:L.t4}}>
            <span style={{fontWeight:700,color:L.pur}}>R</span><span>= Rule</span>
            <span style={{fontWeight:700,color:L.blue}}>A</span><span>= Lexie AI</span>
            <span style={{fontWeight:700,color:L.teal}}>Q</span><span>= Query Studio / pipeline</span>
          </div>
          {/* Policy summary */}
          {lookups.some(l=>l.health?.inactiveInSource>0||l.health?.overallStatus==='REVIEW_DUE'||l.health?.overallStatus==='AT_RISK')&&(
            <div style={{marginTop:16,padding:'14px 16px',background:'#FCEBEB',border:'1px solid #F09595',borderRadius:9}}>
              <div style={{fontSize:12,fontWeight:700,color:'#791F1F',marginBottom:10,display:'flex',alignItems:'center',gap:8}}>
                <Shield size={14} color="#A32D2D"/> Active policy violations in lookup registry
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                <div style={{padding:'10px 12px',background:'#F7C1C1',borderRadius:7}}>
                  <div style={{fontSize:10,fontWeight:700,color:'#A32D2D',marginBottom:4}}>POL-SV-001 · Stale value prohibition</div>
                  <div style={{fontSize:22,fontWeight:700,color:'#791F1F',fontFamily:'var(--font-mono)'}}>
                    {lookups.filter(l=>l.health?.inactiveInSource>0).length}
                  </div>
                  <div style={{fontSize:11,color:'#A32D2D'}}>lookup{lookups.filter(l=>l.health?.inactiveInSource>0).length!==1?'s':''} with INACTIVE_IN_SOURCE values · new rule bindings blocked</div>
                </div>
                <div style={{padding:'10px 12px',background:'#FAC775',borderRadius:7}}>
                  <div style={{fontSize:10,fontWeight:700,color:'#633806',marginBottom:4}}>POL-SV-002 · Overdue review prohibition</div>
                  <div style={{fontSize:22,fontWeight:700,color:'#412402',fontFamily:'var(--font-mono)'}}>
                    {lookups.filter(l=>l.health?.overallStatus==='REVIEW_DUE'||l.health?.overallStatus==='AT_RISK').length}
                  </div>
                  <div style={{fontSize:11,color:'#633806'}}>lookup{lookups.filter(l=>l.health?.overallStatus==='REVIEW_DUE'||l.health?.overallStatus==='AT_RISK').length!==1?'s':''} overdue for review · new pipeline bindings blocked</div>
                </div>
              </div>
              <div style={{marginTop:10,fontSize:11,color:'#791F1F',lineHeight:1.6}}>
                These policies prevent the multi-point failure pattern: lookup carries stale value → booking system stops using it → reporting system does not know → audit finding.
                Resolve by retiring inactive values or certifying the lookup via the Registry tab.
              </div>
            </div>
          )}
        </div>
      )}

      <Drawer open={!!histLk} onClose={()=>setHistLk(null)} eyebrow="Filter Lookup · History"
        title={histLk?histLk.cd:''} sub={histLk?(histLk.tenantCd||'GLOBAL'):''}
        footer="Append-only governance log — who · what · when. Illustrative in this prototype.">
        {histLk && <HistoryTimeline events={govEvents({name:histLk.cd, kind:'Filter lookup', status:histLk.st, seed:(histLk.cd||'').length})}/>}
      </Drawer>
    </div>
  )
}
function WorkflowScreen() {
  const [tab,       setTab]      = useState('ALL')
  const [wfTab,     setWfTab]    = useState('queue')
  const [approved,  setApproved] = useState([])
  const [rejected,  setRejected] = useState([])
  const [lnoReqs,   setLnoReqs]  = useState(LN_OVERRIDE_REQUESTS)
  const [selReq,    setSelReq]   = useState(null)
  const [reviewNote,setReviewNote]= useState('')

  const effSt  = w => approved.includes(w.id)?'APPROVED':rejected.includes(w.id)?'REJECTED':w.st
  const rows   = WF.filter(w=>tab==='ALL'||effSt(w)===tab)
  const pending= WF.filter(w=>effSt(w)==='PENDING').length
  const lnoPending = lnoReqs.filter(r=>r.st==='PENDING').length
  const cols   = '1.8fr 1.4fr 1fr 1fr 0.8fr 140px'

  return (
    <div>
      <PageHdr title="Workflow Queue" icon={CheckSquare} sub="Governance approvals for object registrations, attribute pairings, logical name overrides and hierarchy definitions"
        action={<div style={{display:'flex',alignItems:'center',gap:8}}><span style={{fontSize:12,color:L.t3}}>{pending+lnoPending} pending</span><Btn label="Refresh" icon={RefreshCw}/></div>}/>

      {/* Top-level tab: Approval Queue | Logical Name Overrides */}
      <div style={{display:'flex',gap:0,borderBottom:`1px solid ${L.bd}`,marginBottom:20}}>
        {[
          {id:'queue', label:'Approval Queue',           badge:pending},
          {id:'lno',   label:'Logical Name Overrides',   badge:lnoPending},
        ].map(({id,label,badge})=>(
          <button key={id} onClick={()=>setWfTab(id)} style={{
            padding:'8px 20px',border:'none',cursor:'pointer',background:'transparent',
            fontSize:13,fontWeight:wfTab===id?600:400,color:wfTab===id?L.teal:L.t3,
            borderBottom:wfTab===id?`2px solid ${L.teal}`:'2px solid transparent',
            display:'flex',alignItems:'center',gap:7,
          }}>
            {label}
            {badge>0&&<span style={{fontSize:9,fontWeight:700,background:wfTab===id?L.teal:L.cor,
              color:'#fff',borderRadius:10,padding:'1px 6px'}}>{badge}</span>}
          </button>
        ))}
      </div>

      {/* ── Approval Queue ── */}
      {wfTab==='queue'&&(
        <div>
          <div style={{display:'flex',gap:2,marginBottom:16,background:L.s3,padding:4,borderRadius:8,width:'fit-content',border:`1px solid ${L.bd}`}}>
            {['ALL','PENDING','APPROVED','REJECTED'].map(t=>(
              <button key={t} onClick={()=>setTab(t)} style={{display:'flex',alignItems:'center',gap:5,
                padding:'5px 14px',borderRadius:5,border:'none',cursor:'pointer',fontSize:12,fontWeight:600,
                background:tab===t?L.s1:L.s3,color:tab===t?L.t1:L.t3,boxShadow:tab===t?`0 1px 3px ${L.bd}`:'none'}}>
                {t}{t==='PENDING'&&pending>0&&<span style={{fontSize:9,fontWeight:700,background:L.cor,color:'#fff',borderRadius:10,padding:'1px 5px'}}>{pending}</span>}
              </button>
            ))}
          </div>
          <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:10,overflow:'hidden'}}>
            <div style={{display:'grid',gridTemplateColumns:cols,padding:'9px 14px',background:L.s3,borderBottom:`1px solid ${L.bd}`,gap:8,fontSize:10,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.07em'}}>
              {['Object','Type','By','Date','Priority','Actions'].map(h=><span key={h}>{h}</span>)}
            </div>
            {rows.map((w,i)=>{
              const st=effSt(w)
              return (
                <div key={w.id} style={{display:'grid',gridTemplateColumns:cols,padding:'10px 14px',borderBottom:`1px solid ${L.bd2}`,fontSize:12,alignItems:'center',gap:8,background:i%2?L.s2:L.s1}}>
                  <div><div style={{fontSize:12,fontWeight:600,color:L.t1,marginBottom:3}}>{w.obj}</div><SBadge st={st}/></div>
                  <span style={{fontFamily:L.mono,fontSize:10,color:L.t2}}>{w.type}</span>
                  <span style={{fontSize:12,color:L.t2}}>{w.by}</span>
                  <span style={{fontSize:12,color:L.t3}}>{w.at}</span>
                  <Chip text={w.pri} c={priClr(w.pri).c} bg={priClr(w.pri).bg}/>
                  <div style={{display:'flex',gap:5}}>
                    {st==='PENDING'&&<Fragment>
                      <button onClick={()=>setApproved(p=>[...p,w.id])} style={{padding:'4px 9px',borderRadius:5,border:'none',cursor:'pointer',background:L.grnBg,color:L.grn,fontSize:11,fontWeight:700}}>Approve</button>
                      <button onClick={()=>setRejected(p=>[...p,w.id])} style={{padding:'4px 9px',borderRadius:5,border:'none',cursor:'pointer',background:L.corBg,color:L.cor,fontSize:11,fontWeight:700}}>Reject</button>
                    </Fragment>}
                    {st!=='PENDING'&&<Eye size={14} color={L.t4} style={{cursor:'pointer'}}/>}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* ── Logical Name Overrides ── */}
      {wfTab==='lno'&&(
        <div>
          <div style={{marginBottom:14}}>
            <div style={{fontSize:13,fontWeight:600,color:L.t1}}>Client Logical Name Override Requests</div>
            <div style={{fontSize:11,color:L.t3,marginTop:3,lineHeight:1.6}}>
              Clients may propose alternative short/long display names for registered attributes. Each approved request is stored
              in <span style={{fontFamily:L.mono,fontSize:10,background:L.s3,padding:'1px 5px',borderRadius:3}}>meta.attribute_logical_name_override</span> scoped
              to the requesting tenant. The Lextr enterprise default is preserved unchanged.
            </div>
          </div>
          <div style={{border:`1px solid ${L.bd}`,borderRadius:10,overflow:'hidden'}}>
            <div style={{display:'grid',gridTemplateColumns:'90px 110px 1.2fr 1fr 1fr 1.5fr 100px 70px 90px',
              padding:'8px 14px',background:L.s3,borderBottom:`1px solid ${L.bd}`,gap:8,
              fontSize:9,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.06em',alignItems:'center'}}>
              {['Req ID','Tenant','Object · Attribute','Current Short Nm','Proposed Short Nm','Reason','Requested By','Status','Action'].map(h=><span key={h}>{h}</span>)}
            </div>
            {lnoReqs.map(req=>(
              <div key={req.id} style={{borderBottom:`1px solid ${L.bd2}`}}>
                <div style={{display:'grid',gridTemplateColumns:'90px 110px 1.2fr 1fr 1fr 1.5fr 100px 70px 90px',
                  padding:'10px 14px',gap:8,fontSize:12,alignItems:'center',
                  background:selReq===req.id?L.s3:L.s1}}>
                  <span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:L.blueDk}}>{req.id}</span>
                  <Chip text={req.tenant} c={L.pur} bg={L.purBg} sz={9}/>
                  <div>
                    <span style={{fontFamily:L.mono,fontSize:10,color:L.t2}}>{req.schema_cd}.{req.object_cd}</span>
                    <div style={{fontFamily:L.mono,fontSize:10,color:L.teal,marginTop:2,fontWeight:700}}>{req.attribute_cd}</div>
                  </div>
                  <div>
                    <div style={{fontSize:11,fontWeight:600,color:L.t2}}>{req.current_short}</div>
                    <div style={{fontSize:9,color:L.t4,marginTop:1,fontStyle:'italic'}}>{req.current_long}</div>
                  </div>
                  <div>
                    <div style={{fontSize:11,fontWeight:700,color:L.teal}}>{req.proposed_short}</div>
                    <div style={{fontSize:9,color:L.tealDk,marginTop:1,fontStyle:'italic'}}>{req.proposed_long}</div>
                  </div>
                  <div style={{fontSize:11,color:L.t2,lineHeight:1.5}}>{req.reason.slice(0,75)}{req.reason.length>75?'…':''}</div>
                  <div>
                    <div style={{fontSize:10,fontWeight:600,color:L.t2}}>{req.by.split('@')[0]}</div>
                    <div style={{fontSize:9,color:L.t4}}>{req.at}</div>
                  </div>
                  <span style={{padding:'2px 7px',borderRadius:4,fontSize:10,fontWeight:700,display:'inline-block',
                    background:req.st==='APPROVED'?L.grnBg:req.st==='PENDING'?L.ambBg:L.corBg,
                    color:req.st==='APPROVED'?L.grn:req.st==='PENDING'?L.amb:L.cor}}>{req.st}</span>
                  {req.st==='PENDING'?(
                    <button onClick={()=>setSelReq(selReq===req.id?null:req.id)}
                      style={{padding:'4px 9px',borderRadius:5,border:`1px solid ${L.bd}`,background:L.s1,
                        cursor:'pointer',fontSize:10,fontWeight:600,color:L.t2}}>
                      {selReq===req.id?'Close':'Review'}
                    </button>
                  ):<span style={{fontSize:10,color:L.t4}}>—</span>}
                </div>
                {selReq===req.id&&(
                  <div style={{padding:'16px 18px',background:L.s3,borderTop:`1px solid ${L.bd2}`}}>
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14,marginBottom:14}}>
                      <div style={{background:L.s1,border:`1px solid ${L.bd}`,borderRadius:8,padding:14}}>
                        <div style={{fontSize:10,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.05em',marginBottom:8}}>
                          Lextr Enterprise Default (unchanged)
                        </div>
                        <div style={{fontSize:13,fontWeight:700,color:L.t1}}>{req.current_short}</div>
                        <div style={{fontSize:11,color:L.t3,marginTop:3,fontStyle:'italic'}}>{req.current_long}</div>
                        <div style={{fontSize:10,color:L.t4,marginTop:6,fontFamily:L.mono}}>
                          meta.attribute_catalog · {req.schema_cd}.{req.object_cd}.{req.attribute_cd}
                        </div>
                      </div>
                      <div style={{background:L.tealBg,border:`1px solid ${L.teal}55`,borderRadius:8,padding:14}}>
                        <div style={{fontSize:10,fontWeight:700,color:L.tealDk,textTransform:'uppercase',letterSpacing:'.05em',marginBottom:8}}>
                          Proposed Override — Tenant: {req.tenant}
                        </div>
                        <div style={{fontSize:13,fontWeight:700,color:L.teal}}>{req.proposed_short}</div>
                        <div style={{fontSize:11,color:L.tealDk,marginTop:3,fontStyle:'italic'}}>{req.proposed_long}</div>
                        <div style={{fontSize:10,color:L.teal,marginTop:6,fontFamily:L.mono}}>
                          meta.attribute_logical_name_override · tenant_cd = {req.tenant}
                        </div>
                      </div>
                    </div>
                    <div style={{marginBottom:12,padding:'10px 12px',background:L.s1,border:`1px solid ${L.bd}`,borderRadius:7}}>
                      <div style={{fontSize:10,fontWeight:700,color:L.t2,marginBottom:4}}>Client justification</div>
                      <div style={{fontSize:12,color:L.t1,lineHeight:1.6}}>{req.reason}</div>
                    </div>
                    <div style={{marginBottom:12}}>
                      <label style={{fontSize:10,fontWeight:600,color:L.t2,display:'block',marginBottom:4}}>Governance review note</label>
                      <textarea value={reviewNote} onChange={e=>setReviewNote(e.target.value)} rows={2}
                        placeholder="Document the governance decision rationale..."
                        style={{width:'100%',padding:'7px 9px',border:`1px solid ${L.bd}`,borderRadius:6,fontSize:11,
                          color:L.t1,fontFamily:L.font,outline:'none',resize:'none',boxSizing:'border-box'}}/>
                    </div>
                    <div style={{display:'flex',gap:10,alignItems:'center'}}>
                      <button onClick={()=>{setLnoReqs(p=>p.map(r=>r.id===req.id?{...r,st:'APPROVED'}:r));setSelReq(null);setReviewNote('')}}
                        style={{padding:'7px 18px',borderRadius:6,border:'none',background:L.teal,color:'#fff',cursor:'pointer',fontSize:12,fontWeight:700}}>
                        ✓ Approve &amp; store tenant override
                      </button>
                      <button onClick={()=>{setLnoReqs(p=>p.map(r=>r.id===req.id?{...r,st:'REJECTED'}:r));setSelReq(null);setReviewNote('')}}
                        style={{padding:'7px 18px',borderRadius:6,border:`1px solid ${L.cor}`,background:L.corBg,color:L.cor,cursor:'pointer',fontSize:12,fontWeight:700}}>
                        ✗ Reject
                      </button>
                      <div style={{flex:1}}/>
                      <div style={{fontSize:10,color:L.t4,maxWidth:320,lineHeight:1.5}}>
                        Approval inserts a row into <span style={{fontFamily:L.mono}}>meta.attribute_logical_name_override</span> with tenant_cd = {req.tenant}. Enterprise default in <span style={{fontFamily:L.mono}}>meta.attribute_catalog</span> is not modified.
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════
// SIDEBAR — Governance LHP theme
// ══════════════════════════════════════════════════════════════════════
// ── NAV with section grouping ─────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════════
// DOWNSTREAM CONSUMPTION  (placeholder — UI simulation; backend is real API/JSON)
// The semantic layer is one horizontal layer. Every consumption layer is configured
// through ONE consistent descriptor: an exposure structure (technical | data-asset)
// plus independent outbound exposures, each carrying an aggregation pyramid
// (top = aggregated → bottom = granular/lowest). This mirrors the shape the real
// /api/semantic-layer/consumption/* endpoints + JSON contract will serve.
// ══════════════════════════════════════════════════════════════════════
const CONSUMPTION_LAYERS = [
  { id:'adhoc', name:'Ad-hoc Analysis', kind:'INTERACTIVE_QUERY', color:L.teal,
    desc:'Analysts explore governed objects directly. The Data Catalog is exposed either as the technical structure (schema · table · column) or the data-asset structure (business domain · asset · concept). Outbound exposures run independently and are connected logically through an aggregation pyramid.',
    defaultStructure:'DATA_ASSET',
    outbounds:[
      { id:'cx_adhoc_cube', name:'Regulatory analytics cube', structure:'TECHNICAL', engine:'CLICKHOUSE', status:'SIMULATED',
        pyramid:[
          {lvl:0, grain:'Report aggregate',     card:'~1.2K cells', bind:'analytics.variance_result_cache'},
          {lvl:1, grain:'Asset-class rollup',   card:'~48K rows',   bind:'analytics.gl_balance_daily_agg'},
          {lvl:2, grain:'Position / account',   card:'~12M rows',   bind:'core.gl_balance'},
          {lvl:3, grain:'Transaction (lowest)', card:'~420M rows',  bind:'core.gl_balance (detail)'},
        ]},
      { id:'cx_adhoc_risk', name:'Risk data-asset view', structure:'DATA_ASSET', engine:'POSTGRES', status:'SIMULATED',
        pyramid:[
          {lvl:0, grain:'Risk domain summary',  card:'~300 rows',   bind:'Credit Risk (data asset)'},
          {lvl:1, grain:'Exposure rollup',      card:'~2M rows',    bind:'core.loan_contract'},
          {lvl:2, grain:'Facility / position',  card:'~9M rows',    bind:'core.gl_balance'},
        ]},
    ]},
  { id:'rules', name:'Rules Authoring Dataset', kind:'BATCH_DATASET', color:L.pur,
    desc:'A governed, denormalised input set the Rules & Logic Assist authoring environment binds to. Exposed as a data-asset structure so rule authors reference business concepts rather than physical columns.',
    defaultStructure:'DATA_ASSET',
    outbounds:[
      { id:'cx_rules_input', name:'Calculation input set', structure:'DATA_ASSET', engine:'POSTGRES', status:'SIMULATED',
        pyramid:[
          {lvl:0, grain:'Rule output (metric)', card:'~900 rules',  bind:'CECL / IRB measures'},
          {lvl:1, grain:'Driver rollup',        card:'~50K rows',   bind:'PD / LGD / EAD drivers'},
          {lvl:2, grain:'Account-level inputs', card:'~12M rows',   bind:'core.gl_balance + attrs'},
        ]},
    ]},
  { id:'intelligence', name:'Lextr Intelligence', kind:'AI_DESCRIPTOR', color:L.blue,
    desc:'Lextr Intelligence (Lexie) consumes the layer through a governed descriptor / resolve contract — exposed as a data-asset structure of semantic concepts and aliases so the AI reasons over business meaning. Consumer handshake endpoints are owner-gated.',
    defaultStructure:'DATA_ASSET',
    outbounds:[
      { id:'cx_int_descriptor', name:'Semantic descriptor feed', structure:'DATA_ASSET', engine:'SEMANTIC_SERVICE', status:'PROPOSED',
        pyramid:[
          {lvl:0, grain:'Concept catalog',       card:'~1.1K concepts', bind:'meta.semantic_concept (proposed)'},
          {lvl:1, grain:'Object descriptors',    card:'~79 objects',    bind:'meta.object_catalog'},
          {lvl:2, grain:'Attribute descriptors', card:'~1,035 attrs',   bind:'meta.attribute_catalog'},
        ]},
    ]},
  { id:'regreport', name:'Regulatory Report Generation', kind:'REPORT_CELLS', color:L.amb,
    desc:'Report-cell generation (FR Y-9C, FFIEC) draws governed values from the layer — exposed as a technical structure mapped to report-line definitions. Variance analysis runs over the same pyramid.',
    defaultStructure:'TECHNICAL',
    outbounds:[
      { id:'cx_rr_y9c', name:'Y-9C report cells', structure:'TECHNICAL', engine:'CLICKHOUSE', status:'SIMULATED',
        pyramid:[
          {lvl:0, grain:'Schedule total cell',   card:'~2.4K cells', bind:'report_line_definition'},
          {lvl:1, grain:'Line-item rollup',      card:'~40K rows',   bind:'analytics.gl_balance_daily_agg'},
          {lvl:2, grain:'Source position',       card:'~12M rows',   bind:'core.gl_balance'},
        ]},
    ]},
]

const CX_STRUCT = {
  TECHNICAL:  {label:'Technical structure',  c:L.blue, bg:L.blueBg, icon:Table2,   desc:'schema · table · column'},
  DATA_ASSET: {label:'Data-asset structure', c:L.pur,  bg:L.purBg,  icon:BookOpen,  desc:'business domain · asset · concept'},
}
const CX_STATUS = {
  SIMULATED: {c:L.amb, bg:L.ambBg},
  PROPOSED:  {c:L.blue, bg:L.blueBg},
  ACTIVE:    {c:L.teal, bg:L.tealBg},
}
const CX_KIND_OPTS = [
  {v:'INTERACTIVE_QUERY', l:'Interactive query (ad-hoc)'},
  {v:'BATCH_DATASET',     l:'Batch dataset (rules / pipeline)'},
  {v:'AI_DESCRIPTOR',     l:'AI descriptor (Lextr Intelligence)'},
  {v:'REPORT_CELLS',      l:'Report cells (regulatory)'},
  {v:'CUSTOM',            l:'Custom'},
]
const CX_KIND_COLOR = {INTERACTIVE_QUERY:L.teal, BATCH_DATASET:L.pur, AI_DESCRIPTOR:L.blue, REPORT_CELLS:L.amb, CUSTOM:L.grn}
const CX_ENGINE_OPTS = ['POSTGRES','CLICKHOUSE','NEO4J','SEMANTIC_SERVICE']

// ── SDLC promotion model ─────────────────────────────────────────────
const CX_ENVS = ['DRAFT','DEV','TEST','UAT','PROD']
const CX_ENV_META = {
  DRAFT:{c:L.t3,  bg:L.s3,    note:'authored, not yet deployed'},
  DEV:  {c:L.blue,bg:L.blueBg,note:'developer environment'},
  TEST: {c:L.amb, bg:L.ambBg, note:'integration / SIT'},
  UAT:  {c:L.pur, bg:L.purBg, note:'business acceptance'},
  PROD: {c:L.teal,bg:L.tealBg,note:'production'},
}
// Role accountable for sign-off into each environment (illustrative; enforced by backend governance/OPA)
const CX_PROMO_ROLE = { DEV:'Developer', TEST:'QA / Data Engineer', UAT:'Data Steward', PROD:'Owner / Governance' }
// Seed exposures already live at various stages
const SEED_ENV = { adhoc:4, rules:3, intelligence:0, regreport:2 }

// ── logical-only helpers (the UI surfaces logical names; physical lives in the semantic layer) ──
const CX_ROLE = {
  IDENTIFIER:{c:L.t3,  bg:L.s3},
  CODE:      {c:L.blue,bg:L.blueBg},
  DIMENSION: {c:L.pur, bg:L.purBg},
  MEASURE:   {c:L.teal,bg:L.tealBg},
}
const cxBase = (bind)=> (bind||'').replace(/\s*\(.*\)\s*$/,'')
// extract the underlying catalog key (schema.table) from a possibly-suffixed bind
const cxKey = (bind)=>{ const m=(bind||'').match(/^[a-z][a-z_]*\.[a-z][a-z_]*/); return m?m[0]:cxBase(bind) }
// logical display names for objects that are not in the mock CATALOG (meta/report/analytics)
const CX_ALIAS = {
  'report_line_definition':'Report Line Definition',
  'meta.object_catalog':'Object Catalog',
  'meta.attribute_catalog':'Attribute Catalog',
  'meta.semantic_concept':'Semantic Concept',
  'analytics.variance_result_cache':'Variance Result Cache',
  'analytics.gl_balance_daily_agg':'GL Balance Daily Aggregate',
  'analytics.loan_performance_daily':'Loan Performance Daily',
}
function cxHumanize(s){
  const seg=(s||'').split('.').pop().replace(/[_+]+/g,' ').trim()
  return seg.replace(/\b\w/g, c=>c.toUpperCase())
}
function cxSuffix(bind){
  if (/\+\s*attrs/i.test(bind||'')) return ' (+ attributes)'
  const m=(bind||'').match(/\(([^)]+)\)/); return m?` (${m[1]})`:''
}
function cxLogicalObj(bind){
  if (CATALOG[bind] && CATALOG[bind].logicalShortNm) return CATALOG[bind].logicalShortNm
  const key=cxKey(bind)
  const base = (CATALOG[key]&&CATALOG[key].logicalShortNm) || CX_ALIAS[bind] || CX_ALIAS[key] || cxHumanize(key||bind)
  return CX_ALIAS[bind] ? base : base + cxSuffix(bind)
}
function cxIllustrative(grain){
  const g=(grain||'').toLowerCase()
  if (g.includes('transaction')) return ['Transaction Reference','Trade Date','Amount','Counterparty','Instrument']
  if (g.includes('position')||g.includes('account')||g.includes('facility')) return ['Account','Legal Entity','Currency','Balance Amount','As-of Date']
  if (g.includes('rollup')||g.includes('class')||g.includes('exposure')) return ['Asset Class','Legal Entity','Reporting Period','Aggregated Amount']
  if (g.includes('concept')) return ['Concept Name','Business Definition','Synonyms','Owning Domain']
  if (g.includes('object')) return ['Object Name','Domain','Grain','Steward']
  if (g.includes('attribute')) return ['Attribute Name','Business Definition','Logical Data Type','CDE Flag']
  if (g.includes('driver')) return ['Driver Name','Driver Category','Reporting Period','Driver Value']
  if (g.includes('rule')||g.includes('metric')) return ['Measure Name','Regulatory Framework','Reporting Period','Measure Value']
  return ['Reporting Period','Legal Entity','Report Line','Reported Amount','Currency']
}
function cxLevelAttrRows(level, outbound){
  const bind=level.bind, key=cxKey(bind)
  const cat=(CATALOG[bind]&&CATALOG[bind].attrs)||(CATALOG[key]&&CATALOG[key].attrs)||[]
  const picked = outbound && outbound.attributes && (outbound.attributes[bind]||outbound.attributes[key])
  if (picked && picked.length){
    return picked.map(cd=>{const a=cat.find(x=>x.cd===cd); return {name:a?(a.ln||cd):cd, role:a?a.semantic:null}})
  }
  if (cat.length){
    return cat.slice(0,14).map(a=>({name:a.ln||a.cd, role:a.semantic}))
  }
  return cxIllustrative(level.grain).map(n=>({name:n, role:null, illustrative:true}))
}
function cxLogicalAttrMap(attrs){
  const out={}
  Object.entries(attrs||{}).forEach(([obj,cds])=>{
    const cat=(CATALOG[obj]&&CATALOG[obj].attrs)||[]
    out[cxLogicalObj(obj)] = (cds||[]).map(cd=>{const a=cat.find(x=>x.cd===cd);return a?(a.ln||cd):cd})
  })
  return out
}

function CxPyramid({ outbound, color }) {
  const levels = outbound.pyramid
  const [open, setOpen] = useState(null)
  const n = levels.length
  return (
    <div style={{display:'flex',flexDirection:'column',gap:6,marginTop:10}}>
      {levels.map((p,i)=>{
        const w  = n<=1 ? 90 : Math.round(42 + (i/(n-1))*50)   // apex (aggregated) narrow → base (granular) wide
        const op = 1 - (i/Math.max(n,1))*0.5
        const isOpen = open===i
        const rows = isOpen ? cxLevelAttrRows(p, outbound) : null
        const illustrative = rows && rows.some(r=>r.illustrative)
        return (
          <div key={i}>
            <div onClick={()=>setOpen(isOpen?null:i)} style={{display:'flex',alignItems:'center',gap:12,cursor:'pointer'}}>
              <div style={{width:w+'%',minWidth:150,background:color,opacity:op,borderRadius:5,
                padding:'7px 11px',display:'flex',alignItems:'center',justifyContent:'space-between',transition:'width .2s'}}>
                <span style={{fontSize:11,fontWeight:700,color:'#fff',letterSpacing:'.02em'}}>
                  <span style={{marginRight:6,fontSize:9}}>{isOpen?'▼':'▶'}</span>L{p.lvl} · {p.grain}
                </span>
                <span style={{fontSize:10,fontWeight:600,color:'#ffffffcc'}}>{p.card}</span>
              </div>
              <span style={{fontSize:11,color:L.t2,fontWeight:600,whiteSpace:'nowrap'}}>{cxLogicalObj(p.bind)}</span>
            </div>
            {isOpen && (
              <div style={{margin:'7px 0 4px',padding:'12px 14px',border:`1px solid ${L.bd}`,borderRadius:8,background:L.s1}}>
                <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:9,flexWrap:'wrap'}}>
                  <List size={13} color={color}/>
                  <span style={{fontSize:12,fontWeight:700,color:L.t1}}>{cxLogicalObj(p.bind)}</span>
                  <Chip text={`${rows.length} logical attribute${rows.length===1?'':'s'}`} c={color} bg={color+'18'} sz={9}/>
                  {illustrative && <Chip text="illustrative" c={L.amb} bg={L.ambBg} sz={9}/>}
                </div>
                <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:6}}>
                  {rows.map((r,j)=>(
                    <div key={j} style={{display:'flex',alignItems:'center',gap:8,padding:'6px 9px',borderRadius:6,
                      border:`1px solid ${L.bd}`,background:L.s2}}>
                      <span style={{fontSize:11,color:L.t1,flex:1}}>{r.name}</span>
                      {r.role && <Chip text={r.role} c={(CX_ROLE[r.role]||{}).c||L.t3} bg={(CX_ROLE[r.role]||{}).bg||L.s3} sz={9}/>}
                    </div>
                  ))}
                </div>
                <div style={{fontSize:10,color:L.t4,marginTop:8,lineHeight:1.5}}>Logical attribute names only — physical columns are resolved by the semantic layer at query time.</div>
              </div>
            )}
          </div>
        )
      })}
      <div style={{display:'flex',alignItems:'center',gap:6,marginTop:3,fontSize:10,color:L.t4}}>
        <ArrowRight size={11} style={{transform:'rotate(90deg)'}}/> aggregated (top) → granular (lowest) · click a level to view its logical attributes
      </div>
    </div>
  )
}

function CxEnvTrack({ envIdx, onPromote }) {
  const cur = CX_ENVS[envIdx]
  const nextEnv = CX_ENVS[envIdx+1]
  const gates = nextEnv ? [
    {k:'Validation',          d:`Every bound object & attribute exists, is ACTIVE and governed in ${nextEnv}`},
    {k:'Policy (OPA)',        d:'POL-CE-003 single-engine per outbound · tenancy by client_id · externalized bundle'},
    {k:'Governance approval', d:`Workflow task (meta.workflow_task) signed off by ${CX_PROMO_ROLE[nextEnv]}`},
    {k:'Versioned apply',     d:`Descriptor version pinned and applied to the ${nextEnv} semantic-service`},
  ] : []
  return (
    <div style={{marginTop:18}}>
      <div style={{fontSize:11,fontWeight:700,color:L.t2,marginBottom:10}}>SDLC promotion · environment track</div>
      <div style={{display:'flex',alignItems:'flex-start'}}>
        {CX_ENVS.map((e,i)=>{
          const m=CX_ENV_META[e]; const done=i<envIdx; const on=i===envIdx
          return (
            <Fragment key={e}>
              <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:4,minWidth:64}}>
                <div style={{width:30,height:30,borderRadius:15,display:'flex',alignItems:'center',justifyContent:'center',
                  background:on?m.c:done?m.c+'22':L.s3,border:`1px solid ${on||done?m.c:L.bd}`}}>
                  {done?<Check size={14} color={m.c}/>:<span style={{fontSize:11,fontWeight:800,color:on?'#fff':L.t4}}>{i}</span>}
                </div>
                <span style={{fontSize:10,fontWeight:on?800:600,color:on?m.c:done?L.t2:L.t4}}>{e}</span>
              </div>
              {i<CX_ENVS.length-1 && <div style={{flex:1,height:2,marginTop:15,background:i<envIdx?CX_ENV_META[CX_ENVS[i+1]].c+'66':L.bd}}/>}
            </Fragment>
          )
        })}
      </div>
      <div style={{display:'flex',alignItems:'center',gap:8,marginTop:8,fontSize:11,color:L.t3}}>
        Current: <Chip text={cur} c={CX_ENV_META[cur].c} bg={CX_ENV_META[cur].bg}/> <span style={{color:L.t4}}>· {CX_ENV_META[cur].note}</span>
      </div>
      {nextEnv ? (
        <div style={{marginTop:12,border:`1px solid ${L.bd}`,borderRadius:9,padding:14,background:L.s2}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:8}}>
            <span style={{fontSize:12,fontWeight:700,color:L.t1}}>Promotion gates → {nextEnv}</span>
            <Btn label={`Promote to ${nextEnv}`} icon={ChevronRight} small primary onClick={onPromote}/>
          </div>
          {gates.map(g=>(
            <div key={g.k} style={{display:'flex',alignItems:'flex-start',gap:9,padding:'5px 0'}}>
              <div style={{width:18,height:18,borderRadius:9,background:L.tealBg,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,marginTop:1}}><Check size={11} color={L.teal}/></div>
              <div><span style={{fontSize:12,fontWeight:600,color:L.t1}}>{g.k}</span><span style={{fontSize:11,color:L.t3}}> — {g.d}</span></div>
            </div>
          ))}
          <div style={{fontSize:10,color:L.t4,marginTop:6,lineHeight:1.5}}>Gates are simulated here. In build, each is enforced by the backend — catalog validation, the OPA policy bundle, a governance workflow approval, then a versioned (GitOps) apply to the target environment's semantic-service. Every promotion writes an audit record.</div>
        </div>
      ) : (
        <div style={{marginTop:12,fontSize:12,color:L.teal,fontWeight:600,display:'flex',alignItems:'center',gap:6}}><Shield size={14}/> Live in PROD — no further promotion.</div>
      )}
    </div>
  )
}

function CxWizard({ onCreate, onCancel }) {
  const [step, setStep] = useState(0)
  const [name, setName] = useState('')
  const [kind, setKind] = useState('INTERACTIVE_QUERY')
  const [structure, setStructure] = useState('DATA_ASSET')
  const [engine, setEngine] = useState('POSTGRES')
  const [client, setClient] = useState('GLOBAL')
  const [obName, setObName] = useState('')
  const [levels, setLevels] = useState([{grain:'', bind:'', card:''}])
  const [picked, setPicked] = useState({})   // {obj:[attrCd,...]}

  const catObjs = Object.keys(CATALOG)
  const objOpts = catObjs.map(o=>({v:o,l:cxLogicalObj(o)}))
  const setLvl = (i,f,v)=> setLevels(ls=>ls.map((l,j)=>j===i?{...l,[f]:v}:l))
  const addLvl = ()=> setLevels(ls=>[...ls,{grain:'',bind:'',card:''}])
  const delLvl = (i)=> setLevels(ls=>ls.length>1?ls.filter((_,j)=>j!==i):ls)
  const pyObjs = [...new Set(levels.map(l=>l.bind).filter(Boolean))]
  const toggleAttr = (obj,cd)=> setPicked(p=>{
    const cur=p[obj]||[]; const next=cur.includes(cd)?cur.filter(x=>x!==cd):[...cur,cd]
    return {...next.length?{...p,[obj]:next}:(()=>{const c={...p};delete c[obj];return c})()}
  })

  const okStep0 = name.trim() && kind && structure && engine
  const okStep1 = (obName.trim()||name.trim()) && levels.length>=1 && levels.every(l=>l.grain.trim() && l.bind)
  const canNext = step===0?okStep0 : step===1?okStep1 : true

  const build = ()=>({
    id:'cx_user_'+Date.now(),
    name:name.trim(), kind, color:CX_KIND_COLOR[kind]||L.grn, user:true,
    desc:`User-defined consumption layer, exposed as the ${CX_STRUCT[structure].label.toLowerCase()}.`,
    defaultStructure:structure, client,
    outbounds:[{
      id:'ob_'+Date.now(), name:(obName.trim()||name.trim()+' exposure'),
      structure, engine, status:'SIMULATED',
      pyramid: levels.map((l,i)=>({lvl:i, grain:l.grain.trim(), card:l.card.trim()||'—', bind:l.bind})),
      attributes: picked,
    }],
  })

  const STEPS = ['Define target','Define layout','Pick attributes','Review & create']
  const descriptorPreview = step===3 ? build() : null

  return (
    <div>
      <PageHdr title="Add Consumption Layer" icon={Plus}
        sub="Define a new downstream consumption layer for the semantic layer. It is authored in DRAFT, then promoted through environments (SDLC). This is a UI simulation; the backend persists and promotes the real descriptor."
        action={<Btn label="Cancel" onClick={onCancel}/>}/>

      {/* step rail */}
      <div style={{display:'flex',alignItems:'center',marginBottom:18}}>
        {STEPS.map((s,i)=>(
          <Fragment key={s}>
            <div style={{display:'flex',alignItems:'center',gap:8}}>
              <div style={{width:24,height:24,borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center',
                background:i<step?L.teal:i===step?L.teal:L.s3,border:`1px solid ${i<=step?L.teal:L.bd}`}}>
                {i<step?<Check size={13} color="#fff"/>:<span style={{fontSize:11,fontWeight:800,color:i===step?'#fff':L.t4}}>{i+1}</span>}
              </div>
              <span style={{fontSize:12,fontWeight:i===step?700:500,color:i===step?L.t1:L.t3}}>{s}</span>
            </div>
            {i<STEPS.length-1 && <div style={{width:34,height:2,margin:'0 10px',background:i<step?L.teal:L.bd}}/>}
          </Fragment>
        ))}
      </div>

      <Card>
        {step===0 && (
          <div style={{display:'flex',flexDirection:'column',gap:14,maxWidth:560}}>
            <TextInput label="Consumption layer name" value={name} onChange={setName} placeholder="e.g. Treasury liquidity feed" req/>
            <SelectInput label="Consumption kind" value={kind} onChange={setKind} options={CX_KIND_OPTS} req/>
            <div>
              <label style={{display:'block',fontSize:11,fontWeight:600,color:L.t2,marginBottom:6}}>Default exposure structure *</label>
              <div style={{display:'flex',gap:8}}>
                {Object.entries(CX_STRUCT).map(([k,v])=>{
                  const on=structure===k
                  return (
                    <div key={k} onClick={()=>setStructure(k)} style={{flex:1,padding:'10px 12px',borderRadius:8,cursor:'pointer',
                      background:on?v.bg:L.s1,border:`1px solid ${on?v.c:L.bd}`,boxShadow:on?`0 0 0 1px ${v.c}`:'none'}}>
                      <div style={{display:'flex',alignItems:'center',gap:8}}><v.icon size={15} color={on?v.c:L.t3}/>
                        <span style={{fontSize:12,fontWeight:700,color:on?v.c:L.t2}}>{v.label}</span></div>
                      <div style={{fontSize:10,color:L.t3,marginTop:4,fontFamily:L.mono}}>{v.desc}</div>
                    </div>
                  )
                })}
              </div>
            </div>
            <div style={{display:'flex',gap:12}}>
              <div style={{flex:1}}><SelectInput label="Target engine" value={engine} onChange={setEngine} options={CX_ENGINE_OPTS} req/></div>
              <div style={{flex:1}}><TextInput label="Tenancy (client_id)" value={client} onChange={setClient} placeholder="GLOBAL or client id"/></div>
            </div>
          </div>
        )}

        {step===1 && (
          <div style={{maxWidth:760}}>
            <TextInput label="Outbound exposure name" value={obName} onChange={setObName} placeholder={(name||'New layer')+' exposure'}/>
            <div style={{fontSize:11,fontWeight:700,color:L.t2,margin:'16px 0 6px'}}>Aggregation pyramid · top = aggregated → bottom = granular</div>
            {levels.map((l,i)=>(
              <div key={i} style={{display:'flex',gap:10,alignItems:'flex-end',marginBottom:8,padding:'10px',border:`1px solid ${L.bd}`,borderRadius:8,background:L.s2}}>
                <div style={{width:30,height:30,borderRadius:6,background:L.teal+'1a',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,marginBottom:2}}>
                  <span style={{fontSize:12,fontWeight:800,color:L.teal}}>L{i}</span>
                </div>
                <div style={{flex:1.4}}><TextInput label={i===0?'Grain (level label)':''} value={l.grain} onChange={v=>setLvl(i,'grain',v)} placeholder="e.g. Report aggregate"/></div>
                <div style={{flex:1.6}}><SelectInput label={i===0?'Bound object':''} value={l.bind} onChange={v=>setLvl(i,'bind',v)} options={objOpts} placeholder="Catalog object…"/></div>
                <div style={{flex:1}}><TextInput label={i===0?'Est. cardinality':''} value={l.card} onChange={v=>setLvl(i,'card',v)} placeholder="~12M rows"/></div>
                <Btn label="Remove" small danger onClick={()=>delLvl(i)} disabled={levels.length<=1}/>
              </div>
            ))}
            <Btn label="Add pyramid level" icon={Plus} small onClick={addLvl}/>
          </div>
        )}

        {step===2 && (
          <div style={{maxWidth:760}}>
            <InfoBanner color={L.blue} bg={L.blueBg} text="Pick attributes to expose, grouped by the objects bound in your pyramid. Objects without catalog attributes are introspected at build time."/>
            {pyObjs.length===0 && <div style={{fontSize:12,color:L.t4,marginTop:12}}>No bound objects yet — go back and set a bound object on each pyramid level.</div>}
            {pyObjs.map(obj=>{
              const attrs=(CATALOG[obj]&&CATALOG[obj].attrs)||[]
              const sel=picked[obj]||[]
              return (
                <div key={obj} style={{marginTop:14}}>
                  <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
                    <Database size={13} color={L.t3}/>
                    <span style={{fontSize:12,fontWeight:700,color:L.t1}}>{cxLogicalObj(obj)}</span>
                    <Chip text={`${sel.length} selected`} c={L.teal} bg={L.tealBg} sz={9}/>
                  </div>
                  {attrs.length===0 ? (
                    <div style={{fontSize:11,color:L.t4,paddingLeft:21}}>No catalog attributes — introspected at build.</div>
                  ) : (
                    <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:6,paddingLeft:21}}>
                      {attrs.map(a=>{
                        const on=sel.includes(a.cd)
                        return (
                          <div key={a.cd} onClick={()=>toggleAttr(obj,a.cd)} style={{display:'flex',alignItems:'center',gap:8,padding:'6px 9px',
                            borderRadius:6,cursor:'pointer',border:`1px solid ${on?L.teal:L.bd}`,background:on?L.tealBg:L.s1}}>
                            <div style={{width:15,height:15,borderRadius:4,flexShrink:0,display:'flex',alignItems:'center',justifyContent:'center',
                              background:on?L.teal:L.s1,border:`1px solid ${on?L.teal:L.bd}`}}>{on&&<Check size={10} color="#fff"/>}</div>
                            <span style={{fontSize:11,color:L.t1,flex:1}}>{a.ln||a.cd}</span>
                            {a.semantic && <Chip text={a.semantic} c={(CX_ROLE[a.semantic]||{}).c||L.t3} bg={(CX_ROLE[a.semantic]||{}).bg||L.s3} sz={9}/>}
                          </div>
                        )
                      })}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}

        {step===3 && descriptorPreview && (
          <div style={{maxWidth:820}}>
            <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:12}}>
              <Chip text={descriptorPreview.kind} c={descriptorPreview.color} bg={descriptorPreview.color+'18'}/>
              <Chip text={CX_STRUCT[structure].label} c={CX_STRUCT[structure].c} bg={CX_STRUCT[structure].bg} sz={10}/>
              <Chip text={'engine · '+engine} c={L.t3} bg={L.s3} sz={10}/>
              <Chip text="DRAFT" c={CX_ENV_META.DRAFT.c} bg={CX_ENV_META.DRAFT.bg} sz={10}/>
            </div>
            <div style={{fontSize:11,fontWeight:700,color:L.t2,marginBottom:6}}>Descriptor to be created (served by real backend API/JSON)</div>
            <pre style={{margin:0,background:L.nv,color:'#cfe3f7',borderRadius:8,padding:16,fontSize:11.5,
              fontFamily:L.mono,lineHeight:1.6,overflow:'auto',maxHeight:340}}>{JSON.stringify({
                consumption_layer_cd:descriptorPreview.id, consumption_kind_cd:descriptorPreview.kind,
                exposure_structure_cd:structure, environment_cd:'DRAFT', lifecycle_status_cd:'AUTHORED',
                tenancy_key:'client_id', client_id:client,
                governance:{policy_engine:'OPA (externalized)', preset_source:'governance.policy_preset'},
                outbound_exposures:descriptorPreview.outbounds.map(o=>({
                  exposure_cd:o.id, exposure_nm:o.name, exposure_structure_cd:o.structure, target_engine_cd:o.engine,
                  aggregation_pyramid:o.pyramid.map(p=>({level:p.lvl,grain:p.grain,est_cardinality:p.card,bound_object:cxLogicalObj(p.bind)})),
                  attributes:cxLogicalAttrMap(o.attributes),
                })),
                promotion_path:CX_ENVS,
                binding_endpoint:'/api/semantic-layer/consumption  (POST — real backend)',
              },null,2)}</pre>
          </div>
        )}

        {/* footer nav */}
        <div style={{display:'flex',justifyContent:'space-between',marginTop:18,borderTop:`1px solid ${L.bd}`,paddingTop:14}}>
          <Btn label="Back" onClick={()=>step===0?onCancel():setStep(s=>s-1)}/>
          {step<3
            ? <Btn label="Next" icon={ChevronRight} primary disabled={!canNext} onClick={()=>setStep(s=>s+1)}/>
            : <Btn label="Create in DRAFT" icon={Check} primary onClick={()=>onCreate(build())}/>}
        </div>
      </Card>
    </div>
  )
}

function DownstreamConsumptionScreen() {
  const [userLayers, setUserLayers] = useState([])
  const [envMap, setEnvMap] = useState(SEED_ENV)
  const [sel, setSel] = useState('adhoc')
  const [structOverride, setStructOverride] = useState({})
  const [showJson, setShowJson] = useState(false)
  const [adding, setAdding] = useState(false)

  const allLayers = [...CONSUMPTION_LAYERS, ...userLayers]
  const layer = allLayers.find(l=>l.id===sel) || allLayers[0]
  const structure = structOverride[layer.id] || layer.defaultStructure
  const envIdx = envMap[layer.id]!=null ? envMap[layer.id] : 0
  const totalOutbounds = allLayers.reduce((a,l)=>a+l.outbounds.length,0)
  const deepest = Math.max(...allLayers.flatMap(l=>l.outbounds.map(o=>o.pyramid.length)))

  const onCreate = (lyr)=>{ setUserLayers(p=>[...p,lyr]); setEnvMap(m=>({...m,[lyr.id]:0})); setSel(lyr.id); setAdding(false) }
  const promote  = ()=> setEnvMap(m=>({...m,[layer.id]:Math.min((m[layer.id]!=null?m[layer.id]:0)+1, CX_ENVS.length-1)}))

  if (adding) return <CxWizard onCreate={onCreate} onCancel={()=>setAdding(false)}/>

  const descriptor = {
    consumption_layer_cd: layer.id,
    consumption_kind_cd:  layer.kind,
    exposure_structure_cd: structure,
    environment_cd: CX_ENVS[envIdx],
    lifecycle_status_cd: envIdx===0?'AUTHORED':'DEPLOYED',
    semantic_layer: 'shared',
    tenancy_key: 'client_id',
    governance: { policy_engine: 'OPA (externalized)', preset_source: 'governance.policy_preset' },
    outbound_exposures: layer.outbounds.map(o=>({
      exposure_cd: o.id, exposure_nm: o.name,
      exposure_structure_cd: o.structure, target_engine_cd: o.engine, status_cd: o.status,
      aggregation_pyramid: o.pyramid.map(p=>({ level:p.lvl, grain:p.grain, est_cardinality:p.card, bound_object:cxLogicalObj(p.bind) })),
      ...(o.attributes?{attributes:cxLogicalAttrMap(o.attributes)}:{}),
    })),
    promotion_path: CX_ENVS,
    binding_endpoint: '/api/semantic-layer/consumption/'+layer.id+'/resolve',
    binding_note: 'UI placeholder — this descriptor is served by the real backend API/JSON',
  }

  return (
    <div>
      <PageHdr title="Downstream Consumption" icon={GitBranch}
        sub="The semantic layer is a single horizontal layer exposed to many consumption layers. Each is authored through one consistent descriptor — an exposure structure plus independent outbound exposures, each with an aggregation pyramid — and promoted through environments (SDLC). This screen is a UI simulation; the backend is a real API / JSON contract."
        action={<div style={{display:'flex',gap:8}}>
          <Btn label={showJson?'Hide descriptor':'View descriptor JSON'} icon={Eye} small onClick={()=>setShowJson(s=>!s)}/>
          <Btn label="Add consumption layer" icon={Plus} small primary onClick={()=>setAdding(true)}/>
        </div>}/>

      <InfoBanner color={L.amb} bg={L.ambBg}
        text="PLACEHOLDER — UI simulation only. Adding a layer and promoting it across environments are simulated here; in build they are served by /api/semantic-layer/consumption/* (real API + JSON) with promotion gated by catalog validation, the OPA policy bundle, and governance workflow approval. Policies stay externalized in OPA; tenancy is keyed by client_id; theming flows from TENANT.logoUrl / cssOverrideUrl."/>

      <div style={{display:'flex',gap:10,margin:'16px 0 4px'}}>
        <StatCard value={allLayers.length} label="Consumption layers (horizontal exposure)" icon={Layers} color={L.teal}/>
        <StatCard value={totalOutbounds} label="Independent outbound exposures" icon={GitBranch} color={L.blue}/>
        <StatCard value={CX_ENVS.length} label="SDLC environments · DRAFT→PROD" icon={Shield} color={L.pur}/>
        <StatCard value={deepest} label="Deepest aggregation pyramid (levels)" icon={BarChart2} color={L.amb}/>
      </div>

      <div style={{display:'flex',gap:16,marginTop:14,alignItems:'flex-start'}}>
        {/* consumption layer list */}
        <div style={{width:264,flexShrink:0}}>
          <div style={{fontSize:10,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.08em',margin:'2px 0 8px'}}>Consumption layers</div>
          {allLayers.map(l=>{
            const on = l.id===sel; const e=CX_ENVS[envMap[l.id]!=null?envMap[l.id]:0]; const em=CX_ENV_META[e]
            return (
              <div key={l.id} onClick={()=>setSel(l.id)} style={{
                padding:'11px 12px',borderRadius:9,marginBottom:8,cursor:'pointer',
                background:on?L.s1:'transparent',
                border:`1px solid ${on?l.color:L.bd}`,
                boxShadow:on?`0 0 0 1px ${l.color}`:'none',transition:'border-color .15s'}}>
                <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:5}}>
                  <div style={{width:26,height:26,borderRadius:7,background:l.color+'1a',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                    <GitBranch size={13} color={l.color}/>
                  </div>
                  <span style={{fontSize:13,fontWeight:on?700:600,color:on?l.color:L.t1}}>{l.name}</span>
                </div>
                <div style={{display:'flex',gap:6,flexWrap:'wrap',alignItems:'center'}}>
                  <Chip text={e} c={em.c} bg={em.bg} sz={9}/>
                  <Chip text={l.outbounds.length+' outbound'+(l.outbounds.length>1?'s':'')} c={L.t3} bg={L.s3} sz={9}/>
                  {l.user&&<Chip text="new" c={L.grn} bg={L.grnBg} sz={9}/>}
                </div>
              </div>
            )
          })}
          <div onClick={()=>setAdding(true)} style={{padding:'10px 12px',borderRadius:9,border:`1px dashed ${L.teal}`,
            display:'flex',alignItems:'center',gap:8,color:L.teal,fontSize:12,cursor:'pointer',fontWeight:600,background:L.tealBg}}>
            <Plus size={13}/> Add consumption layer
          </div>
        </div>

        {/* config surface — consistent across every layer */}
        <div style={{flex:1,minWidth:0}}>
          <Card accent={layer.color+'88'}>
            <div style={{display:'flex',alignItems:'center',gap:9,flexWrap:'wrap'}}>
              <h3 style={{margin:0,fontSize:15,fontWeight:700,color:L.t1}}>{layer.name}</h3>
              <Chip text={layer.kind} c={layer.color} bg={layer.color+'18'}/>
              <Chip text={CX_ENVS[envIdx]} c={CX_ENV_META[CX_ENVS[envIdx]].c} bg={CX_ENV_META[CX_ENVS[envIdx]].bg}/>
            </div>
            <p style={{margin:'7px 0 0',fontSize:12,color:L.t3,lineHeight:1.6,maxWidth:640}}>{layer.desc}</p>

            {/* exposure structure — same control on every layer */}
            <div style={{marginTop:16}}>
              <div style={{fontSize:11,fontWeight:700,color:L.t2,marginBottom:6}}>Exposure structure</div>
              <div style={{display:'flex',gap:8}}>
                {Object.entries(CX_STRUCT).map(([k,v])=>{
                  const on = structure===k
                  return (
                    <div key={k} onClick={()=>setStructOverride(m=>({...m,[layer.id]:k}))} style={{
                      flex:1,padding:'10px 12px',borderRadius:8,cursor:'pointer',
                      background:on?v.bg:L.s1,border:`1px solid ${on?v.c:L.bd}`,boxShadow:on?`0 0 0 1px ${v.c}`:'none'}}>
                      <div style={{display:'flex',alignItems:'center',gap:8}}>
                        <v.icon size={15} color={on?v.c:L.t3}/>
                        <span style={{fontSize:12,fontWeight:700,color:on?v.c:L.t2}}>{v.label}</span>
                      </div>
                      <div style={{fontSize:10,color:L.t3,marginTop:4,fontFamily:L.mono}}>{v.desc}</div>
                    </div>
                  )
                })}
              </div>
              <InfoBanner color={L.blue} bg={L.blueBg} text="Every consumption layer is configured through the same descriptor, so the surface stays consistent. The Data Catalog can be exposed as either structure — the choice changes how names resolve, not the underlying governed objects."/>
            </div>

            {/* outbound exposures — independent, each with an aggregation pyramid */}
            <div style={{marginTop:18}}>
              <div style={{fontSize:11,fontWeight:700,color:L.t2,marginBottom:4}}>Outbound exposures · independent, logically connected by aggregation pyramid</div>
              {layer.outbounds.map(o=>{
                const ss = CX_STRUCT[o.structure], st = CX_STATUS[o.status]||CX_STATUS.SIMULATED
                return (
                  <div key={o.id} style={{border:`1px solid ${L.bd}`,borderRadius:9,padding:14,marginTop:10,background:L.s2}}>
                    <div style={{display:'flex',alignItems:'center',gap:8,flexWrap:'wrap'}}>
                      <span style={{fontSize:13,fontWeight:700,color:L.t1}}>{o.name}</span>
                      <Chip text={ss.label} c={ss.c} bg={ss.bg} sz={10}/>
                      <span style={{display:'inline-flex',alignItems:'center',gap:4,fontSize:10,color:L.t3,fontFamily:L.mono}}><Database size={11}/>{o.engine}</span>
                      <Chip text={o.status} c={st.c} bg={st.bg} sz={9}/>
                    </div>
                    <CxPyramid outbound={o} color={layer.color}/>
                  </div>
                )
              })}
            </div>

            {/* SDLC promotion track */}
            <CxEnvTrack envIdx={envIdx} onPromote={promote}/>

            {showJson && (
              <div style={{marginTop:18}}>
                <div style={{fontSize:11,fontWeight:700,color:L.t2,marginBottom:6,display:'flex',alignItems:'center',gap:6}}><Eye size={13}/> Consumption descriptor — served by the real backend API / JSON</div>
                <pre style={{margin:0,background:L.nv,color:'#cfe3f7',borderRadius:8,padding:16,fontSize:11.5,
                  fontFamily:L.mono,lineHeight:1.6,overflow:'auto',maxHeight:360}}>{JSON.stringify(descriptor,null,2)}</pre>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════
// DATA QUALITY · PROFILING · OBSERVABILITY · DQ RULE FLOW · RULE AUTHORING
// The semantic layer does NOT define or execute DQ. Rules are authored and run
// in the external engine. Two entry points: (1) Data Quality — initiate/REQUEST
// only, always via workflow; (2) Rule Authoring (placeholder, external) — author
// a requested rule or author one from scratch. Authored rules show their status
// back in Data Quality. Rules may be single-attribute, cross-attribute, or
// conditional, and carry a plain-English definition.
// ══════════════════════════════════════════════════════════════════════
const DQ_DIMS = ['Completeness','Validity','Conformity','Consistency','Uniqueness','Timeliness']
const CX_RULE_DIMS = ['Completeness','Validity','Conformity','Consistency','Uniqueness']  // rule-authorable dimensions
const DQ_OBJS = ['core.gl_balance','core.loan_contract','core.customer_master','ref.organization_hierarchy','ref.fiscal_period']
const DQ_CELL = {PASS:{c:L.grn,bg:L.grnBg},WARN:{c:L.amb,bg:L.ambBg},FAIL:{c:L.cor,bg:L.corBg},NA:{c:L.t4,bg:L.s3}}
const CX_DIM_INFO = {
  Completeness:{src:'Rule-driven',  desc:'Share of rows where the value is populated (not null / blank).'},
  Validity:    {src:'Rule-driven',  desc:'Values are well-formed against type / format / range.'},
  Conformity:  {src:'Rule-driven',  desc:'Values belong to an allowed reference domain (lookup / reference data).'},
  Consistency: {src:'Rule-driven',  desc:'Cross-attribute & conditional checks hold (if-then, mutual consistency).'},
  Uniqueness:  {src:'Rule-driven',  desc:'No improper duplication on a key or business identity.'},
  Timeliness:  {src:'Observability',desc:'Data is current / on time — derived from the observability plane (freshness / SLA), not a row rule.'},
}
const OBS_EVENTS = [
  {obj:'core.gl_balance',            type:'Freshness',          sev:'WARN', detail:'02:00 load completed 2h 40m late',          ts:'2026-06-16 04:41', st:'OPEN'},
  {obj:'core.customer_master',       type:'Null-rate spike',    sev:'HIGH', detail:'Email Address null-rate 0.4% → 13.7%',       ts:'2026-06-16 03:12', st:'TRIAGE'},
  {obj:'core.loan_contract',         type:'Volume',             sev:'WARN', detail:'Row count -18% vs 30-day median',            ts:'2026-06-15 23:05', st:'OPEN'},
  {obj:'core.gl_balance',            type:'Schema drift',       sev:'INFO', detail:'New column observed at source (unmapped)',    ts:'2026-06-15 21:40', st:'ACK'},
  {obj:'ref.organization_hierarchy', type:'Distribution shift', sev:'INFO', detail:'Legal-entity cardinality +6% week-over-week', ts:'2026-06-15 18:22', st:'RESOLVED'},
]
const OBS_SEV = {HIGH:{c:L.cor,bg:L.corBg},WARN:{c:L.amb,bg:L.ambBg},INFO:{c:L.blue,bg:L.blueBg}}
const OBS_ST  = {OPEN:{c:L.cor,bg:L.corBg},TRIAGE:{c:L.amb,bg:L.ambBg},ACK:{c:L.blue,bg:L.blueBg},RESOLVED:{c:L.grn,bg:L.grnBg}}
const DQ_NULLS = [0.0,0.3,1.2,3.4,6.8,11.5]

function cxAttrCell(attr, j, k){
  if (k===0){ if (!attr.nullable) return {st:'PASS',v:'100'}
    const n=DQ_NULLS[j%DQ_NULLS.length]; const st=n>10?'FAIL':n>5?'WARN':'PASS'; return {st, v:(100-n).toFixed(1)} }
  const s=(j*7+k*3)%23
  if (s<2) return {st:'FAIL', v:(86+s).toFixed(1)}
  if (s<6) return {st:'WARN', v:(92+(s%5)).toFixed(1)}
  return {st:'PASS', v:(99+(s%9)/10).toFixed(1)}
}
// a dimension is "measured" only where an ACTIVE rule of that dimension covers it
const ruleCovers=(rules,obj,a,dim)=> rules.some(r=>r.status==='ACTIVE' && r.obj===obj && r.dim===dim && ((r.attrs&&r.attrs.includes(a))||r.attr===a))
const objCovers =(rules,obj,dim)=> rules.some(r=>r.status==='ACTIVE' && r.obj===obj && r.dim===dim)
function timelinessFor(obj){
  const evs=OBS_EVENTS.filter(e=>e.obj===obj && (e.type==='Freshness'||e.type==='Volume') && (e.st==='OPEN'||e.st==='TRIAGE'))
  if (evs.some(e=>e.sev==='HIGH')) return {st:'FAIL', label:'Late'}
  if (evs.length) return {st:'WARN', label:'Delayed'}
  return {st:'PASS', label:'On time'}
}
function objCellMock(o,k){ const h=(o.length*3+k*5)%17; if (h<2) return {st:'FAIL',v:(87+h).toFixed(1)}; if (h<5) return {st:'WARN',v:(93+(h%4)).toFixed(1)}; return {st:'PASS',v:(99+(h%9)/10).toFixed(1)} }
function MxCell({kind,c}){
  if (kind==='unmeasured') return <div style={{flex:1,display:'flex',justifyContent:'center'}}><span title="No active rule of this dimension" style={{fontSize:10,color:L.t4,padding:'3px 8px',borderRadius:6,background:L.s3,border:`1px dashed ${L.bd}`}}>—</span></div>
  if (kind==='time'){ const cc=DQ_CELL[c.st]; return <div style={{flex:1,display:'flex',justifyContent:'center'}}><span style={{fontSize:10,fontWeight:700,color:cc.c,background:cc.bg,border:`1px solid ${cc.c}33`,borderRadius:6,padding:'3px 8px'}}>{c.label}</span></div> }
  const cc=DQ_CELL[c.st]||DQ_CELL.NA; return <div style={{flex:1,display:'flex',justifyContent:'center'}}><div style={{minWidth:48,textAlign:'center',padding:'4px 7px',borderRadius:6,background:cc.bg,color:cc.c,fontSize:11,fontWeight:700,border:`1px solid ${cc.c}33`}}>{c.v}%</div></div>
}

// ── rule model ──
const CX_SCOPE = {
  ATTRIBUTE:      {label:'Single attribute', short:'Attribute',  c:L.teal, bg:L.tealBg},
  CROSS_ATTRIBUTE:{label:'Cross-attribute',  short:'Cross-attr', c:L.pur,  bg:L.purBg},
  CONDITIONAL:    {label:'Conditional',      short:'Conditional',c:L.amb,  bg:L.ambBg},
}
const CX_RULE_ST = {
  ACTIVE:   {c:L.grn, bg:L.grnBg},
  AUTHORING:{c:L.blue,bg:L.blueBg},
  REQUESTED:{c:L.amb, bg:L.ambBg},
}
const CX_OPS = ['=','≠','in','>','<','≥','≤']
const CX_CHECKS = ['must not be null','must be null','must be in domain','must be positive','must match pattern','must equal']
const objAttrsOf = (o)=> ((CATALOG[o]&&CATALOG[o].attrs)||[]).map(a=>a.ln||a.cd)

function cxPlainEnglish(r){
  if (r.plainEnglish) return r.plainEnglish
  if (r.scope==='CONDITIONAL' && r.condition){ const c=r.condition
    return `If ${c.ifAttr||'…'} ${c.op||'='} ${c.value||'…'} then ${c.thenAttr||'…'} ${c.thenCheck||'must not be null'}.` }
  const th = r.threshold && r.threshold!=='—' ? ` (${r.threshold})` : ''
  if (r.scope==='CROSS_ATTRIBUTE'){ return `${(r.attrs||[r.attr]).join(' and ')} must be mutually consistent${th}.` }
  if (r.dim==='Completeness') return `${r.attr} must not be null${th}.`
  if (r.dim==='Validity')     return `${r.attr} must conform to its domain${th}.`
  if (r.dim==='Uniqueness')   return `${r.attr} must be unique${th}.`
  return `${r.attr} must satisfy the ${r.dim} check${th}.`
}

const CX_RULE_SEED = [
  {id:'r_iso',  rid:'DQR-0001', tenant:'GLOBAL', name:'Currency conforms to ISO_CURRENCY', obj:'core.gl_balance', attr:'Currency', attrs:['Currency'], scope:'ATTRIBUTE', dim:'Validity', threshold:'100%', status:'ACTIVE', origin:'AUTHORED', result:'PASS · 99.2%', lastRun:'2026-05-28 02:14', by:'system', plainEnglish:'Currency must conform to the ISO_CURRENCY domain (100%).', ts:'2026-04-12 09:20', events:[
    {t:'Benchmark refreshed', date:'2026-05-28', desc:'99.2% pass vs ISO_CURRENCY domain.', by:'system'},
    {t:'Activated', badge:'ACTIVE', date:'2026-04-12', desc:'Rule active in the execution engine.', by:'a.rao', team:'Data Quality'},
    {t:'Authored', badge:'AUTHORING', date:'2026-04-10', desc:'Validity check formalised against ISO_CURRENCY.', by:'a.rao', team:'Data Quality'},
    {t:'Requested', badge:'REQUESTED', date:'2026-04-02', desc:'Currency must conform to ISO_CURRENCY.', by:'m.lin', team:'Reg Reporting'},
    {t:'Created (draft)', badge:'DRAFT', date:'2026-04-02', desc:'Rule DQR-0001 drafted.', by:'m.lin', team:'Reg Reporting'},
  ]},
  {id:'r_le',   rid:'DQR-0002', tenant:'GLOBAL', name:'Legal Entity completeness',          obj:'core.gl_balance', attr:'Legal Entity', attrs:['Legal Entity'], scope:'ATTRIBUTE', dim:'Completeness', threshold:'≥ 99.5%', status:'ACTIVE', origin:'AUTHORED', result:'PASS · 99.8%', lastRun:'2026-05-28 02:14', by:'system', plainEnglish:'Legal Entity must not be null (≥ 99.5%).', ts:'2026-03-22 14:05', events:[
    {t:'Activated', badge:'ACTIVE', date:'2026-03-22', desc:'Rule active in the execution engine.', by:'a.rao', team:'Data Quality'},
    {t:'Authored', badge:'AUTHORING', date:'2026-03-20', desc:'Completeness threshold set to ≥ 99.5%.', by:'a.rao', team:'Data Quality'},
    {t:'Requested', badge:'REQUESTED', date:'2026-03-15', desc:'Legal Entity must always be populated.', by:'s.gupta', team:'Reg Reporting'},
    {t:'Created (draft)', badge:'DRAFT', date:'2026-03-15', desc:'Rule DQR-0002 drafted.', by:'s.gupta', team:'Reg Reporting'},
  ]},
  {id:'r_cond', rid:'DQR-0003', tenant:'BHC_A001', name:'Loan accounts require description',  obj:'core.gl_balance', attr:'Account Code', attrs:['Account Code','Account Description'], scope:'CONDITIONAL', dim:'Consistency', threshold:'100%', status:'ACTIVE', origin:'AUTHORED', result:'WARN · 97.4%', lastRun:'2026-05-26 02:14', by:'r.shah', condition:{ifAttr:'Account Code', op:'in', value:'LOAN accounts', thenAttr:'Account Description', thenCheck:'must not be null'}, plainEnglish:'If Account Code in LOAN accounts then Account Description must not be null.', ts:'2026-05-02 11:30', events:[
    {t:'Finding raised', badge:'AUTHORING', date:'2026-05-26', desc:'WARN · 97.4% — 2.6% of loan rows missing description.', by:'system'},
    {t:'Activated', badge:'ACTIVE', date:'2026-05-02', desc:'Conditional rule active in the execution engine.', by:'r.shah', team:'Data Quality'},
    {t:'Authored', badge:'AUTHORING', date:'2026-04-29', desc:'IF/THEN condition formalised from the request.', by:'r.shah', team:'Data Quality'},
    {t:'Requested', badge:'REQUESTED', date:'2026-04-21', desc:'Loan accounts should always carry a description.', by:'you', team:'Reg Reporting'},
    {t:'Created (draft)', badge:'DRAFT', date:'2026-04-21', desc:'Rule DQR-0003 drafted.', by:'you', team:'Reg Reporting'},
  ]},
  {id:'r_cross',rid:'DQR-0004', tenant:'BHC_B002', name:'Booking currency consistency',       obj:'core.gl_balance', attr:'Currency', attrs:['Currency','GL Balance ID'], scope:'CROSS_ATTRIBUTE', dim:'Consistency', threshold:'—', status:'AUTHORING', origin:'AUTHORED', result:'—', lastRun:'—', by:'a.kumar', plainEnglish:'Currency and GL Balance ID must be mutually consistent on the same record.', ts:'2026-06-04 16:10', events:[
    {t:'In authoring', badge:'AUTHORING', date:'2026-06-04', desc:'Author formalising the cross-attribute consistency check.', by:'a.kumar', team:'Data Quality'},
    {t:'Requested', badge:'REQUESTED', date:'2026-06-01', desc:'Booking currency must match the balance record.', by:'m.lin', team:'Reg Reporting'},
    {t:'Created (draft)', badge:'DRAFT', date:'2026-06-01', desc:'Rule DQR-0004 drafted.', by:'m.lin', team:'Reg Reporting'},
  ]},
]
let _ridSeq=4
const nextRid=()=>'DQR-'+String(++_ridSeq).padStart(4,'0')
let _cxRules=CX_RULE_SEED.slice(); const _cxSubs=new Set()
const cxRules={
  all:()=>_cxRules,
  add:(r)=>{_cxRules=[r,..._cxRules];_cxSubs.forEach(f=>f())},
  update:(id,patch)=>{_cxRules=_cxRules.map(r=>r.id===id?{...r,...patch}:r);_cxSubs.forEach(f=>f())},
}
function useCxRules(){ const [,f]=useState(0); useEffect(()=>{ const fn=()=>f(x=>x+1); _cxSubs.add(fn); return ()=>_cxSubs.delete(fn) },[]); return _cxRules }
const rulesForAttr=(rules,obj,a)=> rules.filter(r=>r.obj===obj && ((r.attrs&&r.attrs.includes(a))||r.attr===a))

// ── append-only history: events newest-first ──
const HIST_BADGE={ACTIVE:{c:L.grn,bg:L.grnBg},REQUESTED:{c:L.amb,bg:L.ambBg},DRAFT:{c:L.t3,bg:L.s3},AUTHORING:{c:L.blue,bg:L.blueBg},WORKFLOW:{c:L.pur,bg:L.purBg}}
const HIST_DOT={ACTIVE:L.grn,REQUESTED:L.amb,DRAFT:L.t4,AUTHORING:L.blue,WORKFLOW:L.pur}
function cxLastRun(r){
  if (!r.lastRun || r.lastRun==='—') return {ts:'—', note:'not yet executed', c:L.t4}
  if (r.lastRun==='pending')         return {ts:'pending', note:'awaiting first run', c:L.amb}
  return {ts:r.lastRun, note:r.result||'', c:/FAIL/.test(r.result||'')?L.cor:/WARN/.test(r.result||'')?L.amb:L.grn}
}
function cxRuleEvents(r){
  if (r.events && r.events.length) return r.events
  const d=(r.ts||'2026-05-01').slice(0,10); const ev=[]
  if (r.status==='ACTIVE')    ev.push({t:'Activated',  badge:'ACTIVE',   date:d, desc:'Rule active in the execution engine.', by:r.by||'author', team:'Data Quality'})
  if (r.status==='AUTHORING') ev.push({t:'In authoring',badge:'AUTHORING',date:d, desc:'Author formalising scope, condition, threshold.', by:r.by||'author', team:'Data Quality'})
  if (r.status==='REQUESTED') ev.push({t:'Requested',  badge:'REQUESTED',date:d, desc:cxPlainEnglish(r), by:r.by||'you', team:'Reg Reporting'})
  ev.push({t:'Created (draft)', badge:'DRAFT', date:d, desc:`Rule ${r.rid||''} created.`, by:r.by||'you', team:'Reg Reporting'})
  return ev
}
function HistoryTimeline({events}){
  return (
    <div>
      <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:16}}>
        <span style={{fontSize:12,fontWeight:700,color:L.t1,padding:'3px 10px',background:L.s3,borderRadius:20}}>{events.length} events</span>
        <span style={{fontSize:12,color:L.t4}}>newest first</span>
      </div>
      <div>
        {events.map((e,i)=>{const bd=e.badge&&HIST_BADGE[e.badge]; const dot=(e.badge&&HIST_DOT[e.badge])||L.t4; const last=i===events.length-1; return (
          <div key={i} style={{display:'flex',gap:13,paddingBottom:last?0:18}}>
            <div style={{display:'flex',flexDirection:'column',alignItems:'center',flexShrink:0}}>
              <div style={{width:11,height:11,borderRadius:'50%',background:dot,marginTop:3,flexShrink:0}}/>
              {!last&&<div style={{width:2,flex:1,background:L.bd,marginTop:3}}/>}
            </div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{display:'flex',alignItems:'center',gap:8,flexWrap:'wrap',marginBottom:3}}>
                <span style={{fontSize:13,fontWeight:700,color:L.t1}}>{e.t}</span>
                {bd&&<span style={{fontSize:9,fontWeight:700,color:bd.c,background:bd.bg,padding:'1px 7px',borderRadius:4,textTransform:'uppercase',letterSpacing:'.03em'}}>{e.badge}</span>}
                <span style={{fontSize:11,color:L.t4,marginLeft:'auto'}}>{e.date}</span>
              </div>
              {e.desc&&<div style={{fontSize:12,color:L.t2,lineHeight:1.45,marginBottom:3}}>{e.desc}</div>}
              {e.by&&<div style={{fontSize:11,color:L.t4}}>by {e.by}{e.team?` · ${e.team}`:''}</div>}
            </div>
          </div>)})}
      </div>
    </div>
  )
}
function Drawer({open,onClose,eyebrow,title,sub,children,footer,width=440}){
  return (
    <Fragment>
      <div onClick={onClose} style={{position:'fixed',inset:0,background:'rgba(15,30,53,.28)',opacity:open?1:0,pointerEvents:open?'auto':'none',transition:'opacity .2s',zIndex:1000}}/>
      <div style={{position:'fixed',top:0,right:0,height:'100vh',width:`min(${width}px,94vw)`,background:L.s1,borderLeft:`1px solid ${L.bd}`,boxShadow:'-12px 0 32px rgba(15,30,53,.16)',transform:open?'translateX(0)':'translateX(101%)',transition:'transform .24s cubic-bezier(.4,0,.2,1)',zIndex:1001,display:'flex',flexDirection:'column'}}>
        <div style={{padding:'16px 20px',borderBottom:`1px solid ${L.bd}`,flexShrink:0}}>
          <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',gap:12}}>
            <div style={{minWidth:0}}>
              {eyebrow&&<div style={{display:'flex',alignItems:'center',gap:6,fontSize:10,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.08em',marginBottom:6}}><History size={12}/>{eyebrow}</div>}
              <div style={{fontSize:16,fontWeight:700,color:L.t1}}>{title}</div>
              {sub&&<div style={{fontSize:12,color:L.t3,marginTop:2}}>{sub}</div>}
            </div>
            <button onClick={onClose} style={{background:'none',border:'none',cursor:'pointer',color:L.t4,fontSize:22,lineHeight:1,padding:2,flexShrink:0}}
              onMouseEnter={e=>e.currentTarget.style.color=L.t1} onMouseLeave={e=>e.currentTarget.style.color=L.t4}>×</button>
          </div>
        </div>
        <div style={{padding:'18px 20px',overflowY:'auto',flex:1}}>{children}</div>
        {footer&&<div style={{padding:'12px 20px',borderTop:`1px solid ${L.bd}`,flexShrink:0,fontSize:11,color:L.t4,display:'flex',gap:7,alignItems:'flex-start'}}><Shield size={13} style={{flexShrink:0,marginTop:1}}/><span>{footer}</span></div>}
      </div>
    </Fragment>
  )
}

// ── shared form bits ──
function ScopePicker({value,onChange}){ return (
  <div style={{display:'flex',gap:8}}>{Object.entries(CX_SCOPE).map(([k,v])=>{const on=value===k;return(
    <div key={k} onClick={()=>onChange(k)} style={{flex:1,padding:'8px 10px',borderRadius:7,cursor:'pointer',textAlign:'center',
      background:on?v.bg:L.s1,border:`1px solid ${on?v.c:L.bd}`,boxShadow:on?`0 0 0 1px ${v.c}`:'none'}}>
      <span style={{fontSize:11,fontWeight:700,color:on?v.c:L.t2}}>{v.label}</span></div>)})}</div>) }
function AttrMulti({options,selected,onToggle,exclude}){ const opts=options.filter(o=>o!==exclude); return (
  <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:6}}>{opts.map(o=>{const on=selected.includes(o);return(
    <div key={o} onClick={()=>onToggle(o)} style={{display:'flex',alignItems:'center',gap:7,padding:'5px 8px',borderRadius:6,cursor:'pointer',
      border:`1px solid ${on?L.teal:L.bd}`,background:on?L.tealBg:L.s1}}>
      <div style={{width:13,height:13,borderRadius:3,background:on?L.teal:L.s1,border:`1px solid ${on?L.teal:L.bd}`,display:'flex',alignItems:'center',justifyContent:'center'}}>{on&&<Check size={9} color="#fff"/>}</div>
      <span style={{fontSize:11,color:L.t1}}>{o}</span></div>)})}</div>) }
function CondBuilder({attrs,cond,onChange}){ const set=(k,v)=>onChange({...cond,[k]:v}); return (
  <div style={{display:'flex',flexWrap:'wrap',gap:8,alignItems:'flex-end'}}>
    <span style={{fontSize:11,fontWeight:700,color:L.t3,paddingBottom:9}}>IF</span>
    <div style={{width:160}}><SelectInput label="" value={cond.ifAttr} onChange={v=>set('ifAttr',v)} options={attrs} placeholder="attribute"/></div>
    <div style={{width:70}}><SelectInput label="" value={cond.op} onChange={v=>set('op',v)} options={CX_OPS}/></div>
    <div style={{width:150}}><TextInput label="" value={cond.value} onChange={v=>set('value',v)} placeholder="value"/></div>
    <span style={{fontSize:11,fontWeight:700,color:L.t3,paddingBottom:9}}>THEN</span>
    <div style={{width:160}}><SelectInput label="" value={cond.thenAttr} onChange={v=>set('thenAttr',v)} options={attrs} placeholder="attribute"/></div>
    <div style={{width:170}}><SelectInput label="" value={cond.thenCheck} onChange={v=>set('thenCheck',v)} options={CX_CHECKS}/></div>
  </div>) }
function PlainPreview({rule}){ return (
  <div style={{padding:'9px 12px',background:L.s3,borderRadius:7,border:`1px solid ${L.bd}`,fontSize:12,color:L.t1,lineHeight:1.5}}>
    <span style={{fontSize:10,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.05em',marginRight:8}}>Plain English</span>{cxPlainEnglish(rule)}</div>) }

// ── plain-English input with @attribute mentions ──
const CX_THRESHOLDS = ['100%','≥ 99.9%','≥ 99.5%','≥ 99%','≥ 95%','≥ 90%','> 0','≥ 0','= 0','≤ 100%','within ±1%','within ±5%']
function MentionInput({value,onChange,options,numerics,placeholder,rows=3}){
  const ref=useRef(null)
  const [menu,setMenu]=useState(null)
  const scan=(text,caret)=>{ const up=text.slice(0,caret); const m=up.match(/([@#])([A-Za-z0-9_%.±]*)$/); setMenu(m?{trig:m[1],q:m[2],start:caret-m[0].length}:null) }
  const onText=(e)=>{ onChange(e.target.value); scan(e.target.value,e.target.selectionStart) }
  const pick=(opt)=>{ const el=ref.current; const caret=el?el.selectionStart:value.length; const before=value.slice(0,menu.start); const after=value.slice(caret); const next=before+opt+' '+after; onChange(next); setMenu(null); setTimeout(()=>{ if(el){el.focus(); const p=(before+opt+' ').length; el.setSelectionRange(p,p)} },0) }
  const src=menu?(menu.trig==='#'?(numerics||CX_THRESHOLDS):options):[]
  const filtered=menu?src.filter(o=>o.toLowerCase().includes((menu.q||'').toLowerCase())).slice(0,8):[]
  const isNum=menu&&menu.trig==='#'
  return (
    <div style={{position:'relative'}}>
      <textarea ref={ref} value={value} onChange={onText} onKeyUp={(e)=>scan(e.target.value,e.target.selectionStart)} onClick={(e)=>scan(e.target.value,e.target.selectionStart)} onBlur={()=>setTimeout(()=>setMenu(null),150)} placeholder={placeholder} rows={rows}
        style={{width:'100%',padding:'8px 10px',border:`1px solid ${L.bd}`,borderRadius:6,fontSize:13,color:L.t1,resize:'vertical',boxSizing:'border-box',outline:'none',lineHeight:1.6,fontFamily:L.font}}/>
      {menu && filtered.length>0 && (
        <div style={{position:'absolute',top:'100%',left:0,marginTop:4,zIndex:30,minWidth:240,maxHeight:200,overflow:'auto',background:L.s1,border:`1px solid ${L.bd}`,borderRadius:8,boxShadow:'0 6px 18px rgba(14,30,53,0.12)'}}>
          <div style={{padding:'6px 10px',fontSize:10,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.05em',borderBottom:`1px solid ${L.s3}`}}>{isNum?'Insert threshold / value':'Insert attribute'}</div>
          {filtered.map(o=>(<div key={o} onMouseDown={(e)=>{e.preventDefault();pick(o)}} style={{padding:'7px 10px',fontSize:12,color:L.t1,cursor:'pointer',display:'flex',alignItems:'center',gap:7}}
            onMouseEnter={e=>e.currentTarget.style.background=L.s3} onMouseLeave={e=>e.currentTarget.style.background='transparent'}>{isNum?<BarChart2 size={12} color={L.amb}/>:<Tag size={12} color={L.teal}/>}<span style={isNum?{fontFamily:L.mono}:{}}>{o}</span></div>))}
        </div>)}
    </div>
  )
}

// ── request form (Data Quality — plain-English REQUEST only, opens as a Draft tab) ──
function RuleRequestForm({ draftId, obj:obj0, attr:attr0, onSubmit, onCancel }){
  const [obj,setObj]=useState(obj0||DQ_OBJS[0])
  const allAttrs=objAttrsOf(obj)
  const [attr,setAttr]=useState(attr0||allAttrs[0]||'')
  const [name,setName]=useState(attr0?`${attr0} — `:'')
  const [dim,setDim]=useState('Completeness')
  const [text,setText]=useState('')
  const [just,setJust]=useState('')
  const [tenant,setTenant]=useState('GLOBAL')
  useEffect(()=>{ if(!objAttrsOf(obj).includes(attr)) setAttr(objAttrsOf(obj)[0]||'') },[obj])
  const mentioned=allAttrs.filter(a=>text.includes(a))
  const attrs=[...new Set([attr,...mentioned].filter(Boolean))]
  const extra=mentioned.filter(a=>a!==attr)
  const scope=/\bif\b[\s\S]*\bthen\b/i.test(text)?'CONDITIONAL':(extra.length>0?'CROSS_ATTRIBUTE':'ATTRIBUTE')
  const sc=CX_SCOPE[scope]
  const ok=name.trim() && text.trim() && obj && attr
  return (
    <div style={{border:`1px solid ${L.teal}`,borderRadius:10,overflow:'hidden',background:L.s1}}>
      <div style={{display:'flex',alignItems:'center',gap:10,padding:'10px 16px',background:L.tealBg,borderBottom:`1px solid ${L.teal}44`}}>
        <span style={{color:L.amb,fontSize:11}}>●</span>
        <span style={{fontSize:13,fontWeight:700,color:L.tealDk}}>Request a DQ rule</span>
        <span style={{fontFamily:L.mono,fontSize:11,fontWeight:700,color:L.t3,background:L.s1,padding:'2px 8px',borderRadius:5,border:`1px solid ${L.bd}`}}>{draftId}</span>
        <span style={{marginLeft:'auto',fontSize:10,color:L.tealDk}}>Plain-English request · author formalises in Rule Authoring</span>
      </div>
      <div style={{padding:16}}>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:12,marginBottom:10}}>
          <SelectInput label="Object (logical)" value={obj} onChange={setObj} options={DQ_OBJS.map(o=>({v:o,l:cxLogicalObj(o)}))} req/>
          <SelectInput label="Primary attribute" value={attr} onChange={setAttr} options={allAttrs} req/>
          <SelectInput label="Scope (tenant)" value={tenant} onChange={setTenant} options={[{v:'GLOBAL',l:'Global (all tenants)'},{v:'BHC_A001',l:'BHC_A001'},{v:'BHC_B002',l:'BHC_B002'}]}/>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1.6fr 1fr',gap:12,marginBottom:10}}>
          <TextInput label="Proposed rule name" value={name} onChange={setName} req placeholder="e.g. Loan accounts require description"/>
          <SelectInput label="Suggested dimension" value={dim} onChange={setDim} options={CX_RULE_DIMS}/>
        </div>
        <label style={{display:'block',fontSize:11,fontWeight:600,color:L.t2,marginBottom:5}}>Requirement in plain English<span style={{color:L.cor}}> *</span> <span style={{color:L.t4,fontWeight:400}}>— type <b>@</b> for an attribute, <b>#</b> for a threshold / value</span></label>
        <MentionInput value={text} onChange={setText} options={allAttrs} numerics={CX_THRESHOLDS} rows={3}
          placeholder="Describe the check in plain English. e.g. @Legal Entity must be populated #≥ 99.5% of the time, or If @Account Code is a loan then @Account Description must not be null."/>
        <div style={{display:'flex',alignItems:'center',gap:8,flexWrap:'wrap',margin:'10px 0'}}>
          <span style={{fontSize:11,color:L.t3}}>Detected:</span>
          <Chip text={sc.short} c={sc.c} bg={sc.bg} sz={9}/>
          {attrs.map(a=><Chip key={a} text={'@'+a} c={L.t3} bg={L.s3} sz={9}/>)}
          {CX_THRESHOLDS.filter(t=>text.includes(t)).map(t=><Chip key={t} text={'#'+t} c={L.ambDk} bg={L.ambBg} sz={9}/>)}
        </div>
        <div style={{marginBottom:12}}><TextInput label="Business justification" value={just} onChange={setJust} placeholder="Regulatory driver, CDE…"/></div>
        <div style={{display:'flex',gap:8,justifyContent:'flex-end',alignItems:'center'}}>
          <span style={{fontSize:10,color:L.t4,marginRight:'auto'}}>The semantic layer never authors or executes the rule.</span>
          <Btn label="Discard" small onClick={onCancel}/>
          <Btn label="Submit request → Rule Authoring" icon={ChevronRight} small primary disabled={!ok}
            onClick={()=>onSubmit({obj,attr,tenant,name:name.trim(),scope,attrs,dim,threshold:'—',condition:null,plainEnglish:text.trim(),req:'',just:just.trim()})}/>
        </div>
      </div>
    </div>
  )
}

// ── author form (Rule Authoring — author requested or from scratch) ──
function RuleAuthorForm({ initial, onSave, onCancel }){
  const [obj,setObj]=useState(initial?initial.obj:'core.gl_balance')
  const allAttrs=objAttrsOf(obj)
  const [name,setName]=useState(initial?initial.name:'')
  const [attr,setAttr]=useState(initial?initial.attr:(allAttrs[0]||''))
  const [scope,setScope]=useState(initial?initial.scope:'ATTRIBUTE')
  const [extra,setExtra]=useState(initial&&initial.attrs?initial.attrs.filter(a=>a!==initial.attr):[])
  const [cond,setCond]=useState(initial&&initial.condition?initial.condition:{ifAttr:'',op:'=',value:'',thenAttr:'',thenCheck:'must not be null'})
  const [dim,setDim]=useState(initial?initial.dim:'Completeness')
  const [threshold,setThreshold]=useState(initial?initial.threshold:'')
  const [pe,setPe]=useState(initial?cxPlainEnglish(initial):'')
  const [tenant,setTenant]=useState(initial?(initial.tenant||'GLOBAL'):'GLOBAL')
  const effDim=scope==='ATTRIBUTE'?dim:'Consistency'
  const attrs=scope==='ATTRIBUTE'?[attr]:scope==='CROSS_ATTRIBUTE'?[attr,...extra]:[cond.ifAttr,cond.thenAttr].filter(Boolean)
  const gen={scope,attr,attrs,dim:effDim,threshold,condition:cond}
  const ok=name.trim() && attr && (scope!=='CONDITIONAL'||(cond.ifAttr&&cond.thenAttr))
  return (
    <div style={{margin:'8px 0 12px',padding:16,border:`1px solid ${L.blue}`,borderRadius:9,background:L.blueBg}}>
      <div style={{fontSize:13,fontWeight:700,color:L.blueDk,marginBottom:12,display:'flex',alignItems:'center',gap:7}}><Edit2 size={14}/> {initial?`Author requested rule — ${initial.name}`:'Author new rule (from scratch)'}</div>
      <div style={{display:'grid',gridTemplateColumns:'1.6fr 1fr',gap:12,marginBottom:10}}>
        <TextInput label="Rule name" value={name} onChange={setName} req/>
        <SelectInput label="DQ dimension" value={scope==='ATTRIBUTE'?dim:'Consistency'} onChange={setDim} options={CX_RULE_DIMS} req disabled={scope!=='ATTRIBUTE'}/>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:12,marginBottom:10}}>
        <SelectInput label="Object" value={obj} onChange={(v)=>{setObj(v);setAttr(objAttrsOf(v)[0]||'')}} options={DQ_OBJS.map(o=>({v:o,l:cxLogicalObj(o)}))}/>
        <SelectInput label="Primary attribute" value={attr} onChange={setAttr} options={allAttrs}/>
        <SelectInput label="Scope (tenant)" value={tenant} onChange={setTenant} options={[{v:'GLOBAL',l:'Global (all tenants)'},{v:'BHC_A001',l:'BHC_A001'},{v:'BHC_B002',l:'BHC_B002'}]}/>
      </div>
      <div style={{marginBottom:10}}><label style={{display:'block',fontSize:11,fontWeight:600,color:L.t2,marginBottom:6}}>Rule type</label><ScopePicker value={scope} onChange={setScope}/></div>
      {scope==='CROSS_ATTRIBUTE' && <div style={{marginBottom:10}}><label style={{display:'block',fontSize:11,fontWeight:600,color:L.t2,marginBottom:6}}>Also involves</label><AttrMulti options={allAttrs} selected={extra} exclude={attr} onToggle={(o)=>setExtra(s=>s.includes(o)?s.filter(x=>x!==o):[...s,o])}/></div>}
      {scope==='CONDITIONAL' && <div style={{marginBottom:10}}><CondBuilder attrs={allAttrs} cond={cond} onChange={setCond}/></div>}
      <div style={{display:'grid',gridTemplateColumns:'1fr 2fr',gap:12,marginBottom:10}}>
        <TextInput label="Threshold" value={threshold} onChange={setThreshold} placeholder="e.g. 100%"/>
        <TextInput label="Plain-English definition" value={pe} onChange={setPe} placeholder={cxPlainEnglish(gen)}/>
      </div>
      <div style={{marginBottom:12}}><PlainPreview rule={{...gen,plainEnglish:pe||cxPlainEnglish(gen)}}/></div>
      <div style={{display:'flex',gap:8,justifyContent:'flex-end'}}>
        <Btn label="Cancel" small onClick={onCancel}/>
        <Btn label={initial?'Author & activate':'Create & activate'} icon={Check} small primary disabled={!ok}
          onClick={()=>onSave({name:name.trim(),obj,attr,tenant,attrs,scope,dim:effDim,threshold:threshold.trim()||'—',condition:scope==='CONDITIONAL'?cond:null,plainEnglish:pe.trim()||cxPlainEnglish(gen)})}/>
      </div>
      <div style={{fontSize:10,color:L.blueDk,marginTop:8}}>Placeholder for the external authoring/execution engine. On save the rule becomes ACTIVE and its status appears in Data Quality.</div>
    </div>
  )
}

function DataQualityScreen({ onNav }) {
  const [tab,setTab]=useState('matrix')
  const [expObj,setExpObj]=useState('core.gl_balance')
  const [drafts,setDrafts]=useState([])
  const [activeId,setActiveId]=useState(null)
  const [defsFor,setDefsFor]=useState(null)
  const [flash,setFlash]=useState(null)
  const [dimInfo,setDimInfo]=useState(false)
  const [histRule,setHistRule]=useState(null)
  const [dqTenant,setDqTenant]=useState('ALL')
  const rules=useCxRules()
  const openFindings=rules.filter(r=>/WARN|FAIL/.test(r.result||'')).length + DQ_OBJS.filter(o=>timelinessFor(o).st!=='PASS').length
  const nameCol={flex:'0 0 210px'}, rulesCol={flex:'0 0 70px'}, actCol={flex:'0 0 118px'}

  const openDraft=(ctx={})=>{ const id=randId('REQ'); setDrafts(p=>[...p,{id,...ctx}]); setActiveId(id) }
  const closeDraft=(id)=>{ setDrafts(p=>{ const rem=p.filter(d=>d.id!==id); if(activeId===id) setTimeout(()=>setActiveId(rem.length?rem[rem.length-1].id:null),0); return rem }) }

  const submitReq=(form)=>{
    const rid=nextRid(); const date=new Date().toISOString().slice(0,10); const ts=new Date().toISOString().slice(0,16).replace('T',' ')
    cxRules.add({id:'req_'+Date.now(), rid, name:form.name, obj:form.obj, attr:form.attr, tenant:form.tenant||'GLOBAL', attrs:form.attrs, scope:form.scope, condition:form.condition,
      dim:form.dim, threshold:form.threshold, status:'REQUESTED', origin:'REQUESTED', result:'—', lastRun:'—', by:'you', plainEnglish:form.plainEnglish, req:form.req, just:form.just, ts,
      events:[
        {t:'Requested', badge:'REQUESTED', date, desc:form.plainEnglish, by:'you', team:'Reg Reporting'},
        {t:'Created (draft)', badge:'DRAFT', date, desc:`Rule ${rid} drafted from request.`, by:'you', team:'Reg Reporting'},
      ]})
    setFlash(`Requested "${form.name}" (${rid}) — raised to Rule Authoring with a workflow task.`)
  }

  const currentBase=activeId!==null?activeId:tab
  const histTarget=rules.find(r=>r.id===histRule)
  const shownRules=dqTenant==='ALL'?rules:rules.filter(r=>(r.tenant||'GLOBAL')===dqTenant)

  return (
    <div>
      <PageHdr title="Data Quality" icon={Shield}
        sub="Observe DQ results against governed logical objects/attributes, see the rules and their plain-English definitions, and initiate rule requests. Rules are authored and executed in the external engine — the semantic layer does not execute."/>
      <InfoBanner color={L.amb} bg={L.ambBg} text="PLACEHOLDER — UI simulation. From Data Quality you can only INITIATE/REQUEST a rule (with workflow). Results are shown against logical attributes (never physical). Rules may be single-attribute, cross-attribute, or conditional. Per client; policies externalized in OPA."/>
      {flash && <InfoBanner color={L.grn} bg={L.grnBg} text={flash}/>}
      <div style={{marginTop:16}}>
        <GovTabStrip
          base={[{id:'matrix',label:'DQ Matrix'},{id:'rules',label:`DQ Rules (${rules.length})`}]}
          drafts={drafts} activeId={currentBase}
          onSelect={id=>{ if(id==='matrix'||id==='rules'){setActiveId(null);setTab(id)} else setActiveId(id) }}
          onClose={closeDraft} addLabel=" Request Rule" onAdd={()=>openDraft()}/>
      </div>

      {activeId===null && tab==='matrix' && (
        <div>
          <div style={{display:'flex',gap:10,marginBottom:14}}>
            <StatCard value={DQ_OBJS.length} label="Governed objects monitored" icon={Database} color={L.teal}/>
            <StatCard value={DQ_DIMS.length} label="DQ dimensions" icon={BarChart2} color={L.blue}/>
            <StatCard value={openFindings} label="Open findings (warn / fail)" icon={AlertTriangle} color={L.amb}/>
            <StatCard value={rules.length} label="DQ rules (incl. requested)" icon={List} color={L.pur}/>
          </div>
          <InfoBanner color={L.blue} bg={L.blueBg} text="Click an object to expand its attribute-level matrix. A cell shows the latest score only where an ACTIVE rule of that dimension exists; “—” means unmeasured (no such rule yet). Timeliness is sourced from the observability plane, not a row rule. Accuracy is assessed externally and is not a rule-driven column. The # rules column is coverage (how many checks watch the attribute) and is distinct from the scores."/>
          <div style={{display:'flex',justifyContent:'flex-end',margin:'4px 0 8px'}}>
            <button onClick={()=>setDimInfo(true)} style={{display:'flex',alignItems:'center',gap:6,background:'none',border:'none',cursor:'pointer',fontSize:12,color:L.blue,fontWeight:600,padding:'4px 2px'}}
              onMouseEnter={e=>e.currentTarget.style.textDecoration='underline'} onMouseLeave={e=>e.currentTarget.style.textDecoration='none'}>
              <Info size={14}/> How each dimension is determined
            </button>
          </div>
          <Card noPad>
            <div style={{overflowX:'auto'}}>
              <div style={{minWidth:920}}>
                <div style={{display:'flex',alignItems:'center',padding:'11px 14px',borderBottom:`1px solid ${L.bd}`}}>
                  <div style={{...nameCol,fontSize:11,fontWeight:700,color:L.t3,textTransform:'uppercase',letterSpacing:'.05em'}}>Object / attribute</div>
                  {DQ_DIMS.map(d=><div key={d} style={{flex:1,textAlign:'center',fontSize:10,fontWeight:700,color:L.t3}}>{d}</div>)}
                  <div style={{...rulesCol,textAlign:'center',fontSize:10,fontWeight:700,color:L.t3}}># rules</div>
                  <div style={actCol}/>
                </div>
                {DQ_OBJS.map(o=>{
                  const on=expObj===o; const attrs=((CATALOG[o]&&CATALOG[o].attrs)||[]).slice(0,8)
                  const objRuleCount=rules.filter(r=>r.obj===o).length
                  return (
                    <div key={o}>
                      <div onClick={()=>setExpObj(on?null:o)} style={{display:'flex',alignItems:'center',padding:'9px 14px',borderBottom:`1px solid ${L.s3}`,cursor:'pointer',background:on?L.s2:'transparent'}}>
                        <div style={{...nameCol,fontSize:12,fontWeight:700,color:L.t1,display:'flex',alignItems:'center',gap:7}}><span style={{fontSize:9,color:L.t4}}>{on?'▼':'▶'}</span><Database size={12} color={L.t4}/>{cxLogicalObj(o)}</div>
                        {DQ_DIMS.map((d,k)=> d==='Timeliness'?<MxCell key={k} kind="time" c={timelinessFor(o)}/> : objCovers(rules,o,d)?<MxCell key={k} c={objCellMock(o,k)}/> : <MxCell key={k} kind="unmeasured"/>)}
                        <div style={{...rulesCol,textAlign:'center',fontSize:11,color:L.t3}}>{objRuleCount}</div>
                        <div style={actCol}/>
                      </div>
                      {on && attrs.map((a,j)=>{
                        const aL=a.ln||a.cd; const ar=rulesForAttr(rules,o,aL)
                        const isDefs=defsFor&&defsFor.obj===o&&defsFor.attr===aL
                        return (
                          <Fragment key={a.cd}>
                            <div style={{display:'flex',alignItems:'center',padding:'7px 14px 7px 30px',borderBottom:`1px solid ${L.s3}`,background:L.s1}}>
                              <div style={{...nameCol,fontSize:11,color:L.t2,display:'flex',alignItems:'center',gap:6}}>{aL}{a.semantic&&<Chip text={a.semantic} c={(CX_ROLE[a.semantic]||{}).c||L.t3} bg={(CX_ROLE[a.semantic]||{}).bg||L.s3} sz={8}/>}</div>
                              {DQ_DIMS.map((d,k)=> d==='Timeliness'?<MxCell key={k} kind="time" c={timelinessFor(o)}/> : ruleCovers(rules,o,aL,d)?<MxCell key={k} c={cxAttrCell(a,j,k)}/> : <MxCell key={k} kind="unmeasured"/>)}
                              <div style={{...rulesCol,display:'flex',justifyContent:'center'}}>
                                <div onClick={(e)=>{e.stopPropagation();setDefsFor(isDefs?null:{obj:o,attr:aL})}} style={{cursor:'pointer',minWidth:30,textAlign:'center',padding:'2px 8px',borderRadius:10,
                                  background:ar.length?L.purBg:L.s3,color:ar.length?L.pur:L.t4,fontSize:11,fontWeight:700,border:`1px solid ${ar.length?L.pur+'55':L.bd}`}}>{ar.length}</div>
                              </div>
                              <div style={{...actCol,display:'flex',justifyContent:'flex-end'}}><Btn label="Request rule" icon={Plus} small onClick={()=>openDraft({obj:o,attr:aL})}/></div>
                            </div>
                            {isDefs && <div style={{padding:'10px 14px 12px 30px',background:L.s2,borderBottom:`1px solid ${L.s3}`}}>
                              <div style={{fontSize:11,fontWeight:700,color:L.t2,marginBottom:8}}>Rules on {aL} — plain English</div>
                              {ar.length===0 ? <div style={{fontSize:12,color:L.t4}}>No rules yet. Use Request rule to initiate one.</div> :
                                ar.map(r=>{const rs=CX_RULE_ST[r.status]||CX_RULE_ST.REQUESTED, sc=CX_SCOPE[r.scope]||CX_SCOPE.ATTRIBUTE; return (
                                  <div key={r.id} style={{padding:'8px 11px',border:`1px solid ${L.bd}`,borderRadius:7,background:L.s1,marginBottom:6}}>
                                    <div style={{display:'flex',alignItems:'center',gap:7,flexWrap:'wrap',marginBottom:3}}>
                                      <span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:L.purDk}}>{r.rid}</span>
                                      <span style={{fontSize:12,fontWeight:700,color:L.t1}}>{r.name}</span>
                                      <Chip text={sc.short} c={sc.c} bg={sc.bg} sz={8}/><Chip text={r.dim} c={L.t3} bg={L.s3} sz={8}/><Chip text={r.status} c={rs.c} bg={rs.bg} sz={8}/><TenantChip tenant={r.tenant} sz={8}/>
                                      <button onClick={()=>setHistRule(r.id)} title="History" style={{marginLeft:'auto',background:'none',border:'none',cursor:'pointer',color:L.t4,padding:2,display:'flex'}}
                                        onMouseEnter={e=>e.currentTarget.style.color=L.teal} onMouseLeave={e=>e.currentTarget.style.color=L.t4}><History size={14}/></button>
                                    </div>
                                    <div style={{fontSize:12,color:L.t2}}>{cxPlainEnglish(r)}</div>
                                  </div>)})}
                            </div>}
                          </Fragment>
                        )
                      })}
                    </div>
                  )
                })}
              </div>
            </div>
          </Card>
        </div>
      )}

      {activeId===null && tab==='rules' && (
        <div>
          <div style={{display:'flex',gap:10,marginBottom:14}}>
            <StatCard value={rules.length} label="DQ rules total" icon={List} color={L.teal}/>
            <StatCard value={rules.filter(r=>r.scope!=='ATTRIBUTE').length} label="Cross-attribute / conditional" icon={GitBranch} color={L.pur}/>
            <StatCard value={rules.filter(r=>r.status==='ACTIVE').length} label="Active (executing)" icon={Check} color={L.grn}/>
            <StatCard value={rules.filter(r=>r.status==='REQUESTED').length} label="Requested" icon={Clock} color={L.amb}/>
          </div>
          <InfoBanner color={L.blue} bg={L.blueBg} text="Read-only inventory with plain-English definitions. Every rule carries a stable ID (DQR-####), a tenant scope (GLOBAL or a client), and an append-only history. Cross-attribute and conditional rules span multiple attributes."/>
          <div style={{display:'flex',alignItems:'center',gap:8,margin:'6px 0 10px',flexWrap:'wrap'}}>
            <span style={{fontSize:11,fontWeight:600,color:L.t3}}>Tenant scope:</span>
            {['ALL',...TENANTS].map(t=>{const on=dqTenant===t; return (
              <button key={t} onClick={()=>setDqTenant(t)} style={{padding:'4px 11px',borderRadius:12,fontSize:11,fontWeight:600,cursor:'pointer',
                border:`1px solid ${on?L.pur:L.bd}`,background:on?L.purBg:L.s1,color:on?L.purDk:L.t3}}>{t}{t!=='ALL'?` (${rules.filter(r=>(r.tenant||'GLOBAL')===t).length})`:` (${rules.length})`}</button>)})}
          </div>
          <Card noPad>
            <div style={{display:'grid',gridTemplateColumns:'0.7fr 1.4fr 0.75fr 0.75fr 1.7fr 0.75fr 1.1fr 44px',minWidth:1040}}>
              {['Rule ID','Rule','Type','Dimension','Definition (plain English)','Status','Last execution',''].map((h,i)=>(<div key={i} style={{padding:'11px 14px',fontSize:11,fontWeight:700,color:L.t3,borderBottom:`1px solid ${L.bd}`,textTransform:'uppercase',letterSpacing:'.05em'}}>{h}</div>))}
              {shownRules.map(r=>{const rs=CX_RULE_ST[r.status]||CX_RULE_ST.REQUESTED, sc=CX_SCOPE[r.scope]||CX_SCOPE.ATTRIBUTE, lr=cxLastRun(r); return (
                <Fragment key={r.id}>
                  <div style={{padding:'10px 14px',borderBottom:`1px solid ${L.s3}`,display:'flex',alignItems:'center'}}><span style={{fontFamily:L.mono,fontSize:11,fontWeight:700,color:L.purDk}}>{r.rid}</span></div>
                  <div style={{padding:'10px 14px',fontSize:12,color:L.t1,borderBottom:`1px solid ${L.s3}`}}>{r.name}<div style={{display:'flex',alignItems:'center',gap:6,marginTop:2}}><TenantChip tenant={r.tenant} sz={8}/><span style={{fontSize:10,color:L.t4}}>{cxLogicalObj(r.obj)} · {(r.attrs||[r.attr]).join(', ')}</span></div></div>
                  <div style={{padding:'10px 14px',borderBottom:`1px solid ${L.s3}`}}><Chip text={sc.short} c={sc.c} bg={sc.bg} sz={9}/></div>
                  <div style={{padding:'10px 14px',fontSize:12,color:L.t2,borderBottom:`1px solid ${L.s3}`}}>{r.dim}</div>
                  <div style={{padding:'10px 14px',fontSize:12,color:L.t2,borderBottom:`1px solid ${L.s3}`}}>{cxPlainEnglish(r)}</div>
                  <div style={{padding:'10px 14px',borderBottom:`1px solid ${L.s3}`}}><Chip text={r.status} c={rs.c} bg={rs.bg} sz={9}/></div>
              <div style={{padding:'10px 14px',borderBottom:`1px solid ${L.s3}`}}><div style={{fontFamily:L.mono,fontSize:11,color:L.t2}}>{lr.ts}</div><div style={{fontSize:10,color:lr.c}}>{lr.note}</div></div>
                  <div style={{padding:'8px 8px',borderBottom:`1px solid ${L.s3}`,display:'flex',alignItems:'center',justifyContent:'center'}}>
                    <button onClick={()=>setHistRule(r.id)} title="History" style={{background:'none',border:'none',cursor:'pointer',color:L.t4,padding:4,display:'flex'}}
                      onMouseEnter={e=>e.currentTarget.style.color=L.teal} onMouseLeave={e=>e.currentTarget.style.color=L.t4}><History size={15}/></button>
                  </div>
                </Fragment>)})}
            </div>
          </Card>
          <div style={{fontSize:11,fontWeight:700,color:L.t2,margin:'18px 0 8px'}}>Matrix on rule · rule × DQ dimension</div>
          <Card noPad>
            <div style={{overflowX:'auto'}}><div style={{display:'grid',gridTemplateColumns:`90px 240px repeat(${CX_RULE_DIMS.length}, 1fr)`,minWidth:820}}>
              <div style={{padding:'10px 14px',fontSize:10,fontWeight:700,color:L.t3,borderBottom:`1px solid ${L.bd}`,textTransform:'uppercase'}}>ID</div>
              <div style={{padding:'10px 14px',fontSize:10,fontWeight:700,color:L.t3,borderBottom:`1px solid ${L.bd}`,textTransform:'uppercase'}}>Rule</div>
              {CX_RULE_DIMS.map(d=><div key={d} style={{padding:'10px 6px',fontSize:10,fontWeight:700,color:L.t3,borderBottom:`1px solid ${L.bd}`,textAlign:'center'}}>{d}</div>)}
              {shownRules.map(r=>{const rs=CX_RULE_ST[r.status]||CX_RULE_ST.REQUESTED; return (
                <Fragment key={r.id}>
                  <div style={{padding:'9px 14px',fontFamily:L.mono,fontSize:10,fontWeight:700,color:L.purDk,borderBottom:`1px solid ${L.s3}`}}>{r.rid}</div>
                  <div style={{padding:'9px 14px',fontSize:11,color:L.t1,borderBottom:`1px solid ${L.s3}`,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>{r.name}</div>
                  {CX_RULE_DIMS.map(d=>(<div key={d} style={{padding:'7px 6px',borderBottom:`1px solid ${L.s3}`,display:'flex',justifyContent:'center'}}>{d===r.dim?<div style={{minWidth:22,height:18,borderRadius:5,background:rs.bg,border:`1px solid ${rs.c}55`,display:'flex',alignItems:'center',justifyContent:'center'}}><Check size={11} color={rs.c}/></div>:<span style={{color:L.bd}}>·</span>}</div>))}
                </Fragment>)})}
            </div></div>
          </Card>
        </div>
      )}

      {drafts.map(d=>(
        <div key={d.id} style={{display:activeId===d.id?'block':'none'}}>
          <RuleRequestForm draftId={d.id} obj={d.obj} attr={d.attr} onCancel={()=>closeDraft(d.id)} onSubmit={(form)=>{submitReq(form);closeDraft(d.id)}}/>
        </div>
      ))}

      <Drawer open={dimInfo} onClose={()=>setDimInfo(false)} eyebrow="DQ Reference" title="How each dimension is determined" sub="What each dimension means, and where its verdict comes from">
        <div style={{display:'flex',flexDirection:'column',gap:8}}>
          {DQ_DIMS.map(d=>{const di=CX_DIM_INFO[d]; const sc=di.src==='Observability'?{c:L.pur,bg:L.purBg}:{c:L.teal,bg:L.tealBg}; return (
            <div key={d} style={{padding:'10px 12px',border:`1px solid ${L.bd}`,borderRadius:8,background:L.s2}}>
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}><span style={{fontSize:13,fontWeight:700,color:L.t1}}>{d}</span><Chip text={di.src} c={sc.c} bg={sc.bg} sz={8}/></div>
              <div style={{fontSize:12,color:L.t2,lineHeight:1.5}}>{di.desc}</div>
            </div>)})}
          <div style={{padding:'10px 12px',border:`1px dashed ${L.amb}66`,borderRadius:8,background:L.ambBg}}>
            <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}><span style={{fontSize:13,fontWeight:700,color:L.ambDk}}>Accuracy</span><Chip text="Externally assessed · not rule-driven" c={L.amb} bg="#fff" sz={8}/></div>
            <div style={{fontSize:12,color:L.t2,lineHeight:1.5}}>Does the value match real-world truth? A DQ rule cannot determine this — assessed externally via reconciliation / verification, then attested back.</div>
          </div>
        </div>
      </Drawer>

      <Drawer open={!!histTarget} onClose={()=>setHistRule(null)} eyebrow="DQ Rule · History"
        title={histTarget?histTarget.name:''} sub={histTarget?`${histTarget.rid} · ${cxLogicalObj(histTarget.obj)}`:''}
        footer="Append-only governance log — who · what · when. Rule execution evidence (which run produced which result) lives in Audit & Evidence.">
        {histTarget && <HistoryTimeline events={cxRuleEvents(histTarget)}/>}
      </Drawer>
    </div>
  )
}

function DataProfilingScreen() {
  const [profObj,setProfObj]=useState('core.gl_balance')
  const profAttrs=((CATALOG[profObj]&&CATALOG[profObj].attrs)||[]).slice(0,12)
  const PROFILED_AT={'core.gl_balance':'2026-06-15 03:10','core.customer_master':'2026-06-15 03:12','core.loan_contract':'2026-06-15 03:14','ref.organization_hierarchy':'2026-06-14 03:10','ref.fiscal_period':'2026-06-14 03:11'}
  const profiledAt=PROFILED_AT[profObj]||'2026-06-15 03:10'
  return (
    <div>
      <PageHdr title="Data Profiling" icon={BarChart2} sub="Profile results for governed objects, surfaced against logical attributes. Profiling is computed in the external execution engine; the layer presents the metrics. UI simulation."/>
      <InfoBanner color={L.amb} bg={L.ambBg} text="PLACEHOLDER — UI simulation. Profiling runs in the external execution engine; results are shown against logical attributes and semantic roles. Physical columns and types are never shown. Per client."/>
      <div style={{display:'flex',alignItems:'flex-end',gap:14,margin:'16px 0 14px',flexWrap:'wrap'}}>
        <div style={{maxWidth:320,flex:'1 1 240px'}}><SelectInput label="Object" value={profObj} onChange={setProfObj} options={DQ_OBJS.map(o=>({v:o,l:cxLogicalObj(o)}))}/></div>
        <div style={{display:'flex',alignItems:'center',gap:7,padding:'7px 12px',border:`1px solid ${L.bd}`,borderRadius:8,background:L.s2}}>
          <Clock size={13} color={L.t4}/><span style={{fontSize:11,color:L.t3}}>Last profiled</span>
          <span style={{fontFamily:L.mono,fontSize:12,fontWeight:700,color:L.t1}}>{profiledAt}</span>
          <Chip text="external engine" c={L.pur} bg={L.purBg} sz={8}/>
        </div>
      </div>
      <Card noPad>
        <div style={{display:'grid',gridTemplateColumns:'2fr 1fr 1fr 1fr 1fr',minWidth:640}}>
          {['Logical attribute','Role','Null %','Distinct %','Status'].map(h=>(<div key={h} style={{padding:'11px 14px',fontSize:11,fontWeight:700,color:L.t3,borderBottom:`1px solid ${L.bd}`,textTransform:'uppercase',letterSpacing:'.05em'}}>{h}</div>))}
          {profAttrs.length===0 && <div style={{gridColumn:'1 / -1',padding:14,fontSize:12,color:L.t4}}>Profile introspected at build for this object.</div>}
          {profAttrs.map((a,i)=>{const nullPct=a.nullable?DQ_NULLS[i%DQ_NULLS.length]:0.0; const distinct=a.semantic==='IDENTIFIER'?100:a.semantic==='CODE'?(2+(i%5)):a.semantic==='MEASURE'?(82+i%12):(8+(i*3)%22); const st=nullPct>10?'FAIL':nullPct>5?'WARN':'PASS'; const cc=DQ_CELL[st]; const rc=CX_ROLE[a.semantic]||{c:L.t3,bg:L.s3}; return (
            <Fragment key={a.cd}>
              <div style={{padding:'10px 14px',fontSize:12,color:L.t1,borderBottom:`1px solid ${L.s3}`}}>{a.ln||a.cd}</div>
              <div style={{padding:'10px 14px',borderBottom:`1px solid ${L.s3}`}}>{a.semantic&&<Chip text={a.semantic} c={rc.c} bg={rc.bg} sz={9}/>}</div>
              <div style={{padding:'10px 14px',fontSize:12,color:L.t2,borderBottom:`1px solid ${L.s3}`}}>{nullPct.toFixed(1)}%</div>
              <div style={{padding:'10px 14px',fontSize:12,color:L.t2,borderBottom:`1px solid ${L.s3}`}}>~{distinct}%</div>
              <div style={{padding:'10px 14px',borderBottom:`1px solid ${L.s3}`}}><Chip text={st} c={cc.c} bg={cc.bg} sz={9}/></div>
            </Fragment>)})}
        </div>
      </Card>
    </div>
  )
}

function DataObservabilityScreen() {
  const openSignals=OBS_EVENTS.filter(e=>e.st==='OPEN'||e.st==='TRIAGE').length
  return (
    <div>
      <PageHdr title="Data Observability" icon={Activity} sub="Pipeline and store signals (freshness, volume, schema drift, distribution) correlated with governed objects. Signals are emitted by external tooling; the layer ingests and governs the response. UI simulation."/>
      <InfoBanner color={L.amb} bg={L.ambBg} text="PLACEHOLDER — UI simulation. Observability is performed by external tooling on the pipelines/physical stores. The layer ingests signals against governed objects, correlates with DQ + lineage, can trigger a targeted DQ re-run, and routes resolution to the Workflow Queue — system of record for the signal and the resolution, not the collector."/>
      <div style={{display:'flex',gap:10,margin:'16px 0 14px'}}>
        <StatCard value={openSignals} label="Open signals (trigger DQ / workflow)" icon={Activity} color={L.cor}/>
        <StatCard value={OBS_EVENTS.filter(e=>e.sev==='HIGH').length} label="High severity" icon={AlertTriangle} color={L.amb}/>
        <StatCard value={OBS_EVENTS.length} label="Signals (last 24h)" icon={Clock} color={L.blue}/>
        <StatCard value="ext" label="Source · observability tooling" icon={Eye} color={L.pur}/>
      </div>
      <Card noPad>
        <div style={{display:'grid',gridTemplateColumns:'1.4fr 1fr 0.7fr 2.4fr 1.2fr 1fr',minWidth:820}}>
          {['Object (logical)','Signal','Severity','Detail','Detected','Status'].map(h=>(<div key={h} style={{padding:'11px 14px',fontSize:11,fontWeight:700,color:L.t3,borderBottom:`1px solid ${L.bd}`,textTransform:'uppercase',letterSpacing:'.05em'}}>{h}</div>))}
          {OBS_EVENTS.map((e,i)=>{const sv=OBS_SEV[e.sev]||OBS_SEV.INFO, ss=OBS_ST[e.st]||OBS_ST.OPEN; return (
            <Fragment key={i}>
              <div style={{padding:'10px 14px',fontSize:12,color:L.t1,borderBottom:`1px solid ${L.s3}`,display:'flex',alignItems:'center',gap:7}}><Database size={12} color={L.t4}/>{cxLogicalObj(e.obj)}</div>
              <div style={{padding:'10px 14px',fontSize:12,color:L.t2,borderBottom:`1px solid ${L.s3}`}}>{e.type}</div>
              <div style={{padding:'10px 14px',borderBottom:`1px solid ${L.s3}`}}><Chip text={e.sev} c={sv.c} bg={sv.bg} sz={9}/></div>
              <div style={{padding:'10px 14px',fontSize:12,color:L.t3,borderBottom:`1px solid ${L.s3}`}}>{e.detail}</div>
              <div style={{padding:'10px 14px',fontSize:11,color:L.t3,borderBottom:`1px solid ${L.s3}`,fontFamily:L.mono}}>{e.ts}</div>
              <div style={{padding:'10px 14px',borderBottom:`1px solid ${L.s3}`,display:'flex',alignItems:'center',gap:6}}><Chip text={e.st} c={ss.c} bg={ss.bg} sz={9}/>{(e.st==='OPEN'||e.st==='TRIAGE')&&<span style={{display:'inline-flex',alignItems:'center',gap:2,fontSize:10,color:L.teal}}><ArrowRight size={10}/>WF</span>}</div>
            </Fragment>)})}
        </div>
      </Card>
    </div>
  )
}

function DqRuleFlowScreen({ onNav }) {
  const node=(label,sub,c,bg)=>(
    <div style={{flex:1,minWidth:130,padding:'12px 12px',borderRadius:9,border:`1px solid ${c}`,background:bg,textAlign:'center'}}>
      <div style={{fontSize:12,fontWeight:700,color:c}}>{label}</div>
      {sub&&<div style={{fontSize:10,color:L.t3,marginTop:3,lineHeight:1.4}}>{sub}</div>}
    </div>)
  const arrow=<div style={{display:'flex',alignItems:'center',color:L.t4,padding:'0 4px'}}><ArrowRight size={16}/></div>
  return (
    <div>
      <PageHdr title="DQ Rule Flow" icon={GitBranch}
        sub="How a DQ rule moves from request to active — and the two entry points. The semantic layer initiates requests with workflow; authoring and execution happen in the external engine."/>
      <InfoBanner color={L.amb} bg={L.ambBg} text="PLACEHOLDER — UI simulation of the DQ rule lifecycle. The semantic layer hosts the request, the workflow, and the resulting status; rule authoring and execution live in the external engine."/>

      <div style={{fontSize:12,fontWeight:700,color:L.t2,margin:'18px 0 10px'}}>Two entry points</div>
      <div style={{display:'flex',gap:14,flexWrap:'wrap'}}>
        <div style={{flex:1,minWidth:300,border:`1px solid ${L.teal}`,borderRadius:10,padding:16,background:L.tealBg}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}><div style={{width:24,height:24,borderRadius:12,background:L.teal,color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:800,fontSize:12}}>1</div><span style={{fontSize:13,fontWeight:700,color:L.tealDk}}>From Data Quality</span></div>
          <div style={{fontSize:12,color:L.t2,lineHeight:1.6}}>Initiate / <b>request</b> a rule from an attribute. Request <b>only</b> — always routed through a governance <b>workflow</b>. Enters the lifecycle as <b>REQUESTED</b>.</div>
          <div style={{marginTop:10}}><Btn label="Go to Data Quality" icon={Shield} small onClick={()=>onNav('dq')}/></div>
        </div>
        <div style={{flex:1,minWidth:300,border:`1px solid ${L.amb}`,borderRadius:10,padding:16,background:L.ambBg}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}><div style={{width:24,height:24,borderRadius:12,background:L.amb,color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:800,fontSize:12}}>2</div><span style={{fontSize:13,fontWeight:700,color:L.ambDk}}>From Rule Authoring (external)</span></div>
          <div style={{fontSize:12,color:L.t2,lineHeight:1.6}}><b>Author</b> a requested rule, or author a <b>new rule from scratch</b>. Authoring and execution happen in the external engine. Once authored, the rule is <b>ACTIVE</b> and its status shows back in Data Quality.</div>
          <div style={{marginTop:10}}><Btn label="Go to Rule Authoring" icon={Edit2} small onClick={()=>onNav('ruleauthoring')}/></div>
        </div>
      </div>

      <div style={{fontSize:12,fontWeight:700,color:L.t2,margin:'22px 0 10px'}}>Lifecycle</div>
      <Card>
        <div style={{display:'flex',alignItems:'stretch',flexWrap:'wrap',gap:2}}>
          {node('Initiate / Request','Data Quality · with workflow',L.teal,L.tealBg)}{arrow}
          {node('REQUESTED','awaiting authoring',L.amb,L.ambBg)}{arrow}
          {node('Workflow approval','governance task',L.blue,L.blueBg)}{arrow}
          {node('Authoring','external engine',L.blue,L.blueBg)}{arrow}
          {node('ACTIVE','executes in engine',L.grn,L.grnBg)}{arrow}
          {node('Status in Data Quality','visible with current status',L.teal,L.tealBg)}
        </div>
        <div style={{display:'flex',gap:18,marginTop:14,fontSize:11,color:L.t3,flexWrap:'wrap'}}>
          <span><b style={{color:L.tealDk}}>Entry 1</b> enters at <b>Initiate / Request</b>.</span>
          <span><b style={{color:L.ambDk}}>Entry 2</b> enters at <b>Authoring</b> (author a requested rule) or creates a rule that goes straight to <b>ACTIVE</b> (from scratch).</span>
        </div>
      </Card>
      <InfoBanner color={L.blue} bg={L.blueBg} text="Boundary: the semantic layer requests, governs the workflow, and reflects status. It never authors or executes a rule — the external engine does."/>
    </div>
  )
}

function RuleAuthoringScreen({ onNav }) {
  const rules=useCxRules()
  const [authoring,setAuthoring]=useState(null)  // 'new' | rule.id
  const [histRule,setHistRule]=useState(null)
  const requested=rules.filter(r=>r.status==='REQUESTED')
  const saveNew=(form)=>{ const rid=nextRid(); const date=new Date().toISOString().slice(0,10); const ts=new Date().toISOString().slice(0,16).replace('T',' ')
    cxRules.add({id:'auth_'+Date.now(), rid, ...form, status:'ACTIVE', origin:'AUTHORED', result:'pending run', lastRun:'pending', by:'author', ts,
      events:[
        {t:'Authored & activated', badge:'ACTIVE', date, desc:form.plainEnglish||cxPlainEnglish(form), by:'author', team:'Data Quality'},
        {t:'Created (authored)', badge:'DRAFT', date, desc:`Rule ${rid} authored from scratch.`, by:'author', team:'Data Quality'},
      ]}); setAuthoring(null) }
  const saveReq=(r,form)=>{ const date=new Date().toISOString().slice(0,10)
    cxRules.update(r.id,{...form, status:'ACTIVE', origin:'AUTHORED', result:'pending run', lastRun:'pending', by:'author',
      events:[{t:'Authored & activated', badge:'ACTIVE', date, desc:form.plainEnglish||cxPlainEnglish({...r,...form}), by:'author', team:'Data Quality'}, ...(r.events||[])]}); setAuthoring(null) }
  const histTarget=rules.find(r=>r.id===histRule)
  return (
    <div>
      <PageHdr title="Placeholder · Rule Authoring" icon={Edit2}
        sub="External capability (placeholder). Author rules requested from Data Quality, or author a new rule from scratch. Authoring and execution happen in the external engine; the semantic layer never executes."
        action={<Btn label="Author new rule" icon={Plus} small primary onClick={()=>setAuthoring(authoring==='new'?null:'new')}/>}/>
      <InfoBanner color={L.amb} bg={L.ambBg} text="PLACEHOLDER — represents the external Rule Authoring / execution capability. Entry point 2: author a requested rule or one from scratch. Once authored, the rule is ACTIVE and its status appears in Data Quality."/>

      {authoring==='new' && <RuleAuthorForm onCancel={()=>setAuthoring(null)} onSave={saveNew}/>}

      <div style={{display:'flex',gap:10,margin:'16px 0 14px'}}>
        <StatCard value={requested.length} label="Requested · awaiting authoring" icon={Clock} color={L.amb}/>
        <StatCard value={rules.filter(r=>r.status==='AUTHORING').length} label="In authoring" icon={Edit2} color={L.blue}/>
        <StatCard value={rules.filter(r=>r.status==='ACTIVE').length} label="Active in engine" icon={Check} color={L.grn}/>
        <StatCard value={rules.length} label="Rules total" icon={List} color={L.teal}/>
      </div>

      {requested.length>0 && <div style={{fontSize:11,fontWeight:700,color:L.t2,marginBottom:8}}>Requested rules (from Data Quality)</div>}
      {requested.map(r=>{const sc=CX_SCOPE[r.scope]||CX_SCOPE.ATTRIBUTE; return (
        <div key={r.id} style={{border:`1px solid ${L.amb}66`,borderRadius:9,padding:14,marginBottom:10,background:L.ambBg}}>
          <div style={{display:'flex',alignItems:'center',gap:8,flexWrap:'wrap',marginBottom:6}}>
            <span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:L.purDk,background:'#fff',padding:'1px 7px',borderRadius:4}}>{r.rid}</span>
            <span style={{fontSize:13,fontWeight:700,color:L.t1}}>{r.name}</span>
            <Chip text="REQUESTED" c={L.amb} bg="#fff" sz={9}/><Chip text={sc.short} c={sc.c} bg="#fff" sz={9}/><Chip text={r.dim} c={L.blue} bg="#fff" sz={9}/><TenantChip tenant={r.tenant} sz={9}/>
            <button onClick={()=>setHistRule(r.id)} title="History" style={{background:'none',border:'none',cursor:'pointer',color:L.t3,padding:2,display:'flex'}}
              onMouseEnter={e=>e.currentTarget.style.color=L.amb} onMouseLeave={e=>e.currentTarget.style.color=L.t3}><History size={15}/></button>
            <span style={{fontSize:11,color:L.t3,marginLeft:'auto'}}>by {r.by} · {r.ts||''}</span>
          </div>
          <div style={{fontSize:12,color:L.t2,marginBottom:4}}>Target: <b>{cxLogicalObj(r.obj)} · {(r.attrs||[r.attr]).join(', ')}</b></div>
          <div style={{fontSize:12,color:L.t2,marginBottom:4}}><b>Definition:</b> {cxPlainEnglish(r)}</div>
          {r.just && <div style={{fontSize:11,color:L.t3,marginBottom:6}}>Justification: {r.just}</div>}
          <div style={{display:'flex',alignItems:'center',gap:8}}>
            <Chip text="workflow: pending author assignment" c={L.amb} bg="#fff" sz={9}/>
            <Btn label={authoring===r.id?'Close':'Author this rule'} icon={Edit2} small primary onClick={()=>setAuthoring(authoring===r.id?null:r.id)}/>
          </div>
          {authoring===r.id && <RuleAuthorForm initial={r} onCancel={()=>setAuthoring(null)} onSave={(form)=>saveReq(r,form)}/>}
        </div>)})}

      <div style={{fontSize:11,fontWeight:700,color:L.t2,margin:'8px 0 8px'}}>Rule inventory</div>
      <Card noPad>
        <div style={{display:'grid',gridTemplateColumns:'0.7fr 1.4fr 0.75fr 0.75fr 1.7fr 0.75fr 1.1fr 44px',minWidth:1040}}>
          {['Rule ID','Rule','Type','Dimension','Definition (plain English)','Status','Last execution',''].map((h,i)=>(<div key={i} style={{padding:'11px 14px',fontSize:11,fontWeight:700,color:L.t3,borderBottom:`1px solid ${L.bd}`,textTransform:'uppercase',letterSpacing:'.05em'}}>{h}</div>))}
          {rules.map(r=>{const rs=CX_RULE_ST[r.status]||CX_RULE_ST.REQUESTED, sc=CX_SCOPE[r.scope]||CX_SCOPE.ATTRIBUTE, lr=cxLastRun(r); return (
            <Fragment key={r.id}>
              <div style={{padding:'10px 14px',borderBottom:`1px solid ${L.s3}`,display:'flex',alignItems:'center'}}><span style={{fontFamily:L.mono,fontSize:11,fontWeight:700,color:L.purDk}}>{r.rid}</span></div>
              <div style={{padding:'10px 14px',fontSize:12,color:L.t1,borderBottom:`1px solid ${L.s3}`}}>{r.name}<div style={{display:'flex',alignItems:'center',gap:6,marginTop:2}}><TenantChip tenant={r.tenant} sz={8}/><span style={{fontSize:10,color:L.t4}}>{cxLogicalObj(r.obj)}</span></div></div>
              <div style={{padding:'10px 14px',borderBottom:`1px solid ${L.s3}`}}><Chip text={sc.short} c={sc.c} bg={sc.bg} sz={9}/></div>
              <div style={{padding:'10px 14px',fontSize:12,color:L.t2,borderBottom:`1px solid ${L.s3}`}}>{r.dim}</div>
              <div style={{padding:'10px 14px',fontSize:12,color:L.t2,borderBottom:`1px solid ${L.s3}`}}>{cxPlainEnglish(r)}</div>
              <div style={{padding:'10px 14px',borderBottom:`1px solid ${L.s3}`}}><Chip text={r.status} c={rs.c} bg={rs.bg} sz={9}/></div>
              <div style={{padding:'10px 14px',borderBottom:`1px solid ${L.s3}`}}><div style={{fontFamily:L.mono,fontSize:11,color:L.t2}}>{lr.ts}</div><div style={{fontSize:10,color:lr.c}}>{lr.note}</div></div>
              <div style={{padding:'8px 8px',borderBottom:`1px solid ${L.s3}`,display:'flex',alignItems:'center',justifyContent:'center'}}>
                <button onClick={()=>setHistRule(r.id)} title="History" style={{background:'none',border:'none',cursor:'pointer',color:L.t4,padding:4,display:'flex'}}
                  onMouseEnter={e=>e.currentTarget.style.color=L.teal} onMouseLeave={e=>e.currentTarget.style.color=L.t4}><History size={15}/></button>
              </div>
            </Fragment>)})}
        </div>
      </Card>

      <Drawer open={!!histTarget} onClose={()=>setHistRule(null)} eyebrow="DQ Rule · History"
        title={histTarget?histTarget.name:''} sub={histTarget?`${histTarget.rid} · ${cxLogicalObj(histTarget.obj)}`:''}
        footer="Append-only governance log — who · what · when. Rule execution evidence (which run produced which result) lives in Audit & Evidence.">
        {histTarget && <HistoryTimeline events={cxRuleEvents(histTarget)}/>}
      </Drawer>
    </div>
  )
}


// ── Data Catalog · object-level Data Quality tab (rules + on-demand definitions + timestamped matrix) ──
function CatalogDqTab({ objKey }){
  const rules=useCxRules()
  const [open,setOpen]=useState({})
  const [histRule,setHistRule]=useState(null)
  const objRules=rules.filter(r=>r.obj===objKey)
  const attrs=((CATALOG[objKey]&&CATALOG[objKey].attrs)||[]).slice(0,10)
  const byType=(t)=>objRules.filter(r=>r.scope===t).length
  const execs=objRules.map(r=>r.lastRun).filter(x=>x&&x!=='—'&&x!=='pending').sort()
  const lastExecObj=execs.length?execs[execs.length-1]:'—'
  const attrLastRun=(aL)=>{ const rs=rulesForAttr(objRules,objKey,aL).map(r=>r.lastRun).filter(x=>x&&x!=='—'&&x!=='pending').sort(); return rs.length?rs[rs.length-1]:'—' }
  const histTarget=rules.find(r=>r.id===histRule)
  return (
    <div>
      <div style={{display:'flex',gap:10,marginBottom:12,flexWrap:'wrap'}}>
        <StatCard value={objRules.length} label="DQ rules on this object" icon={List} color={L.teal}/>
        <StatCard value={objRules.filter(r=>r.status==='ACTIVE').length} label="Active (executing)" icon={Check} color={L.grn}/>
        <StatCard value={objRules.filter(r=>r.status==='REQUESTED').length} label="Requested" icon={Clock} color={L.amb}/>
      </div>
      <InfoBanner color={L.blue} bg={L.blueBg} text="Read-only view of the DQ rules governing this object — counts by type, plain-English definition on demand, and the attribute × dimension matrix with last-execution timestamps. Rules are authored and executed in the external engine; request or author from the Data Quality screen."/>
      <div style={{display:'flex',gap:8,alignItems:'center',margin:'12px 0',flexWrap:'wrap'}}>
        <span style={{fontSize:11,color:L.t3,fontWeight:600}}>By type:</span>
        <Chip text={`Attribute · ${byType('ATTRIBUTE')}`} c={CX_SCOPE.ATTRIBUTE.c} bg={CX_SCOPE.ATTRIBUTE.bg} sz={9}/>
        <Chip text={`Cross-attr · ${byType('CROSS_ATTRIBUTE')}`} c={CX_SCOPE.CROSS_ATTRIBUTE.c} bg={CX_SCOPE.CROSS_ATTRIBUTE.bg} sz={9}/>
        <Chip text={`Conditional · ${byType('CONDITIONAL')}`} c={CX_SCOPE.CONDITIONAL.c} bg={CX_SCOPE.CONDITIONAL.bg} sz={9}/>
        <span style={{marginLeft:'auto',display:'flex',alignItems:'center',gap:6,fontSize:11,color:L.t3}}><Clock size={12} color={L.t4}/>Last execution <span style={{fontFamily:L.mono,fontWeight:700,color:L.t1}}>{lastExecObj}</span></span>
      </div>

      <div style={{fontSize:11,fontWeight:700,color:L.t2,margin:'14px 0 8px'}}>Rules · definition on demand</div>
      <Card noPad>
        <div style={{display:'grid',gridTemplateColumns:'0.7fr 1.7fr 0.8fr 0.8fr 0.8fr 1fr 40px',minWidth:760}}>
          {['Rule ID','Rule','Type','Dimension','Status','Last execution',''].map((h,i)=><div key={i} style={{padding:'10px 12px',fontSize:10,fontWeight:700,color:L.t3,borderBottom:`1px solid ${L.bd}`,textTransform:'uppercase',letterSpacing:'.05em'}}>{h}</div>)}
          {objRules.length===0 && <div style={{gridColumn:'1 / -1',padding:14,fontSize:12,color:L.t4}}>No DQ rules on this object yet. Request one from the Data Quality screen.</div>}
          {objRules.map(r=>{const rs=CX_RULE_ST[r.status]||CX_RULE_ST.REQUESTED, sc=CX_SCOPE[r.scope]||CX_SCOPE.ATTRIBUTE, lr=cxLastRun(r), ex=!!open[r.rid]; return (
            <Fragment key={r.id}>
              <div style={{padding:'9px 12px',borderBottom:`1px solid ${L.s3}`,display:'flex',alignItems:'center'}}><span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:L.purDk}}>{r.rid}</span></div>
              <div style={{padding:'9px 12px',fontSize:12,color:L.t1,borderBottom:`1px solid ${L.s3}`,cursor:'pointer'}} onClick={()=>setOpen(o=>({...o,[r.rid]:!o[r.rid]}))}>
                <span style={{display:'flex',alignItems:'center',gap:6}}><span style={{fontSize:9,color:L.t4}}>{ex?'▼':'▶'}</span>{r.name}<TenantChip tenant={r.tenant} sz={8}/></span></div>
              <div style={{padding:'9px 12px',borderBottom:`1px solid ${L.s3}`}}><Chip text={sc.short} c={sc.c} bg={sc.bg} sz={8}/></div>
              <div style={{padding:'9px 12px',fontSize:11,color:L.t2,borderBottom:`1px solid ${L.s3}`}}>{r.dim}</div>
              <div style={{padding:'9px 12px',borderBottom:`1px solid ${L.s3}`}}><Chip text={r.status} c={rs.c} bg={rs.bg} sz={8}/></div>
              <div style={{padding:'9px 12px',borderBottom:`1px solid ${L.s3}`}}><div style={{fontFamily:L.mono,fontSize:10,color:L.t2}}>{lr.ts}</div><div style={{fontSize:9,color:lr.c}}>{lr.note}</div></div>
              <div style={{padding:'7px 6px',borderBottom:`1px solid ${L.s3}`,display:'flex',justifyContent:'center'}}><HistBtn onClick={()=>setHistRule(r.id)}/></div>
              {ex && <div style={{gridColumn:'1 / -1',padding:'8px 14px 12px 34px',background:L.s2,borderBottom:`1px solid ${L.s3}`,fontSize:12,color:L.t2}}>
                <span style={{fontSize:10,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.05em',marginRight:8}}>Definition</span>{cxPlainEnglish(r)}</div>}
            </Fragment>)})}
        </div>
      </Card>

      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',margin:'18px 0 8px'}}>
        <span style={{fontSize:11,fontWeight:700,color:L.t2}}>DQ matrix · attribute × dimension</span>
        <span style={{fontSize:10,color:L.t4}}>as of last execution · {lastExecObj}</span>
      </div>
      <Card noPad>
        <div style={{overflowX:'auto'}}><div style={{minWidth:820}}>
          <div style={{display:'flex',alignItems:'center',padding:'10px 14px',borderBottom:`1px solid ${L.bd}`}}>
            <div style={{flex:'0 0 200px',fontSize:10,fontWeight:700,color:L.t3,textTransform:'uppercase'}}>Attribute</div>
            {DQ_DIMS.map(d=><div key={d} style={{flex:1,textAlign:'center',fontSize:10,fontWeight:700,color:L.t3}}>{d}</div>)}
            <div style={{flex:'0 0 120px',textAlign:'right',fontSize:10,fontWeight:700,color:L.t3}}>Last run</div>
          </div>
          {attrs.map((a,j)=>{const aL=a.ln||a.cd; return (
            <div key={a.cd} style={{display:'flex',alignItems:'center',padding:'7px 14px',borderBottom:`1px solid ${L.s3}`}}>
              <div style={{flex:'0 0 200px',fontSize:11,color:L.t2,display:'flex',alignItems:'center',gap:6}}>{aL}{a.semantic&&<Chip text={a.semantic} c={(CX_ROLE[a.semantic]||{}).c||L.t3} bg={(CX_ROLE[a.semantic]||{}).bg||L.s3} sz={8}/>}</div>
              {DQ_DIMS.map((d,k)=> d==='Timeliness'?<MxCell key={k} kind="time" c={timelinessFor(objKey)}/> : ruleCovers(objRules,objKey,aL,d)?<MxCell key={k} c={cxAttrCell(a,j,k)}/> : <MxCell key={k} kind="unmeasured"/>)}
              <div style={{flex:'0 0 120px',textAlign:'right',fontFamily:L.mono,fontSize:10,color:L.t3}}>{attrLastRun(aL)}</div>
            </div>)})}
        </div></div>
      </Card>

      <Drawer open={!!histTarget} onClose={()=>setHistRule(null)} eyebrow="DQ Rule · History"
        title={histTarget?histTarget.name:''} sub={histTarget?`${histTarget.rid} · ${cxLogicalObj(histTarget.obj)}`:''}
        footer="Append-only governance log — who · what · when. Rule execution evidence lives in Audit & Evidence.">
        {histTarget && <HistoryTimeline events={cxRuleEvents(histTarget)}/>}
      </Drawer>
    </div>
  )
}

// ── Data Catalog · attribute-level Data Quality tab ──
function CatalogAttrDqTab({ objKey, attrLn }){
  const rules=useCxRules()
  const [open,setOpen]=useState({})
  const [histRule,setHistRule]=useState(null)
  const objRules=rules.filter(r=>r.obj===objKey)
  const ar=rulesForAttr(objRules,objKey,attrLn)
  const allAttrs=((CATALOG[objKey]&&CATALOG[objKey].attrs)||[])
  const attrObj=allAttrs.find(a=>(a.ln||a.cd)===attrLn)||{}
  const j=Math.max(0,allAttrs.findIndex(a=>(a.ln||a.cd)===attrLn))
  const execs=ar.map(r=>r.lastRun).filter(x=>x&&x!=='—'&&x!=='pending').sort()
  const lastExec=execs.length?execs[execs.length-1]:'—'
  const histTarget=rules.find(r=>r.id===histRule)
  return (
    <div>
      <div style={{display:'flex',gap:10,marginBottom:12,flexWrap:'wrap'}}>
        <StatCard value={ar.length} label="Rules on this attribute" icon={List} color={L.teal}/>
        <StatCard value={ar.filter(r=>r.status==='ACTIVE').length} label="Active" icon={Check} color={L.grn}/>
        <StatCard value={ar.filter(r=>r.status==='REQUESTED').length} label="Requested" icon={Clock} color={L.amb}/>
      </div>
      <InfoBanner color={L.blue} bg={L.blueBg} text="DQ rules governing this attribute — dimension coverage with the latest verdict, plain-English definition on demand, tenant scope, and last execution. Rules are authored and executed in the external engine."/>
      <div style={{fontSize:11,fontWeight:700,color:L.t2,margin:'14px 0 8px'}}>Dimension coverage · this attribute <span style={{fontWeight:400,color:L.t4}}>· as of {lastExec}</span></div>
      <Card noPad>
        <div style={{display:'flex',alignItems:'center',padding:'10px 14px',borderBottom:`1px solid ${L.bd}`}}>
          {DQ_DIMS.map(d=><div key={d} style={{flex:1,textAlign:'center',fontSize:10,fontWeight:700,color:L.t3}}>{d}</div>)}
        </div>
        <div style={{display:'flex',alignItems:'center',padding:'8px 14px'}}>
          {DQ_DIMS.map((d,k)=> d==='Timeliness'?<MxCell key={k} kind="time" c={timelinessFor(objKey)}/> : ruleCovers(ar,objKey,attrLn,d)?<MxCell key={k} c={cxAttrCell(attrObj,j,k)}/> : <MxCell key={k} kind="unmeasured"/>)}
        </div>
      </Card>
      <div style={{fontSize:11,fontWeight:700,color:L.t2,margin:'18px 0 8px'}}>Rules · definition on demand</div>
      <Card noPad>
        <div style={{display:'grid',gridTemplateColumns:'0.7fr 1.6fr 0.8fr 0.8fr 0.8fr 1fr 40px',minWidth:760}}>
          {['Rule ID','Rule','Type','Dimension','Status','Last execution',''].map((h,i)=><div key={i} style={{padding:'10px 12px',fontSize:10,fontWeight:700,color:L.t3,borderBottom:`1px solid ${L.bd}`,textTransform:'uppercase',letterSpacing:'.05em'}}>{h}</div>)}
          {ar.length===0 && <div style={{gridColumn:'1 / -1',padding:14,fontSize:12,color:L.t4}}>No DQ rules on this attribute yet. Request one from the Data Quality screen.</div>}
          {ar.map(r=>{const rs=CX_RULE_ST[r.status]||CX_RULE_ST.REQUESTED, sc=CX_SCOPE[r.scope]||CX_SCOPE.ATTRIBUTE, lr=cxLastRun(r), ex=!!open[r.rid]; return (
            <Fragment key={r.id}>
              <div style={{padding:'9px 12px',borderBottom:`1px solid ${L.s3}`,display:'flex',alignItems:'center'}}><span style={{fontFamily:L.mono,fontSize:10,fontWeight:700,color:L.purDk}}>{r.rid}</span></div>
              <div style={{padding:'9px 12px',fontSize:12,color:L.t1,borderBottom:`1px solid ${L.s3}`,cursor:'pointer'}} onClick={()=>setOpen(o=>({...o,[r.rid]:!o[r.rid]}))}>
                <span style={{display:'flex',alignItems:'center',gap:6,flexWrap:'wrap'}}><span style={{fontSize:9,color:L.t4}}>{ex?'▼':'▶'}</span>{r.name}<TenantChip tenant={r.tenant} sz={8}/></span></div>
              <div style={{padding:'9px 12px',borderBottom:`1px solid ${L.s3}`}}><Chip text={sc.short} c={sc.c} bg={sc.bg} sz={8}/></div>
              <div style={{padding:'9px 12px',fontSize:11,color:L.t2,borderBottom:`1px solid ${L.s3}`}}>{r.dim}</div>
              <div style={{padding:'9px 12px',borderBottom:`1px solid ${L.s3}`}}><Chip text={r.status} c={rs.c} bg={rs.bg} sz={8}/></div>
              <div style={{padding:'9px 12px',borderBottom:`1px solid ${L.s3}`}}><div style={{fontFamily:L.mono,fontSize:10,color:L.t2}}>{lr.ts}</div><div style={{fontSize:9,color:lr.c}}>{lr.note}</div></div>
              <div style={{padding:'7px 6px',borderBottom:`1px solid ${L.s3}`,display:'flex',justifyContent:'center'}}><HistBtn onClick={()=>setHistRule(r.id)}/></div>
              {ex && <div style={{gridColumn:'1 / -1',padding:'8px 14px 12px 34px',background:L.s2,borderBottom:`1px solid ${L.s3}`,fontSize:12,color:L.t2}}>
                <span style={{fontSize:10,fontWeight:700,color:L.t4,textTransform:'uppercase',letterSpacing:'.05em',marginRight:8}}>Definition</span>{cxPlainEnglish(r)}</div>}
            </Fragment>)})}
        </div>
      </Card>
      <Drawer open={!!histTarget} onClose={()=>setHistRule(null)} eyebrow="DQ Rule · History"
        title={histTarget?histTarget.name:''} sub={histTarget?`${histTarget.rid} · ${cxLogicalObj(histTarget.obj)}`:''}
        footer="Append-only governance log — who · what · when. Rule execution evidence lives in Audit & Evidence.">
        {histTarget && <HistoryTimeline events={cxRuleEvents(histTarget)}/>}
      </Drawer>
    </div>
  )
}

const NAV_SECTIONS = [
  {
    label:'Discovery',
    items:[
      {id:'hub',     label:'Semantic Hub',   Icon:LayoutDashboard},
      {id:'catalog', label:'Data Catalog',    Icon:BookOpen},
    ]
  },
  {
    label:'Registration',
    items:[
      {id:'register',      label:'Register Object',   Icon:Plus},
      {id:'relationships', label:'Relationship Mgmt', Icon:Network},
      {id:'pairings',      label:'Attribute Pairing', Icon:Link2},
      {id:'lookups',       label:'Filter Lookups',    Icon:Filter},
      {id:'hierarchy',     label:'Sem. Workspaces (prototype)',   Icon:Globe},
    ]
  },
  {
    label:'Operations',
    items:[
      {id:'query',    label:'Query Studio',   Icon:Play},
      {id:'workflow', label:'Workflow Queue', Icon:CheckSquare},
    ]
  },
  {
    label:'Consumption',
    items:[
      {id:'consumption', label:'Downstream Consumption', Icon:GitBranch},
    ]
  },
  {
    label:'Quality & Observability',
    items:[
      {id:'dq',            label:'Data Quality',       Icon:Shield},
      {id:'profiling',     label:'Data Profiling',     Icon:BarChart2},
      {id:'observability', label:'Data Observability', Icon:Activity},
    ]
  },
]

// Keep flat NAV for backwards compat
const NAV = NAV_SECTIONS.flatMap(s=>s.items)

function Sidebar({active, onNav}) {
  const pending = WF.filter(w=>w.st==='PENDING').length
  return (
    <div style={{
      width:216, background:L.s1, display:'flex', flexDirection:'column',
      flexShrink:0, borderRight:`1px solid ${L.bd}`,
    }}>
      {/* ── Brand ── */}
      <div style={{padding:'18px 16px 14px', borderBottom:`1px solid ${L.bd}`}}>
        <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:12}}>
          <div style={{width:32,height:32,borderRadius:8,background:L.teal,
            display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
            <Layers size={16} color="#fff"/>
          </div>
          <div>
            <div style={{fontSize:13,fontWeight:800,color:L.t1,letterSpacing:'0.06em',lineHeight:1}}>LEXTR</div>
            <div style={{fontSize:9,color:L.t4,letterSpacing:'0.1em',marginTop:2,textTransform:'uppercase'}}>Semantic Layer</div>
          </div>
        </div>
        <div style={{padding:'5px 9px',background:L.s3,borderRadius:6,border:`1px solid ${L.bd}`,
          display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <span style={{fontSize:9,color:L.t4,textTransform:'uppercase',letterSpacing:'.05em'}}>DDL</span>
          <span style={{fontSize:10,color:L.teal,fontWeight:700}}>v2.0 · v2.1 · v2.2</span>
        </div>
      </div>

      {/* ── Navigation ── */}
      <nav style={{flex:1,padding:'6px 0',overflow:'auto'}}>
        {NAV_SECTIONS.map(section=>(
          <div key={section.label} style={{marginBottom:2}}>
            <div style={{
              padding:'9px 16px 3px',
              fontSize:9,fontWeight:700,
              color:L.t4,
              textTransform:'uppercase',letterSpacing:'0.1em',
            }}>{section.label}</div>
            {section.items.map(({id,label,Icon})=>{
              const on = active===id
              const isPending = id==='workflow' && pending>0
              return (
                <button key={id} onClick={()=>onNav(id)} style={{
                  display:'flex', alignItems:'center', gap:9,
                  width:'100%', padding:'7px 16px',
                  border:'none', cursor:'pointer',
                  background:on?L.tealBg:'transparent',
                  borderLeft:on?`3px solid ${L.teal}`:'3px solid transparent',
                  textAlign:'left', transition:'background .12s',
                }}
                onMouseEnter={e=>{if(!on)e.currentTarget.style.background=L.s3}}
                onMouseLeave={e=>{if(!on)e.currentTarget.style.background='transparent'}}>
                  <div style={{
                    width:26, height:26, borderRadius:6, flexShrink:0,
                    display:'flex', alignItems:'center', justifyContent:'center',
                    background:on?L.teal+'22':L.s4,
                  }}>
                    <Icon size={13} color={on?L.teal:L.t3}/>
                  </div>
                  <span style={{
                    flex:1, fontSize:12, fontWeight:on?600:400,
                    color:on?L.teal:L.t2,
                    letterSpacing:'0.01em',
                  }}>{label}</span>
                  {isPending&&(
                    <span style={{
                      fontSize:9,fontWeight:700,background:L.cor,color:'#fff',
                      borderRadius:10,padding:'1px 6px',
                    }}>{pending}</span>
                  )}
                </button>
              )
            })}
          </div>
        ))}
      </nav>

      {/* ── Footer ── */}
      <div style={{
        padding:'10px 16px', borderTop:`1px solid ${L.bd}`,
        fontSize:9, lineHeight:1.9,
      }}>
        {['PostgreSQL · ClickHouse','Neo4j · Lextr semantic-service'].map(t=>(
          <div key={t} style={{color:L.t4}}>{t}</div>
        ))}
        <div style={{color:L.teal,fontWeight:700,marginTop:2}}>All Apache 2.0</div>
      </div>
    </div>
  )
}



// ══════════════════════════════════════════════════════════════════════
// APP SHELL — simple screen router
// Tab management is per-screen (Governance pattern): each screen manages
// its own draft tabs internally via GovTabStrip.
// ══════════════════════════════════════════════════════════════════════

const BASE_SCREENS = {
  hub:           HubScreen,
  catalog:       CatalogScreen,
  register:      RegisterScreen,
  relationships: RelationshipsScreen,
  pairings:      PairingsScreen,
  lookups:       FilterLookupScreen,
  hierarchy:     HierarchyScreen,
  query:         QueryStudioScreen,
  workflow:      WorkflowScreen,
  consumption:   DownstreamConsumptionScreen,
  dq:            DataQualityScreen,
  profiling:     DataProfilingScreen,
  observability: DataObservabilityScreen,
  dqflow:        DqRuleFlowScreen,
  ruleauthoring: RuleAuthoringScreen,
}


export default function SemanticLayerApp() {
  const [screen, setScreen] = useState('hub')
  const BaseScreen = BASE_SCREENS[screen] || HubScreen
  const handleNav  = (id) => { if (BASE_SCREENS[id]) setScreen(id) }

  return (
    <div style={{display:'flex',height:'100vh',fontFamily:L.font,background:L.s2,overflow:'hidden'}}>
      <Sidebar active={screen} onNav={handleNav}/>
      <main style={{flex:1,overflow:'auto',padding:'26px 28px'}}>
        <BaseScreen onNav={handleNav}/>
      </main>
    </div>
  )
}
