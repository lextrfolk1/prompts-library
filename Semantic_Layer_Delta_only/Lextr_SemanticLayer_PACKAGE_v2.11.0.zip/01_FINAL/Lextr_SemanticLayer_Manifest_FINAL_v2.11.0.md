# Lextr Semantic Layer — Development Manifest (digest)

**RELEASE: FINAL v2.11.0** · manifest 2.11.0+fable.1 (stable_v6) · released for development 2026-08-26

**Version:** 2.11.0+fable.1 · **Package:** stable_v6 · **FINAL — v2.11.0 lands SL-only items (Locale committed; Attribute Promotion PROPOSED, pending owner rulings + Core workflow stages)**

**44 logic points · 165 sub-tasks · 39 tables**

## v2.11.0

SL-side items completable without Core. COMMITTED (Locale, no Core dependency): meta.domain_value_text (localized value_desc + ai_context per locale, en-US fallback; value_cd never translated); LP-43 normalisation switched to Unicode case-folding + declared form (not LOWER()); DOMAIN_RESOLVE_TTL_SECONDS preset (version/as-of-pinned resolve is immutable). Attribute-name localization DEFERRED (recorded gap on LP-05). PROPOSED (pending owner rulings + Core workflow stages): LP-44 Attribute Promotion + V16 provenance columns.

## Changes (cumulative)

### New logic point
- **LP-43** — Domain registration + governed AI resolve. Governed domain store behind coded attributes; tenant-scoped, as-of, certified allowed values for AI grounding (no client-side mock).

### Amended logic points
- **LP-03** — Capture the full attribute authoring contract: exposure flags, semantic role, CDE/DE + source, domain block, operational block, effective dating.
- **LP-05** — Return the full contract so every captured field round-trips to the catalog + consumers.
- **LP-16** — Catalog shows DOMAIN ALLOWED VALUES from the governed LP-43 resolve — not a hardcoded map.
- **LP-17** — Register attribute step captures the full contract; inline-vs-reference guarded by DOMAIN_INLINE_MAX_CARDINALITY.
- **LP-39** — Completeness gate gains a UI->contract round-trip check: any dropped authoring field fails the build.

### New tables (additive V10)
- **meta.domain_catalog** — Governed codeset header. source_type INLINE|ENUMERATED|REFERENCE_TABLE; AI context; tenant; lifecycle; certification.
- **meta.domain_value** — (code, description) rows + sort/active, per-value AI context, regulatory ref, effective dates, source-freshness, lifecycle.

### attribute_catalog — new columns (additive V11)
- **semantic_role_cd** — CODE|DIMENSION|MEASURE|IDENTIFIER|DATE|FACT
- **semantic_enabled_flg / ai_exposed_flg** — Per-attribute exposure to the semantic layer / to AI (was UI-only)
- **element_class_cd / element_class_source_cd** — CDE|DE and ORGANIC|HUMAN provenance
- **domain_mode_cd** — NONE|YN_FLAG|ENUM_LIST|REF_DOMAIN
- **domain_values_jsonb** — ENUM_LIST inline values (small/private domains)
- **domain_cd / domain_ref_table_nm / domain_ref_code_col / domain_ref_desc_col** — REF_DOMAIN link: registered domain OR reference-table + which columns are code/description
- **insert_mode_cd / update_mode_cd / delete_mode_cd / immutable_flg / null_on_insert_flg / attr_source_system_cd** — Operational-behaviour block (the Operational tab)
- **effective_start_dt / effective_end_dt** — Per-attribute effective dating

### New governance threshold
- **DOMAIN_INLINE_MAX_CARDINALITY = 100** — policy_preset (DB-driven, tunable). At/below -> inline allowed; above, or shared/dynamic -> reference domain.

### New pending item
- **POL-DM-001** — Domain-resolve policy to author in the OPA bundle (LP-14).

### Committed since (owner approvals)
- **LP-41 · meta.tenant_workspace (+_object)** — Promoted PROPOSED → COMMITTED (2026-08-19). Bounded-agent scope: the explicit per-tenant object set an agent may operate over. Additive V8.

### v2.10.0 — Domain values at scale (Intelligence ASK)
- **meta.domain_value_synonym (V12)** — ASK 1/7 — governed vocabulary; UNIQUE NULLS NOT DISTINCT = one phrase→one value per scope; tenant overrides GLOBAL as tracked exception; four-eyes certified.
- **meta.domain_value_source_map (V13)** — ASK 5 — canonical value ← per-source stored code; gives resolution_basis=SOURCE_MAPPING real meaning.
- **domain_catalog.version_nbr / value_count_nbr (V14)** — ASK 6/4 — cite a domain version in saved reports; know cardinality before fetching.
- **domain_value.ai_exposure_cd (V14)** — ASK 7.1 — per-value AI exposure, inherits attribute, never wider.
- **DOMAIN_MAX_ENUMERATE_CARDINALITY (preset)** — ASK 4 — full-set resolve refuses above the ceiling and directs to search.
- **LP-43 amended** — ASK 3 — deterministic phrase resolve: EXACT|AMBIGUOUS|UNRESOLVED + required resolution_basis + version; no fuzzy/stemming/embedding; paginated trigram search; as-of past-version.
- **LP-12 amended** — ASK 7.2 — SYNONYM_AUTHOR four-eyes; resolve uses ACTIVE+certified synonyms only.
- **YN_FLAG removed** — ASK 2a — booleans are two-value ENUM_LIST so they carry descriptions + synonyms; existing YN_FLAG attrs need a curated migration.
- **FIX (v2.9.0 bug)** — DOMAIN_INLINE_MAX_CARDINALITY seed corrected to real policy_preset columns (was un-migratable).

### v2.11.0 — Locale (committed, no Core dependency)
- **meta.domain_value_text (V15)** — LOCALE Gap 1 — description + AI context localized per value per locale; en-US fallback; value_cd never translated.
- **LP-43 normalisation → Unicode case-folding** — Deterministic match correct for Turkish i / German ss / accents (not LOWER()).
- **DOMAIN_RESOLVE_TTL_SECONDS = 300 (preset)** — Resolve TTL stated; version/as-of-pinned resolve is immutable, cacheable indefinitely.

### v2.11.0 — deferred / proposed (need owner or Core)
- **Attribute-name localization** — DEFERRED recorded gap — meta.attribute_text for logical_long_nm + descriptions; English names until scheduled.
- **LP-44 Attribute Promotion (PROPOSED)** — Provenance (V16) + four-eyes promotion. Pending owner confirmation of 5 rulings + Core workflow stages.


## Logic points

### LP-01 — Apply fixed DDL as Flyway baseline migration
*Wave:* Wave 1 · *Depends:* —

The fixed PostgreSQL schema is the ring-fenced contract. It is applied exactly as delivered; the team builds against it and may not alter it. Tenancy key is client_id; taxonomy_cd carries MDRM.

**Scope.** Land Lextr_SemanticLayer_DDL.sql as V1__semantic_layer_baseline.sql in the Flyway migration set; verify all 18 tables (incl. the two attribute_pairing tables), indexes, seeds, and constraints apply cleanly on PostgreSQL 16.

**Steps:** Copy DDL into Flyway versioned migration; Run flyway migrate on clean DB; Run flyway validate; Smoke-query each table and the two seeds

**Tests:** Flyway migrate succeeds on a clean PG16; All 18 tables + indexes exist; governance.policy_preset seeded with 6 GOV-FL rows; data_connection seeded with PG/CH/Neo4j; Constraint checks reject bad enum values
**Pending:** P-09 standards version on header; ASSUMED-2 client_id length

### LP-02 — Schema & connection registry read API
*Wave:* Wave 2 · *Depends:* LP-01

Consumers and internal services resolve which engine an object lives on via the connection registry. Secrets are never returned — only secrets_ref exists and it stays server-side.

**Scope.** Spring Boot read endpoints: GET schemas; GET connections; GET connection by id (secrets_ref never exposed). DAO via NamedParameterJdbcTemplate, SQL in queries.properties.

**Steps:** Controller->Service->DAO->Impl scaffolding; Externalize SQL; Map rows to SNAKE_CASE DTOs; Unit tests with mocked DAO

**Tests:** GET /schemas returns active schemas; GET /connections excludes secrets_ref; GET /connections/{id} 404 on unknown; DAO SQL loaded from queries.properties; Coverage >=90%
**Pending:** P-04 API path convention

### LP-03 — Object registration API (producer write)
*Wave:* Wave 3 · *Depends:* LP-02

A producer (incl. the Regulatory Ingestion module) registers an object and its attributes. It lands DRAFT pending governance approval. Taxonomy/MDRM is first-class: taxonomy_cd(12) with jurisdictional length validated in OPA, not the DB. Attribute key metadata (pk_flg/fk_flg/nullable_flg) is captured at registration from introspection so dynamically-registered objects carry correct key roles for downstream key-aware screens (Relationships, Pairings) — eliminating any hardcoded client-side attribute-metadata map.

**Scope.** POST register object + attributes in one transaction; lands DRAFT; validates logical_short_nm<=32 and taxonomy_cd via OPA; writes audit; raises governance workflow task. Capture data classification (sensitivity tier + PII/MNPI/CSI flags + AI-exposure tier) at registration; values validated against meta.data_classification_ref (LP-31). Persist pk_flg/fk_flg/nullable_flg per attribute (from introspection) into meta.attribute_catalog (columns already in the baseline). Capture the FULL per-attribute authoring contract: semantic_role_cd; semantic_enabled_flg + ai_exposed_flg (per-attribute exposure); element_class_cd (CDE|DE) + element_class_source_cd; the domain block (domain_mode_cd NONE|YN_FLAG|ENUM_LIST|REF_DOMAIN; ENUM_LIST -> domain_values_jsonb; REF_DOMAIN -> domain_cd or domain_ref_table_nm + code/desc cols); the operational block (insert/update/delete mode, immutable_flg, null_on_insert_flg, attr_source_system_cd); and effective_start_dt/effective_end_dt.

**Steps:** Define request DTO (object + attrs[] + taxonomy fields); Validate <=32 names in service; Call OPA for taxonomy jurisdiction rule; Transactional insert object_catalog + attribute_catalog; Insert audit + workflow task; Capture + validate data classification at registration (LP-31 scheme); Persist pk_flg/fk_flg/nullable_flg per attribute (from introspection); Persist per-attribute exposure (semantic_enabled_flg, ai_exposed_flg) + semantic_role_cd; Persist CDE/DE element_class_cd + element_class_source_cd; Persist domain block (mode + inline values OR domain_cd/ref-table link + code/desc cols); Persist operational block + effective dating

**Tests:** Register persists object + attrs atomically; logical_short_nm>32 rejected; taxonomy_cd jurisdiction rule enforced via OPA (USA=8, Lextr=8, non-USA=12); Object lands DRAFT; Audit row written; Coverage >=90%; classification captured and validated against the governed scheme; pk_flg/fk_flg/nullable_flg persisted per attribute and round-trip via LP-05; every field the Register UI captures is persisted (exposure, role, CDE/DE, domain, operational, effective); ENUM_LIST persists domain_values_jsonb; REF_DOMAIN persists domain_cd or ref-table+cols
**Pending:** P-02 taxonomy resolved (now in DDL); P-05 producer write surface; ASSUMED-1 OPA taxonomy rule

### LP-04 — Taxonomy/MDRM jurisdiction OPA policy
*Wave:* Wave 2 · *Depends:* LP-01

MDRM (called Taxonomy globally) has jurisdiction-specific length rules. Because this is jurisdictional business policy, it lives in OPA — not a DB constraint — so it can change without a schema migration.

**Scope.** OPA/Rego package validating taxonomy_cd length by jurisdiction/source: USA reg-defined=8, Lextr-assigned=8, non-USA=12. Externalized; only binding reference in DB.

**Steps:** Define input contract (taxonomy_cd, source, jurisdiction); Write allow/deny + reason rules; opa test for every branch; Register binding reference

**Tests:** USA REG_DEFINED 8-char passes; 12 fails; Lextr LEXTR_ASSIGNED 8 passes; non-USA 12 passes; 8 fails; Missing jurisdiction -> deny with reason; opa test coverage of all branches
**Pending:** ASSUMED-1 confirm OPA placement vs CHECK

### LP-05 — Object/attribute read & exposure API
*Wave:* Wave 3 · *Depends:* LP-02

Consumers read objects via list (filter by schema, lifecycle status; client-scoped) and detail (object with its attributes, effective override names applied). This is the stable exposure contract the rebuild must keep. Read/exposure enforces POL-AC-001 (ring-fencing) and POL-DC-001 (classification masking) at the OPA gateway; callers only receive entitled, appropriately-masked fields.

**Scope.** GET list objects (filter schema,status; client-scoped); GET object detail with attrs[]; GET attributes; introspect endpoint. Effective override names applied. Enforce POL-AC-001 ring-fencing + POL-DC-001 classification masking (authored in LP-31) on every read/exposure; deny cross-tenant; mask/withhold unentitled fields. Physical-name resolution for external engines is a separate governed endpoint (LP-32), not this read path. Attribute detail/exposure returns pk_flg/fk_flg/nullable_flg so consumers (Relationships/Pairings key pickers) resolve keys dynamically with no hardcoded map. Attribute detail/exposure returns the full authoring contract: semantic_role_cd, semantic_enabled_flg, ai_exposed_flg, element_class_cd/source, the domain block (mode + resolved allowed values via LP-43), the operational block, and effective dating — so everything the Register UI captured round-trips to the catalog and consumers.

**Steps:** List endpoint with optional filters; Detail endpoint joining attributes; Apply approved logical-name overrides; client_id scoping in WHERE (OPA-checked); Unit tests; Apply POL-AC-001 + POL-DC-001 on read/exposure (mask/withhold; deny cross-tenant); Return pk_flg/fk_flg/nullable_flg on attribute detail/exposure; Return the full attribute authoring contract incl. resolved domain allowed values (via LP-43)

**Tests:** List filters by schema and status; Detail returns object + attrs[]; client_id scoping returns GLOBAL + caller client rows; Effective override name applied when approved; Coverage >=90%; cross-tenant denied; unentitled/Restricted fields masked or withheld; attribute detail returns pk_flg/fk_flg/nullable_flg; attribute detail round-trips every field LP-03 captured (no silent drop)
**Pending:** P-06 jurisdiction/report/period filters; P-04 API path; Attribute-name localization (logical_long_nm + descriptions) via a meta.attribute_text table — DEFERRED (recorded gap); ship English names until owner schedules [v2.11.0]

### LP-06 — Relationship registration + Neo4j projection
*Wave:* Wave 4 · *Depends:* LP-03

A relationship is governed in PostgreSQL (system of record) and projected into Neo4j for traversal/visualization. Cross-engine relationships are blocked by OPA POL-CE-001.

**Scope.** POST relationship (PG system of record); cross-engine check via OPA POL-CE-001; on save, project node/edge into Neo4j (Spring Data Neo4j); stamp neo4j_synced_ts. GET /relationships (list; client-scoped; filterable by object) so the Relationship screen reads governed joins from the PG system of record instead of local storage; Neo4j remains the traversal projection.

**Steps:** Resolve engines of both objects; OPA POL-CE-001 check; Insert relationship row; Project to Neo4j via Spring Data Neo4j; Stamp neo4j_synced_ts; GET /relationships list endpoint (PG system of record; client-scoped)

**Tests:** Same-engine relationship persists; Cross-engine blocked by POL-CE-001 with both engines named; Neo4j node/edge created on save; neo4j_synced_ts stamped; Coverage >=90%; GET /relationships lists persisted relationships; client scoping respected
**Pending:** ASSUMED-4 projection direction

### LP-07 — Filter lookup registration + governance floor
*Wave:* Wave 3 · *Depends:* LP-02

Filter lookups are reusable governed value sets. Review period is governed by GOV-FL-001 (read from DB). An override looser than the floor is rejected, naming the policy.

**Scope.** POST register lookup (SQL_QUERY|MANUAL_LIST); read GOV-FL-001 from policy_preset; reject override>floor with 422+policy code; land DRAFT; raise workflow task.

**Steps:** Validate construction-type-specific fields; Read GOV-FL-001 from policy_preset; Compare override to floor; Insert lookup DRAFT; Raise workflow task

**Tests:** SQL_QUERY requires filter_obj/condition/attr; MANUAL_LIST requires subtype; override>GOV-FL-001 -> 422 naming GOV-FL-001; valid within floor -> DRAFT; Coverage >=90%

### LP-08 — Effective-review-period + health (service layer)
*Wave:* Wave 4 · *Depends:* LP-07

Effective review period and lookup health are computed in the Java service (the standard stack keeps logic in services, not the DB). Source can be GOV_DEFAULT, LOOKUP_OVERRIDE, or GOV_ENFORCED.

**Scope.** Service-layer computation of effective review period (floor vs stricter override vs HAND_TYPED 0.5x factor) and lookup health; expose read endpoints. NO PG functions/triggers.

**Steps:** Service method reading policy_preset; Resolve floor vs override vs factor; Compute health from value lifecycle + review due; Expose read endpoints; Unit tests for all paths

**Tests:** Floor path returns GOV-FL-001; Stricter override accepted; Looser override capped -> GOV_ENFORCED + note; HAND_TYPED applies 0.5x (90->45); health states computed (HEALTHY/REVIEW_DUE/AT_RISK/PENDING); Coverage >=90%
**Pending:** ASSUMED-5 confirm service-layer relocation

### LP-09 — Filter lookup Phase-1 preview + exec log
*Wave:* Wave 4 · *Depends:* LP-07

Before use, a lookup is previewed (Phase 1). Manual lists return active/anticipated values; SQL lookups execute distinct on their engine. Every execution is logged for audit and stats.

**Scope.** POST preview: MANUAL_LIST returns ACTIVE+ANTICIPATED values; SQL_QUERY runs distinct on the lookup engine; append exec-log row every time; return sample+count+duration.

**Steps:** Branch on construction type; Resolve engine + execute or read values; Append exec-log; Return preview payload

**Tests:** MANUAL_LIST returns ACTIVE+ANTICIPATED only; SQL_QUERY executes on resolved engine; exec-log row appended each run; strategy + duration recorded; Coverage >=90%
**Pending:** P-07 self-healing on engine call

### LP-10 — Certify + stale-value policy (POL-SV-001)
*Wave:* Wave 5 · *Depends:* LP-08, LP-09

Certification marks a lookup current/healthy. Stale (inactive-in-source) values block certification via OPA POL-SV-001.

**Scope.** POST certify: count INACTIVE_IN_SOURCE; OPA POL-SV-001; on block 422; on success set last_certified, health HEALTHY, next_review_due via LP-08, write audit.

**Steps:** Count inactive values; OPA POL-SV-001; Set certified + health + review-due; Audit

**Tests:** inactive>0 -> POL-SV-001 blocks with 422; inactive=0 -> certifies, health HEALTHY; next_review_due set from effective period; audit row written; Coverage >=90%

### LP-11 — Bind lookup + overdue-review policy (POL-SV-002)
*Wave:* Wave 5 · *Depends:* LP-08

Binding applies a lookup where needed. Pipeline binding of an overdue lookup is blocked by POL-SV-002; interactive Query Studio use is exempt.

**Scope.** POST bind: context RULE|QUERY_STUDIO|PIPELINE|LEXIE; if PIPELINE and overdue, OPA POL-SV-002 blocks; QUERY_STUDIO exempt; insert binding.

**Steps:** Resolve review status; OPA POL-SV-002 if PIPELINE; Insert binding

**Tests:** PIPELINE + overdue -> POL-SV-002 blocks; QUERY_STUDIO + overdue -> allowed; binding row created; Coverage >=90%

### LP-12 — Governance workflow approval + typed side-effects
*Wave:* Wave 5 · *Depends:* LP-03, LP-07

Every governed change flows through the workflow queue. Approval triggers a typed side effect and writes audit. Approved tasks cannot be re-approved. New typed task types DQ_RULE_REQUEST (LP-24) and CONSUMPTION_PROMOTE (LP-28) extend the queue; task_type_cd is varchar(40) with no CHECK, so the values are additive while the side-effect dispatch is new service logic. Rejection is symmetric to approval: a typed rejection side-effect demotes the operational entity (object/lookup/pairing/relationship/override) to REJECTED/INACTIVE, so a rejected item never remains usable. Previously only the task record changed.

**Scope.** GET queue (filter status/type); POST approve: typed side-effects (activate lookup, apply LNO, activate anticipated value, raise DQ rule request, promote consumption outbound); audit; non-repeatable. POST reject: typed rejection side-effects (demote the operational entity to REJECTED/INACTIVE by task_type), symmetric to approve; audit; non-repeatable. New typed task SYNONYM_AUTHOR (LP-43): a domain-value synonym is a semantic assertion and requires four-eyes approval; on approval, set certified_by/certified_ts; resolve uses only ACTIVE + certified synonyms.

**Steps:** Queue read with filters; Approve dispatch by task_type; Apply side effect transactionally; Audit; Add DQ_RULE_REQUEST + CONSUMPTION_PROMOTE dispatch (typed side-effects); Reject dispatch by task_type (demote operational entity to REJECTED/INACTIVE); Add SYNONYM_AUTHOR dispatch (four-eyes; set certified_by/ts on approval)

**Tests:** approve FILTER_LOOKUP_REGISTER -> lookup ACTIVE; approve LNO_APPROVE -> override APPROVED; approve ANTICIPATED_VALUE -> value ANTICIPATED + workflow_ref; re-approve rejected; audit written; Coverage >=90%; approve DQ_RULE_REQUEST surfaces requested rule; approve CONSUMPTION_PROMOTE advances env; reject FILTER_LOOKUP_REGISTER -> lookup INACTIVE/REJECTED; reject OBJECT_REGISTRATION -> object REJECTED; reject ATTRIBUTE_PAIRING/RELATIONSHIP -> entity REJECTED/INACTIVE; approve SYNONYM_AUTHOR -> synonym certified + resolvable; unapproved synonym not used in resolve

### LP-13 — Governance presets read API (startup defaults)
*Wave:* Wave 2 · *Depends:* LP-01

The whole platform reads its defaults from governance.policy_preset at startup. Nothing is hardcoded.

**Scope.** GET governance defaults (all presets, value cast to declared type, keyed by code); GET one preset.

**Steps:** Read presets; Cast by data_type_cd; Return keyed map

**Tests:** all presets returned keyed by code; INTEGER/BOOLEAN/DECIMAL cast correctly; unknown preset 404; Coverage >=90%

### LP-14 — OPA policy bundle: cross-engine + stale + overdue
*Wave:* Wave 2 · *Depends:* LP-01

All authorization/business policy is externalized to OPA. Five policies plus the taxonomy policy (LP-04) form the bundle. Evaluation fails open with logging so an outage never hard-stops the platform; every decision is recorded. POL-CE-002 also governs cross-engine attribute pairing, consumed by LP-22. v2.5.0 adds POL-DQ-001 (DQ request-only + tenant-scope + result principal, LP-24) and POL-CL-001 (consumption promotion gate, LP-28) to the bundle. v2.6.0 adds POL-AC-001 (access ring-fencing) and POL-DC-001 (classification-driven exposure), authored in LP-31, to the bundle. v2.7.0 adds POL-RS-001 (resolution exposure, LP-32) and POL-RR-001 (rule-output ingest, LP-33).

**Scope.** Rego packages: POL-CE-001/002/003 (cross-engine relationship/pairing/workspace), POL-SV-001 (stale), POL-SV-002 (overdue, QS exempt); POL-DQ-001 (DQ request gate); POL-CL-001 (consumption promotion gate); POL-AC-001 (access ring-fencing); POL-DC-001 (classification-driven exposure); POL-RS-001 (logical→physical resolution exposure); POL-RR-001 (external rule-output ingest). Single entry point; fail-open with logging. POL-DM-001 (domain resolve) covers: tenant isolation on resolve (cross-tenant DENIED, never silently filtered); principal entitlement (who may resolve which domain); per-value AI-exposure gate (ai_exposure_cd, never wider than the attribute); and REFUSAL above DOMAIN_MAX_ENUMERATE_CARDINALITY as a policy decision (not service logic).

**Steps:** Author 9 policy packages; Single evaluate entry point; opa test per branch; Register binding references

**Tests:** each policy allow/deny branch; reason text names policy code; QS exemption in POL-SV-002; default deny on unknown policy; opa test all branches; POL-DQ-001 + POL-CL-001 allow/deny branches covered; POL-AC-001 + POL-DC-001 allow/deny branches covered; POL-RS-001 + POL-RR-001 allow/deny branches covered; POL-DM-001: cross-tenant denied; per-value AI-exposure enforced; cardinality-ceiling refusal named
**Pending:** P-07 self-healing pattern around OPA client

### LP-15 — Tenant theming primitives (logo, CSS, multi-tenant)
*Wave:* Wave 1 · *Depends:* —

Every screen renders under tenant theming: configurable logo and client-pointable CSS, multi-tenant by default, brand-free token-driven theme. v2.5.0 names three reusable governance primitives consumed platform-wide: Drawer+HistoryTimeline (append-only history slide-in), GovTabStrip (base tabs + closeable draft tabs carrying Draft IDs), and TenantChip (GLOBAL vs client scope).

**Scope.** React/MUI theme primitives consuming TENANT.logoUrl and TENANT.cssOverrideUrl; token-only, brand-free; client-pointable CSS; multi-tenant theming flow-through. Also expose shared FE governance primitives: Drawer+HistoryTimeline, GovTabStrip (draft-tab pattern with Draft IDs), TenantChip (GLOBAL vs client).

**Steps:** Theme provider reading TENANT config; Logo + CSS override hooks; Fallback theme; Tests; Shared primitives: Drawer+HistoryTimeline, GovTabStrip, TenantChip

**Tests:** logoUrl renders configured logo; cssOverrideUrl applied at runtime; default theme when tenant config absent; no hardcoded brand; Coverage >=90%; Drawer/HistoryTimeline, GovTabStrip draft tabs, and TenantChip render and are reusable

### LP-16 — Data Catalog screen (dual tree + search)
*Wave:* Wave 4 · *Depends:* LP-05, LP-15, LP-24, LP-30

Data Catalog lets a steward browse objects in a technical or data-asset tree, search by logical or physical name, and inspect an object's attributes. Logical name primary, physical secondary. v2.5.0 adds object-level and attribute-level Data Quality tabs, an object history drawer, and a GLOBAL tenant-scope chip.

**Scope.** React/MUI/AG Grid: dual technical/data-asset tree, search across logical+physical names, match counts, named empty state, object detail with attributes. Add object-level + attribute-level Data Quality tabs (rule counts, on-demand plain-English definitions, timestamped dimension matrix — data from LP-24), an object history drawer (LP-30), a GLOBAL tenant-scope chip, and the attribute tab set (Detail / Operational / Data Quality / Usage / AI Context / CDE-DE). Surface each object/attribute's data classification (sensitivity tier + PII/MNPI/CSI + AI-exposure) in the catalog (read-only). Attribute detail shows DOMAIN + governed DOMAIN ALLOWED VALUES resolved via LP-43 (never client-side mock), tenant-scoped and lifecycle-filtered; plus semantic/AI exposure, CDE/DE, operational and effective-dating fields.

**Steps:** Tree component (two modes); Search filter logic; Detail panel; Wire to LP-05 API via Redux; DQ tabs (object+attribute) from LP-24; object history drawer from LP-30; GLOBAL scope chip; Show data classification chips on objects/attributes (from LP-31)

**Tests:** dual tree renders from API; search filters logical+physical, shows count; empty state names term; detail shows attrs with logical primary/physical secondary; Coverage >=90%; object + attribute DQ tabs render rule counts and definitions; history drawer + GLOBAL chip render; classification surfaced read-only on objects + attributes; allowed values render from the governed resolve (LP-43), not a hardcoded map
**Pending:** P-04 API path

### LP-17 — Register Object wizard (5-step)
*Wave:* Wave 4 · *Depends:* LP-03, LP-05, LP-15, LP-30

A steward registers an object through a 5-step wizard. The object is chosen from a GOVERNED INVENTORY PICKER (no free-text object code): a Schema -> Object Type -> Object drill-down filtered to the registration-actionable subset (New / Has-Updates / Pending / Not-Eligible). The Register list defaults to a registration queue (actionable subset) with an 'All objects' toggle, synced to the full object inventory. Taxonomy/MDRM with jurisdiction is captured; submit lands the object DRAFT for governance approval.

**Scope.** MUI Stepper: schema -> object type -> object (governed inventory picker; registration-actionable subset; Not-Eligible disabled with reason) -> introspect -> names & roles (<=32 validation) -> taxonomy/CDE -> classification -> review & submit; posts to LP-03. Register list = registration queue (default) with an All-objects toggle; 'Has Updates' is a derived status (REGISTERED with attrReg<attrTotal). GLOBAL tenant-scope indicator + object history drawer (LP-30). Picker is fed by existing LP-05/LP-02 reads (object inventory + attribute counts); 'registration-actionable' and 'Has Updates' are UI-derived — FE/UX only, no schema/contract change (additive, downstream-only). The attribute step captures the full authoring contract (semantic/AI exposure per attribute, semantic role, CDE/DE + source, domain mode incl. Enumerated-list inline values and Reference-domain/Reference-table link with code/desc column mapping, operational block, effective dates) and posts it to LP-03; DOMAIN_INLINE_MAX_CARDINALITY guards inline vs reference.

**Steps:** Governed ObjectPicker (Schema -> Object Type -> Object) sourced from LP-05/LP-02 reads; Registration-queue default view + All-objects toggle (synced to object inventory); Not-Eligible disabled with reason; 'Has Updates' derived status; Stepper scaffold + per-step validation (<=32 names); Taxonomy capture + classification step (LP-31 scheme); Submit to LP-03; GLOBAL scope indicator + object history drawer (LP-30)

**Tests:** object chosen from picker (no free-text object code); Schema -> Object Type -> Object drill-down filters the picker; changing schema/type clears object; Not-Eligible options shown disabled with reason; registration queue is default; All-objects toggle reveals full inventory; 'Has Updates' derived for REGISTERED objects with attrReg<attrTotal; 5 steps gate correctly; logical_short_nm>32 blocks advance; submit posts and lands DRAFT; classification captured + validated; Coverage >=90%; Enumerated-list captures inline values; Reference-domain captures domain_cd or ref-table+code/desc cols; inline domain blocked above DOMAIN_INLINE_MAX_CARDINALITY (policy_preset)
**Pending:** P-05 producer write surface

### LP-18 — Filter Lookups screen (register/preview/certify/bind)
*Wave:* Wave 6 · *Depends:* LP-07, LP-09, LP-10, LP-11, LP-13, LP-15, LP-30

The richest governance screen: register, preview, certify, and bind lookups. Review period is read-only (GOV-FL-001 badge); policy blocks surface their code.

**Scope.** AG Grid registry + detail (6 stat cards), registration form (SQL/manual subtypes), value grid (lifecycle, FUTURE_PENDING approve/reject), read-only review period with GOV-FL-001 badge + exception request, preview/certify/bind actions. Add a per-row history clock opening the shared Drawer+HistoryTimeline (LP-15 primitive, fed by LP-30).

**Steps:** Registry grid (LP-07/08 reads); Registration form; Value grid; Action wiring (LP-09/10/11); Per-row history clock -> Drawer+HistoryTimeline (LP-30)

**Tests:** registry renders health from API; review period read-only + badge; HAND_TYPED shows caution; FUTURE_PENDING shows approve/reject; preview/certify/bind call APIs and surface POL-SV codes; Coverage >=90%; per-row history drawer renders the entity timeline

### LP-19 — Relationship view (Cytoscape over Neo4j)
*Wave:* Wave 6 · *Depends:* LP-06, LP-15, LP-30

Relationships are visualized with Cytoscape.js over the Neo4j projection. The PostgreSQL manifest remains the system of record.

**Scope.** Cytoscape.js graph rendering the relationship/lineage graph from Neo4j; node = object, edge = relationship; cross-engine relationships visually flagged; POL-CE-001 block surfaced on attempted save. Add a per-row history clock opening the shared Drawer+HistoryTimeline (LP-15 primitive, fed by LP-30).

**Steps:** Cytoscape component; Fetch projected graph; Render + style cross-engine; Surface policy block; Per-row history clock -> Drawer+HistoryTimeline (LP-30)

**Tests:** graph renders nodes/edges from Neo4j projection; cross-engine edge flagged; POL-CE-001 block surfaces with policy code; layout stable on N nodes; Coverage >=90%; per-row history drawer renders the entity timeline

### LP-20 — Query Studio (assemble, tag lookup, generate SQL)
*Wave:* Wave 7 · *Depends:* LP-05, LP-09, LP-11, LP-14, LP-15, LP-22

Query Studio assembles a query visually, tags governed filter lookups, enforces single-engine via POL-CE-003, and generates physical SQL with logical aliases. The most complex interaction; integrates multiple services. Approved attribute pairings substitute a display attribute for its indexed filter attribute during SQL generation (resolved natively by the semantic-service; LP-22).

**Scope.** Assemble workspace of attributes; tag eligible lookups; POL-CE-003 single-engine check; Phase-1 resolve; generate physical SQL with logical aliases + comment header; execution trace; apply approved attribute pairings (display→filter substitution) during SQL generation via the semantic-service (LP-22).

**Steps:** Workspace grid; Eligibility computation client-side; Phase-1 resolve via LP-09; SQL generation; POL-CE-003 + trace

**Tests:** add/remove attribute updates workspace + clears tag; only eligible lookups offered (attr/domain/boolean match); cross-engine workspace blocked by POL-CE-003; SQL uses physical names + logical aliases; <=20 inline, >20 counted placeholder, large = strategy placeholder; Coverage >=90%; approved pairing substitutes display→filter attribute in generated SQL
**Pending:** P-08 Cube/analytics scope (note: no Cube.dev; Lextr semantic-service)

### LP-21 — Workflow Queue screen
*Wave:* Wave 6 · *Depends:* LP-12, LP-15

Approvers work a typed queue; approval triggers the governed side effect. A shared governance banner surfaces policy codes platform-wide.

**Scope.** AG Grid of pending tasks; typed approve/reject; presets panel (read-only); governance banner shared component naming the policy code on blocks.

**Steps:** Queue grid; Approve/reject wiring; Presets panel; Shared GovernanceBanner

**Tests:** queue renders pending tasks; approve calls LP-12 and reflects side effect; presets panel shows GOV-FL values; governance banner shows policy code; Coverage >=90%

### LP-22 — Attribute pairing registration + resolution API
*Wave:* Wave 4 · *Depends:* LP-03

Attribute pairing lets a consumer filter on a human-readable DISPLAY attribute (e.g. customer_nm) while the Lextr-native semantic-service substitutes an indexed FILTER attribute (e.g. customer_id) before SQL generation. Both attributes must be registered on the same object; the filter attribute must be indexed before activation. Resolution and value caching are native to the semantic-service (NO Cube.dev). Cross-engine pairing is blocked by OPA POL-CE-002.

**Scope.** POST register pairing (validate both attrs registered on the same object, display<>filter, land DRAFT, raise workflow task); activation gate verifies the filter attribute is indexed; POST resolve/preview (Phase-1 fill the value cache via INLINE_MAP | CACHED_LOOKUP | RUNTIME_QUERY); cross-engine check via OPA POL-CE-002; audit on every change. GET /attribute-pairings (list; client-scoped) for the registry screen; INLINE_MAP accepts a VALIDATED display->filter JSON map persisted to lookup_inline_map_jsonb (not a placeholder).

**Steps:** Validate both attributes exist on the object and display<>filter; Verify filter attribute is indexed (service-layer activation gate); Cross-engine check via OPA POL-CE-002; Insert pairing DRAFT + workflow task; Resolve+cache values on preview; append cache rows; compute TTL/expiry in service; GET /attribute-pairings list endpoint (client-scoped); INLINE_MAP: accept + validate a display->filter JSON map; persist to lookup_inline_map_jsonb

**Tests:** register persists pairing DRAFT atomically; display==filter rejected; unregistered attribute rejected; activation blocked when filter attribute not indexed; cross-engine pairing blocked by POL-CE-002 naming both engines; resolve fills value cache; expiry computed in service; audit row written; coverage >=90%; GET /attribute-pairings lists registered pairings; client scoping respected; INLINE_MAP rejects malformed JSON; valid map persisted to lookup_inline_map_jsonb
**Pending:** P-12 pairing strategy defaults + index-verification mechanism

### LP-23 — Attribute Pairing screen (registry + register + value cache)
*Wave:* Wave 6 · *Depends:* LP-15, LP-22, LP-30

A steward registers and manages attribute pairings: a registry of display→filter pairings (strategy, cardinality, cross-engine flag, governance status), a register form, and a value-cache view. Surfaces the index-required activation gate and the POL-CE-002 cross-engine block.

**Scope.** React/MUI/AG Grid: pairing registry grid (display→filter, strategy, cardinality, cross-engine, governance status), register form (object → display attr → filter attr → strategy/cardinality), value-cache panel, governance status; surfaces POL-CE-002 block and index-required gate. Add a per-row history clock opening the shared Drawer+HistoryTimeline (LP-15 primitive, fed by LP-30). When strategy = INLINE_MAP, render a validated JSON map field (multiline, monospace); block submit on invalid JSON; bind the parsed map to lookup_inline_map_jsonb.

**Steps:** Registry grid from LP-22 reads; Register form with attribute pickers; Value-cache panel; Wire actions to LP-22 via Redux; surface policy/gate messages; Per-row history clock -> Drawer+HistoryTimeline (LP-30); Conditional INLINE_MAP JSON field with validation; disable submit on invalid JSON

**Tests:** registry renders from API; register form blocks display==filter; index-required gate surfaced on activation; POL-CE-002 cross-engine block surfaced with policy code; value-cache panel renders; coverage >=90%; per-row history drawer renders the entity timeline; INLINE_MAP renders a JSON map field; malformed JSON blocks submit; parsed map sent in payload
**Pending:** P-12

### LP-24 — Data Quality rule catalog + request / observe API
*Wave:* Wave 6 · *Depends:* LP-03, LP-05, LP-12, LP-14

The Semantic Layer hosts DQ rule definitions and status and lets a steward REQUEST a rule in plain English; authoring and execution are EXTERNAL. A rule runs once on base inputs keyed by logical attribute + client_id; downstream consumption inherits the verdict. Dimensions: Completeness, Validity, Conformity, Consistency, Uniqueness, Timeliness. Accuracy is externally attested (not rule-driven). Timeliness is sourced from observability (LP-27). A large portion of DQ rules are client-scoped (client_id); registration is mostly GLOBAL.

**Scope.** POST /dq/rule-requests (plain-English text + @-mentioned attributes + #-threshold + suggested dimension + justification + tenant scope; lands REQUESTED; raises a DQ_RULE_REQUEST workflow task via LP-12; request-only, never authors/executes). GET /dq/rules (inventory filterable by object/attribute/dimension/status/tenant; stable dq_rule_cd DQR-####, scope ATTRIBUTE|CROSS_ATTRIBUTE|CONDITIONAL, plain-English definition, last_run_ts, result). GET /dq/matrix (object x dimension and attribute x dimension coverage with latest verdict; measured vs UNMEASURED cells distinguished). POST /dq/results (external engine posts execution verdicts; append-only; write restricted to the engine principal via OPA POL-DQ-001).

**Steps:** Land additive Flyway migration V3__data_quality.sql (3 tables); Author request endpoint (REQUEST-only) + workflow task side-effect; Author read endpoints: rules inventory + coverage matrix; Author result-ingest endpoint restricted to engine principal; OPA POL-DQ-001 (request-only + tenant-scope + result principal); Audit every change to meta.metadata_change_history; events to LP-30

**Tests:** request lands REQUESTED and raises a DQ_RULE_REQUEST workflow task; @-mentioned attributes and #-threshold parse into attributes[] + threshold; matrix marks unmeasured cells distinctly; Accuracy never rule-driven; POST /dq/results rejected for a non-engine principal (POL-DQ-001); client_id scoping returns GLOBAL + caller client rows; the API never authors or executes a rule; Coverage >=90%
**Pending:** OWNER-APPROVAL: 3 DQ tables (CONTRACT); dimension vocabulary (STANDARD); request-only boundary (DECISION)

### LP-25 — Data Quality screen (matrix + rules + plain-English request)
*Wave:* Wave 7 · *Depends:* LP-24, LP-15

A steward sees the DQ coverage matrix, the rules inventory with on-demand plain-English definitions and last execution, and can REQUEST a rule in plain English. Rule authoring and the rule-flow lifecycle are documented separately and are not in-app screens.

**Scope.** React/MUI/AG Grid: object/attribute x dimension matrix (unmeasured cells, 'how each dimension is determined' slide-in), rules inventory (DQR-#### id, on-demand definition, last execution, per-rule history drawer), plain-English request as a closeable DRAFT TAB with @-mention attributes + #-mention thresholds + Draft ID (shared GovTabStrip from LP-15), tenant filter (GLOBAL/client). Surfaces the request-only boundary.

**Steps:** Matrix grid (LP-24 reads); Rules inventory + definition on demand; Request draft-tab with @/# mention input; History drawer (LP-30); Wire to LP-24 via Redux

**Tests:** matrix renders measured vs unmeasured cells; @/# mention insert attributes/thresholds; request submits to LP-24 and lands REQUESTED; tenant filter narrows inventory; per-rule history drawer renders; Coverage >=90%

### LP-26 — Data Profiling read API + screen
*Wave:* Wave 6 · *Depends:* LP-05, LP-15

An external engine computes profiling metrics; the Semantic Layer PRESENTS them. Per-object logical-attribute metrics (null %, distinct %, role, status) with a last-profiled timestamp. The layer does not compute profiling.

**Scope.** GET /profiling/{object} read API returning per-attribute metrics + last_profiled_ts. React/MUI/AG Grid screen rendering per-object profiling results with last-profiled timestamp. Additive migration V4 supplies meta.profiling_result.

**Steps:** Land profiling_result in additive migration V4__profiling_observability.sql; Read endpoint per object; Service maps rows to DTOs; FE profiling screen; Tests

**Tests:** read returns per-attribute null %/distinct %/role/status; last_profiled_ts surfaced; client scoping respected; screen renders from API; Coverage >=90%
**Pending:** OWNER-APPROVAL: profiling_result table (CONTRACT)

### LP-27 — Data Observability signal ingest + correlation API + screen
*Wave:* Wave 7 · *Depends:* LP-05, LP-12, LP-24, LP-15

External tooling EMITS pipeline/store signals; the Semantic Layer ingests, correlates, and can trigger a DQ re-run (LP-24) or route a finding to the Workflow Queue (LP-12). Signal types: Freshness, Volume, Schema drift, Null-rate spike, Distribution shift; severity HIGH/WARN/INFO; status OPEN/TRIAGE/ACK/RESOLVED; detected_ts. Timeliness verdicts feed the DQ matrix.

**Scope.** POST /observability/signals (ingest from external tooling), GET /observability/signals (filter object/severity/status), POST /observability/signals/{id}/route (raise workflow task) and /trigger-dq (re-run via LP-24). Correlation/auto-trigger thresholds read from governance.policy_preset (DB-driven). React/MUI/AG Grid screen. Additive migration V4 supplies meta.observability_signal. Domain drift: a domain_value whose last_seen_in_source_ts goes stale raises a Schema drift / Distribution shift signal (so a value disappearing from source is observable, not silent).

**Steps:** Land observability_signal in additive migration V4; Ingest + read endpoints; Correlation/route/trigger service (LP-12 + LP-24); Thresholds from policy_preset; Observability screen; Tests

**Tests:** ingest persists a signal with severity + status; route raises a workflow task (LP-12); trigger-dq calls LP-24 re-run; thresholds read from policy_preset, never hardcoded; screen renders signals with severity/status; Coverage >=90%; stale domain_value.last_seen_in_source_ts raises a drift signal
**Pending:** OWNER-APPROVAL: observability_signal table (CONTRACT)

### LP-28 — Consumption-layer exposure + SDLC promotion API
*Wave:* Wave 6 · *Depends:* LP-03, LP-05, LP-12, LP-14

How the governed layer is EXPOSED downstream: a consumption layer (ad-hoc, rules dataset, intelligence descriptor, regulatory report), each outbound exposure as TECHNICAL (schema/table/column) or DATA_ASSET (domain/asset/attribute) structure, an aggregation pyramid (grain -> logical attributes), and an SDLC promotion track DRAFT->DEV->TEST->UAT->PROD with four gates: validation, OPA policy, governance approval via wkfl.workflow_task, versioned apply. Roles DEV=Developer, TEST=QA, UAT=Steward, PROD=Owner. The pyramid resolves to logical attributes only (no physical leakage).

**Scope.** POST/GET consumption layer + outbound exposures (structure, engine, aggregation grain). POST /consumption/{outbound}/promote (run 4 gates: validation, OPA POL-CL-001, governance approval via LP-12, versioned apply; write consumption_promotion). Additive migration V5 supplies 4 consumption tables. A consumer/engine resolves an outbound's grain to physical names via LP-32 (GET /consumption/{outbound}/resolve).

**Steps:** Land 4 consumption tables in additive migration V5__consumption.sql; Layer/outbound register + read endpoints; Promotion endpoint running 4 gates; OPA POL-CL-001 promotion gate; Audit + workflow side-effects (LP-12)

**Tests:** register persists layer + outbound + pyramid atomically; promote runs all 4 gates in order; POL-CL-001 blocks a cross-engine or unapproved promotion with policy code; promotion writes consumption_promotion + bumps version; pyramid resolves to logical attributes only; Coverage >=90%
**Pending:** OWNER-APPROVAL: 4 consumption tables (CONTRACT); env/role model + 4-gate definition (DECISION)

### LP-29 — Downstream Consumption screen (exposure + SDLC promotion)
*Wave:* Wave 7 · *Depends:* LP-28, LP-15

A steward configures consumption-layer exposures and promotes them through the SDLC track. Exposure-structure toggle (technical vs data-asset), aggregation-pyramid drill to logical attributes, Add-Consumption-Layer wizard, and the SDLC promotion track with four gates and role-by-env sign-off.

**Scope.** React/MUI/AG Grid: consumption layers, exposure-structure toggle (TECHNICAL/DATA_ASSET), aggregation-pyramid drill to logical attributes, Add-Consumption-Layer wizard, SDLC promotion track DRAFT->DEV->TEST->UAT->PROD with the 4 gates and role-by-env sign-off. Wired to LP-28 + LP-12.

**Steps:** Layers list + outbound detail (LP-28 reads); Exposure structure toggle + pyramid drill; Add-Layer wizard; SDLC promotion track + gates; Wire to LP-28 via Redux

**Tests:** layers + outbounds render from API; structure toggle switches technical/data-asset view; pyramid drills to logical attributes only; promotion track shows 4 gates + role per env; Coverage >=90%

### LP-30 — Entity governance-history read API
*Wave:* Wave 4 · *Depends:* LP-01, LP-03

A READ surface returning an append-only, newest-first event timeline per entity (objects, relationships, pairings, filter lookups, DQ rules) for the history drawer used across the UI. Distinct from meta.metadata_change_history (the audit WRITE). Recommended: derive from metadata_change_history; if a curated human-facing timeline is needed (who/what/when/status badge), add an optional meta.governance_event projection in V3. CONFIRM (DECISION): derive-from-audit vs dedicated event table.

**Scope.** GET /history/{entity_type}/{entity_ref} -> [{ts, event_txt, status_badge_cd, by, team}] derived from meta.metadata_change_history (or meta.governance_event if approved). Read-only; client-scoped.

**Steps:** SQL over metadata_change_history (or governance_event); Read endpoint per entity; Service maps to timeline DTO; Tests

**Tests:** returns newest-first events for an entity; objects/relationships/pairings/lookups/DQ rules all resolve; client scoping respected; empty timeline returns []; Coverage >=90%
**Pending:** OWNER-APPROVAL: derive-from-audit vs governance_event table (DECISION)

### LP-31 — Data access control (ring-fencing) + data classification
*Wave:* Wave 4 · *Depends:* LP-01, LP-03, LP-14

Data access is enforced at the shared Keycloak(OIDC)+OPA gateway in front of every endpoint, so the same rules apply to analysts, rules, reports, and AI. Two policies run on every request: POL-AC-001 ring-fences access (deny-by-default; tenant/client isolation; role/purpose-based authorization; need-to-know), and POL-DC-001 applies each object/attribute's data classification (Public/Internal/Confidential/Restricted, plus PII, MNPI, CSI, CDE, jurisdiction) to mask, restrict, or deny, and to gate AI exposure (ALLOWED/RESTRICTED/BLOCKED). Classification is captured at registration and is a governed property, not discretionary. This is the control set that lets model inputs satisfy MRM (SR 11-7 / OCC 2011-12) and firm-wide BCBS 239 expectations. Policies are externalized (configurable, never in code) and every access decision is logged.

**Scope.** Additive migration V6 adds a GOVERNED classification lookup and attribute-level classification (object-level classification + PII/confidential/masking already exist in the V1 baseline), plus optional ring-fence grants. POL-AC-001 (deny-by-default access: tenant isolation + role/purpose authorization) and POL-DC-001 (classification-driven masking/restriction + AI exposure) are authored and added to the LP-14 bundle. The shared read/exposure service applies both on every request and masks/withholds fields the caller is not entitled to; cross-tenant access is always denied. Every decision is audited.

**Steps:** Land V6__classification.sql (governed ref + attribute-level classification + grants; object-level already in baseline); Author POL-AC-001 (deny-by-default; tenant isolation; role/purpose authorization); Author POL-DC-001 (classification-driven masking/restriction; AI exposure tier); Enforce both in the shared read/exposure path; mask/withhold unentitled fields; Add POL-AC-001 + POL-DC-001 to the LP-14 OPA bundle; Audit every access decision to meta.metadata_change_history

**Tests:** cross-tenant read is always denied (tenant isolation); role/purpose without entitlement is denied with policy code (POL-AC-001); RESTRICTED/CONFIDENTIAL fields masked or withheld per caller entitlement (POL-DC-001); PII/MNPI/CSI handling enforced by class, not discretion; AI principal blocked from BLOCKED/RESTRICTED-AI attributes; every access decision is logged; default-deny on unknown input; coverage >=90%
**Pending:** OWNER-APPROVAL: classification scheme + tiers (STANDARD); OWNER-APPROVAL: access/authorization model — roles/purposes (DECISION/CONTRACT); OWNER-APPROVAL: masking vs withhold behavior per class (DECISION)

### LP-32 — Logical→Physical resolution API for downstream engines
*Wave:* Wave 7 · *Depends:* LP-05, LP-28, LP-14, LP-31

External execution engines (e.g. the Lextr rules engine — a relational DAG of Filter/Aggregate/Join/Union/Intersect/Minus/Map/Pivot/Concat/Editcheck operators) consume a governed dataset in LOGICAL names and execute on PHYSICAL names. They need ONE thing from the Semantic Layer that did not previously exist: a governed logical→physical RESOLUTION — never SQL. This point exposes physical_attribute_nm, source_object_nm, engine_cd and datatype for a set of logical attributes (or a whole consumption-outbound grain), deliberately crossing the logical-over-physical boundary under a dedicated policy, restricted to authorized engine principals, classification-aware, and audited. No SQL is generated; the engine builds and runs its own DAG.

**Scope.** POST /semantic/resolve (body: outbound_cd OR attributes[]{schema_cd,object_cd,attribute_cd} + purpose_cd) returns per attribute {logical_nm, physical_attribute_nm, source_object_nm, engine_cd, datatype_cd, data_classification_cd, masked_flg}. GET /consumption/{outbound}/resolve resolves the whole outbound grain (LP-28). Authorized engine principals only; POL-RS-001 governs physical-name exposure and applies POL-DC-001 classification (omit/mask restricted attributes); cross-tenant denied; every resolve audited. NO SQL generated — reads catalog only.

**Steps:** Resolution SQL over object_catalog/attribute_catalog (+ overrides) and data_connection (engine_cd) in queries.properties; POST /semantic/resolve (attributes[] or outbound_cd) + GET /consumption/{outbound}/resolve; Author POL-RS-001 (engine-principal physical-name exposure; applies POL-DC-001; deny cross-tenant); Mask/omit attributes the principal is not entitled to; set masked_flg; Add POL-RS-001 to the LP-14 OPA bundle; audit every resolve to metadata_change_history

**Tests:** resolve returns physical_attribute_nm + source_object_nm + engine_cd + datatype for entitled attributes; NO SQL is produced (mapping payload only); non-engine principal denied (POL-RS-001); restricted/unentitled attributes omitted or masked (POL-DC-001); cross-tenant resolve denied; resolve audited; outbound-grain resolve matches LP-28 grain; coverage >=90%
**Pending:** OWNER-APPROVAL: which principals are 'engine principals' allowed to resolve physical names; OWNER-APPROVAL: omit vs mask for restricted attributes in resolve responses

### LP-33 — External rule-engine output ingest
*Wave:* Wave 7 · *Depends:* LP-12, LP-14, LP-31, LP-28

The rules engine's Execution view produces verdicts, values, editcheck violations and datasets. DQ-shaped verdicts post via LP-24 (dq_result). This point adds a GENERAL governed ingest for the other outputs so findings remain traceable in the Semantic Layer, append-only, write-restricted to the engine principal, keyed by an engine-controlled rule reference and the consumption outbound it ran on.

**Scope.** POST /rule-results (rule_ref + outbound_cd + result_type VERDICT|VALUE|EDITCHECK|DATASET + payload + row/violation counts + tenant). Append-only; write restricted to engine principal via POL-RR-001; EDITCHECK results may alternatively route to LP-24 dq_result. Additive migration V7 supplies meta.external_rule_result.

**Steps:** Land V7__external_rule_result.sql (meta.external_rule_result); POST /rule-results ingest endpoint (append-only); Author POL-RR-001 (engine-principal write; tenant scope); Route EDITCHECK to LP-24 dq_result where a dq_rule_cd exists; else land general result; Add POL-RR-001 to LP-14 bundle; audit + LP-30 history events

**Tests:** engine principal can append a result; non-engine write denied (POL-RR-001); result_type CHECK enforced; tenant scope respected; EDITCHECK routes to dq_result when dq_rule_cd present; append-only (no update/delete); coverage >=90%
**Pending:** OWNER-APPROVAL: whether DATASET outputs are stored or referenced by handle

### LP-34 — OpenAPI/Swagger documentation alignment (cross-cutting)
*Wave:* Wave 8 · *Depends:* LP-05

The service already includes springdoc-openapi but no OpenAPI config and no @Tag/@Operation/@ApiResponse annotations. This point exposes and standardizes OpenAPI for the CURRENT controller surface across every feature — discoverable, consistent API docs — without changing any route or payload. Cross-cutting Global Standard applied horizontally across EVERY existing controller/service; reuse > configuration > extension > new; no functional contract change.

**Scope.** Wire the existing springdoc starter: add a single OpenAPI config bean; annotate existing controllers (@Tag/@Operation/@ApiResponse); document multipart/query/request-body endpoints; no route or payload change.

**Steps:** Add OpenAPI config (reuse existing springdoc); Annotate existing controllers across all features; Document multipart/query/body endpoints; Conformance test: spec loads + all routes present

**Tests:** /v3/api-docs loads successfully; every existing controller route appears in the generated spec; no route or payload contract changes; coverage >=90%

### LP-35 — Logging standardization + diagnostics hardening (cross-cutting)
*Wave:* Wave 8 · *Depends:* LP-03

Logging today is mixed (LoggerFactory + @Slf4j) with no centralized config and a controller-advice scoped to one package, so exception logging is not truly global. This point standardizes a single logging pattern and centralized config across the service without changing business behavior. Cross-cutting Global Standard applied horizontally across EVERY existing controller/service; reuse > configuration > extension > new; no functional contract change.

**Scope.** One logging pattern; add logback-spring.xml + logging.level config; reuse the existing controller timing aspect; ensure consistent startup/runtime/error logging across all packages; never log secrets/credentials/PII/raw payloads.

**Steps:** Centralize logback-spring.xml + logging levels; Standardize on one logger pattern; Reuse controller execution-time aspect; No secrets/PII in logs

**Tests:** shared logging path used by touched scope; error paths still map to same HTTP status; startup succeeds with new logging config; no duplicate logging mechanism; coverage >=90%

### LP-36 — Datasource integration + JDBC bean completion (cross-cutting)
*Wave:* Wave 8 · *Depends:* LP-01

A custom datasource model exists (DataSourceProperties binds app.datasource.*; DataSourceConfig builds Hikari and conditionally skips ClickHouse; JdbcTemplateConfig exposes the primary NamedParameterJdbcTemplate). This point hardens datasource integration using the existing custom model so the service is deployable outside a local dev box. Cross-cutting Global Standard applied horizontally across EVERY existing controller/service; reuse > configuration > extension > new; no functional contract change.

**Scope.** Harden the existing custom datasource model: bind app.datasource.*; primary PG + optional ClickHouse path keyed by data_db_engine; test profile binds H2 + Flyway and disables Config Server; no JPA.

**Steps:** Harden Hikari datasource binding (app.datasource.*); Primary PG + conditional ClickHouse path; Test profile: H2 + Flyway, Config Server disabled; No JPA introduced

**Tests:** properties bind to app.datasource; primary datasource selection works; ClickHouse path enabled/skipped by data_db_engine; test profile context loads without remote config; no JPA; coverage >=90%

### LP-37 — Spring Cloud Config integration hardening (cross-cutting)
*Wave:* Wave 8 · *Depends:* LP-36

spring-cloud-starter-config is present; main config imports configserver: with fail-fast/label; test config disables Config Server and relies on local properties; no runtime refresh path. This point hardens the startup-time config-server pattern and the test isolation so generated code runs safely outside a local setup. Cross-cutting Global Standard applied horizontally across EVERY existing controller/service; reuse > configuration > extension > new; no functional contract change.

**Scope.** Harden the startup-time Config Server pattern: preserve spring.application.name; keep test-time Config Server disablement; required properties resolve in test and local; no second config framework; no secrets in repo config.

**Steps:** Preserve startup config-server import + label; Keep test-time Config Server disablement; Ensure properties resolve in test+local; No secrets in repo config

**Tests:** test profile starts with Config Server disabled; required properties resolve in test+local; main config valid for deployed envs; no second config framework; coverage >=90%

### LP-38 — Global exception handling standardization (cross-cutting)
*Wave:* Wave 8 · *Depends:* LP-03

A GlobalExceptionHandler exists but its @ControllerAdvice is scoped to one package, so it is not truly global; error responses are an ad-hoc map. This point broadens the existing handler across all controller packages with a consistent error payload, without redesigning the API contract. Cross-cutting Global Standard applied horizontally across EVERY existing controller/service; reuse > configuration > extension > new; no functional contract change.

**Scope.** Broaden the existing @ControllerAdvice across all controller packages; consistent error payload (message/status/code); preserve HTTP status intent for known exceptions; map domain failures consistently (422 + policy code stays).

**Steps:** Broaden @ControllerAdvice to all controller packages; Consistent error payload structure; Preserve HTTP status intent for known exceptions; Validation errors map consistently

**Tests:** mapped exceptions return expected HTTP status; validation errors map consistently; handling applies across all controller packages; error structure preserved unless contract change approved; coverage >=90%

### LP-39 — Test coverage + completeness gate (cross-cutting)
*Wave:* Wave 8 · *Depends:* LP-34, LP-38

The >=90% coverage bar lives on every point but is not enforced, and there is no gate that catches a missing cross-cutting concern or a missing read API before sign-off. This point adds JaCoCo enforcement and a COMPLETENESS GATE so functional completion cannot masquerade as production-readiness — the durable structural fix the pilot recommends so this class of gap never recurs. Cross-cutting Global Standard applied horizontally across EVERY existing controller/service; reuse > configuration > extension > new; no functional contract change.

**Scope.** JaCoCo >=90% line/branch enforcement that fails the build below threshold; a completeness gate that FAILS generation/build when (a) a required cross-cutting concern (LP-34..LP-40) is absent, (b) an entity with a write has no GET/list read, or (c) a screen has no backing read API. Produces a coverage + completeness report. Completeness gate adds a UI->contract ROUND-TRIP check: every field the registration/catalog UI captures for an attribute MUST persist via LP-03 and return via LP-05; the build fails if any authoring field is dropped.

**Steps:** JaCoCo >=90% enforcement (fail build below threshold); Completeness gate: required cross-cutting concerns present; Completeness gate: every write entity has a GET/list read; Completeness gate: every screen has a backing read API; Emit coverage + completeness report; Round-trip gate: registration UI fields == LP-03 persisted == LP-05 exposed

**Tests:** build fails below 90% coverage; gate fails when a required cross-cutting concern is missing; gate fails when a write entity lacks a GET/list read; gate fails when a screen lacks a backing read API; report lists every check + status; gate fails when a Register-UI attribute field does not round-trip through LP-03->LP-05

### LP-40 — Application observability + resilience hooks (cross-cutting)
*Wave:* Wave 8 · *Depends:* LP-36

Distinct from LP-27 (DATA observability about pipelines): this is APPLICATION observability — Actuator health/readiness/liveness + metrics — plus the self-healing core-path resilience the governance bar has long called for (retries, circuit-breaking, graceful degradation). This resolves pending item P-07. Cross-cutting Global Standard applied horizontally across EVERY existing controller/service; reuse > configuration > extension > new; no functional contract change.

**Scope.** Spring Boot Actuator health/readiness/liveness + Prometheus metrics; resilience on core paths (retries, circuit-breaking, graceful degradation, health/recovery hooks) around external calls (OPA client, engine calls, datasource); confirm the resilience library (P-07).

**Steps:** Actuator health/readiness/liveness endpoints; Prometheus metrics exposure; Resilience on core path (retry/circuit-break/graceful-degrade); Health/recovery hooks; confirm resilience library (P-07)

**Tests:** health/readiness/liveness endpoints respond; metrics scrape endpoint exposed; core-path call retries + circuit-breaks under failure; graceful degradation on dependency outage; coverage >=90%

### LP-41 — Tenant Workspaces management API + screen
*Wave:* Wave 6 · *Depends:* LP-03, LP-05, LP-15

The UI prototype shows a Tenant Workspaces screen; this LP supplies its backing tables/API (owner-approved 2026-08-19). A workspace is a named, per-tenant scoping of registered objects (e.g. WS-ALL, WS-BHC-A) and is the enforcement home for BOUNDED consumer/agent scope: it is the explicit set of objects an agent (e.g. Lextr Intelligence / Lexie) may operate over. Tables ship as additive migration V8.

**Scope.** Additive migration V8 (meta.tenant_workspace + meta.tenant_workspace_object). GET /workspaces?client_id; POST /workspaces; POST /workspaces/{cd}/objects (add a registered object); DELETE /workspaces/{cd}/objects/{schema}/{object} (remove). React/MUI screen wired to the API. Client-scoped; audited. A workspace bounds the object set an agent/consumer may traverse (see consumer_traversal.bounded_scope).

**Steps:** Land V8__tenant_workspace.sql (2 tables) — committed (owner-approved 2026-08-19); GET/POST workspaces; add/remove objects; Client scoping + audit; Workspaces screen wired to the API

**Tests:** GET /workspaces returns active workspaces for the tenant; POST creates a workspace; add/remove object updates membership; client scoping respected; coverage >=90%

### LP-42 — Logical Hierarchies management API + screen [PROPOSED] · **[PROPOSED]**
*Wave:* Wave 6 · *Depends:* LP-05, LP-15

PROPOSED (OWNER-APPROVAL — new tables = CONTRACT). The UI prototype shows a Hierarchy screen but there is no backing table/API. A logical hierarchy defines a named tree over logical attributes (e.g. ENTITY_HIERARCHY, PERIOD_HIERARCHY) with ordered levels. Tables ship as additive migration V9 and are held as a PROPOSAL until the owner approves.

**Scope.** Additive migration V9 (meta.logical_hierarchy + meta.logical_hierarchy_level). GET /hierarchies?client_id; POST /hierarchies (save a tree definition + levels). React/MUI screen. Logical attributes only (no physical leakage). Client-scoped; audited. HELD AS PROPOSAL until owner approval.

**Steps:** Land V9__logical_hierarchy.sql (2 tables) — PROPOSED, owner-approval gated; GET/POST hierarchies (tree + ordered levels); Logical attributes only; client scoping + audit; Hierarchy screen wired to the API

**Tests:** GET /hierarchies returns defined hierarchies for the tenant; POST saves a tree + ordered levels; levels reference logical attributes only; client scoping respected; coverage >=90%
**Pending:** OWNER-APPROVAL: meta.logical_hierarchy + meta.logical_hierarchy_level (CONTRACT)

### LP-43 — Domain registration + governed AI resolve (deterministic phrase resolution)
*Wave:* Wave 6 · *Depends:* LP-03, LP-05

A coded attribute's valid values are a governed codeset (code+description), not UI mock. This point registers/reads governed domains (domain_catalog + domain_value; source INLINE|ENUMERATED|REFERENCE_TABLE) and exposes a governed AI resolve so consumers and Lexie ground on the certified, tenant-scoped, current allowed values — the critical grounding piece for Vertical AI.

**Scope.** Additive V10 (domain_catalog + domain_value) + V11 (attribute_catalog domain columns). GET/POST /domains (+values); source_type ENUMERATED (rows) | REFERENCE_TABLE (project ref_table code/desc cols) | INLINE (attribute domain_values_jsonb). POST /semantic/resolve-domain (attribute or domain_cd, tenant, as-of date) -> ACTIVE allowed values with description + AI context; policy-gated (POL-DM-001); every resolve audited. Catalog (LP-16) and Register (LP-17) consume this — no client-side value maps. DETERMINISTIC PHRASE RESOLUTION (ASK 1-8): resolve a normalised phrase (lower/trim/collapse-space, EXACT compare only — NO fuzzy/stemming/embedding/nearest) against code, description or ACTIVE synonym. Outcome is a closed set of three: EXACT (one match + resolution_basis), AMBIGUOUS (>1 match -> ALL candidates, never a best guess), UNRESOLVED (0 matches -> domain cardinality + search handle). resolution_basis (CODE|DESCRIPTION|SYNONYM|SOURCE_MAPPING + matched text) is REQUIRED on every resolved value, for the evidence trail. Return per value: value_cd, value_desc, ai_context_txt, lifecycle_status_cd, effective dates, and domain_catalog.version_nbr. Synonyms live in meta.domain_value_synonym (governed vocabulary; tenant rows may override GLOBAL as a tracked exception, override_global_flg; resolution considers GLOBAL + caller tenant, TENANT wins). Source codes map via meta.domain_value_source_map (resolution_basis=SOURCE_MAPPING). Scale: value_count_nbr on domain_catalog (service-maintained); GET /domains/{domain_cd}/values?q=&limit=&cursor= (prefix/substring, paginated, trigram-indexed); above DOMAIN_MAX_ENUMERATE_CARDINALITY the full-set resolve REFUSES (policy) and directs to search. Versioning: version_nbr bumped in-service on any value/synonym/mapping change; as_of resolves at the past version so a saved report re-explains as at its authoring date. Per-value ai_exposure_cd (inherits attribute, never wider). YN_FLAG removed — booleans are two-value ENUM_LIST. LOCALE: description + ai_context resolve in the caller's locale via meta.domain_value_text (locale -> en-US -> domain_value.value_desc fallback); value_cd is never translated. Normalisation for deterministic match is UNICODE CASE-FOLDING with a declared normalisation form (NFC + full case-fold + trim + collapse whitespace), done in-service — never SQL LOWER() (which is wrong for Turkish i, German ss, and accents). TTL: a 'latest' resolve may be cached up to DOMAIN_RESOLVE_TTL_SECONDS; a resolve pinned to version_nbr/as_of is immutable and cacheable indefinitely.

**Steps:** Land V10 domain store + V11 attribute domain columns; GET/POST domains + values; source-type handling (ENUMERATED/REFERENCE_TABLE/INLINE); REFERENCE_TABLE: project ref_table (code_col, desc_col); validate table + columns exist; POST /semantic/resolve-domain: tenant + as-of + lifecycle filter; return code+desc+ai_context; POL-DM-001 gate + audit; wire LP-16 catalog + LP-17 register to the resolve; Land V12 synonyms + V13 source-map + V14 (version/count/per-value AI + YN_FLAG removal); Normalise phrase (lower/trim/collapse) then EXACT match on code/desc/ACTIVE synonym — no fuzzy/stemming/embedding; Return EXACT | AMBIGUOUS (all candidates) | UNRESOLVED (cardinality + search handle); resolution_basis + version on every value; Synonym precedence: GLOBAL + tenant; TENANT overrides GLOBAL (override_global_flg tracked exception); GET /domains/{domain_cd}/values?q=&limit=&cursor= (trigram) ; refuse full-set above DOMAIN_MAX_ENUMERATE_CARDINALITY; Bump domain version_nbr in-service on value/synonym/mapping change; as_of resolves at past version; Route synonym authoring through LP-12 SYNONYM_AUTHOR (four-eyes); resolve uses ACTIVE + certified synonyms only; Localize description/ai_context via domain_value_text (locale -> en-US fallback); value_cd untouched; Normalise with Unicode case-folding + declared form (NFC), not LOWER(); Return / honour DOMAIN_RESOLVE_TTL_SECONDS; version/as-of-pinned resolve is immutable

**Tests:** ENUMERATED resolves domain_value rows; REFERENCE_TABLE projects ref-table code/desc; INLINE reads jsonb; resolve is tenant-scoped + as-of-date + lifecycle-filtered (ACTIVE only); POL-DM-001 denies cross-tenant / unauthorized; AI resolve returns per-value ai_context where present; coverage >=90%; phrase matching one ACTIVE synonym -> EXACT with resolution_basis=SYNONYM; phrase matching two values -> AMBIGUOUS with EVERY candidate (never a best guess); unknown phrase -> UNRESOLVED with cardinality + search handle (not an empty success); synonym colliding within domain/locale/tenant -> rejected at WRITE by uq_dvs; RETIRED value excluded from resolve but still resolvable as_of a past date; resolve above DOMAIN_MAX_ENUMERATE_CARDINALITY refuses and names the policy; source-mapped code resolves with resolution_basis=SOURCE_MAPPING; tenant synonym overrides GLOBAL for the same phrase; override flagged (override_global_flg); cross-tenant resolve denied naming POL-DM-001; every resolve audited with domain + version + basis; no fuzzy/stemming/embedding path exists (deterministic compare only); French phrase matches a French synonym AND the value returns a French description (locale-aware); Turkish dotted/dotless i and German ss fold correctly (deterministic, not LOWER); missing locale falls back to en-US then to value_desc; value_cd never translated; version/as-of-pinned resolve marked immutable; latest resolve carries the TTL
**Pending:** POL-DM-001 (domain resolve policy) to author in the OPA bundle (LP-14)

### LP-44 — Attribute promotion (report-local derived → governed) [PROPOSED] · **[PROPOSED]**
*Wave:* Wave 9 · *Depends:* LP-03, LP-12, LP-17

Lextr Intelligence UC10 lets an analyst derive a report-local attribute (a maturity band, a utilisation ratio) grounded on SL attributes only. PROMOTION is the moment that working definition becomes shared meaning in the catalog — the SL's invariant. Until the rulings below are confirmed and Core supplies the workflow stages, the promotion control stays ABSENT rather than approximated.

**Scope.** Additive V16 provenance on attribute_catalog (attr_origin_cd SOURCE_DERIVED|PROMOTED_DERIVED, promoted_from_report_id, derivation_expression_txt, expression_author_cd incl. ASSISTANT_DRAFTED_HUMAN_APPROVED). Promotion routes through attribute registration (LP-03/LP-17) and a new four-eyes wkfl.workflow_task type ATTRIBUTE_PROMOTION (LP-12). SL RECOMMENDED RULINGS (owner to confirm): (1) four-eyes, not the author alone; (2) provenance visible; (3) NO silent rebind — existing report-local copies stay and are FLAGGED for their owners to rebind; (4) demote/retire via standard lifecycle, reports using a retired promoted attr flagged/counted; (5) the expression SURVIVES promotion, and if the SL re-expresses it against its own model an EQUIVALENCE CHECK must pass first (so a promoted attr cannot silently compute a different number). Report-local attributes render visibly distinct from SL attributes.

**Steps:** Land V16 provenance (PROPOSED); Add ATTRIBUTE_PROMOTION four-eyes task (LP-12) wired to Core workflow stages; Promote via attribute registration; stamp provenance + expression_author; Rule out silent rebind: flag report-local copies for owner rebind; Lifecycle demote/retire; equivalence check if re-expressed

**Tests:** promotion requires four-eyes approval before the attribute is ACTIVE; promoted attr is distinguishable from source-derived (attr_origin_cd + provenance visible); existing report-local copies are NOT silently rebound — they are flagged; re-expressed promoted attr fails promotion unless equivalence check passes; assistant-drafted-human-approved expressions are recorded and visible
**Pending:** OWNER-APPROVAL: confirm the 5 promotion rulings (esp. no-silent-rebind, expression-survives); CORE dependency: workflow stages/approval chain for the ATTRIBUTE_PROMOTION task type
