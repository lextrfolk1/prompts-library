# Lextr Semantic Layer — FINAL v2.11.0 — Release Note

**Baseline:** manifest `2.11.0+fable.1` (package `stable_v6`) · **Released for development:** 2026-08-26
**Companion:** if your team built against v2.3.0, work from the **incremental package** (`Lextr_SemanticLayer_DELTA_*`) rather than reading this whole manifest — it contains only what changed.
**Scale:** 44 logic points · 165 sub-task lanes · 39 tables · 5 schemas · 577 columns

Every file below carries `FINAL_v2.11.0` in its name **and** in its header, so a file separated from this note still identifies itself. All artifacts were cross-verified in one pass (23 checks, all passing).

---

## 1 · The package

| File | What it is | Who uses it |
|---|---|---|
| `Lextr_SemanticLayer_Manifest_FINAL_v2.11.0.json` | **Source of truth.** All 44 logic points, the DDL body, the changes diff, the consumer-traversal contract. | Build automation |
| `Lextr_SemanticLayer_Manifest_FINAL_v2.11.0.html` | **Open this first.** Offline viewer — Manifest · Changes · Consumer traversal · Corrections · Correction flow. | Everyone |
| `Lextr_SemanticLayer_Manifest_FINAL_v2.11.0.jsx` | Viewer source; embeds the JSON byte-for-byte. | Front-end |
| `Lextr_SemanticLayer_Manifest_FINAL_v2.11.0.md` | Readable digest of every point. | Reviewers |
| `Lextr_SemanticLayer_DDL_FINAL_v2.11.0.sql` | The schema: V1 baseline + V3…V16 additive migrations. | Data engineering |
| `Lextr_SemanticLayer_Map_FINAL_v2.11.0.html` | **Start here to understand the system.** Dependency graph · build context · coverage & assessment · system map · flows · database (ER + click-to-detail). | Everyone |
| `Lextr_SemanticLayer_UI_FINAL_v2.11.0.html` | Working UI prototype (registration + catalog). | Front-end, demo |
| `Lextr_SemanticLayer_UI_FINAL_v2.11.0.jsx` | UI source. | Front-end |
| `Lextr_SemanticLayer_Catalog_FINAL_v2.11.0.jsx` | **Estate input, not a runtime artifact.** 16 assets · 1,089 real attributes. | Bulk registration |

## 2 · Verification performed

- Manifest JSX embed is **byte-identical** to the JSON.
- Standalone DDL **contains the manifest's `ddl_body`** verbatim.
- All three HTML files **compile (esbuild exit 0) and mount** in a headless DOM.
- UI domain modes (`NONE`, `ENUM_LIST`, `REF_DOMAIN`) **match the DDL's final CHECK constraint exactly**; zero live `YN_FLAG` references remain.
- Map reports the same baseline, point count (44) and table count (39) as the manifest.
- Every file carries the `FINAL v2.11.0` header.

## 3 · Read this before building — status is not uniform

**Committed and buildable:** the schema (V1, V3–V8, V10–V15), registration and exposure, the domain store and vocabulary, relationships, pairings, filter lookups, governance workflow, DQ/profiling/observability, consumption, resolution, and the cross-cutting standards points.

**PROPOSED — do not build without owner approval:**
- **LP-42 / migration V9** — logical hierarchies.
- **LP-44 / migration V16** — attribute promotion provenance. Also needs Core's workflow stages.

**Deferred / open, carried deliberately:**
- `POL-DM-001` (domain-resolve policy) is **not yet authored** — to land in the LP-14 OPA bundle.
- `meta.governance_event` is **commented out** in the DDL; the LP-30 history-versus-audit decision is open.
- **Report Store and Report Inventory exposure** are blocked on Core's answers (see `Lextr_SL_to_Core_Requirements.md`).
- **Attribute-name localization** (`meta.attribute_text`) is a recorded gap on LP-05 — English names ship first.
- Two tables are named in the manifest but created by no live migration: `governance_event` (commented out — deferred) and `attribute_text` (deferred locale table). Both are visible in the map's *Named across the manifest, absent from the DDL* section. *(Corrected 2026-08-26: an earlier draft wrongly listed `data_classification_ref` here — it is a real, live table created by the DDL and owned by LP-31.)*

## 4 · The UI is contract-*consistent*, not contract-*complete*

This matters for planning, so it is stated plainly. The prototype no longer contradicts the manifest: `YN_FLAG` is gone, booleans register as two-value `ENUM_LIST` with per-attribute polarity, and the domain mock carries the governed shape (description, AI context, synonyms, lifecycle).

**Not yet built, and needed before the layer is usable end to end:** synonym authoring (the four-eyes `SYNONYM_AUTHOR` flow), the locale editor for `domain_value_text`, the source-map screen, per-value `ai_exposure_cd`, and display of `version_nbr` / `value_count_nbr`. Domain values in the prototype remain **mock** — production reads LP-43 `/semantic/resolve-domain`. The prototype also hardcodes its theme, with no configurable logo or client CSS hook; that must be addressed before anything client-facing.

## 5 · The catalog carries no domain layer — by far the largest open item

The estate catalog has **0 domain values across 1,425 attributes**, against **753 attributes whose semantic role is CODE**. Until each coded attribute declares a domain mode, phrase-to-code resolution cannot be grounded and Lextr Intelligence cannot cite a certified value. Closing this is the purpose of the separate bulk-registration workstream (`Lextr_BulkRegistration_*`), which is packaged separately and targets this same v2.11.0 contract.

Also outstanding in the estate, all visible in the map's coverage tab: 45 derivable pairings unregistered, 343 unapproved abbreviation tokens, and 6 physical columns carrying two different logical names.

## 6 · Known limitation in the bulk-registration rules

Three fields the registration drift rules require have **no column in v2.11.0**: `accepted_from` and `suade_gap_covered` (DR-13) and `conformed_flg` (DR-09). As written those two rules are unimplementable — they need either new columns in a future migration or a rewrite of the rules. Flagged rather than quietly dropped.

---

**Not in this package but current at the same baseline:** `Lextr_Semantic_to_Intelligence_Integration_Contract` (md + docx), `Lextr_SL_Response_to_Intelligence_DomainValues_ASK.md`, `Lextr_SL_to_Core_Requirements.md`, the four `Lextr_BulkRegistration_*` files, and `Lextr_SemanticLayer_SME_Briefing.docx`.
