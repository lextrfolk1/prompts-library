# Lextr Semantic Layer — INCREMENTAL Manifest · v2.3.0 → v2.11.0

**For a team that already implemented v2.3.0.** This contains only what changed.

| | v2.3.0 | v2.11.0 | delta |
|---|---|---|---|
| Logic points | 21 | 44 | **+23 new · 12 amended · 9 unchanged** |
| Sub-task lanes | 77 | 165 | +88 |
| Tables | 16 | 39 | **+23** (21 applyable now, 2 proposed) |
| Columns on `meta.attribute_catalog` | — | — | **+27** |
| New closed vocabularies (CHECK) | — | — | +24 |
| Logic points removed | — | — | 0 — nothing was withdrawn |

## How to use this document

1. UNCHANGED (9 points) — already built to contract. Do not modify. Re-run their existing tests as regression.
2. AMENDED (12 points) — existing code must change. Each entry lists the added and removed scope, steps and tests. ADDITIVE means only additions; REWORK means something was replaced and existing behaviour must change.
3. NEW (23 points) — build from scratch; full scope, steps and tests are included.
4. Apply the incremental DDL (23 tables, 27 columns) before the points that depend on it.
5. PROPOSED items (LP-42, LP-44 and their migrations V9/V16) are NOT approved — do not build.
6. Every new test in this document is a test the team must add; the existing v2.3.0 tests remain valid unless listed under 'removed'.

---

## 1 · UNCHANGED — do not touch (9 points)

Built to a contract that has not moved. Re-run their existing tests as regression only.

| Point | Title | Lanes |
|---|---|---|
| **LP-02** | Schema & connection registry read API | 4 |
| **LP-04** | Taxonomy/MDRM jurisdiction OPA policy | 1 |
| **LP-07** | Filter lookup registration + governance floor | 6 |
| **LP-08** | Effective-review-period + health (service layer) | 4 |
| **LP-09** | Filter lookup Phase-1 preview + exec log | 5 |
| **LP-10** | Certify + stale-value policy (POL-SV-001) | 5 |
| **LP-11** | Bind lookup + overdue-review policy (POL-SV-002) | 5 |
| **LP-13** | Governance presets read API (startup defaults) | 4 |
| **LP-21** | Workflow Queue screen | 2 |

---

## 2 · AMENDED — existing code must change (12 points)

**REWORK** (5) — something was replaced; existing behaviour changes: LP-01, LP-12, LP-14, LP-17, LP-20

**ADDITIVE** (7) — only additions: LP-03, LP-05, LP-06, LP-15, LP-16, LP-18, LP-19


### LP-01 — Apply fixed DDL as Flyway baseline migration  ·  `REWORK`

**scope**

- ~~REMOVED:~~ verify all tables, indexes, seeds, and constraints apply cleanly on PostgreSQL 16.
- **ADD:** verify all 18 tables (incl.
- **ADD:** the two attribute_pairing tables), indexes, seeds, and constraints apply cleanly on PostgreSQL 16.

**tests_must_cover**

- ~~REMOVED:~~ All 13 tables + indexes exist
- **ADD:** All 18 tables + indexes exist

**pre_build_knowledge**

- **ADD:** If the V1 baseline is already applied, the two attribute_pairing tables are an ADDITIVE follow-on migration (e.g. V2__attribute_pairing.sql), not an edit to V1

**fixed_contracts**

- **ADD:** meta.attribute_pairing_catalog + meta.attribute_pairing_value_cache (attribute pairing)


### LP-03 — Object registration API (producer write)  ·  `ADDITIVE`

**scope**

- **ADD:** Capture data classification (sensitivity tier + PII/MNPI/CSI flags + AI-exposure tier) at registration;
- **ADD:** values validated against meta.data_classification_ref (LP-31).
- **ADD:** Persist pk_flg/fk_flg/nullable_flg per attribute (from introspection) into meta.attribute_catalog (columns already in the baseline).
- **ADD:** Capture the FULL per-attribute authoring contract: semantic_role_cd;
- **ADD:** semantic_enabled_flg + ai_exposed_flg (per-attribute exposure);
- **ADD:** element_class_cd (CDE|DE) + element_class_source_cd;
- **ADD:** the domain block (domain_mode_cd NONE|YN_FLAG|ENUM_LIST|REF_DOMAIN;
- **ADD:** ENUM_LIST -> domain_values_jsonb;
- **ADD:** REF_DOMAIN -> domain_cd or domain_ref_table_nm + code/desc cols);
- **ADD:** the operational block (insert/update/delete mode, immutable_flg, null_on_insert_flg, attr_source_system_cd);
- **ADD:** and effective_start_dt/effective_end_dt.

**background**

- **ADD:** Attribute key metadata (pk_flg/fk_flg/nullable_flg) is captured at registration from introspection so dynamically-registered objects carry correct key roles for downstream key-aware screens (Relationships, Pairings) — eliminating any hardcoded client-side attribute-metadata map.

**manifest_of_steps**

- **ADD:** Capture + validate data classification at registration (LP-31 scheme)
- **ADD:** Persist pk_flg/fk_flg/nullable_flg per attribute (from introspection)
- **ADD:** Persist per-attribute exposure (semantic_enabled_flg, ai_exposed_flg) + semantic_role_cd
- **ADD:** Persist CDE/DE element_class_cd + element_class_source_cd
- **ADD:** Persist domain block (mode + inline values OR domain_cd/ref-table link + code/desc cols)
- **ADD:** Persist operational block + effective dating

**tests_must_cover**

- **ADD:** classification captured and validated against the governed scheme
- **ADD:** pk_flg/fk_flg/nullable_flg persisted per attribute and round-trip via LP-05
- **ADD:** every field the Register UI captures is persisted (exposure, role, CDE/DE, domain, operational, effective)
- **ADD:** ENUM_LIST persists domain_values_jsonb; REF_DOMAIN persists domain_cd or ref-table+cols

**pre_build_knowledge**

- **ADD:** pk_flg/fk_flg/nullable_flg columns already exist in attribute_catalog; wire them through registration (no schema change) [UPDATE v2.8.0 — pilot gap]
- **ADD:** attribute_catalog authoring contract extended in v2.9.0; capture must round-trip via LP-05 [UPDATE v2.9.0]

**fixed_contracts**

- **ADD:** LP-31 classification scheme


### LP-05 — Object/attribute read & exposure API  ·  `ADDITIVE`

**scope**

- **ADD:** Enforce POL-AC-001 ring-fencing + POL-DC-001 classification masking (authored in LP-31) on every read/exposure;
- **ADD:** deny cross-tenant;
- **ADD:** mask/withhold unentitled fields.
- **ADD:** Physical-name resolution for external engines is a separate governed endpoint (LP-32), not this read path.
- **ADD:** Attribute detail/exposure returns pk_flg/fk_flg/nullable_flg so consumers (Relationships/Pairings key pickers) resolve keys dynamically with no hardcoded map.
- **ADD:** Attribute detail/exposure returns the full authoring contract: semantic_role_cd, semantic_enabled_flg, ai_exposed_flg, element_class_cd/source, the domain block (mode + resolved allowed values via LP-43), the operational block, and effective dating — so everything the Register UI captured round-trips to the catalog and consumers.

**background**

- **ADD:** Read/exposure enforces POL-AC-001 (ring-fencing) and POL-DC-001 (classification masking) at the OPA gateway;
- **ADD:** callers only receive entitled, appropriately-masked fields.

**manifest_of_steps**

- **ADD:** Apply POL-AC-001 + POL-DC-001 on read/exposure (mask/withhold; deny cross-tenant)
- **ADD:** Return pk_flg/fk_flg/nullable_flg on attribute detail/exposure
- **ADD:** Return the full attribute authoring contract incl. resolved domain allowed values (via LP-43)

**tests_must_cover**

- **ADD:** cross-tenant denied; unentitled/Restricted fields masked or withheld
- **ADD:** attribute detail returns pk_flg/fk_flg/nullable_flg
- **ADD:** attribute detail round-trips every field LP-03 captured (no silent drop)

**pre_build_knowledge**

- **ADD:** Attribute key flags are part of the stable exposure contract [UPDATE v2.8.0 — pilot gap]
- **ADD:** Exposure is the round-trip proof for LP-03 capture [UPDATE v2.9.0]

**fixed_contracts**

- **ADD:** LP-31 access + classification policies

**pending_items**

- **ADD:** Attribute-name localization (logical_long_nm + descriptions) via a meta.attribute_text table — DEFERRED (recorded gap); ship English names until owner schedules [v2.11.0]


### LP-06 — Relationship registration + Neo4j projection  ·  `ADDITIVE`

**scope**

- **ADD:** GET /relationships (list;
- **ADD:** client-scoped;
- **ADD:** filterable by object) so the Relationship screen reads governed joins from the PG system of record instead of local storage;
- **ADD:** Neo4j remains the traversal projection.

**manifest_of_steps**

- **ADD:** GET /relationships list endpoint (PG system of record; client-scoped)

**tests_must_cover**

- **ADD:** GET /relationships lists persisted relationships; client scoping respected

**pre_build_knowledge**

- **ADD:** Listing reads from PG (system of record); the graph view (LP-19) reads the Neo4j projection [UPDATE v2.8.0 — pilot gap]


### LP-12 — Governance workflow approval + typed side-effects  ·  `REWORK`

**scope**

- ~~REMOVED:~~ POST approve: typed side-effects (activate lookup, apply LNO, activate anticipated value);
- **ADD:** POST approve: typed side-effects (activate lookup, apply LNO, activate anticipated value, raise DQ rule request, promote consumption outbound);
- **ADD:** POST reject: typed rejection side-effects (demote the operational entity to REJECTED/INACTIVE by task_type), symmetric to approve;
- **ADD:** New typed task SYNONYM_AUTHOR (LP-43): a domain-value synonym is a semantic assertion and requires four-eyes approval;
- **ADD:** on approval, set certified_by/certified_ts;
- **ADD:** resolve uses only ACTIVE + certified synonyms.

**background**

- **ADD:** New typed task types DQ_RULE_REQUEST (LP-24) and CONSUMPTION_PROMOTE (LP-28) extend the queue;
- **ADD:** task_type_cd is varchar(40) with no CHECK, so the values are additive while the side-effect dispatch is new service logic.
- **ADD:** Rejection is symmetric to approval: a typed rejection side-effect demotes the operational entity (object/lookup/pairing/relationship/override) to REJECTED/INACTIVE, so a rejected item never remains usable.
- **ADD:** Previously only the task record changed.

**manifest_of_steps**

- **ADD:** Add DQ_RULE_REQUEST + CONSUMPTION_PROMOTE dispatch (typed side-effects)
- **ADD:** Reject dispatch by task_type (demote operational entity to REJECTED/INACTIVE)
- **ADD:** Add SYNONYM_AUTHOR dispatch (four-eyes; set certified_by/ts on approval)

**tests_must_cover**

- **ADD:** approve DQ_RULE_REQUEST surfaces requested rule; approve CONSUMPTION_PROMOTE advances env
- **ADD:** reject FILTER_LOOKUP_REGISTER -> lookup INACTIVE/REJECTED
- **ADD:** reject OBJECT_REGISTRATION -> object REJECTED
- **ADD:** reject ATTRIBUTE_PAIRING/RELATIONSHIP -> entity REJECTED/INACTIVE
- **ADD:** approve SYNONYM_AUTHOR -> synonym certified + resolvable; unapproved synonym not used in resolve

**pre_build_knowledge**

- **ADD:** task_type_cd values are additive (no CHECK); side-effect dispatch is typed [UPDATE v2.5.0]
- **ADD:** Registration lands DRAFT; approval -> ACTIVE; rejection -> REJECTED/INACTIVE (typed, symmetric) [UPDATE v2.8.0 — pilot gap]


### LP-14 — OPA policy bundle: cross-engine + stale + overdue  ·  `REWORK`

**scope**

- ~~REMOVED:~~ Rego packages: POL-CE-001/002/003 (cross-engine relationship/pairing/workspace), POL-SV-001 (stale), POL-SV-002 (overdue, QS exempt).
- **ADD:** Rego packages: POL-CE-001/002/003 (cross-engine relationship/pairing/workspace), POL-SV-001 (stale), POL-SV-002 (overdue, QS exempt);
- **ADD:** POL-DQ-001 (DQ request gate);
- **ADD:** POL-CL-001 (consumption promotion gate);
- **ADD:** POL-AC-001 (access ring-fencing);
- **ADD:** POL-DC-001 (classification-driven exposure);
- **ADD:** POL-RS-001 (logical→physical resolution exposure);
- **ADD:** POL-RR-001 (external rule-output ingest).
- **ADD:** POL-DM-001 (domain resolve) covers: tenant isolation on resolve (cross-tenant DENIED, never silently filtered);
- **ADD:** principal entitlement (who may resolve which domain);
- **ADD:** per-value AI-exposure gate (ai_exposure_cd, never wider than the attribute);
- **ADD:** and REFUSAL above DOMAIN_MAX_ENUMERATE_CARDINALITY as a policy decision (not service logic).

**background**

- **ADD:** POL-CE-002 also governs cross-engine attribute pairing, consumed by LP-22.
- **ADD:** v2.5.0 adds POL-DQ-001 (DQ request-only + tenant-scope + result principal, LP-24) and POL-CL-001 (consumption promotion gate, LP-28) to the bundle.
- **ADD:** v2.6.0 adds POL-AC-001 (access ring-fencing) and POL-DC-001 (classification-driven exposure), authored in LP-31, to the bundle.
- **ADD:** v2.7.0 adds POL-RS-001 (resolution exposure, LP-32) and POL-RR-001 (rule-output ingest, LP-33).

**manifest_of_steps**

- ~~REMOVED:~~ Author 5 policy packages
- **ADD:** Author 9 policy packages

**tests_must_cover**

- **ADD:** POL-DQ-001 + POL-CL-001 allow/deny branches covered
- **ADD:** POL-AC-001 + POL-DC-001 allow/deny branches covered
- **ADD:** POL-RS-001 + POL-RR-001 allow/deny branches covered
- **ADD:** POL-DM-001: cross-tenant denied; per-value AI-exposure enforced; cardinality-ceiling refusal named

**fixed_contracts**

- ~~REMOVED:~~ OPA packages POL-CE-001/002/003, POL-SV-001/002
- **ADD:** OPA packages POL-CE-001/002/003, POL-SV-001/002, POL-DQ-001, POL-CL-001, POL-AC-001, POL-DC-001, POL-RS-001, POL-RR-001


### LP-15 — Tenant theming primitives (logo, CSS, multi-tenant)  ·  `ADDITIVE`

*Sub-task lanes: 2 → 3*

**scope**

- **ADD:** Also expose shared FE governance primitives: Drawer+HistoryTimeline, GovTabStrip (draft-tab pattern with Draft IDs), TenantChip (GLOBAL vs client).

**background**

- **ADD:** v2.5.0 names three reusable governance primitives consumed platform-wide: Drawer+HistoryTimeline (append-only history slide-in), GovTabStrip (base tabs + closeable draft tabs carrying Draft IDs), and TenantChip (GLOBAL vs client scope).

**manifest_of_steps**

- **ADD:** Shared primitives: Drawer+HistoryTimeline, GovTabStrip, TenantChip

**tests_must_cover**

- **ADD:** Drawer/HistoryTimeline, GovTabStrip draft tabs, and TenantChip render and are reusable

**New sub-tasks**

- `LP-15.3` (TS) — Shared FE governance primitives: Drawer+HistoryTimeline (append-only slide-in), GovTabStrip (base + closeable draft tabs with Draft IDs), TenantChip (GLOBAL vs client). Brand-free tokens.


### LP-16 — Data Catalog screen (dual tree + search)  ·  `ADDITIVE`

**scope**

- **ADD:** Add object-level + attribute-level Data Quality tabs (rule counts, on-demand plain-English definitions, timestamped dimension matrix — data from LP-24), an object history drawer (LP-30), a GLOBAL tenant-scope chip, and the attribute tab set (Detail / Operational / Data Quality / Usage / AI Context / CDE-DE).
- **ADD:** Surface each object/attribute's data classification (sensitivity tier + PII/MNPI/CSI + AI-exposure) in the catalog (read-only).
- **ADD:** Attribute detail shows DOMAIN + governed DOMAIN ALLOWED VALUES resolved via LP-43 (never client-side mock), tenant-scoped and lifecycle-filtered;
- **ADD:** plus semantic/AI exposure, CDE/DE, operational and effective-dating fields.

**background**

- **ADD:** v2.5.0 adds object-level and attribute-level Data Quality tabs, an object history drawer, and a GLOBAL tenant-scope chip.

**manifest_of_steps**

- **ADD:** DQ tabs (object+attribute) from LP-24; object history drawer from LP-30; GLOBAL scope chip
- **ADD:** Show data classification chips on objects/attributes (from LP-31)

**tests_must_cover**

- **ADD:** object + attribute DQ tabs render rule counts and definitions; history drawer + GLOBAL chip render
- **ADD:** classification surfaced read-only on objects + attributes
- **ADD:** allowed values render from the governed resolve (LP-43), not a hardcoded map

**pre_build_knowledge**

- **ADD:** Catalog allowed-values come from LP-43 governed resolve [UPDATE v2.9.0]

**fixed_contracts**

- **ADD:** LP-24 DQ read API
- **ADD:** LP-30 history read API
- **ADD:** LP-31 classification

**depends_on**

- **ADD:** LP-24
- **ADD:** LP-30


### LP-17 — Register Object wizard (5-step)  ·  `REWORK`

**scope**

- ~~REMOVED:~~ MUI Stepper: connection/object -> introspect -> names & roles (<=32 validation) -> taxonomy/CDE -> review & submit;
- **ADD:** MUI Stepper: schema -> object type -> object (governed inventory picker;
- **ADD:** registration-actionable subset;
- **ADD:** Not-Eligible disabled with reason) -> introspect -> names & roles (<=32 validation) -> taxonomy/CDE -> classification -> review & submit;
- **ADD:** Register list = registration queue (default) with an All-objects toggle;
- **ADD:** 'Has Updates' is a derived status (REGISTERED with attrReg<attrTotal).
- **ADD:** GLOBAL tenant-scope indicator + object history drawer (LP-30).
- **ADD:** Picker is fed by existing LP-05/LP-02 reads (object inventory + attribute counts);
- **ADD:** 'registration-actionable' and 'Has Updates' are UI-derived — FE/UX only, no schema/contract change (additive, downstream-only).
- **ADD:** The attribute step captures the full authoring contract (semantic/AI exposure per attribute, semantic role, CDE/DE + source, domain mode incl.
- **ADD:** Enumerated-list inline values and Reference-domain/Reference-table link with code/desc column mapping, operational block, effective dates) and posts it to LP-03;
- **ADD:** DOMAIN_INLINE_MAX_CARDINALITY guards inline vs reference.

**background**

- ~~REMOVED:~~ A steward registers an object through a 5-step wizard, including taxonomy/MDRM capture with jurisdiction.
- ~~REMOVED:~~ Submit lands the object DRAFT for governance approval.
- **ADD:** A steward registers an object through a 5-step wizard.
- **ADD:** The object is chosen from a GOVERNED INVENTORY PICKER (no free-text object code): a Schema -> Object Type -> Object drill-down filtered to the registration-actionable subset (New / Has-Updates / Pending / Not-Eligible).
- **ADD:** The Register list defaults to a registration queue (actionable subset) with an 'All objects' toggle, synced to the full object inventory.
- **ADD:** Taxonomy/MDRM with jurisdiction is captured;
- **ADD:** submit lands the object DRAFT for governance approval.

**manifest_of_steps**

- ~~REMOVED:~~ Stepper scaffold
- ~~REMOVED:~~ Per-step validation
- ~~REMOVED:~~ Taxonomy capture UI
- ~~REMOVED:~~ Submit to LP-03
- **ADD:** Governed ObjectPicker (Schema -> Object Type -> Object) sourced from LP-05/LP-02 reads
- **ADD:** Registration-queue default view + All-objects toggle (synced to object inventory)
- **ADD:** Not-Eligible disabled with reason; 'Has Updates' derived status
- **ADD:** Stepper scaffold + per-step validation (<=32 names)
- **ADD:** Taxonomy capture + classification step (LP-31 scheme)
- **ADD:** Submit to LP-03; GLOBAL scope indicator + object history drawer (LP-30)

**tests_must_cover**

- ~~REMOVED:~~ 5 steps gate correctly
- ~~REMOVED:~~ logical_short_nm>32 blocks advance
- ~~REMOVED:~~ taxonomy fields captured + jurisdiction shown
- ~~REMOVED:~~ submit posts and lands DRAFT
- **ADD:** object chosen from picker (no free-text object code)
- **ADD:** Schema -> Object Type -> Object drill-down filters the picker; changing schema/type clears object
- **ADD:** Not-Eligible options shown disabled with reason
- **ADD:** registration queue is default; All-objects toggle reveals full inventory
- **ADD:** 'Has Updates' derived for REGISTERED objects with attrReg<attrTotal
- **ADD:** 5 steps gate correctly; logical_short_nm>32 blocks advance
- **ADD:** submit posts and lands DRAFT; classification captured + validated
- **ADD:** Enumerated-list captures inline values; Reference-domain captures domain_cd or ref-table+code/desc cols
- **ADD:** inline domain blocked above DOMAIN_INLINE_MAX_CARDINALITY (policy_preset)

**pre_build_knowledge**

- ~~REMOVED:~~ Behavior reference: prototype Register screen
- **ADD:** Behavior reference: prototype Register screen + current Semantic Layer UI (Register Object)
- **ADD:** Object is chosen from a governed inventory picker, NOT a free-text object code [UPDATE v2.7.0]
- **ADD:** Field order is the logical drill-down Schema → Object Type → Object [UPDATE v2.7.0]
- **ADD:** Picker is sourced from existing reads (LP-05 object inventory incl. attribute counts; LP-02 schemas); 'registration-actionable' and 'Has updates' are UI-derived [UPDATE v2.7.0]
- **ADD:** FE/UX refinement only — NO schema or API contract change (additive, downstream-only) [UPDATE v2.7.0]
- **ADD:** Object is selected from a governed inventory picker, never free-typed [UPDATE v2.8.0]
- **ADD:** Picker source = LP-05/LP-02 reads (inventory + attr counts); registration-actionable + Has-Updates are UI-derived
- **ADD:** FE/UX refinement only — no schema or API contract change (additive, downstream-only)
- **ADD:** Register captures the full attribute authoring contract; inline threshold is DB-driven [UPDATE v2.9.0]

**fixed_contracts**

- **ADD:** LP-05 object inventory read (picker source)
- **ADD:** LP-02 schema registry (schema drill-down)

**depends_on**

- **ADD:** LP-05
- **ADD:** LP-30


### LP-18 — Filter Lookups screen (register/preview/certify/bind)  ·  `ADDITIVE`

**scope**

- **ADD:** Add a per-row history clock opening the shared Drawer+HistoryTimeline (LP-15 primitive, fed by LP-30).

**manifest_of_steps**

- **ADD:** Per-row history clock -> Drawer+HistoryTimeline (LP-30)

**tests_must_cover**

- **ADD:** per-row history drawer renders the entity timeline

**depends_on**

- **ADD:** LP-30


### LP-19 — Relationship view (Cytoscape over Neo4j)  ·  `ADDITIVE`

**scope**

- **ADD:** Add a per-row history clock opening the shared Drawer+HistoryTimeline (LP-15 primitive, fed by LP-30).

**manifest_of_steps**

- **ADD:** Per-row history clock -> Drawer+HistoryTimeline (LP-30)

**tests_must_cover**

- **ADD:** per-row history drawer renders the entity timeline

**depends_on**

- **ADD:** LP-30


### LP-20 — Query Studio (assemble, tag lookup, generate SQL)  ·  `REWORK`

**scope**

- ~~REMOVED:~~ execution trace.
- **ADD:** execution trace;
- **ADD:** apply approved attribute pairings (display→filter substitution) during SQL generation via the semantic-service (LP-22).

**background**

- **ADD:** Approved attribute pairings substitute a display attribute for its indexed filter attribute during SQL generation (resolved natively by the semantic-service;
- **ADD:** LP-22).

**tests_must_cover**

- **ADD:** approved pairing substitutes display→filter attribute in generated SQL

**depends_on**

- **ADD:** LP-22


---

## 3 · NEW — build from scratch (23 points)


### LP-22 — Attribute pairing registration + resolution API

*Wave:* Wave 4 · *Depends on:* LP-03 · *Lanes:* 5 · *Languages:* SQL, JAVA

Attribute pairing lets a consumer filter on a human-readable DISPLAY attribute (e.g. customer_nm) while the Lextr-native semantic-service substitutes an indexed FILTER attribute (e.g. customer_id) before SQL generation. Both attributes must be registered on the same object; the filter attribute must be indexed before activation. Resolution and value caching are native to the semantic-service (NO Cube.dev). Cross-engine pairing is blocked by OPA POL-CE-002.

**Scope.** POST register pairing (validate both attrs registered on the same object, display<>filter, land DRAFT, raise workflow task); activation gate verifies the filter attribute is indexed; POST resolve/preview (Phase-1 fill the value cache via INLINE_MAP | CACHED_LOOKUP | RUNTIME_QUERY); cross-engine check via OPA POL-CE-002; audit on every change. GET /attribute-pairings (list; client-scoped) for the registry screen; INLINE_MAP accepts a VALIDATED display->filter JSON map persisted to lookup_inline_map_jsonb (not a placeholder).

**Steps**
- Validate both attributes exist on the object and display<>filter
- Verify filter attribute is indexed (service-layer activation gate)
- Cross-engine check via OPA POL-CE-002
- Insert pairing DRAFT + workflow task
- Resolve+cache values on preview; append cache rows; compute TTL/expiry in service
- GET /attribute-pairings list endpoint (client-scoped)
- INLINE_MAP: accept + validate a display->filter JSON map; persist to lookup_inline_map_jsonb

**Tests that must pass**
- register persists pairing DRAFT atomically
- display==filter rejected
- unregistered attribute rejected
- activation blocked when filter attribute not indexed
- cross-engine pairing blocked by POL-CE-002 naming both engines
- resolve fills value cache; expiry computed in service
- audit row written
- coverage >=90%
- GET /attribute-pairings lists registered pairings; client scoping respected
- INLINE_MAP rejects malformed JSON; valid map persisted to lookup_inline_map_jsonb

**Before building**
- Pairing resolution is native semantic-service, NOT Cube.dev queryRewrite
- Filter attribute MUST be indexed to activate
- Cache expiry computed in service (no generated columns)
- client_id NULL = GLOBAL
- INLINE_MAP value is a validated user-provided JSON map, never a dummy placeholder [UPDATE v2.8.0 — pilot gap]

**Fixed contracts:** meta.attribute_pairing_catalog; meta.attribute_pairing_value_cache; OPA POL-CE-002 (cross-engine pairing); wkfl.workflow_task; meta.metadata_change_history

**Open:** P-12 pairing strategy defaults + index-verification mechanism


### LP-23 — Attribute Pairing screen (registry + register + value cache)

*Wave:* Wave 6 · *Depends on:* LP-15, LP-22, LP-30 · *Lanes:* 2 · *Languages:* TS

A steward registers and manages attribute pairings: a registry of display→filter pairings (strategy, cardinality, cross-engine flag, governance status), a register form, and a value-cache view. Surfaces the index-required activation gate and the POL-CE-002 cross-engine block.

**Scope.** React/MUI/AG Grid: pairing registry grid (display→filter, strategy, cardinality, cross-engine, governance status), register form (object → display attr → filter attr → strategy/cardinality), value-cache panel, governance status; surfaces POL-CE-002 block and index-required gate. Add a per-row history clock opening the shared Drawer+HistoryTimeline (LP-15 primitive, fed by LP-30). When strategy = INLINE_MAP, render a validated JSON map field (multiline, monospace); block submit on invalid JSON; bind the parsed map to lookup_inline_map_jsonb.

**Steps**
- Registry grid from LP-22 reads
- Register form with attribute pickers
- Value-cache panel
- Wire actions to LP-22 via Redux; surface policy/gate messages
- Per-row history clock -> Drawer+HistoryTimeline (LP-30)
- Conditional INLINE_MAP JSON field with validation; disable submit on invalid JSON

**Tests that must pass**
- registry renders from API
- register form blocks display==filter
- index-required gate surfaced on activation
- POL-CE-002 cross-engine block surfaced with policy code
- value-cache panel renders
- coverage >=90%
- per-row history drawer renders the entity timeline
- INLINE_MAP renders a JSON map field; malformed JSON blocks submit; parsed map sent in payload

**Before building**
- Behavior reference: prototype Attribute Pairing screen (do not copy code)
- Pairing is cross-attribute, not logical→physical aliasing
- INLINE_MAP requires a validated JSON map field in the register form [UPDATE v2.8.0 — pilot gap]

**Fixed contracts:** LP-22 pairing API (fixed); TENANT theming

**Open:** P-12


### LP-24 — Data Quality rule catalog + request / observe API

*Wave:* Wave 6 · *Depends on:* LP-03, LP-05, LP-12, LP-14 · *Lanes:* 6 · *Languages:* SQL, REGO, JAVA

The Semantic Layer hosts DQ rule definitions and status and lets a steward REQUEST a rule in plain English; authoring and execution are EXTERNAL. A rule runs once on base inputs keyed by logical attribute + client_id; downstream consumption inherits the verdict. Dimensions: Completeness, Validity, Conformity, Consistency, Uniqueness, Timeliness. Accuracy is externally attested (not rule-driven). Timeliness is sourced from observability (LP-27). A large portion of DQ rules are client-scoped (client_id); registration is mostly GLOBAL.

**Scope.** POST /dq/rule-requests (plain-English text + @-mentioned attributes + #-threshold + suggested dimension + justification + tenant scope; lands REQUESTED; raises a DQ_RULE_REQUEST workflow task via LP-12; request-only, never authors/executes). GET /dq/rules (inventory filterable by object/attribute/dimension/status/tenant; stable dq_rule_cd DQR-####, scope ATTRIBUTE|CROSS_ATTRIBUTE|CONDITIONAL, plain-English definition, last_run_ts, result). GET /dq/matrix (object x dimension and attribute x dimension coverage with latest verdict; measured vs UNMEASURED cells distinguished). POST /dq/results (external engine posts execution verdicts; append-only; write restricted to the engine principal via OPA POL-DQ-001).

**Steps**
- Land additive Flyway migration V3__data_quality.sql (3 tables)
- Author request endpoint (REQUEST-only) + workflow task side-effect
- Author read endpoints: rules inventory + coverage matrix
- Author result-ingest endpoint restricted to engine principal
- OPA POL-DQ-001 (request-only + tenant-scope + result principal)
- Audit every change to meta.metadata_change_history; events to LP-30

**Tests that must pass**
- request lands REQUESTED and raises a DQ_RULE_REQUEST workflow task
- @-mentioned attributes and #-threshold parse into attributes[] + threshold
- matrix marks unmeasured cells distinctly; Accuracy never rule-driven
- POST /dq/results rejected for a non-engine principal (POL-DQ-001)
- client_id scoping returns GLOBAL + caller client rows
- the API never authors or executes a rule
- Coverage >=90%

**Before building**
- Layer observes/requests/routes — never authors or executes DQ (DECISION)
- Dimension vocabulary fixed; Accuracy is externally attested (STANDARD)
- Tables ship as additive migration V3 (downstream-only); client_id NULL = GLOBAL

**Fixed contracts:** meta.dq_rule_catalog (V3); meta.dq_rule_attribute (V3); meta.dq_result (V3); wkfl.workflow_task (DQ_RULE_REQUEST); OPA POL-DQ-001; meta.metadata_change_history

**Open:** OWNER-APPROVAL: 3 DQ tables (CONTRACT); dimension vocabulary (STANDARD); request-only boundary (DECISION)


### LP-25 — Data Quality screen (matrix + rules + plain-English request)

*Wave:* Wave 7 · *Depends on:* LP-24, LP-15 · *Lanes:* 2 · *Languages:* TS

A steward sees the DQ coverage matrix, the rules inventory with on-demand plain-English definitions and last execution, and can REQUEST a rule in plain English. Rule authoring and the rule-flow lifecycle are documented separately and are not in-app screens.

**Scope.** React/MUI/AG Grid: object/attribute x dimension matrix (unmeasured cells, 'how each dimension is determined' slide-in), rules inventory (DQR-#### id, on-demand definition, last execution, per-rule history drawer), plain-English request as a closeable DRAFT TAB with @-mention attributes + #-mention thresholds + Draft ID (shared GovTabStrip from LP-15), tenant filter (GLOBAL/client). Surfaces the request-only boundary.

**Steps**
- Matrix grid (LP-24 reads)
- Rules inventory + definition on demand
- Request draft-tab with @/# mention input
- History drawer (LP-30)
- Wire to LP-24 via Redux

**Tests that must pass**
- matrix renders measured vs unmeasured cells
- @/# mention insert attributes/thresholds
- request submits to LP-24 and lands REQUESTED
- tenant filter narrows inventory
- per-rule history drawer renders
- Coverage >=90%

**Before building**
- Behavior reference: prototype Data Quality screen (do not copy code)
- Logical attributes only (never physical)
- Request-only — no in-app authoring

**Fixed contracts:** LP-24 DQ API (fixed); LP-15 GovTabStrip + Drawer/HistoryTimeline + TenantChip; TENANT theming


### LP-26 — Data Profiling read API + screen

*Wave:* Wave 6 · *Depends on:* LP-05, LP-15 · *Lanes:* 6 · *Languages:* SQL, JAVA, TS

An external engine computes profiling metrics; the Semantic Layer PRESENTS them. Per-object logical-attribute metrics (null %, distinct %, role, status) with a last-profiled timestamp. The layer does not compute profiling.

**Scope.** GET /profiling/{object} read API returning per-attribute metrics + last_profiled_ts. React/MUI/AG Grid screen rendering per-object profiling results with last-profiled timestamp. Additive migration V4 supplies meta.profiling_result.

**Steps**
- Land profiling_result in additive migration V4__profiling_observability.sql
- Read endpoint per object
- Service maps rows to DTOs
- FE profiling screen
- Tests

**Tests that must pass**
- read returns per-attribute null %/distinct %/role/status
- last_profiled_ts surfaced
- client scoping respected
- screen renders from API
- Coverage >=90%

**Before building**
- Layer presents external profiling results; does not compute them
- Tables ship as additive migration V4 (downstream-only)

**Fixed contracts:** meta.profiling_result (V4); LP-05 reads; TENANT theming

**Open:** OWNER-APPROVAL: profiling_result table (CONTRACT)


### LP-27 — Data Observability signal ingest + correlation API + screen

*Wave:* Wave 7 · *Depends on:* LP-05, LP-12, LP-24, LP-15 · *Lanes:* 8 · *Languages:* SQL, REGO, JAVA, TS

External tooling EMITS pipeline/store signals; the Semantic Layer ingests, correlates, and can trigger a DQ re-run (LP-24) or route a finding to the Workflow Queue (LP-12). Signal types: Freshness, Volume, Schema drift, Null-rate spike, Distribution shift; severity HIGH/WARN/INFO; status OPEN/TRIAGE/ACK/RESOLVED; detected_ts. Timeliness verdicts feed the DQ matrix.

**Scope.** POST /observability/signals (ingest from external tooling), GET /observability/signals (filter object/severity/status), POST /observability/signals/{id}/route (raise workflow task) and /trigger-dq (re-run via LP-24). Correlation/auto-trigger thresholds read from governance.policy_preset (DB-driven). React/MUI/AG Grid screen. Additive migration V4 supplies meta.observability_signal. Domain drift: a domain_value whose last_seen_in_source_ts goes stale raises a Schema drift / Distribution shift signal (so a value disappearing from source is observable, not silent).

**Steps**
- Land observability_signal in additive migration V4
- Ingest + read endpoints
- Correlation/route/trigger service (LP-12 + LP-24)
- Thresholds from policy_preset
- Observability screen
- Tests

**Tests that must pass**
- ingest persists a signal with severity + status
- route raises a workflow task (LP-12)
- trigger-dq calls LP-24 re-run
- thresholds read from policy_preset, never hardcoded
- screen renders signals with severity/status
- Coverage >=90%
- stale domain_value.last_seen_in_source_ts raises a drift signal

**Before building**
- Layer ingests external signals; does not emit them
- Auto-trigger thresholds DB-driven (governance.policy_preset)
- Tables ship as additive migration V4 (downstream-only)

**Fixed contracts:** meta.observability_signal (V4); wkfl.workflow_task; LP-24 DQ re-run; governance.policy_preset; TENANT theming

**Open:** OWNER-APPROVAL: observability_signal table (CONTRACT)


### LP-28 — Consumption-layer exposure + SDLC promotion API

*Wave:* Wave 6 · *Depends on:* LP-03, LP-05, LP-12, LP-14 · *Lanes:* 6 · *Languages:* SQL, REGO, JAVA

How the governed layer is EXPOSED downstream: a consumption layer (ad-hoc, rules dataset, intelligence descriptor, regulatory report), each outbound exposure as TECHNICAL (schema/table/column) or DATA_ASSET (domain/asset/attribute) structure, an aggregation pyramid (grain -> logical attributes), and an SDLC promotion track DRAFT->DEV->TEST->UAT->PROD with four gates: validation, OPA policy, governance approval via wkfl.workflow_task, versioned apply. Roles DEV=Developer, TEST=QA, UAT=Steward, PROD=Owner. The pyramid resolves to logical attributes only (no physical leakage).

**Scope.** POST/GET consumption layer + outbound exposures (structure, engine, aggregation grain). POST /consumption/{outbound}/promote (run 4 gates: validation, OPA POL-CL-001, governance approval via LP-12, versioned apply; write consumption_promotion). Additive migration V5 supplies 4 consumption tables. A consumer/engine resolves an outbound's grain to physical names via LP-32 (GET /consumption/{outbound}/resolve).

**Steps**
- Land 4 consumption tables in additive migration V5__consumption.sql
- Layer/outbound register + read endpoints
- Promotion endpoint running 4 gates
- OPA POL-CL-001 promotion gate
- Audit + workflow side-effects (LP-12)

**Tests that must pass**
- register persists layer + outbound + pyramid atomically
- promote runs all 4 gates in order
- POL-CL-001 blocks a cross-engine or unapproved promotion with policy code
- promotion writes consumption_promotion + bumps version
- pyramid resolves to logical attributes only
- Coverage >=90%

**Before building**
- Promotion gates: validation -> OPA -> governance approval (LP-12) -> versioned apply (DECISION)
- Logical attributes only in the pyramid
- Tables ship as additive migration V5 (downstream-only)

**Fixed contracts:** meta.consumption_layer (V5); meta.consumption_outbound (V5); meta.consumption_outbound_grain (V5); meta.consumption_promotion (V5); OPA POL-CL-001; wkfl.workflow_task (CONSUMPTION_PROMOTE); meta.metadata_change_history; LP-32 resolution API

**Open:** OWNER-APPROVAL: 4 consumption tables (CONTRACT); env/role model + 4-gate definition (DECISION)


### LP-29 — Downstream Consumption screen (exposure + SDLC promotion)

*Wave:* Wave 7 · *Depends on:* LP-28, LP-15 · *Lanes:* 2 · *Languages:* TS

A steward configures consumption-layer exposures and promotes them through the SDLC track. Exposure-structure toggle (technical vs data-asset), aggregation-pyramid drill to logical attributes, Add-Consumption-Layer wizard, and the SDLC promotion track with four gates and role-by-env sign-off.

**Scope.** React/MUI/AG Grid: consumption layers, exposure-structure toggle (TECHNICAL/DATA_ASSET), aggregation-pyramid drill to logical attributes, Add-Consumption-Layer wizard, SDLC promotion track DRAFT->DEV->TEST->UAT->PROD with the 4 gates and role-by-env sign-off. Wired to LP-28 + LP-12.

**Steps**
- Layers list + outbound detail (LP-28 reads)
- Exposure structure toggle + pyramid drill
- Add-Layer wizard
- SDLC promotion track + gates
- Wire to LP-28 via Redux

**Tests that must pass**
- layers + outbounds render from API
- structure toggle switches technical/data-asset view
- pyramid drills to logical attributes only
- promotion track shows 4 gates + role per env
- Coverage >=90%

**Before building**
- Behavior reference: prototype Downstream Consumption screen (do not copy code)
- Logical attributes only in pyramid

**Fixed contracts:** LP-28 consumption API (fixed); LP-12 workflow; TENANT theming


### LP-30 — Entity governance-history read API

*Wave:* Wave 4 · *Depends on:* LP-01, LP-03 · *Lanes:* 4 · *Languages:* SQL, JAVA

A READ surface returning an append-only, newest-first event timeline per entity (objects, relationships, pairings, filter lookups, DQ rules) for the history drawer used across the UI. Distinct from meta.metadata_change_history (the audit WRITE). Recommended: derive from metadata_change_history; if a curated human-facing timeline is needed (who/what/when/status badge), add an optional meta.governance_event projection in V3. CONFIRM (DECISION): derive-from-audit vs dedicated event table.

**Scope.** GET /history/{entity_type}/{entity_ref} -> [{ts, event_txt, status_badge_cd, by, team}] derived from meta.metadata_change_history (or meta.governance_event if approved). Read-only; client-scoped.

**Steps**
- SQL over metadata_change_history (or governance_event)
- Read endpoint per entity
- Service maps to timeline DTO
- Tests

**Tests that must pass**
- returns newest-first events for an entity
- objects/relationships/pairings/lookups/DQ rules all resolve
- client scoping respected
- empty timeline returns []
- Coverage >=90%

**Before building**
- History is a READ projection of the audit trail; the write stays meta.metadata_change_history
- Derive-from-audit vs governance_event table is a DECISION to confirm

**Fixed contracts:** meta.metadata_change_history (read); meta.governance_event (optional, V3)

**Open:** OWNER-APPROVAL: derive-from-audit vs governance_event table (DECISION)


### LP-31 — Data access control (ring-fencing) + data classification

*Wave:* Wave 4 · *Depends on:* LP-01, LP-03, LP-14 · *Lanes:* 6 · *Languages:* SQL, REGO, JAVA

Data access is enforced at the shared Keycloak(OIDC)+OPA gateway in front of every endpoint, so the same rules apply to analysts, rules, reports, and AI. Two policies run on every request: POL-AC-001 ring-fences access (deny-by-default; tenant/client isolation; role/purpose-based authorization; need-to-know), and POL-DC-001 applies each object/attribute's data classification (Public/Internal/Confidential/Restricted, plus PII, MNPI, CSI, CDE, jurisdiction) to mask, restrict, or deny, and to gate AI exposure (ALLOWED/RESTRICTED/BLOCKED). Classification is captured at registration and is a governed property, not discretionary. This is the control set that lets model inputs satisfy MRM (SR 11-7 / OCC 2011-12) and firm-wide BCBS 239 expectations. Policies are externalized (configurable, never in code) and every access decision is logged.

**Scope.** Additive migration V6 adds a GOVERNED classification lookup and attribute-level classification (object-level classification + PII/confidential/masking already exist in the V1 baseline), plus optional ring-fence grants. POL-AC-001 (deny-by-default access: tenant isolation + role/purpose authorization) and POL-DC-001 (classification-driven masking/restriction + AI exposure) are authored and added to the LP-14 bundle. The shared read/exposure service applies both on every request and masks/withholds fields the caller is not entitled to; cross-tenant access is always denied. Every decision is audited.

**Steps**
- Land V6__classification.sql (governed ref + attribute-level classification + grants; object-level already in baseline)
- Author POL-AC-001 (deny-by-default; tenant isolation; role/purpose authorization)
- Author POL-DC-001 (classification-driven masking/restriction; AI exposure tier)
- Enforce both in the shared read/exposure path; mask/withhold unentitled fields
- Add POL-AC-001 + POL-DC-001 to the LP-14 OPA bundle
- Audit every access decision to meta.metadata_change_history

**Tests that must pass**
- cross-tenant read is always denied (tenant isolation)
- role/purpose without entitlement is denied with policy code (POL-AC-001)
- RESTRICTED/CONFIDENTIAL fields masked or withheld per caller entitlement (POL-DC-001)
- PII/MNPI/CSI handling enforced by class, not discretion
- AI principal blocked from BLOCKED/RESTRICTED-AI attributes
- every access decision is logged
- default-deny on unknown input; coverage >=90%

**Before building**
- Enforcement is cross-cutting at the Keycloak(OIDC)+OPA gateway; all read/exposure (LP-05) and consumption (LP-28) inherit it
- Object-level classification (data_classification_cd, pii_flg, confidential_flg, ai_governance_cd) is already in the V1 baseline; V6 governs it and extends classification to the attribute level
- Tables/columns ship as additive migration V6 (downstream-only); client_id NULL = GLOBAL

**Fixed contracts:** meta.data_classification_ref (V6); attribute_catalog classification columns + object_catalog classification FK (V6); meta.attribute_access_grant (V6, optional); OPA POL-AC-001; OPA POL-DC-001; LP-14 OPA bundle; meta.metadata_change_history

**Open:** OWNER-APPROVAL: classification scheme + tiers (STANDARD); OWNER-APPROVAL: access/authorization model — roles/purposes (DECISION/CONTRACT); OWNER-APPROVAL: masking vs withhold behavior per class (DECISION)


### LP-32 — Logical→Physical resolution API for downstream engines

*Wave:* Wave 7 · *Depends on:* LP-05, LP-28, LP-14, LP-31 · *Lanes:* 5 · *Languages:* JAVA, SQL, REGO

External execution engines (e.g. the Lextr rules engine — a relational DAG of Filter/Aggregate/Join/Union/Intersect/Minus/Map/Pivot/Concat/Editcheck operators) consume a governed dataset in LOGICAL names and execute on PHYSICAL names. They need ONE thing from the Semantic Layer that did not previously exist: a governed logical→physical RESOLUTION — never SQL. This point exposes physical_attribute_nm, source_object_nm, engine_cd and datatype for a set of logical attributes (or a whole consumption-outbound grain), deliberately crossing the logical-over-physical boundary under a dedicated policy, restricted to authorized engine principals, classification-aware, and audited. No SQL is generated; the engine builds and runs its own DAG.

**Scope.** POST /semantic/resolve (body: outbound_cd OR attributes[]{schema_cd,object_cd,attribute_cd} + purpose_cd) returns per attribute {logical_nm, physical_attribute_nm, source_object_nm, engine_cd, datatype_cd, data_classification_cd, masked_flg}. GET /consumption/{outbound}/resolve resolves the whole outbound grain (LP-28). Authorized engine principals only; POL-RS-001 governs physical-name exposure and applies POL-DC-001 classification (omit/mask restricted attributes); cross-tenant denied; every resolve audited. NO SQL generated — reads catalog only.

**Steps**
- Resolution SQL over object_catalog/attribute_catalog (+ overrides) and data_connection (engine_cd) in queries.properties
- POST /semantic/resolve (attributes[] or outbound_cd) + GET /consumption/{outbound}/resolve
- Author POL-RS-001 (engine-principal physical-name exposure; applies POL-DC-001; deny cross-tenant)
- Mask/omit attributes the principal is not entitled to; set masked_flg
- Add POL-RS-001 to the LP-14 OPA bundle; audit every resolve to metadata_change_history

**Tests that must pass**
- resolve returns physical_attribute_nm + source_object_nm + engine_cd + datatype for entitled attributes
- NO SQL is produced (mapping payload only)
- non-engine principal denied (POL-RS-001)
- restricted/unentitled attributes omitted or masked (POL-DC-001)
- cross-tenant resolve denied; resolve audited
- outbound-grain resolve matches LP-28 grain; coverage >=90%

**Before building**
- Physical names are otherwise never exposed (logical-over-physical); this is the single governed exception for engine principals
- Resolve at the consumption-outbound grain matches the dataset the engine's operators consume (LP-28)
- Editcheck verdicts from the engine post back via LP-24 (DQ) or LP-33 (general)

**Fixed contracts:** meta.object_catalog (read); meta.attribute_catalog (read); meta.attribute_logical_name_override; meta.data_connection (engine_cd); meta.consumption_outbound_grain (LP-28); OPA POL-RS-001; OPA POL-DC-001; LP-14 OPA bundle; meta.metadata_change_history

**Open:** OWNER-APPROVAL: which principals are 'engine principals' allowed to resolve physical names; OWNER-APPROVAL: omit vs mask for restricted attributes in resolve responses


### LP-33 — External rule-engine output ingest

*Wave:* Wave 7 · *Depends on:* LP-12, LP-14, LP-31, LP-28 · *Lanes:* 4 · *Languages:* JAVA, SQL, REGO

The rules engine's Execution view produces verdicts, values, editcheck violations and datasets. DQ-shaped verdicts post via LP-24 (dq_result). This point adds a GENERAL governed ingest for the other outputs so findings remain traceable in the Semantic Layer, append-only, write-restricted to the engine principal, keyed by an engine-controlled rule reference and the consumption outbound it ran on.

**Scope.** POST /rule-results (rule_ref + outbound_cd + result_type VERDICT|VALUE|EDITCHECK|DATASET + payload + row/violation counts + tenant). Append-only; write restricted to engine principal via POL-RR-001; EDITCHECK results may alternatively route to LP-24 dq_result. Additive migration V7 supplies meta.external_rule_result.

**Steps**
- Land V7__external_rule_result.sql (meta.external_rule_result)
- POST /rule-results ingest endpoint (append-only)
- Author POL-RR-001 (engine-principal write; tenant scope)
- Route EDITCHECK to LP-24 dq_result where a dq_rule_cd exists; else land general result
- Add POL-RR-001 to LP-14 bundle; audit + LP-30 history events

**Tests that must pass**
- engine principal can append a result; non-engine write denied (POL-RR-001)
- result_type CHECK enforced; tenant scope respected
- EDITCHECK routes to dq_result when dq_rule_cd present
- append-only (no update/delete); coverage >=90%

**Before building**
- Mirrors LP-24 POST /dq/results principal restriction
- Rule identity is engine-controlled (rule_ref); SL keeps it traceable

**Fixed contracts:** meta.external_rule_result (V7); meta.dq_result (LP-24, for EDITCHECK); OPA POL-RR-001; wkfl.workflow_task; meta.metadata_change_history

**Open:** OWNER-APPROVAL: whether DATASET outputs are stored or referenced by handle


### LP-34 — OpenAPI/Swagger documentation alignment (cross-cutting)

*Wave:* Wave 8 · *Depends on:* LP-05 · *Lanes:* 2 · *Languages:* JAVA

The service already includes springdoc-openapi but no OpenAPI config and no @Tag/@Operation/@ApiResponse annotations. This point exposes and standardizes OpenAPI for the CURRENT controller surface across every feature — discoverable, consistent API docs — without changing any route or payload. Cross-cutting Global Standard applied horizontally across EVERY existing controller/service; reuse > configuration > extension > new; no functional contract change.

**Scope.** Wire the existing springdoc starter: add a single OpenAPI config bean; annotate existing controllers (@Tag/@Operation/@ApiResponse); document multipart/query/request-body endpoints; no route or payload change.

**Steps**
- Add OpenAPI config (reuse existing springdoc)
- Annotate existing controllers across all features
- Document multipart/query/body endpoints
- Conformance test: spec loads + all routes present

**Tests that must pass**
- /v3/api-docs loads successfully
- every existing controller route appears in the generated spec
- no route or payload contract changes
- coverage >=90%

**Before building**
- Reuse existing springdoc-openapi-starter-webmvc-ui; do not add Swagger2/Springfox
- Document, never redesign, the API surface

**Fixed contracts:** existing controllers (all features); springdoc-openapi-starter-webmvc-ui


### LP-35 — Logging standardization + diagnostics hardening (cross-cutting)

*Wave:* Wave 8 · *Depends on:* LP-03 · *Lanes:* 2 · *Languages:* JAVA

Logging today is mixed (LoggerFactory + @Slf4j) with no centralized config and a controller-advice scoped to one package, so exception logging is not truly global. This point standardizes a single logging pattern and centralized config across the service without changing business behavior. Cross-cutting Global Standard applied horizontally across EVERY existing controller/service; reuse > configuration > extension > new; no functional contract change.

**Scope.** One logging pattern; add logback-spring.xml + logging.level config; reuse the existing controller timing aspect; ensure consistent startup/runtime/error logging across all packages; never log secrets/credentials/PII/raw payloads.

**Steps**
- Centralize logback-spring.xml + logging levels
- Standardize on one logger pattern
- Reuse controller execution-time aspect
- No secrets/PII in logs

**Tests that must pass**
- shared logging path used by touched scope
- error paths still map to same HTTP status
- startup succeeds with new logging config
- no duplicate logging mechanism
- coverage >=90%

**Before building**
- Reuse existing timing aspect + handler patterns
- No business logic in logging code; no secrets logged

**Fixed contracts:** ControllerExecutionTimeAspect; GlobalExceptionHandler (see LP-38); logback-spring.xml


### LP-36 — Datasource integration + JDBC bean completion (cross-cutting)

*Wave:* Wave 8 · *Depends on:* LP-01 · *Lanes:* 2 · *Languages:* JAVA

A custom datasource model exists (DataSourceProperties binds app.datasource.*; DataSourceConfig builds Hikari and conditionally skips ClickHouse; JdbcTemplateConfig exposes the primary NamedParameterJdbcTemplate). This point hardens datasource integration using the existing custom model so the service is deployable outside a local dev box. Cross-cutting Global Standard applied horizontally across EVERY existing controller/service; reuse > configuration > extension > new; no functional contract change.

**Scope.** Harden the existing custom datasource model: bind app.datasource.*; primary PG + optional ClickHouse path keyed by data_db_engine; test profile binds H2 + Flyway and disables Config Server; no JPA.

**Steps**
- Harden Hikari datasource binding (app.datasource.*)
- Primary PG + conditional ClickHouse path
- Test profile: H2 + Flyway, Config Server disabled
- No JPA introduced

**Tests that must pass**
- properties bind to app.datasource
- primary datasource selection works
- ClickHouse path enabled/skipped by data_db_engine
- test profile context loads without remote config
- no JPA; coverage >=90%

**Before building**
- Reuse existing DataSourceProperties/DataSourceConfig/JdbcTemplateConfig
- Preserve app.datasource.primary + NamedParameterJdbcTemplate approach

**Fixed contracts:** DataSourceProperties; DataSourceConfig; JdbcTemplateConfig; application-test.yml


### LP-37 — Spring Cloud Config integration hardening (cross-cutting)

*Wave:* Wave 8 · *Depends on:* LP-36 · *Lanes:* 2 · *Languages:* JAVA

spring-cloud-starter-config is present; main config imports configserver: with fail-fast/label; test config disables Config Server and relies on local properties; no runtime refresh path. This point hardens the startup-time config-server pattern and the test isolation so generated code runs safely outside a local setup. Cross-cutting Global Standard applied horizontally across EVERY existing controller/service; reuse > configuration > extension > new; no functional contract change.

**Scope.** Harden the startup-time Config Server pattern: preserve spring.application.name; keep test-time Config Server disablement; required properties resolve in test and local; no second config framework; no secrets in repo config.

**Steps**
- Preserve startup config-server import + label
- Keep test-time Config Server disablement
- Ensure properties resolve in test+local
- No secrets in repo config

**Tests that must pass**
- test profile starts with Config Server disabled
- required properties resolve in test+local
- main config valid for deployed envs
- no second config framework
- coverage >=90%

**Before building**
- Reuse existing Spring Cloud Config setup + test disablement
- No hardcoded secrets/credentials in repo config

**Fixed contracts:** application.yml; application-test.yml; spring-cloud-starter-config


### LP-38 — Global exception handling standardization (cross-cutting)

*Wave:* Wave 8 · *Depends on:* LP-03 · *Lanes:* 2 · *Languages:* JAVA

A GlobalExceptionHandler exists but its @ControllerAdvice is scoped to one package, so it is not truly global; error responses are an ad-hoc map. This point broadens the existing handler across all controller packages with a consistent error payload, without redesigning the API contract. Cross-cutting Global Standard applied horizontally across EVERY existing controller/service; reuse > configuration > extension > new; no functional contract change.

**Scope.** Broaden the existing @ControllerAdvice across all controller packages; consistent error payload (message/status/code); preserve HTTP status intent for known exceptions; map domain failures consistently (422 + policy code stays).

**Steps**
- Broaden @ControllerAdvice to all controller packages
- Consistent error payload structure
- Preserve HTTP status intent for known exceptions
- Validation errors map consistently

**Tests that must pass**
- mapped exceptions return expected HTTP status
- validation errors map consistently
- handling applies across all controller packages
- error structure preserved unless contract change approved
- coverage >=90%

**Before building**
- Reuse the existing GlobalExceptionHandler; do not add a parallel layer
- Preserve current HTTP status intent

**Fixed contracts:** GlobalExceptionHandler; all controllers


### LP-39 — Test coverage + completeness gate (cross-cutting)

*Wave:* Wave 8 · *Depends on:* LP-34, LP-38 · *Lanes:* 2 · *Languages:* JAVA

The >=90% coverage bar lives on every point but is not enforced, and there is no gate that catches a missing cross-cutting concern or a missing read API before sign-off. This point adds JaCoCo enforcement and a COMPLETENESS GATE so functional completion cannot masquerade as production-readiness — the durable structural fix the pilot recommends so this class of gap never recurs. Cross-cutting Global Standard applied horizontally across EVERY existing controller/service; reuse > configuration > extension > new; no functional contract change.

**Scope.** JaCoCo >=90% line/branch enforcement that fails the build below threshold; a completeness gate that FAILS generation/build when (a) a required cross-cutting concern (LP-34..LP-40) is absent, (b) an entity with a write has no GET/list read, or (c) a screen has no backing read API. Produces a coverage + completeness report. Completeness gate adds a UI->contract ROUND-TRIP check: every field the registration/catalog UI captures for an attribute MUST persist via LP-03 and return via LP-05; the build fails if any authoring field is dropped.

**Steps**
- JaCoCo >=90% enforcement (fail build below threshold)
- Completeness gate: required cross-cutting concerns present
- Completeness gate: every write entity has a GET/list read
- Completeness gate: every screen has a backing read API
- Emit coverage + completeness report
- Round-trip gate: registration UI fields == LP-03 persisted == LP-05 exposed

**Tests that must pass**
- build fails below 90% coverage
- gate fails when a required cross-cutting concern is missing
- gate fails when a write entity lacks a GET/list read
- gate fails when a screen lacks a backing read API
- report lists every check + status
- gate fails when a Register-UI attribute field does not round-trip through LP-03->LP-05

**Before building**
- Coverage is enforced, not just asserted
- The gate is the 'remember for future' control that prevents silent re-introduction of these gaps
- Round-trip check prevents UI-authors/manifest-persists drift recurring [UPDATE v2.9.0]

**Fixed contracts:** JaCoCo config; CI pipeline; manifest required-concern inventory


### LP-40 — Application observability + resilience hooks (cross-cutting)

*Wave:* Wave 8 · *Depends on:* LP-36 · *Lanes:* 2 · *Languages:* JAVA

Distinct from LP-27 (DATA observability about pipelines): this is APPLICATION observability — Actuator health/readiness/liveness + metrics — plus the self-healing core-path resilience the governance bar has long called for (retries, circuit-breaking, graceful degradation). This resolves pending item P-07. Cross-cutting Global Standard applied horizontally across EVERY existing controller/service; reuse > configuration > extension > new; no functional contract change.

**Scope.** Spring Boot Actuator health/readiness/liveness + Prometheus metrics; resilience on core paths (retries, circuit-breaking, graceful degradation, health/recovery hooks) around external calls (OPA client, engine calls, datasource); confirm the resilience library (P-07).

**Steps**
- Actuator health/readiness/liveness endpoints
- Prometheus metrics exposure
- Resilience on core path (retry/circuit-break/graceful-degrade)
- Health/recovery hooks; confirm resilience library (P-07)

**Tests that must pass**
- health/readiness/liveness endpoints respond
- metrics scrape endpoint exposed
- core-path call retries + circuit-breaks under failure
- graceful degradation on dependency outage
- coverage >=90%

**Before building**
- App observability is distinct from LP-27 data observability
- Resolves P-07 self-healing bar

**Fixed contracts:** Spring Boot Actuator; Prometheus; resilience library [P-07 confirm]; OPA client + engine/datasource calls


### LP-41 — Tenant Workspaces management API + screen

*Wave:* Wave 6 · *Depends on:* LP-03, LP-05, LP-15 · *Lanes:* 4 · *Languages:* SQL, JAVA, TS

The UI prototype shows a Tenant Workspaces screen; this LP supplies its backing tables/API (owner-approved 2026-08-19). A workspace is a named, per-tenant scoping of registered objects (e.g. WS-ALL, WS-BHC-A) and is the enforcement home for BOUNDED consumer/agent scope: it is the explicit set of objects an agent (e.g. Lextr Intelligence / Lexie) may operate over. Tables ship as additive migration V8.

**Scope.** Additive migration V8 (meta.tenant_workspace + meta.tenant_workspace_object). GET /workspaces?client_id; POST /workspaces; POST /workspaces/{cd}/objects (add a registered object); DELETE /workspaces/{cd}/objects/{schema}/{object} (remove). React/MUI screen wired to the API. Client-scoped; audited. A workspace bounds the object set an agent/consumer may traverse (see consumer_traversal.bounded_scope).

**Steps**
- Land V8__tenant_workspace.sql (2 tables) — committed (owner-approved 2026-08-19)
- GET/POST workspaces; add/remove objects
- Client scoping + audit
- Workspaces screen wired to the API

**Tests that must pass**
- GET /workspaces returns active workspaces for the tenant
- POST creates a workspace
- add/remove object updates membership
- client scoping respected
- coverage >=90%

**Before building**
- Tables are COMMITTED (owner-approved 2026-08-19); additive migration V8; client_id NULL = GLOBAL
- Workspace = the explicit bounded scope set for consumer/agent access (bounded, not autonomous)
- Additive migration V8; client_id NULL = GLOBAL

**Fixed contracts:** meta.tenant_workspace (V8); meta.tenant_workspace_object (V8); TENANT theming


### LP-42 — Logical Hierarchies management API + screen [PROPOSED] · **PROPOSED — DO NOT BUILD**

*Wave:* Wave 6 · *Depends on:* LP-05, LP-15 · *Lanes:* 4 · *Languages:* SQL, JAVA, TS

PROPOSED (OWNER-APPROVAL — new tables = CONTRACT). The UI prototype shows a Hierarchy screen but there is no backing table/API. A logical hierarchy defines a named tree over logical attributes (e.g. ENTITY_HIERARCHY, PERIOD_HIERARCHY) with ordered levels. Tables ship as additive migration V9 and are held as a PROPOSAL until the owner approves.

**Scope.** Additive migration V9 (meta.logical_hierarchy + meta.logical_hierarchy_level). GET /hierarchies?client_id; POST /hierarchies (save a tree definition + levels). React/MUI screen. Logical attributes only (no physical leakage). Client-scoped; audited. HELD AS PROPOSAL until owner approval.

**Steps**
- Land V9__logical_hierarchy.sql (2 tables) — PROPOSED, owner-approval gated
- GET/POST hierarchies (tree + ordered levels)
- Logical attributes only; client scoping + audit
- Hierarchy screen wired to the API

**Tests that must pass**
- GET /hierarchies returns defined hierarchies for the tenant
- POST saves a tree + ordered levels
- levels reference logical attributes only
- client scoping respected
- coverage >=90%

**Before building**
- Tables are PROPOSED (CONTRACT) — not landed until owner approval
- Levels bind to logical attributes only (no physical leakage)
- Additive migration V9; client_id NULL = GLOBAL

**Fixed contracts:** meta.logical_hierarchy (V9, PROPOSED); meta.logical_hierarchy_level (V9, PROPOSED); TENANT theming

**Open:** OWNER-APPROVAL: meta.logical_hierarchy + meta.logical_hierarchy_level (CONTRACT)


### LP-43 — Domain registration + governed AI resolve (deterministic phrase resolution)

*Wave:* Wave 6 · *Depends on:* LP-03, LP-05 · *Lanes:* 5 · *Languages:* SQL, JAVA, REGO, TS

A coded attribute's valid values are a governed codeset (code+description), not UI mock. This point registers/reads governed domains (domain_catalog + domain_value; source INLINE|ENUMERATED|REFERENCE_TABLE) and exposes a governed AI resolve so consumers and Lexie ground on the certified, tenant-scoped, current allowed values — the critical grounding piece for Vertical AI.

**Scope.** Additive V10 (domain_catalog + domain_value) + V11 (attribute_catalog domain columns). GET/POST /domains (+values); source_type ENUMERATED (rows) | REFERENCE_TABLE (project ref_table code/desc cols) | INLINE (attribute domain_values_jsonb). POST /semantic/resolve-domain (attribute or domain_cd, tenant, as-of date) -> ACTIVE allowed values with description + AI context; policy-gated (POL-DM-001); every resolve audited. Catalog (LP-16) and Register (LP-17) consume this — no client-side value maps. DETERMINISTIC PHRASE RESOLUTION (ASK 1-8): resolve a normalised phrase (lower/trim/collapse-space, EXACT compare only — NO fuzzy/stemming/embedding/nearest) against code, description or ACTIVE synonym. Outcome is a closed set of three: EXACT (one match + resolution_basis), AMBIGUOUS (>1 match -> ALL candidates, never a best guess), UNRESOLVED (0 matches -> domain cardinality + search handle). resolution_basis (CODE|DESCRIPTION|SYNONYM|SOURCE_MAPPING + matched text) is REQUIRED on every resolved value, for the evidence trail. Return per value: value_cd, value_desc, ai_context_txt, lifecycle_status_cd, effective dates, and domain_catalog.version_nbr. Synonyms live in meta.domain_value_synonym (governed vocabulary; tenant rows may override GLOBAL as a tracked exception, override_global_flg; resolution considers GLOBAL + caller tenant, TENANT wins). Source codes map via meta.domain_value_source_map (resolution_basis=SOURCE_MAPPING). Scale: value_count_nbr on domain_catalog (service-maintained); GET /domains/{domain_cd}/values?q=&limit=&cursor= (prefix/substring, paginated, trigram-indexed); above DOMAIN_MAX_ENUMERATE_CARDINALITY the full-set resolve REFUSES (policy) and directs to search. Versioning: version_nbr bumped in-service on any value/synonym/mapping change; as_of resolves at the past version so a saved report re-explains as at its authoring date. Per-value ai_exposure_cd (inherits attribute, never wider). YN_FLAG removed — booleans are two-value ENUM_LIST. LOCALE: description + ai_context resolve in the caller's locale via meta.domain_value_text (locale -> en-US -> domain_value.value_desc fallback); value_cd is never translated. Normalisation for deterministic match is UNICODE CASE-FOLDING with a declared normalisation form (NFC + full case-fold + trim + collapse whitespace), done in-service — never SQL LOWER() (which is wrong for Turkish i, German ss, and accents). TTL: a 'latest' resolve may be cached up to DOMAIN_RESOLVE_TTL_SECONDS; a resolve pinned to version_nbr/as_of is immutable and cacheable indefinitely.

**Steps**
- Land V10 domain store + V11 attribute domain columns
- GET/POST domains + values; source-type handling (ENUMERATED/REFERENCE_TABLE/INLINE)
- REFERENCE_TABLE: project ref_table (code_col, desc_col); validate table + columns exist
- POST /semantic/resolve-domain: tenant + as-of + lifecycle filter; return code+desc+ai_context
- POL-DM-001 gate + audit; wire LP-16 catalog + LP-17 register to the resolve
- Land V12 synonyms + V13 source-map + V14 (version/count/per-value AI + YN_FLAG removal)
- Normalise phrase (lower/trim/collapse) then EXACT match on code/desc/ACTIVE synonym — no fuzzy/stemming/embedding
- Return EXACT | AMBIGUOUS (all candidates) | UNRESOLVED (cardinality + search handle); resolution_basis + version on every value
- Synonym precedence: GLOBAL + tenant; TENANT overrides GLOBAL (override_global_flg tracked exception)
- GET /domains/{domain_cd}/values?q=&limit=&cursor= (trigram) ; refuse full-set above DOMAIN_MAX_ENUMERATE_CARDINALITY
- Bump domain version_nbr in-service on value/synonym/mapping change; as_of resolves at past version
- Route synonym authoring through LP-12 SYNONYM_AUTHOR (four-eyes); resolve uses ACTIVE + certified synonyms only
- Localize description/ai_context via domain_value_text (locale -> en-US fallback); value_cd untouched
- Normalise with Unicode case-folding + declared form (NFC), not LOWER()
- Return / honour DOMAIN_RESOLVE_TTL_SECONDS; version/as-of-pinned resolve is immutable

**Tests that must pass**
- ENUMERATED resolves domain_value rows; REFERENCE_TABLE projects ref-table code/desc; INLINE reads jsonb
- resolve is tenant-scoped + as-of-date + lifecycle-filtered (ACTIVE only)
- POL-DM-001 denies cross-tenant / unauthorized
- AI resolve returns per-value ai_context where present
- coverage >=90%
- phrase matching one ACTIVE synonym -> EXACT with resolution_basis=SYNONYM
- phrase matching two values -> AMBIGUOUS with EVERY candidate (never a best guess)
- unknown phrase -> UNRESOLVED with cardinality + search handle (not an empty success)
- synonym colliding within domain/locale/tenant -> rejected at WRITE by uq_dvs
- RETIRED value excluded from resolve but still resolvable as_of a past date
- resolve above DOMAIN_MAX_ENUMERATE_CARDINALITY refuses and names the policy
- source-mapped code resolves with resolution_basis=SOURCE_MAPPING
- tenant synonym overrides GLOBAL for the same phrase; override flagged (override_global_flg)
- cross-tenant resolve denied naming POL-DM-001; every resolve audited with domain + version + basis
- no fuzzy/stemming/embedding path exists (deterministic compare only)
- French phrase matches a French synonym AND the value returns a French description (locale-aware)
- Turkish dotted/dotless i and German ss fold correctly (deterministic, not LOWER)
- missing locale falls back to en-US then to value_desc; value_cd never translated
- version/as-of-pinned resolve marked immutable; latest resolve carries the TTL

**Before building**
- Domain source types: INLINE (attribute jsonb) | ENUMERATED (domain_value) | REFERENCE_TABLE (project a ref table)
- Link, don't copy: REF_DOMAIN resolves live from source (always current)
- Grounding contract for Vertical AI: code + description + ai_context, certified + tenant-scoped [v2.9.0]
- The layer is DETERMINISTIC: fuzzy/approximate matching stays with the CONSUMER, never the layer [v2.10.0 ASK 3]
- resolution_basis + domain version are REQUIRED for the evidence trail [v2.10.0]
- Booleans are two-value ENUM_LIST (YN_FLAG removed) so they carry descriptions + synonyms [v2.10.0 ASK 2a]
- Tenant synonym overrides GLOBAL as a TRACKED exception, never silently [v2.10.0]
- Metadata is localized, the CODE is not: value_cd never translated; value_desc/ai_context are per-locale [v2.11.0]
- Deterministic match uses Unicode case-folding, not LOWER() — required once text is multilingual [v2.11.0]

**Fixed contracts:** meta.domain_catalog (V10); meta.domain_value (V10); attribute_catalog domain columns (V11); governance.policy_preset DOMAIN_INLINE_MAX_CARDINALITY; meta.domain_value_synonym (V12); meta.domain_value_source_map (V13); domain_catalog.version_nbr + value_count_nbr (V14); domain_value.ai_exposure_cd (V14); governance.policy_preset DOMAIN_MAX_ENUMERATE_CARDINALITY; meta.domain_value_text (V15); governance.policy_preset DOMAIN_RESOLVE_TTL_SECONDS

**Open:** POL-DM-001 (domain resolve policy) to author in the OPA bundle (LP-14)


### LP-44 — Attribute promotion (report-local derived → governed) [PROPOSED] · **PROPOSED — DO NOT BUILD**

*Wave:* Wave 9 · *Depends on:* LP-03, LP-12, LP-17 · *Lanes:* 4 · *Languages:* SQL, JAVA, TS

Lextr Intelligence UC10 lets an analyst derive a report-local attribute (a maturity band, a utilisation ratio) grounded on SL attributes only. PROMOTION is the moment that working definition becomes shared meaning in the catalog — the SL's invariant. Until the rulings below are confirmed and Core supplies the workflow stages, the promotion control stays ABSENT rather than approximated.

**Scope.** Additive V16 provenance on attribute_catalog (attr_origin_cd SOURCE_DERIVED|PROMOTED_DERIVED, promoted_from_report_id, derivation_expression_txt, expression_author_cd incl. ASSISTANT_DRAFTED_HUMAN_APPROVED). Promotion routes through attribute registration (LP-03/LP-17) and a new four-eyes wkfl.workflow_task type ATTRIBUTE_PROMOTION (LP-12). SL RECOMMENDED RULINGS (owner to confirm): (1) four-eyes, not the author alone; (2) provenance visible; (3) NO silent rebind — existing report-local copies stay and are FLAGGED for their owners to rebind; (4) demote/retire via standard lifecycle, reports using a retired promoted attr flagged/counted; (5) the expression SURVIVES promotion, and if the SL re-expresses it against its own model an EQUIVALENCE CHECK must pass first (so a promoted attr cannot silently compute a different number). Report-local attributes render visibly distinct from SL attributes.

**Steps**
- Land V16 provenance (PROPOSED)
- Add ATTRIBUTE_PROMOTION four-eyes task (LP-12) wired to Core workflow stages
- Promote via attribute registration; stamp provenance + expression_author
- Rule out silent rebind: flag report-local copies for owner rebind
- Lifecycle demote/retire; equivalence check if re-expressed

**Tests that must pass**
- promotion requires four-eyes approval before the attribute is ACTIVE
- promoted attr is distinguishable from source-derived (attr_origin_cd + provenance visible)
- existing report-local copies are NOT silently rebound — they are flagged
- re-expressed promoted attr fails promotion unless equivalence check passes
- assistant-drafted-human-approved expressions are recorded and visible

**Before building**
- PROPOSED — pending owner confirmation of the 5 rulings AND Core workflow-stage definitions for ATTRIBUTE_PROMOTION
- Report-local by default; promotion is never a side effect of creating a derived attribute
- Expressions ground on SL attributes only — never a physical column, never free SQL

**Fixed contracts:** attribute_catalog provenance columns (V16, PROPOSED); wkfl.workflow_task ATTRIBUTE_PROMOTION type

**Open:** OWNER-APPROVAL: confirm the 5 promotion rulings (esp. no-silent-rebind, expression-survives); CORE dependency: workflow stages/approval chain for the ATTRIBUTE_PROMOTION task type


---

## 4 · Database delta

Run `Lextr_SemanticLayer_DELTA_DDL_v2.3.0_to_v2.11.0.sql` as additive Flyway migrations. It adds **23 tables** (21 applyable, 2 proposed and commented out) and **27 columns** on `meta.attribute_catalog`.

`meta.governance_event` is **deferred** — commented out in v2.11.0 and not created by this script.

### New tables

| Table | Owning points | Status |
|---|---|---|
| `meta.attribute_access_grant` | LP-31 | committed |
| `meta.attribute_pairing_catalog` | LP-01 LP-22 | committed |
| `meta.attribute_pairing_value_cache` | LP-01 LP-22 | committed |
| `meta.consumption_layer` | LP-28 | committed |
| `meta.consumption_outbound` | LP-28 LP-32 | committed |
| `meta.consumption_outbound_grain` | LP-28 LP-32 | committed |
| `meta.consumption_promotion` | LP-28 | committed |
| `meta.data_classification_ref` | LP-03 LP-31 | committed |
| `meta.domain_catalog` | LP-43 | committed |
| `meta.domain_value` | LP-03 LP-27 LP-43 | committed |
| `meta.domain_value_source_map` | LP-43 | committed |
| `meta.domain_value_synonym` | LP-43 | committed |
| `meta.domain_value_text` | LP-43 | committed |
| `meta.dq_result` | LP-24 LP-33 | committed |
| `meta.dq_rule_attribute` | LP-24 | committed |
| `meta.dq_rule_catalog` | LP-24 | committed |
| `meta.external_rule_result` | LP-33 | committed |
| `meta.logical_hierarchy` | LP-42 | **PROPOSED — do not apply** |
| `meta.logical_hierarchy_level` | LP-42 | **PROPOSED — do not apply** |
| `meta.observability_signal` | LP-27 | committed |
| `meta.profiling_result` | LP-26 | committed |
| `meta.tenant_workspace` | LP-41 | committed |
| `meta.tenant_workspace_object` | LP-41 | committed |

### Columns added to `meta.attribute_catalog`

+27 columns, +3 constraints.

| Column | Type |
|---|---|
| `data_classification_cd` | varchar(30) |
| `mnpi_flg` | boolean |
| `csi_flg` | boolean |
| `ai_exposure_cd` | varchar(12) |
| `semantic_role_cd` | varchar(20) |
| `semantic_enabled_flg` | boolean |
| `ai_exposed_flg` | boolean |
| `element_class_cd` | varchar(10) |
| `element_class_source_cd` | varchar(20) |
| `domain_mode_cd` | varchar(20) |
| `domain_cd` | varchar(40) |
| `domain_values_jsonb` | jsonb |
| `domain_ref_table_nm` | varchar(120) |
| `domain_ref_code_col` | varchar(32) |
| `domain_ref_desc_col` | varchar(32) |
| `insert_mode_cd` | varchar(20) |
| `update_mode_cd` | varchar(20) |
| `delete_mode_cd` | varchar(20) |
| `immutable_flg` | boolean |
| `null_on_insert_flg` | boolean |
| `attr_source_system_cd` | varchar(50) |
| `effective_start_dt` | date |
| `effective_end_dt` | date |
| `attr_origin_cd` | varchar(20) |
| `promoted_from_report_id` | varchar(64) |
| `derivation_expression_txt` | text |
| `expression_author_cd` | varchar(30) |

### New closed vocabularies (CHECK constraints)

| Column | Allowed values |
|---|---|
| `attribute_access_grant.access_level_cd` | MASKED · NONE · READ |
| `attribute_catalog.ai_exposure_cd` | ALLOWED · BLOCKED · RESTRICTED |
| `attribute_catalog.attr_origin_cd` | PROMOTED_DERIVED · SOURCE_DERIVED |
| `attribute_catalog.domain_mode_cd` | ENUM_LIST · NONE · REF_DOMAIN · YN_FLAG |
| `attribute_catalog.element_class_cd` | CDE · DE |
| `attribute_catalog.element_class_source_cd` | HUMAN · ORGANIC |
| `attribute_catalog.expression_author_cd` | ASSISTANT_DRAFTED_HUMAN_APPROVED · HUMAN |
| `attribute_catalog.semantic_role_cd` | CODE · DATE · DIMENSION · FACT · IDENTIFIER · MEASURE |
| `consumption_layer.default_structure_cd` | DATA_ASSET · TECHNICAL |
| `consumption_outbound.current_env_cd` | DEV · DRAFT · PROD · TEST · UAT |
| `consumption_outbound.structure_cd` | DATA_ASSET · TECHNICAL |
| `consumption_promotion.from_env_cd` | DEV · DRAFT · PROD · TEST · UAT |
| `domain_catalog.lifecycle_status_cd` | ACTIVE · APPROVED · DEPRECATED · DRAFT · RETIRED · REVIEW |
| `domain_catalog.source_type_cd` | ENUMERATED · INLINE · REFERENCE_TABLE |
| `domain_value.ai_exposure_cd` | ALLOWED · BLOCKED · RESTRICTED |
| `domain_value_synonym.lifecycle_status_cd` | ACTIVE · INACTIVE · RETIRED |
| `domain_value_synonym.synonym_type_cd` | ABBREVIATION · BUSINESS · REGULATORY · SOURCE_LABEL |
| `dq_result.result_cd` | FAIL · PASS · WARN |
| `dq_rule_catalog.origin_cd` | AUTHORED · REQUESTED |
| `dq_rule_catalog.rule_scope_cd` | ATTRIBUTE · CONDITIONAL · CROSS_ATTRIBUTE |
| `dq_rule_catalog.rule_status_cd` | ACTIVE · AUTHORING · REQUESTED · RETIRED |
| `external_rule_result.result_type_cd` | DATASET · EDITCHECK · VALUE · VERDICT |
| `observability_signal.severity_cd` | HIGH · INFO · WARN |
| `observability_signal.signal_status_cd` | ACK · OPEN · RESOLVED · TRIAGE |

---

## 5 · Do NOT build — proposed, pending owner approval

| Point | What | Why |
|---|---|---|
| **LP-42** | Logical hierarchies + migration V9 | owner approval pending |
| **LP-44** | Attribute promotion + migration V16 provenance columns | owner approval pending on 5 rulings, and Core must supply the workflow stages |

## 6 · Open items carried forward

- POL-DM-001 (domain-resolve policy) is not yet authored — lands in the LP-14 bundle.
- meta.governance_event is commented out in the DDL; the LP-30 history-vs-audit decision is open.
- meta.data_classification_ref and meta.attribute_text are named in the manifest but created by no migration.
- Attribute-name localization is a recorded gap on LP-05 — English names ship first.