-- =============================================================================
-- Lextr Semantic Layer — INCREMENTAL DDL  v2.3.0 -> v2.11.0
-- For a build that already applied the v2.3.0 baseline (16 tables).
-- Apply IN ORDER, as additive Flyway migrations. Never edit a landed migration.
--
-- Adds 23 tables and 27 columns on meta.attribute_catalog.
-- PROPOSED sections are marked and must NOT be applied without owner approval:
--   · meta.logical_hierarchy / logical_hierarchy_level   (LP-42, migration V9)
--   · attribute promotion provenance columns             (LP-44, migration V16)
-- =============================================================================

-- ---- extensions ----
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ---- new tables ----

-- meta.attribute_pairing_catalog
CREATE TABLE meta.attribute_pairing_catalog (
    id                              bigserial    PRIMARY KEY,
    pairing_cd                      varchar(80)  NOT NULL UNIQUE,
    pairing_nm                      varchar(200) NOT NULL,
    schema_cd                       varchar(30)  NOT NULL,
    object_cd                       varchar(50)  NOT NULL,
    display_attribute_cd            varchar(32)  NOT NULL,        -- what the user sees/filters on
    filter_attribute_cd             varchar(32)  NOT NULL,        -- what SQL actually uses (indexed)
    pairing_type_cd                 varchar(30)  NOT NULL DEFAULT 'LABEL_TO_KEY',
    lookup_strategy_cd              varchar(30)  NOT NULL DEFAULT 'CACHED_LOOKUP',
    lookup_inline_map_jsonb         jsonb,                        -- INLINE_MAP: {display:filter}
    lookup_sql_template_txt         text,                         -- RUNTIME_QUERY template
    lookup_cache_enabled_flg        boolean      NOT NULL DEFAULT true,
    lookup_cache_ttl_seconds_nbr    integer      NOT NULL DEFAULT 3600,
    cardinality_cd                  varchar(20)  NOT NULL DEFAULT 'ONE_TO_ONE',
    is_bidirectional_flg            boolean      NOT NULL DEFAULT false,
    is_cross_engine_flg             boolean      NOT NULL DEFAULT false,  -- POL-CE-002 gate
    filter_attribute_indexed_flg    boolean      NOT NULL DEFAULT true,   -- activation gate
    filter_attribute_index_type_cd  varchar(20),
    performance_gain_pct_est_nbr    integer,
    ai_context_txt                  text,
    client_id                       varchar(40),                  -- NULL = GLOBAL
    lifecycle_status_cd             varchar(30)  NOT NULL DEFAULT 'DRAFT',
    governance_review_status_cd     varchar(30)  NOT NULL DEFAULT 'PENDING',
    version_nbr                     integer      NOT NULL DEFAULT 1,
    created_ts                      timestamptz  NOT NULL DEFAULT now(),
    created_by                      varchar(100) NOT NULL DEFAULT current_user,
    updated_ts                      timestamptz,
    updated_by                      varchar(100),
    CONSTRAINT uq_apc_object_pair UNIQUE (schema_cd, object_cd,
                                          display_attribute_cd, filter_attribute_cd),
    CONSTRAINT fk_apc_object FOREIGN KEY (schema_cd, object_cd)
        REFERENCES meta.object_catalog (schema_cd, object_cd),
    CONSTRAINT ck_apc_type CHECK (pairing_type_cd IN
        ('LABEL_TO_KEY','NAME_TO_CODE','DESCRIPTION_TO_ID','DISPLAY_TO_FILTER')),
    CONSTRAINT ck_apc_strategy CHECK (lookup_strategy_cd IN
        ('CACHED_LOOKUP','INLINE_MAP','RUNTIME_QUERY')),
    CONSTRAINT ck_apc_cardinality CHECK (cardinality_cd IN
        ('ONE_TO_ONE','MANY_TO_ONE','ONE_TO_MANY')),
    CONSTRAINT ck_apc_diff_attrs CHECK (display_attribute_cd <> filter_attribute_cd),
    CONSTRAINT ck_apc_lifecycle CHECK (lifecycle_status_cd IN
        ('DRAFT','REVIEW','APPROVED','ACTIVE','DEPRECATED','RETIRED'))
    -- [ASSUMED-6] The "filter attribute must be indexed" activation gate is enforced in the
    --             service layer (checks pg_indexes), NOT as a DB constraint, consistent with
    --             logic-in-service. Confirm with Standards Doc (P-12).
);

-- meta.attribute_pairing_value_cache
CREATE TABLE meta.attribute_pairing_value_cache (
    id                  bigserial    PRIMARY KEY,
    pairing_cd          varchar(80)  NOT NULL
        REFERENCES meta.attribute_pairing_catalog (pairing_cd) ON DELETE CASCADE,
    client_id           varchar(40)  NOT NULL DEFAULT 'GLOBAL',
    display_value_txt   varchar(500) NOT NULL,
    filter_value_txt    varchar(500) NOT NULL,    -- ONE_TO_MANY: JSON array -> SQL IN (...)
    is_one_to_many_flg  boolean      NOT NULL DEFAULT false,
    hit_count_nbr       bigint       NOT NULL DEFAULT 0,
    last_hit_ts         timestamptz,
    cached_ts           timestamptz  NOT NULL DEFAULT now(),
    expires_ts          timestamptz,
    CONSTRAINT uq_apvc UNIQUE (pairing_cd, display_value_txt, client_id)
);

-- meta.dq_rule_catalog
CREATE TABLE meta.dq_rule_catalog (
    id                      bigserial    PRIMARY KEY,
    dq_rule_cd              varchar(20)  NOT NULL UNIQUE,          -- DQR-####
    schema_cd               varchar(30)  NOT NULL,
    object_cd               varchar(50)  NOT NULL,
    primary_attribute_cd    varchar(32),
    rule_scope_cd           varchar(20)  NOT NULL DEFAULT 'ATTRIBUTE',
    dq_dimension_cd         varchar(20)  NOT NULL,
    threshold_txt           varchar(40),
    plain_english_txt       text         NOT NULL,
    condition_json          jsonb,
    rule_status_cd          varchar(20)  NOT NULL DEFAULT 'REQUESTED',
    origin_cd               varchar(20)  NOT NULL DEFAULT 'REQUESTED',
    justification_txt       text,
    last_run_ts             timestamptz,
    last_result_txt         varchar(60),
    client_id               varchar(40),                          -- NULL = GLOBAL
    created_ts              timestamptz  NOT NULL DEFAULT now(),
    created_by              varchar(100) NOT NULL DEFAULT current_user,
    updated_ts              timestamptz,
    updated_by              varchar(100),
    CONSTRAINT ck_dqr_scope CHECK (rule_scope_cd IN ('ATTRIBUTE','CROSS_ATTRIBUTE','CONDITIONAL')),
    CONSTRAINT ck_dqr_dim   CHECK (dq_dimension_cd IN
        ('Completeness','Validity','Conformity','Consistency','Uniqueness','Timeliness')),
    CONSTRAINT ck_dqr_status CHECK (rule_status_cd IN ('REQUESTED','AUTHORING','ACTIVE','RETIRED')),
    CONSTRAINT ck_dqr_origin CHECK (origin_cd IN ('REQUESTED','AUTHORED'))
    -- [ASSUMED] Accuracy is externally attested and is NOT a rule dimension. Confirm.
);

-- meta.dq_rule_attribute
CREATE TABLE meta.dq_rule_attribute (              -- cross-attribute / conditional membership
    id                  bigserial    PRIMARY KEY,
    dq_rule_cd          varchar(20)  NOT NULL
        REFERENCES meta.dq_rule_catalog (dq_rule_cd) ON DELETE CASCADE,
    attribute_cd        varchar(32)  NOT NULL,
    role_cd             varchar(20)  NOT NULL DEFAULT 'INVOLVED',  -- PRIMARY|INVOLVED|IF|THEN
    created_ts          timestamptz  NOT NULL DEFAULT now(),
    created_by          varchar(100) NOT NULL DEFAULT current_user,
    CONSTRAINT uq_dqra UNIQUE (dq_rule_cd, attribute_cd, role_cd)
);

-- meta.dq_result
CREATE TABLE meta.dq_result (                      -- external engine verdict ingest (append-only)
    id                  bigserial    PRIMARY KEY,
    dq_rule_cd          varchar(20)  NOT NULL
        REFERENCES meta.dq_rule_catalog (dq_rule_cd) ON DELETE CASCADE,
    client_id           varchar(40),
    result_cd           varchar(10)  NOT NULL,                     -- PASS|WARN|FAIL
    value_pct_nbr       numeric(6,3),
    run_ts              timestamptz  NOT NULL DEFAULT now(),
    detail_txt          text,
    CONSTRAINT ck_dqres CHECK (result_cd IN ('PASS','WARN','FAIL'))
);

-- meta.profiling_result
CREATE TABLE meta.profiling_result (
    id                  bigserial    PRIMARY KEY,
    schema_cd           varchar(30)  NOT NULL,
    object_cd           varchar(50)  NOT NULL,
    attribute_cd        varchar(32)  NOT NULL,
    null_pct_nbr        numeric(5,2),
    distinct_pct_nbr    numeric(5,2),
    attribute_role_cd   varchar(30),
    profile_status_cd   varchar(20),
    client_id           varchar(40),
    last_profiled_ts    timestamptz  NOT NULL DEFAULT now(),
    created_ts          timestamptz  NOT NULL DEFAULT now(),
    created_by          varchar(100) NOT NULL DEFAULT current_user
);

-- meta.observability_signal
CREATE TABLE meta.observability_signal (
    id                  bigserial    PRIMARY KEY,
    schema_cd           varchar(30)  NOT NULL,
    object_cd           varchar(50)  NOT NULL,
    signal_type_cd      varchar(30)  NOT NULL,    -- Freshness|Volume|Schema drift|Null-rate spike|Distribution shift
    severity_cd         varchar(10)  NOT NULL DEFAULT 'INFO',
    detail_txt          text,
    signal_status_cd    varchar(12)  NOT NULL DEFAULT 'OPEN',
    client_id           varchar(40),
    detected_ts         timestamptz  NOT NULL DEFAULT now(),
    created_ts          timestamptz  NOT NULL DEFAULT now(),
    created_by          varchar(100) NOT NULL DEFAULT current_user,
    updated_ts          timestamptz,
    updated_by          varchar(100),
    CONSTRAINT ck_obs_sev CHECK (severity_cd IN ('HIGH','WARN','INFO')),
    CONSTRAINT ck_obs_status CHECK (signal_status_cd IN ('OPEN','TRIAGE','ACK','RESOLVED'))
);

-- meta.consumption_layer
CREATE TABLE meta.consumption_layer (
    id                      bigserial    PRIMARY KEY,
    layer_cd                varchar(40)  NOT NULL UNIQUE,
    layer_nm                varchar(120) NOT NULL,
    layer_kind_cd           varchar(30)  NOT NULL,   -- INTERACTIVE_QUERY|BATCH_DATASET|AI_DESCRIPTOR|REPORT_CELLS
    default_structure_cd    varchar(20)  NOT NULL DEFAULT 'DATA_ASSET',
    description_txt         text,
    client_id               varchar(40),
    lifecycle_status_cd     varchar(30)  NOT NULL DEFAULT 'ACTIVE',
    created_ts              timestamptz  NOT NULL DEFAULT now(),
    created_by              varchar(100) NOT NULL DEFAULT current_user,
    updated_ts              timestamptz,
    updated_by              varchar(100),
    CONSTRAINT ck_cl_struct CHECK (default_structure_cd IN ('TECHNICAL','DATA_ASSET'))
);

-- meta.consumption_outbound
CREATE TABLE meta.consumption_outbound (
    id                      bigserial    PRIMARY KEY,
    outbound_cd             varchar(60)  NOT NULL UNIQUE,
    layer_cd                varchar(40)  NOT NULL
        REFERENCES meta.consumption_layer (layer_cd) ON DELETE CASCADE,
    outbound_nm             varchar(160) NOT NULL,
    structure_cd            varchar(20)  NOT NULL,   -- TECHNICAL | DATA_ASSET
    engine_cd               varchar(30),             -- POSTGRES|CLICKHOUSE|NEO4J|SEMANTIC_SERVICE
    current_env_cd          varchar(10)  NOT NULL DEFAULT 'DRAFT',
    version_nbr             integer      NOT NULL DEFAULT 1,
    lifecycle_status_cd     varchar(30)  NOT NULL DEFAULT 'DRAFT',
    created_ts              timestamptz  NOT NULL DEFAULT now(),
    created_by              varchar(100) NOT NULL DEFAULT current_user,
    updated_ts              timestamptz,
    updated_by              varchar(100),
    CONSTRAINT ck_co_struct CHECK (structure_cd IN ('TECHNICAL','DATA_ASSET')),
    CONSTRAINT ck_co_env CHECK (current_env_cd IN ('DRAFT','DEV','TEST','UAT','PROD'))
);

-- meta.consumption_outbound_grain
CREATE TABLE meta.consumption_outbound_grain (       -- aggregation pyramid (logical only)
    id                  bigserial    PRIMARY KEY,
    outbound_cd         varchar(60)  NOT NULL
        REFERENCES meta.consumption_outbound (outbound_cd) ON DELETE CASCADE,
    level_nbr           integer      NOT NULL,
    grain_txt           varchar(120) NOT NULL,
    cardinality_txt     varchar(60),
    logical_bind_txt    varchar(200),                -- logical attribute binding (no physical leakage)
    CONSTRAINT uq_cog UNIQUE (outbound_cd, level_nbr)
);

-- meta.consumption_promotion
CREATE TABLE meta.consumption_promotion (            -- SDLC promotion audit (4 gates)
    id                  bigserial    PRIMARY KEY,
    outbound_cd         varchar(60)  NOT NULL
        REFERENCES meta.consumption_outbound (outbound_cd) ON DELETE CASCADE,
    from_env_cd         varchar(10)  NOT NULL,
    to_env_cd           varchar(10)  NOT NULL,
    gate_results_json   jsonb        NOT NULL,        -- {validation, opa, governance, apply}
    workflow_task_id    bigint,
    version_nbr         integer      NOT NULL,
    promoted_by         varchar(100) NOT NULL DEFAULT current_user,
    promoted_ts         timestamptz  NOT NULL DEFAULT now(),
    CONSTRAINT ck_cp_env CHECK (from_env_cd IN ('DRAFT','DEV','TEST','UAT','PROD')
                            AND to_env_cd   IN ('DRAFT','DEV','TEST','UAT','PROD'))
);

-- meta.data_classification_ref
CREATE TABLE meta.data_classification_ref (
    classification_cd   varchar(30)  PRIMARY KEY,            -- PUBLIC|INTERNAL|CONFIDENTIAL|RESTRICTED
    classification_nm   varchar(60)  NOT NULL,
    rank_nbr            integer      NOT NULL,               -- ordinal sensitivity (higher = stricter)
    description_txt     text,
    created_ts          timestamptz  NOT NULL DEFAULT now(),
    created_by          varchar(100) NOT NULL DEFAULT current_user
);

-- meta.attribute_access_grant
CREATE TABLE meta.attribute_access_grant (
    id                  bigserial    PRIMARY KEY,
    schema_cd           varchar(30)  NOT NULL,
    object_cd           varchar(50)  NOT NULL,
    attribute_cd        varchar(32)  NOT NULL,
    grantee_role_cd     varchar(40)  NOT NULL,               -- role or purpose
    access_level_cd     varchar(12)  NOT NULL DEFAULT 'READ', -- NONE|MASKED|READ
    client_id           varchar(40),                          -- NULL = GLOBAL
    created_ts          timestamptz  NOT NULL DEFAULT now(),
    created_by          varchar(100) NOT NULL DEFAULT current_user,
    CONSTRAINT ck_aag_level CHECK (access_level_cd IN ('NONE','MASKED','READ')),
    CONSTRAINT uq_aag UNIQUE (schema_cd, object_cd, attribute_cd, grantee_role_cd, client_id)
);

-- meta.external_rule_result
CREATE TABLE meta.external_rule_result (
    id                  bigserial    PRIMARY KEY,
    rule_ref            varchar(120) NOT NULL,             -- engine-controlled rule identifier
    outbound_cd         varchar(40),                       -- consumption outbound it ran on (LP-28)
    run_ts              timestamptz  NOT NULL DEFAULT now(),
    result_type_cd      varchar(20)  NOT NULL,             -- VERDICT|VALUE|EDITCHECK|DATASET
    verdict_flg         boolean,
    value_num           numeric(20,6),
    value_txt           text,
    row_count_nbr       integer,
    violation_count_nbr integer,
    engine_cd           varchar(40),                       -- which rules engine posted
    client_id           varchar(40),                       -- NULL = GLOBAL
    created_ts          timestamptz  NOT NULL DEFAULT now(),
    created_by          varchar(100) NOT NULL DEFAULT current_user,
    CONSTRAINT ck_err_type CHECK (result_type_cd IN ('VERDICT','VALUE','EDITCHECK','DATASET'))
);

-- meta.tenant_workspace
CREATE TABLE meta.tenant_workspace (
    workspace_cd         varchar(40)  PRIMARY KEY,
    workspace_nm         varchar(120) NOT NULL,
    description_txt      text,
    client_id            varchar(40),                      -- NULL = GLOBAL
    lifecycle_status_cd  varchar(30)  NOT NULL DEFAULT 'ACTIVE',
    created_ts           timestamptz  NOT NULL DEFAULT now(),
    created_by           varchar(100) NOT NULL DEFAULT current_user,
    updated_ts           timestamptz,
    updated_by           varchar(100),
    CONSTRAINT ck_tw_lifecycle CHECK (lifecycle_status_cd IN
        ('DRAFT','REVIEW','APPROVED','ACTIVE','DEPRECATED','RETIRED'))
);

-- meta.tenant_workspace_object
CREATE TABLE meta.tenant_workspace_object (
    id                  bigserial    PRIMARY KEY,
    workspace_cd        varchar(40)  NOT NULL
        REFERENCES meta.tenant_workspace (workspace_cd) ON DELETE CASCADE,
    schema_cd           varchar(30)  NOT NULL,
    object_cd           varchar(50)  NOT NULL,
    added_ts            timestamptz  NOT NULL DEFAULT now(),
    added_by            varchar(100) NOT NULL DEFAULT current_user,
    CONSTRAINT uq_two UNIQUE (workspace_cd, schema_cd, object_cd),
    CONSTRAINT fk_two_object FOREIGN KEY (schema_cd, object_cd)
        REFERENCES meta.object_catalog (schema_cd, object_cd) ON DELETE CASCADE
);

-- meta.logical_hierarchy   *** PROPOSED — owner approval required ***
-- CREATE TABLE meta.logical_hierarchy (
--     hierarchy_cd         varchar(40)  PRIMARY KEY,
--     hierarchy_nm         varchar(120) NOT NULL,
--     hierarchy_type_cd    varchar(30),                      -- ENTITY|PERIOD|ORG|PRODUCT|...
--     root_attribute_cd    varchar(32),                      -- logical attribute (no physical leak)
--     description_txt      text,
--     client_id            varchar(40),                      -- NULL = GLOBAL
--     lifecycle_status_cd  varchar(30)  NOT NULL DEFAULT 'ACTIVE',
--     created_ts           timestamptz  NOT NULL DEFAULT now(),
--     created_by           varchar(100) NOT NULL DEFAULT current_user,
--     updated_ts           timestamptz,
--     updated_by           varchar(100),
--     CONSTRAINT ck_lh_lifecycle CHECK (lifecycle_status_cd IN
--         ('DRAFT','REVIEW','APPROVED','ACTIVE','DEPRECATED','RETIRED'))
-- );

-- meta.logical_hierarchy_level   *** PROPOSED — owner approval required ***
-- CREATE TABLE meta.logical_hierarchy_level (
--     id                  bigserial    PRIMARY KEY,
--     hierarchy_cd        varchar(40)  NOT NULL
--         REFERENCES meta.logical_hierarchy (hierarchy_cd) ON DELETE CASCADE,
--     level_nbr           integer      NOT NULL,
--     level_nm            varchar(120) NOT NULL,
--     level_attribute_cd  varchar(32),                       -- logical attribute only
--     parent_level_nbr    integer,
--     CONSTRAINT uq_lhl UNIQUE (hierarchy_cd, level_nbr)
-- );

-- meta.domain_catalog
CREATE TABLE meta.domain_catalog (
    domain_cd                    varchar(40)  PRIMARY KEY,
    domain_nm                    varchar(120) NOT NULL,
    domain_desc                  text,
    source_type_cd               varchar(20)  NOT NULL DEFAULT 'ENUMERATED', -- INLINE|ENUMERATED|REFERENCE_TABLE
    ref_table_nm                 varchar(120),                    -- REFERENCE_TABLE: table that holds the values
    ref_code_col                 varchar(32),                     -- which column is the code
    ref_desc_col                 varchar(32),                     -- which column is the description
    semantic_group_cd            varchar(50),
    ai_business_context_txt      text,                            -- AI grounding at domain level
    ai_governance_context_txt    text,
    client_id                    varchar(40),                     -- NULL = GLOBAL
    lifecycle_status_cd          varchar(30)  NOT NULL DEFAULT 'ACTIVE',
    governance_review_status_cd  varchar(30)  NOT NULL DEFAULT 'DRAFT',
    last_certified_ts            timestamptz,
    last_certified_by            varchar(100),
    next_review_due_dt           date,
    created_ts                   timestamptz  NOT NULL DEFAULT now(),
    created_by                   varchar(100) NOT NULL DEFAULT current_user,
    updated_ts                   timestamptz,
    updated_by                   varchar(100),
    CONSTRAINT ck_dc_source CHECK (source_type_cd IN ('INLINE','ENUMERATED','REFERENCE_TABLE')),
    CONSTRAINT ck_dc_life   CHECK (lifecycle_status_cd IN ('DRAFT','REVIEW','APPROVED','ACTIVE','DEPRECATED','RETIRED'))
);

-- meta.domain_value
CREATE TABLE meta.domain_value (
    id                      bigserial    PRIMARY KEY,
    domain_cd               varchar(40)  NOT NULL
        REFERENCES meta.domain_catalog (domain_cd) ON DELETE CASCADE,
    value_cd                varchar(100) NOT NULL,
    value_desc              text,
    sort_order_nbr          integer,
    active_flg              boolean      NOT NULL DEFAULT true,
    ai_context_txt          text,                                 -- per-value AI grounding
    regulatory_ref_txt      varchar(100),                         -- MDRM / schedule-line mapping
    effective_start_dt      date,
    effective_end_dt        date,
    lifecycle_status_cd     varchar(30)  NOT NULL DEFAULT 'ACTIVE', -- ACTIVE|INACTIVE_IN_SOURCE|ANTICIPATED|RETIRED
    last_seen_in_source_ts  timestamptz,
    certified_by            varchar(100),
    certified_ts            timestamptz,
    created_ts              timestamptz  NOT NULL DEFAULT now(),
    created_by              varchar(100) NOT NULL DEFAULT current_user,
    CONSTRAINT uq_dv UNIQUE (domain_cd, value_cd),
    CONSTRAINT ck_dv_life CHECK (lifecycle_status_cd IN
        ('ACTIVE','INACTIVE_IN_SOURCE','ANTICIPATED','RETIRED'))
);

-- meta.domain_value_synonym
CREATE TABLE meta.domain_value_synonym (
    id                  bigserial    PRIMARY KEY,
    domain_cd           varchar(40)  NOT NULL,
    value_cd            varchar(100) NOT NULL,
    synonym_txt         varchar(200) NOT NULL,   -- normalised on write: lower, trim, collapse whitespace
    synonym_type_cd     varchar(20)  NOT NULL,   -- BUSINESS|REGULATORY|SOURCE_LABEL|ABBREVIATION
    locale_cd           varchar(10)  NOT NULL DEFAULT 'en-US',
    client_id           varchar(40),             -- NULL = GLOBAL; tenants may add their own vocabulary
    override_global_flg boolean      NOT NULL DEFAULT false,  -- tenant row intentionally overrides a GLOBAL mapping (tracked exception)
    effective_start_dt  date,
    effective_end_dt    date,
    lifecycle_status_cd varchar(30)  NOT NULL DEFAULT 'ACTIVE',
    certified_by        varchar(100),            -- set on four-eyes approval (LP-12 SYNONYM_AUTHOR)
    certified_ts        timestamptz,
    created_ts          timestamptz  NOT NULL DEFAULT now(),
    created_by          varchar(100) NOT NULL DEFAULT current_user,
    CONSTRAINT fk_dvs FOREIGN KEY (domain_cd, value_cd)
        REFERENCES meta.domain_value (domain_cd, value_cd) ON DELETE CASCADE,
    CONSTRAINT ck_dvs_type CHECK (synonym_type_cd IN ('BUSINESS','REGULATORY','SOURCE_LABEL','ABBREVIATION')),
    CONSTRAINT ck_dvs_life CHECK (lifecycle_status_cd IN ('ACTIVE','INACTIVE','RETIRED')),
    CONSTRAINT uq_dvs UNIQUE NULLS NOT DISTINCT (domain_cd, synonym_txt, locale_cd, client_id)
);

-- meta.domain_value_source_map
CREATE TABLE meta.domain_value_source_map (
    id                bigserial    PRIMARY KEY,
    domain_cd         varchar(40)  NOT NULL,
    value_cd          varchar(100) NOT NULL,     -- the CANONICAL value
    source_system_cd  varchar(50)  NOT NULL,
    source_value_cd   varchar(100) NOT NULL,     -- what that system actually stores
    client_id         varchar(40),
    effective_start_dt date,
    effective_end_dt   date,
    created_ts        timestamptz  NOT NULL DEFAULT now(),
    created_by        varchar(100) NOT NULL DEFAULT current_user,
    CONSTRAINT fk_dvsm FOREIGN KEY (domain_cd, value_cd)
        REFERENCES meta.domain_value (domain_cd, value_cd) ON DELETE CASCADE,
    CONSTRAINT uq_dvsm UNIQUE NULLS NOT DISTINCT (domain_cd, source_system_cd, source_value_cd, client_id)
);

-- meta.domain_value_text
CREATE TABLE meta.domain_value_text (
    id              bigserial    PRIMARY KEY,
    domain_cd       varchar(40)  NOT NULL,
    value_cd        varchar(100) NOT NULL,
    locale_cd       varchar(10)  NOT NULL DEFAULT 'en-US',
    value_desc      text,
    ai_context_txt  text,
    created_ts      timestamptz  NOT NULL DEFAULT now(),
    created_by      varchar(100) NOT NULL DEFAULT current_user,
    CONSTRAINT fk_dvt FOREIGN KEY (domain_cd, value_cd)
        REFERENCES meta.domain_value (domain_cd, value_cd) ON DELETE CASCADE,
    CONSTRAINT uq_dvt UNIQUE (domain_cd, value_cd, locale_cd)
);

-- ---- indexes for the new tables ----
CREATE INDEX ix_apc_object  ON meta.attribute_pairing_catalog (schema_cd, object_cd);
CREATE INDEX ix_apc_display ON meta.attribute_pairing_catalog (display_attribute_cd);
CREATE INDEX ix_apc_client  ON meta.attribute_pairing_catalog (client_id);
CREATE INDEX ix_apvc_lookup ON meta.attribute_pairing_value_cache
    (pairing_cd, client_id, display_value_txt);
CREATE INDEX ix_dqr_object ON meta.dq_rule_catalog (schema_cd, object_cd);
CREATE INDEX ix_dqr_client ON meta.dq_rule_catalog (client_id);
CREATE INDEX ix_dqr_status ON meta.dq_rule_catalog (rule_status_cd);
CREATE INDEX ix_dqres_rule ON meta.dq_result (dq_rule_cd, run_ts DESC);
CREATE INDEX ix_prof_object ON meta.profiling_result (schema_cd, object_cd);
CREATE INDEX ix_obs_object ON meta.observability_signal (schema_cd, object_cd, detected_ts DESC);
CREATE INDEX ix_co_layer ON meta.consumption_outbound (layer_cd);
CREATE INDEX ix_cp_outbound ON meta.consumption_promotion (outbound_cd, promoted_ts DESC);
CREATE INDEX ix_aag_attr ON meta.attribute_access_grant (schema_cd, object_cd, attribute_cd);
CREATE INDEX ix_err_rule ON meta.external_rule_result (rule_ref, run_ts);
CREATE INDEX ix_err_outbound ON meta.external_rule_result (outbound_cd);
CREATE INDEX ix_tw_client ON meta.tenant_workspace (client_id);
CREATE INDEX ix_two_ws ON meta.tenant_workspace_object (workspace_cd);
CREATE INDEX ix_lh_client ON meta.logical_hierarchy (client_id);
CREATE INDEX ix_lhl_hierarchy ON meta.logical_hierarchy_level (hierarchy_cd);
CREATE INDEX ix_dc_client ON meta.domain_catalog (client_id);
CREATE INDEX ix_dv_domain ON meta.domain_value (domain_cd);
CREATE INDEX ix_dvs_value  ON meta.domain_value_synonym (domain_cd, value_cd);
CREATE INDEX ix_dvs_search ON meta.domain_value_synonym USING gin (synonym_txt gin_trgm_ops);
CREATE INDEX ix_dvsm_value ON meta.domain_value_source_map (domain_cd, value_cd);
CREATE INDEX ix_dvt ON meta.domain_value_text (domain_cd, value_cd);

-- ---- new columns on the existing meta.attribute_catalog ----
-- 27 columns: classification, exposure, semantic role, CDE class, the domain block,
-- operational behaviour, effective dating. The last 4 are PROPOSED (LP-44).

ALTER TABLE meta.attribute_catalog
    ADD COLUMN data_classification_cd varchar(30)
        REFERENCES meta.data_classification_ref (classification_cd),
    ADD COLUMN mnpi_flg        boolean NOT NULL DEFAULT false,
    ADD COLUMN csi_flg         boolean NOT NULL DEFAULT false,
    ADD COLUMN ai_exposure_cd  varchar(12) NOT NULL DEFAULT 'ALLOWED',   -- ALLOWED|RESTRICTED|BLOCKED
    ADD CONSTRAINT ck_attr_ai_exposure CHECK (ai_exposure_cd IN ('ALLOWED','RESTRICTED','BLOCKED'));

ALTER TABLE meta.attribute_catalog
    ADD COLUMN semantic_role_cd        varchar(20),   -- CODE|DIMENSION|MEASURE|IDENTIFIER|DATE|FACT
    ADD COLUMN semantic_enabled_flg    boolean NOT NULL DEFAULT false,  -- exposed to the semantic layer
    ADD COLUMN ai_exposed_flg          boolean NOT NULL DEFAULT false,  -- exposed to AI / Lexie
    ADD COLUMN element_class_cd        varchar(10),   -- CDE (regulatory) | DE (analytical/operational)
    ADD COLUMN element_class_source_cd varchar(20),   -- ORGANIC | HUMAN
    ADD COLUMN domain_mode_cd          varchar(20) NOT NULL DEFAULT 'NONE', -- NONE|YN_FLAG|ENUM_LIST|REF_DOMAIN
    ADD COLUMN domain_cd               varchar(40),   -- REF_DOMAIN -> domain_catalog
    ADD COLUMN domain_values_jsonb     jsonb,         -- ENUM_LIST inline [{value_cd,value_desc,sort_order_nbr,active_flg}]
    ADD COLUMN domain_ref_table_nm     varchar(120),  -- REF_DOMAIN table-backed override
    ADD COLUMN domain_ref_code_col     varchar(32),
    ADD COLUMN domain_ref_desc_col     varchar(32),
    ADD COLUMN insert_mode_cd          varchar(20),   -- ETL_BATCH|API|MANUAL|COMPUTED
    ADD COLUMN update_mode_cd          varchar(20),   -- IMMUTABLE|MUTABLE|APPEND_ONLY
    ADD COLUMN delete_mode_cd          varchar(20),   -- N/A|SOFT|HARD
    ADD COLUMN immutable_flg           boolean NOT NULL DEFAULT false,
    ADD COLUMN null_on_insert_flg      boolean NOT NULL DEFAULT false,
    ADD COLUMN attr_source_system_cd   varchar(50),   -- lineage: originating source system
    ADD COLUMN effective_start_dt      date,
    ADD COLUMN effective_end_dt        date;

ALTER TABLE meta.attribute_catalog
    ADD CONSTRAINT ck_ac_domain_mode CHECK (domain_mode_cd IN ('NONE','YN_FLAG','ENUM_LIST','REF_DOMAIN')),
    ADD CONSTRAINT ck_ac_elem_class  CHECK (element_class_cd IS NULL OR element_class_cd IN ('CDE','DE')),
    ADD CONSTRAINT ck_ac_elem_src    CHECK (element_class_source_cd IS NULL OR element_class_source_cd IN ('ORGANIC','HUMAN')),
    ADD CONSTRAINT ck_ac_sem_role    CHECK (semantic_role_cd IS NULL OR semantic_role_cd IN
        ('CODE','DIMENSION','MEASURE','IDENTIFIER','DATE','FACT')),
    ADD CONSTRAINT fk_ac_domain FOREIGN KEY (domain_cd) REFERENCES meta.domain_catalog (domain_cd);

ALTER TABLE meta.attribute_catalog DROP CONSTRAINT ck_ac_domain_mode;

ALTER TABLE meta.attribute_catalog ADD CONSTRAINT ck_ac_domain_mode
    CHECK (domain_mode_cd IN ('NONE','ENUM_LIST','REF_DOMAIN'));

-- *** PROPOSED (LP-44) — do not apply without owner approval ***
-- ALTER TABLE meta.attribute_catalog
--     ADD COLUMN attr_origin_cd          varchar(20) NOT NULL DEFAULT 'SOURCE_DERIVED', -- SOURCE_DERIVED|PROMOTED_DERIVED
--     ADD COLUMN promoted_from_report_id varchar(64),                                   -- the report a promoted attr came from
--     ADD COLUMN derivation_expression_txt text,                                        -- the surviving expression
--     ADD COLUMN expression_author_cd    varchar(30);

-- *** PROPOSED (LP-44) — do not apply without owner approval ***
-- ALTER TABLE meta.attribute_catalog
--     ADD CONSTRAINT ck_ac_attr_origin CHECK (attr_origin_cd IN ('SOURCE_DERIVED','PROMOTED_DERIVED')),
--     ADD CONSTRAINT ck_ac_expr_author CHECK (expression_author_cd IS NULL OR expression_author_cd IN ('HUMAN','ASSISTANT_DRAFTED_HUMAN_APPROVED'));

-- ---- governance presets (DB-driven thresholds) ----
INSERT INTO governance.policy_preset
  (policy_cd, policy_nm, policy_scope_cd, default_value_txt, data_type_cd,
   is_overrideable_flg, override_requires_approval_flg) VALUES
 ('GOV-FL-001','Minimum review frequency (floor, days)','FILTER_LOOKUP','90','INTEGER',true,true),
 ('GOV-FL-002','Auto-expire window (days)','FILTER_LOOKUP','180','INTEGER',true,true),
 ('GOV-FL-003','Grace period (days)','FILTER_LOOKUP','14','INTEGER',true,true),
 ('GOV-FL-004','Anticipated values require approval','FILTER_LOOKUP','true','BOOLEAN',false,false),
 ('GOV-FL-005','Maximum values per lookup','FILTER_LOOKUP','500','INTEGER',true,true),
 ('GOV-FL-006','HAND_TYPED review factor','FILTER_LOOKUP','0.5','DECIMAL',false,false)
ON CONFLICT (policy_cd) DO NOTHING;
INSERT INTO governance.policy_preset
  (policy_cd, policy_nm, policy_scope_cd, default_value_txt, data_type_cd, is_overrideable_flg, override_requires_approval_flg)
VALUES ('DOMAIN_INLINE_MAX_CARDINALITY','Max inline (ENUM_LIST) domain cardinality','DOMAIN','100','INTEGER',true,true)
ON CONFLICT (policy_cd) DO NOTHING;
INSERT INTO governance.policy_preset
  (policy_cd, policy_nm, policy_scope_cd, default_value_txt, data_type_cd, is_overrideable_flg, override_requires_approval_flg)
VALUES ('DOMAIN_MAX_ENUMERATE_CARDINALITY','Max values a full-set domain resolve may return before it must refuse and direct to search','DOMAIN','1000','INTEGER',true,true)
ON CONFLICT (policy_cd) DO NOTHING;
INSERT INTO governance.policy_preset
  (policy_cd, policy_nm, policy_scope_cd, default_value_txt, data_type_cd, is_overrideable_flg, override_requires_approval_flg)
VALUES ('DOMAIN_RESOLVE_TTL_SECONDS','Max seconds a consumer may cache a latest domain resolve;
